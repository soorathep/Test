import {stringifyStudy} from './study-state.js';
import * as e from './stability.js';
import {palette as c} from './palette.js';
const $=id=>document.getElementById(id),fmt=(v,n=4)=>v==null?'N/A':v!==0&&Math.abs(v)<1e-4?v.toExponential(2):Number(v).toFixed(n);
let result,curve,map=e.phaseMap();
const trace=(x,y,name,color,dash='solid',mode='lines')=>({x,y,name,mode,line:{color,width:2,dash},marker:{color,size:8},connectgaps:false});
async function chart(){
 if(!result)return;const {A,z,binodal:b}=result,asym=typeof A==='object',level=asym?A.A12:A,kind=$('lle-chart').value;let traces=[],yTitle,note,xTitle='Mole fraction of component 1 · x₁',shapes=[];
 if(kind==='gibbs'){
  traces=[trace(curve.map(r=>r.x),curve.map(r=>r.ideal),'Ideal reference',c.teal),trace(curve.map(r=>r.x),curve.map(r=>r.g),'Homogeneous liquid',c.amber),trace(curve.map(r=>r.x),curve.map(r=>r.hull),'Equilibrium convex envelope',c.graphite,'dash')];
  for(const [i,gap] of result.gaps.entries())traces.push(trace([gap.xAlpha,gap.xBeta],[gap.gAlpha,gap.gBeta],`Common tangent / gap ${i+1}`,c.graphite,'solid','lines+markers'));shapes=e.spinodals(A).roots.map(x=>({type:'line',xref:'x',yref:'paper',x0:x,x1:x,y0:0,y1:1,line:{color:c.graphite,width:1.5,dash:'dot'}}));
  traces.push(trace([z],[result.homogeneousG],'Homogeneous feed',c.amber,'solid','markers'));traces.at(-1).marker.symbol='diamond';
  if(result.phase==='two liquids')traces.push(trace([z],[result.equilibriumG],'Equilibrated feed',c.graphite,'solid','markers'));
  yTitle='Mixing Gibbs energy / RT';note='The common tangent is a physical two-liquid mixture only between its contact points. Dotted vertical lines mark spinodals. The equilibrium envelope follows the original curve outside the miscibility gap.';
 }else if(kind==='map'){
  traces=[trace(map.map(r=>r.xAlpha),map.map(r=>r.A),'Binodal',c.amber),trace(map.map(r=>r.xBeta),map.map(r=>r.A),'Binodal (rich branch)',c.amber),trace(map.map(r=>r.spinodalAlpha),map.map(r=>r.A),'Spinodal',c.graphite,'dash'),trace(map.map(r=>r.spinodalBeta),map.map(r=>r.A),'Spinodal (rich branch)',c.graphite,'dash'),trace([.5],[2],'Critical point',c.graphite,'solid','markers'),trace([z],[level],'Current feed',c.teal,'solid','markers')];
  shapes=[{type:'line',x0:0,x1:1,y0:level,y1:level,line:{color:c.teal,width:1.5,dash:'dot'}}];if(asym)traces=traces.filter(t=>t.name!=='Critical point');yTitle=asym?`A₁₂ (A₂₁ = ${A.A21} fixed)`:'Interaction parameter A';note='Inside the binodal: two liquids at equilibrium. Between binodal and spinodal: metastable homogeneous feed. Inside the spinodal: unstable homogeneous feed. Vertical axis is an interaction parameter, not temperature. With two parameters, this is a slice at the selected fixed A₂₁; blank regions have no resolved miscibility gap.';
 }else if(kind==='tpd'){
  const t=result.tpd;traces=[trace(t.points.map(p=>p.x),t.points.map(p=>p.tpd),'TPD relative to homogeneous feed',c.amber)];if(t.minimum!==null)traces.push(trace([t.w],[t.minimum],'Global minimum',c.graphite,'solid','markers'));yTitle='TPD / RT';xTitle='Trial liquid composition · w₁';note=t.status+' The minimum searches stationary points, not just plotted samples.';
 }else{
  traces=[trace(curve.filter(r=>r.curvature!==null).map(r=>r.x),curve.filter(r=>r.curvature!==null).map(r=>r.curvature),'Homogeneous curvature',c.amber)];if(result.curvature!==null)traces.push(trace([z],[result.curvature],'Current feed',c.teal,'solid','markers'));
  yTitle='g″(x₁)';note='Negative curvature indicates local instability. Positive curvature alone cannot rule out metastability. Curvature diverges at pure endpoints; those endpoints are omitted. The vertical display is clipped to show the central region.';
 }
 await Plotly.react('lle-plot',traces,{margin:{l:65,r:16,t:18,b:55},font:{family:'Archivo, sans-serif',size:12,color:c.graphite},paper_bgcolor:'transparent',plot_bgcolor:'transparent',showlegend:false,xaxis:{title:{text:xTitle},range:[0,1],zeroline:false},yaxis:{title:{text:yTitle},zerolinecolor:c.graphite,...(kind==='curvature'?{range:[-9,20]}:kind==='map'?{range:[0,6.1]}:{})},shapes,hovermode:'closest'},{responsive:true,displayModeBar:false});
 $('lle-legend').replaceChildren(...traces.filter(t=>!t.name.includes('branch')).map(t=>{const span=document.createElement('span'),i=document.createElement('i');i.style.borderColor=t.line.color;i.style.borderTopStyle=t.line.dash==='solid'?'solid':'dashed';if(t.mode==='markers')i.className='legend-marker';span.append(i,document.createTextNode(t.name));return span;}));$('lle-chart-note').textContent=note;
}
function run(){
 try{
  const model=$('lle-model').value,asym=model==='asymmetric',nrtl=model==='nrtl';
  $('lle-one-control').hidden=model!=='symmetric';$('lle-two-control').hidden=!asym;$('lle-nrtl-control').hidden=!nrtl;
  const keys=nrtl?['tau12','tau21','alpha']:asym?['A12','A21']:['A'];
  for(const key of [...keys,'z'])if($(`lle-${key}`).value.trim()==='')throw new Error('Enter both model parameters and the feed composition.');
  const values=Object.fromEntries(keys.map(key=>[key,Number($(`lle-${key}`).value)])),A=nrtl?{model:'nrtl',...values}:asym?values:values.A,z=Number($('lle-z').value);
  result=e.equilibrium(A,z);curve=e.gibbsCurve(A);map=nrtl?null:e.phaseMap(asym?A.A21:null);
  $('lle-chart').querySelector('option[value="map"]').disabled=nrtl;if(nrtl&&$('lle-chart').value==='map')$('lle-chart').value='gibbs';
  for(const key of keys)$(`lle-${key}-range`).value=values[key];$('lle-z-range').value=z;$('lle-error').hidden=true;$('lle-results').hidden=false;$('lle-export').disabled=false;
  const r=result,b=r.binodal;$('lle-phase').textContent=r.phase;$('lle-state').textContent=r.state;$('lle-curvature').textContent=r.curvature===null?'Pure endpoint: curvature diverges':`g″(z₁) = ${fmt(r.curvature)}`;$('lle-beta').textContent=fmt(r.fractionBeta);$('lle-gain').textContent=fmt(r.gain,6);
  const explanation={stable:'The homogeneous feed is on the convex envelope. Its equilibrium state is one liquid at the feed composition.',metastable:'The homogeneous feed has positive curvature, but a finite split reaches a lower Gibbs energy on the common tangent. The equilibrium state is two liquids.',unstable:'The homogeneous feed has negative curvature. Small composition fluctuations lower Gibbs energy; the final bulk equilibrium is two liquids on the common tangent.',critical:'The two coexistence compositions merge at the critical composition. This is one critical liquid, not two distinct phases; a lever-rule fraction is not defined.','spinodal boundary':'The homogeneous feed has zero local curvature at the spinodal. The common tangent still gives a lower-energy two-liquid equilibrium.','binodal boundary':'The feed lies at a coexistence boundary. An infinitesimal amount of the conjugate liquid can appear; the present liquid remains at the feed composition.'};
  $('lle-interpretation').textContent=explanation[r.state];$('lle-alpha-x').textContent=fmt(b?.xAlpha,b&&b.xBeta-b.xAlpha<.001?8:4);$('lle-beta-x').textContent=fmt(b?.xBeta,b&&b.xBeta-b.xAlpha<.001?8:4);
  $('lle-composition-note').textContent=b?(r.phase==='two liquids'?'Both binodal compositions are present. Changing z₁ at fixed parameters changes the fractions, not these compositions.':'These are binodal boundary compositions at these parameters. Both are not present for the current feed.'):'No resolved miscibility gap for these parameters.';if(r.gaps.length>1)$('lle-composition-note').textContent+=` There are ${r.gaps.length} separate gaps; all are shown on the Gibbs plot.`;
  $('lle-lever').replaceChildren();if(r.phase==='two liquids'){for(const [name,fraction,color] of [['α',r.fractionAlpha,c.teal],['β',r.fractionBeta,c.amber]]){const span=document.createElement('span');span.style.width=`${100*fraction}%`;span.style.background=color;span.title=`${name}: ${fmt(fraction)}`;$('lle-lever').append(span);}}
  $('lle-fractions').textContent=r.phase==='two liquids'?`Lever rule: fᵅ = ${fmt(r.fractionAlpha)}, fᵝ = ${fmt(r.fractionBeta)}. α: component-1-poor; β: component-1-rich.`:`One liquid: x₁ = z₁ = ${fmt(z)}. No two-phase fraction is assigned.`;
  const check=(name,value)=>`<div class="check-row"><span>${name}</span><strong>${value}</strong></div>`;
  $('lle-checks').innerHTML=check('Minimum feed TPD',fmt(r.tpd.minimum,7))+check('Common-tangent slope',fmt(b?.slope,6))+check('Component balance residual',r.balanceResidual.toExponential(2))+check('Chemical-potential equality between present phases',r.chemicalPotentialResidual===null?'N/A':r.chemicalPotentialResidual.toExponential(2))+check('Common-tangent residual (binodal construction)',b?b.tangentResidual.toExponential(2):'N/A')+check('Homogeneous g(z₁)',fmt(r.homogeneousG,6))+check('Equilibrium g(z₁)',fmt(r.equilibriumG,6))+'<p>Dimensionless chemical potentials relative to pure-liquid standards are ln xᵢ + ln γᵢ, evaluated with the selected liquid model. Their equality and the material balance independently check the two-liquid split. Stable single-liquid feeds do not have a second-phase equality to test.</p>';
  $('lle-table').innerHTML='<table><thead><tr><th>x₁</th><th>Homogeneous g</th><th>Convex envelope g</th><th>g″</th></tr></thead><tbody>'+curve.filter((_,i)=>i%10===0).map(v=>`<tr><td>${fmt(v.x)}</td><td>${fmt(v.g,6)}</td><td>${fmt(v.hull,6)}</td><td>${fmt(v.curvature)}</td></tr>`).join('')+'</tbody></table>';
  $('lle-tpd-summary').textContent=`${r.tpd.status} Minimum = ${fmt(r.tpd.minimum,7)} at trial w₁ = ${fmt(r.tpd.w,6)}.`;chart();
 }catch(err){result=null;curve=null;$('lle-error').textContent=err.message;$('lle-error').hidden=false;$('lle-results').hidden=true;$('lle-export').disabled=true;$('lle-checks').textContent='No valid calculation.';$('lle-table').replaceChildren();$('lle-tpd-summary').textContent='No valid calculation.';}
}
for(const key of ['A','A12','A21','tau12','tau21','alpha','z']){$(`lle-${key}-range`).addEventListener('input',()=>{$(`lle-${key}`).value=$(`lle-${key}-range`).value;run();});}
$('lle-model').addEventListener('change',run);
$('lle-run').addEventListener('click',run);$('lle-chart').addEventListener('change',chart);
$('lle-reset').addEventListener('click',()=>{$('lle-model').value='symmetric';$('lle-A').value=3;$('lle-z').value=.35;$('lle-preset').value='';run();});
$('lle-preset').addEventListener('change',()=>{const v={stable:[3,.02],meta:[3,.12],unstable:[3,.5],critical:[2,.5],ideal:[0,.5]}[$('lle-preset').value];if(v){$('lle-model').value='symmetric';$('lle-A').value=v[0];$('lle-z').value=v[1];run();}});
$('lle-export').addEventListener('click',()=>{if(!result)return;const data={version:e.STABILITY_VERSION,result,curve,phaseMap:map,prediction:$('lle-prediction').value,reflection:$('lle-reflection').value},url=URL.createObjectURL(new Blob([stringifyStudy(data,null,2)],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download='liquid-stability-study.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
// Lab 05 passes dimensionless NRTL parameters at its selected fixed temperature.
const query=new URLSearchParams(location.search);
if(query.get('model')==='nrtl'){
 $('lle-model').value='nrtl';
 for(const key of ['tau12','tau21','alpha','z'])if(query.has(key))$(`lle-${key}`).value=query.get(key);
}
run();
