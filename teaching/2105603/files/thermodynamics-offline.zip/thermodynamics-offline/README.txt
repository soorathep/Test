2105603 ADVANCED THERMODYNAMICS: OFFLINE STUDENT PACKAGE

Extract the ZIP before use. Requires a browser and an installed Python 3.
Run serve.py with the ABSOLUTE PATH to your Python interpreter, for example:
  ~/.venvs/research/bin/python /absolute/path/thermodynamics-offline/serve.py
Use your own installed interpreter path on Windows or Linux.
The server uses only the standard library and listens on 127.0.0.1.
It prints a local URL and opens your browser. Ctrl+C stops the server.
Opening HTML through file:// will not reliably run data fetches or workers.

Includes all 13 labs, seven slide decks, reference decks, assessment sets,
seven slide PDFs, six pre-class reading PDFs and available notebooks. Reference decks use HTML to avoid
duplicating their large figures in PDFs. No private instructor key or student records.
Student-facing worked solutions are included; attempt the worksheet first.
External literature and other group website pages need internet.
The supplemental Week 1 Lab 01 walkthrough is available online or as a separate
MP4 download: https://www.skhgroup.net/teaching/2105603/lab01-video.html
Its four-page guide is included. No repeat form submission is required.
Session 2 video and narration are not included in this ZIP. Use the online
lesson with internet access or its separately downloaded MP4 videos:
https://www.skhgroup.net/teaching/2105603/week02-video.html
The Session 2 slides, four-page worksheet and Labs are included locally.
Session 3 is an independent holiday lesson: consistency tests
before liquid stability and LLE. Its study guide, slides, six-page worksheet,
four-page worked solutions, four-page Lab guide and optional background PDF are
included locally. Plan approximately180 minutes for the recording or slides,
independent work, review and a break; actual completion time varies.
Open teaching/2105603/week03-study.html through the local server to begin.
The Session 3 narrated video is online or a separate MP4 download:
https://www.skhgroup.net/teaching/2105603/week03-video.html
The optional Gibbs and stability review slides, slide PDF, four-page guide
and synthetic Lab 04 demonstration study JSON are included. The review video
requires internet or a separate MP4 download:
https://www.skhgroup.net/teaching/2105603/week03-gibbs-review-video.html
The demonstration JSON is synthetic evidence, not a student submission. Restore
it and recompute in Lab 04. This review adds no attendance or repeat exit ticket.
The offline slide/document route covers the same activities; video is not
additional required study. Downloaded MP4s require manual activity pauses.
Session 4 replaces class while the instructor attends the ECS meeting.
The Week 4 combined video begins with Opening 01-14 and includes a four-minute
R1-R3 notebook pause before the core lesson. For offline study, use
teaching/2105603/week04-questions.html as the alternative written opening,
then follow the core slides. Do not add both as separate required activities.
The opening, complete video slide PDF, 40-slide core deck, six-page worksheet, four-page Lab guide,
four-page worked solutions and optional background reading are included.
A-G and I, Lab 10 and Lab 11 remain required; H1-H4 is optional.
For the video route, add 4 minutes for R1-R3, 100 minutes for core work and
10 minutes for the break to the combined recording. Read the staged study
hub for its measured duration and conservative planning total.
Video links preserve the new #opening-01 and existing #slide-16/#slide-30
chapter anchors. The recording and player remain online or a separate download:
https://www.skhgroup.net/teaching/2105603/week04-video.html
Its chapter links preserve the Lab 10 / Lab 11 demonstration anchors.
Complete the existing Session 4 exit ticket and feedback once, with internet.
There is no additional form and no repeat Week 3 submission.
Session 5 replaces class on November 6; classroom discussion resumes November 13.
Begin with teaching/2105603/week05-study.html. One six-page worksheet, one Lab 12,
the 32-slide deck, two-page Lab guide and five-page worked solutions are included.
The lesson first reviews bulk solid versus adsorption, partial versus total
pressure, and independent isotherm and material-balance checks. The main worked
example is the synthetic ideal-gas reaction A2 <=> 2 A, with reference data at
350 K. Compare Gibbs and enthalpy-entropy routes, pressure, and constant-enthalpy
van 't Hoff temperature changes. The Lab's default heat-capacity change must be
set to zero; use the constant-enthalpy van 't Hoff source at 400 K. Follow the
worksheet and Lab guide for exact inputs. Custom species and heat-capacity
polynomials are optional references, not extra required work.
Plan about three hours: the recording plus 128 minutes of activities and a
10-minute break. The staged study hub reports the measured recording duration.
The slides are the offline alternative to the same recording, not an additional
required lesson. Stop at each activity budget; record any unresolved question and
continue. Attempt calculations before opening worked solutions. Keep your
worksheet and synthetic Lab exports for the November 13 discussion. There is no
extra required preparation or follow-up assignment.
Week 5 video and Lab 12 screen demonstrations are online or a separate MP4:
https://www.skhgroup.net/teaching/2105603/week05-video.html
Complete the existing anonymous Session 5 exit ticket and feedback once, online:
https://thermo-2105603-exit-ticket.soorathep-k.chatgpt.site/?session=5
Do not include your name or student ID in the anonymous form.
The Lab 08 demonstration includes its synthetic Excel workbook, CSV, saved
study examples, residual tables and the English walkthrough page.
The Lab 08 video and audio are not included. Open the narrated walkthrough
with internet access or download its MP4 separately:
https://www.skhgroup.net/teaching/2105603/lab08-video.html
Week 6 closes with its own exit ticket and weekly feedback. Open the Week 7 slides
at teaching/2105603/postmidterm-07.html for the Week 7 exit ticket and survey
covering all weeks after the midterm. Connect to the internet to submit the forms.
The offline archive does not store or synchronize student responses.
Optional source toolkit ZIPs are omitted; their links lead to this note.
Python notebooks and figure regeneration need their documented dependencies;
they are not required to run the browser labs. No packages are installed here.
Imported student data stay in the browser unless you export them. Keep your
exported study JSON and worksheet together. New study exports restore inputs;
recalculate after restore. Offline data are not synchronized to the live site.

MANIFEST.json records authoritative hashes of this offline build, including the
rewritten learning-path JSON. The byte-identical public Lab release manifest
records public-source assets, not the modified offline links. That metadata is in
teaching/2105603/labs/release-manifest.json. Third-party assets retain their
bundled license headers; course assets retain their existing attribution.
