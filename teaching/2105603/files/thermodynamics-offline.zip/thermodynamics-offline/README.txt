2105603 ADVANCED THERMODYNAMICS: OFFLINE STUDENT PACKAGE

Extract the ZIP before use. Requires a browser and an installed Python 3.
Run serve.py with the ABSOLUTE PATH to your Python interpreter, for example:
  ~/.venvs/research/bin/python /absolute/path/thermodynamics-offline/serve.py
Use your own installed interpreter path on Windows or Linux.
The server uses only the standard library and listens on 127.0.0.1.
It prints a local URL and opens your browser. Ctrl+C stops the server.
Opening HTML through file:// will not reliably run data fetches or workers.

Includes all 13 labs, six session slides, reference decks, assessment sets,
six session PDFs, six pre-class reading PDFs and available notebooks. Reference decks use HTML to avoid
duplicating their large figures in PDFs. No instructor key or student records.
External literature and other group website pages need internet.
Session 2 video and narration are not included in this ZIP. Use the online
lesson with internet access or its separately downloaded MP4 videos:
https://www.skhgroup.net/teaching/2105603/week02-video.html
The Session 2 slides, four-page worksheet and Labs are included locally.
The Lab 08 demonstration includes its synthetic Excel workbook, CSV, saved
study examples, residual tables and the English walkthrough page.
The Lab 08 video and audio are not included. Open the narrated walkthrough
with internet access or download its MP4 separately:
https://www.skhgroup.net/teaching/2105603/lab08-video.html
The exit ticket and feedback form also require internet to submit responses.
The offline archive does not store or synchronize student responses.
Optional source toolkit ZIPs are omitted; their links lead to this note.
Python notebooks and figure regeneration need their documented dependencies;
they are not required to run the browser labs. No packages are installed here.
Imported student data stay in the browser unless you export them. Keep your
exported study JSON and worksheet together. New study exports restore inputs;
recalculate after restore. Offline data are not synchronized to the live site.

MANIFEST.json records file hashes for this build. Lab release metadata is in
teaching/2105603/labs/release-manifest.json. Third-party assets retain their
bundled license headers; course assets retain their existing attribution.
