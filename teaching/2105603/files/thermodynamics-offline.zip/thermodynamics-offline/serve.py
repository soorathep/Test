"""Serve this extracted directory on loopback only, using Python standard library."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from functools import partial
from pathlib import Path
import webbrowser
root=Path(__file__).resolve().parent
with ThreadingHTTPServer(("127.0.0.1",0),partial(SimpleHTTPRequestHandler,directory=str(root))) as server:
    url=f"http://127.0.0.1:{server.server_port}/"
    print("Open",url,"; press Ctrl+C to stop",flush=True)
    webbrowser.open(url)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
