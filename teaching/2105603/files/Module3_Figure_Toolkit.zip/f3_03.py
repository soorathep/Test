#!/usr/bin/env python3
"""F3.3  G^E = H^E - T S^E, and which of the two terms is actually doing the
        work.

2105603 Advanced Chemical Engineering Thermodynamics — Module 3
Soorathep Kheawhom, Chulalongkorn University

Ethanol (1) + water (2) is the textbook positive-deviation system: G^E is
large and positive across the whole composition range, gamma_1 at infinite
dilution is of order 4, and it forms a minimum-boiling azeotrope. The naive
reading is that ethanol and water dislike each other energetically.

They do not. At 298.15 K H^E is *negative* — mixing releases heat — and the
entire positive G^E comes from -T S^E. The mixture is held apart by entropy,
not by energy, which is the structural signature of hydrophobic hydration.

Heat 50 K and the balance changes: H^E crosses zero near 333 K and by
348.15 K both terms push G^E the same way. G^E itself barely notices, which
is exactly why a G^E model fitted at one temperature and used at another can
be right for the wrong reason.

ROUTE USED FOR H^E — STATED, BECAUSE IT MATTERS
-----------------------------------------------
H^E here is NOT a measurement. It is obtained from the temperature dependence
of a G^E model,

    H^E = -R T^2  d(G^E/RT)/dT

The model is modified UNIFAC (Dortmund), evaluated through
`thermo.unifac.UNIFAC` with the DOUFIP2006 interaction table and DOUFSG
subgroups shipped with the `thermo` package. Its group interaction parameters
are temperature dependent (a + bT + cT^2) and were regressed simultaneously
against VLE, LLE, h^E and gamma^infinity data — see

    Gmehling, J.; Li, J.; Schiller, M. "A modified UNIFAC model. 2. Present
    parameter matrix and results for different thermodynamic properties."
    Ind. Eng. Chem. Res. 1993, 32(1). doi:10.1021/ie00013a024

so its temperature derivative is not an accident of a VLE-only fit: excess
enthalpies were in the regression. That is the reason this model was chosen
over original UNIFAC, whose group parameters carry no fitted temperature
dependence at all.

`thermo`'s analytic HE() is checked here against a central difference of
-R T^2 d(G^E/RT)/dT computed from GE() alone; the largest disagreement is
printed and put on the figure. Ethanol and water are entered by their
UNIFAC subgroup decompositions (CH3 + CH2 + OH(P), and H2O), not by any
fitted binary parameter.

NOTHING ON THIS FIGURE IS ASSUMED OR ILLUSTRATIVE, but the H^E curve is a
model prediction, not a calorimeter reading, and the figure says so.

Run:  python3 f3_03.py
"""
from __future__ import annotations

import os
import sys

import numpy as np

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                   # noqa: E402

from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,       # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, use_style)

OUT = os.environ.get("F3_OUT", "/home/claude/vle3/qmd/figures")
SLUG = "f3_03_gE_hE_tsE"

R = 8.314462618
T_LO, T_HI = 298.15, 348.15
X_MARK = 0.50
# ethanol = CH3 + CH2 + OH(P); water = H2O, in the Dortmund subgroup numbering
CHEMGROUPS = [{1: 1, 2: 1, 14: 1}, {16: 1}]


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def wrapped(text, width):
    """Wrap a caption on spaces, never inside a $...$ span.

    `bbox_inches='tight'` grows the canvas around any text that overflows the
    figure, which silently rescales everything else on the slide. Wrapping the
    footnote to the figure width is the only way to keep the rendered PNG the
    size the script asked for.
    """
    out = []
    for para in text.split("\n"):
        cur, n, inmath = [], 0, False
        for w in para.split(" "):
            if cur and not inmath and n + 1 + len(w) > width:
                out.append(" ".join(cur))
                cur, n = [], 0
            cur.append(w)
            n += len(w) + (1 if n else 0)
            if w.count("$") % 2 == 1:
                inmath = not inmath
        out.append(" ".join(cur))
    return "\n".join(out)



# --------------------------------------------------------------------------
def model(x1, T):
    from thermo.unifac import UNIFAC, DOUFIP2006, DOUFSG
    return UNIFAC.from_subgroups(T=float(T), xs=[float(x1), 1 - float(x1)],
                                 chemgroups=CHEMGROUPS, version=1,
                                 interaction_data=DOUFIP2006,
                                 subgroups=DOUFSG)


def curves(xs, T):
    GE = np.array([model(x, T).GE() for x in xs])
    HE = np.array([model(x, T).HE() for x in xs])
    return GE, HE, HE - GE                      # G^E, H^E, T S^E


def he_finite_difference(xs, T, h=0.01):
    """-R T^2 d(G^E/RT)/dT from GE() alone, the definition, by central diff."""
    gp = np.array([model(x, T + h).GE() / (R * (T + h)) for x in xs])
    gm = np.array([model(x, T - h).GE() / (R * (T - h)) for x in xs])
    return -R * T ** 2 * (gp - gm) / (2 * h)


def make():
    xs = np.linspace(0.02, 0.98, 97)
    panels = {}
    worst = 0.0
    for T in (T_LO, T_HI):
        GE, HE, TSE = curves(xs, T)
        fd = he_finite_difference(xs, T)
        worst = max(worst, float(np.max(np.abs(HE - fd))))
        panels[T] = dict(x=xs, GE=GE, HE=HE, TSE=TSE, fd=fd)

    # the marked composition
    marks = {}
    for T in (T_LO, T_HI):
        m = model(X_MARK, T)
        marks[T] = dict(GE=m.GE(), HE=m.HE(), TSE=m.HE() - m.GE(), SE=m.SE())

    # H^E and G^E at x = 0.5 as a function of temperature, and the zero of H^E
    Tg = np.linspace(283.15, 400.0, 235)
    HEt = np.array([model(X_MARK, t).HE() for t in Tg])
    GEt = np.array([model(X_MARK, t).GE() for t in Tg])
    k = int(np.argmin(np.abs(HEt)))
    lo = max(k - 1, 0)
    hi = min(k + 1, len(Tg) - 1)
    from scipy.optimize import brentq
    Tzero = float(brentq(lambda t: model(X_MARK, t).HE(), Tg[lo], Tg[hi])) \
        if HEt[lo] * HEt[hi] < 0 else float("nan")

    return dict(panels=panels, marks=marks, Tg=Tg, HEt=HEt, GEt=GEt,
                Tzero=Tzero, worst=worst, xs=xs)


# --------------------------------------------------------------------------
def build(d):
    use_style()
    fig = plt.figure(figsize=(16.2, 8.4))
    gs = fig.add_gridspec(1, 3, width_ratios=[1.0, 1.0, 0.92],
                          left=0.050, right=0.988, top=0.782, bottom=0.225,
                          wspace=0.24)
    axes = [fig.add_subplot(gs[0, i]) for i in range(3)]
    for a in axes:
        a.grid(True, zorder=0)
        a.set_axisbelow(True)

    ylo, yhi = -1350.0, 1400.0
    for ax, T in zip(axes[:2], (T_LO, T_HI)):
        p = d["panels"][T]
        ax.axhline(0.0, color=GRAPHITE, lw=1.2, zorder=3)
        ax.plot(p["x"], p["GE"], "-", color=NAVY, lw=3.0, zorder=6,
                label="$G^E$")
        ax.plot(p["x"], p["HE"], "-", color=RUST, lw=2.6, zorder=5,
                label="$H^E$")
        ax.plot(p["x"], p["TSE"], "-", color=TEAL, lw=2.6, zorder=4,
                label="$TS^E$")
        ax.set_xlim(0, 1)
        ax.set_ylim(ylo, yhi)
        ax.set_xlabel("$x_1$   (mole fraction ethanol)")
        ax.set_title(f"$T$ = {T:.2f} K", fontsize=13.5, pad=8, loc="left",
                     x=0.0)
        m = d["marks"][T]
        ax.plot([X_MARK] * 3, [m["GE"], m["HE"], m["TSE"]], "o",
                color=GRAPHITE, ms=7, mfc=PAPER, mew=1.6, zorder=8)
        ax.plot([X_MARK, X_MARK], [m["TSE"], m["GE"]], color=SLATE,
                lw=1.0, ls=":", zorder=3)
        ax.annotate(
            f"at $x_1$ = {X_MARK:.2f}\n"
            f"$G^E$   = {m['GE']:+7.1f}\n"
            f"$H^E$   = {m['HE']:+7.1f}\n"
            f"$TS^E$ = {m['TSE']:+7.1f}   J/mol",
            xy=(X_MARK, m["GE"]), xytext=(0.978, 1360.0), textcoords="data",
            ha="right", va="top", fontsize=11.4, color=INK, zorder=10,
            linespacing=1.5,
            bbox=dict(boxstyle="round,pad=0.28", fc=PAPER, ec=GRAPHITE,
                      lw=1.0, alpha=0.96),
            arrowprops=dict(arrowstyle="-", color=SLATE, lw=1.1, shrinkA=6,
                            shrinkB=4))

    axes[0].set_ylabel("excess property  /  J mol$^{-1}$")
    axes[0].legend(loc="upper left", fontsize=11.5, labelspacing=0.55,
                   bbox_to_anchor=(0.018, 0.995))

    # ------------------------------------------------- panel 3: versus T
    ax = axes[2]
    ax.axhline(0.0, color=GRAPHITE, lw=1.2, zorder=3)
    ax.plot(d["Tg"], d["GEt"], "-", color=NAVY, lw=3.0, zorder=6,
            label="$G^E$")
    ax.plot(d["Tg"], d["HEt"], "-", color=RUST, lw=2.6, zorder=5,
            label="$H^E$")
    ax.plot(d["Tg"], d["HEt"] - d["GEt"], "-", color=TEAL, lw=2.6, zorder=4,
            label="$TS^E$")
    for T in (T_LO, T_HI):
        ax.axvline(T, color=SLATE, lw=1.0, ls=":", zorder=2)
    ax.plot([d["Tzero"]], [0.0], "o", color=RUST, ms=10, mec=PAPER, mew=1.6,
            zorder=9)
    ax.set_xlim(d["Tg"][0], d["Tg"][-1])
    ax.set_ylim(-1420.0, 1400.0)
    ax.set_xlabel("$T$  /  K")
    ax.set_ylabel("excess property at $x_1$ = 0.50  /  J mol$^{-1}$")
    ax.set_title("the same three numbers, versus $T$", fontsize=13.5, pad=8,
                 loc="left", x=0.0)
    ax.legend(loc="lower right", fontsize=11.5, labelspacing=0.55,
              bbox_to_anchor=(0.985, 0.015))
    ax.annotate(f"$H^E$ = 0 at {d['Tzero']:.1f} K",
                xy=(d["Tzero"], 0.0), xytext=(d["Tzero"] - 5.0, -560.0),
                ha="right", va="center", fontsize=11.0, color=RUST, zorder=10,
                bbox=dict(boxstyle="round,pad=0.22", fc=PAPER, ec=RUST,
                          lw=1.0, alpha=0.96),
                arrowprops=dict(arrowstyle="-", color=RUST, lw=1.1,
                                shrinkA=4, shrinkB=6))
    for T in (T_LO, T_HI):
        ax.text(T + 2.5, 1370.0, f"{T:.2f} K", fontsize=10.4, color=SLATE,
                ha="left", va="top", rotation=90, zorder=8)

    fig.text(0.5, 0.960,
             "$G^E$ is positive because of entropy, not energy — and which "
             "term dominates is a function of temperature",
             ha="center", va="center", fontsize=16.0, color=INK)
    fig.text(0.5, 0.917,
             "ethanol (1) + water (2), modified UNIFAC (Dortmund)",
             ha="center", va="center", fontsize=12.5, color=SLATE)
    m0, m1 = d["marks"][T_LO], d["marks"][T_HI]
    fig.text(0.5, 0.868, wrapped(
             f"At 298.15 K mixing gives out heat ($H^E$ = "
             f"{m0['HE']:+.0f} J/mol at $x_1$ = 0.5) and every joule of the "
             f"positive $G^E$, and more, comes from $-TS^E$. "
             f"By 348.15 K $H^E$ has changed sign: $G^E$ moved only "
             f"{m1['GE'] - m0['GE']:+.0f} J/mol while its two parts moved "
             f"{m1['HE'] - m0['HE']:+.0f} and {m1['TSE'] - m0['TSE']:+.0f}.",
             150),
             ha="center", va="center", fontsize=12.0, color=INK,
             linespacing=1.5)

    fig.text(0.5, 0.012, wrapped(
             "$H^E$ IS NOT MEASURED HERE. It is obtained from the temperature "
             "dependence of the model, $H^E = -RT^2\\,\\partial(G^E/RT)/"
             "\\partial T$. The model is modified UNIFAC (Dortmund) — "
             "`thermo.unifac.UNIFAC`, DOUFIP2006 table, DOUFSG subgroups — "
             "whose temperature-dependent group parameters were regressed "
             "simultaneously against VLE, LLE, $h^E$ and $\\gamma^\\infty$ "
             "data\n"
             "(Gmehling, Li & Schiller, $Ind.\\ Eng.\\ Chem.\\ Res.$ 1993, "
             "32(1), doi:10.1021/ie00013a024), which is why its temperature "
             "derivative is worth plotting at all. `thermo`'s analytic HE() "
             "was checked against a central difference of GE() alone over "
             f"97 compositions at both temperatures: largest disagreement "
             f"{d['worst']:.2e} J/mol. No parameter here is fitted or "
             "assumed; ethanol and water enter as UNIFAC subgroups only.", 196),
             ha="center", va="bottom", fontsize=10.2, color=SLATE,
             linespacing=1.6)
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = make()
    print("ethanol (1) + water (2), modified UNIFAC (Dortmund), "
          "thermo DOUFIP2006")
    print(f"  H^E route: -R T^2 d(G^E/RT)/dT.  Analytic HE() vs central "
          f"difference of GE(): max |diff| = {d['worst']:.3e} J/mol "
          f"over 97 compositions at both temperatures")
    for T in (T_LO, T_HI):
        p = d["panels"][T]
        print(f"  --- T = {T} K ---")
        print("     x1        G^E        H^E       TS^E        S^E")
        for x in (0.05, 0.10, 0.20, 0.30, 0.50, 0.70, 0.90, 0.95):
            m = None
            i = int(np.argmin(np.abs(p["x"] - x)))
            from thermo.unifac import UNIFAC, DOUFIP2006, DOUFSG
            mm = UNIFAC.from_subgroups(T=T, xs=[float(p["x"][i]),
                                                1 - float(p["x"][i])],
                                       chemgroups=CHEMGROUPS, version=1,
                                       interaction_data=DOUFIP2006,
                                       subgroups=DOUFSG)
            print(f"   {p['x'][i]:6.4f}  {p['GE'][i]:9.2f}  {p['HE'][i]:9.2f}  "
                  f"{p['TSE'][i]:9.2f}  {mm.SE():9.4f}")
        m = d["marks"][T]
        print(f"    at x1 = {X_MARK}: G^E = {m['GE']:.3f}, H^E = "
              f"{m['HE']:.3f}, TS^E = {m['TSE']:.3f} J/mol; "
              f"check G^E - (H^E - TS^E) = "
              f"{m['GE'] - (m['HE'] - m['TSE']):.3e} J/mol")
    print(f"  H^E at x1 = {X_MARK} crosses zero at T = {d['Tzero']:.3f} K")
    print(f"  G^E at x1 = {X_MARK}: {d['marks'][T_LO]['GE']:.1f} J/mol at "
          f"{T_LO} K -> {d['marks'][T_HI]['GE']:.1f} J/mol at {T_HI} K "
          f"({d['marks'][T_HI]['GE'] - d['marks'][T_LO]['GE']:+.1f}), while "
          f"H^E moves {d['marks'][T_HI]['HE'] - d['marks'][T_LO]['HE']:+.1f} "
          f"and TS^E moves "
          f"{d['marks'][T_HI]['TSE'] - d['marks'][T_LO]['TSE']:+.1f} J/mol")
    for p in write(build(d), SLUG):
        print("wrote", p)
