#!/usr/bin/env python3
"""F3.2  A partial molar property is not a property of the pure substance.

2105603 Advanced Chemical Engineering Thermodynamics — Module 3
Soorathep Kheawhom, Chulalongkorn University

Same system and same data as F3.1 — ethanol (1) + water (2) at 298.15 K —
differentiated across the whole composition range instead of at two points:

    Vbar_1 = V + (1 - x1) dV/dx1        Vbar_2 = V - x1 dV/dx1

Both curves run a long way from the pure-component molar volumes, which are
drawn as horizontal references. A mole of water added to nearly pure ethanol
occupies 14.28 cm3, not 18.07: it is 21 % smaller than a mole of water. That
is the single sentence this module needs a picture for.

The same arithmetic, at the scale of a laboratory bench: one litre of ethanol
mixed with one litre of water does not make two litres. The number this figure
computes is on its face.

DATA. Identical provenance to F3.1 and stated there in full:
  * V^E from the Redlich-Kister correlation of Danahy, Minnick & Shiflett,
    Fermentation 2018, 4(3), 72 (open access), regressed on >700 measured
    density-composition points from the International Critical Tables;
    validity 283.15-313.15 K, 0-100 wt% ethanol.
  * Independent pycnometric points from Pawar & Aher, IJSRSET 2017, 3(6),
    432-447, Table 2, 298.15 K.
  * Pure V1, V2 from `thermo` HEOS_FIT at run time.

WHAT IS EXTRAPOLATED, AND BY HOW MUCH. Neither dataset has a point below
x1 = 0.0719 or above x1 = 0.8622, so both infinite-dilution intercepts are
extrapolations. This script quantifies that rather than hiding it: the
measured points are refitted with 3-, 4- and 5-term Redlich-Kister
expansions and the spread in the intercepts is printed and shown on the
figure as a bar. The composition ranges outside the measurements are shaded.
Nothing else on this figure is assumed.

Run:  python3 f3_02.py
"""
from __future__ import annotations

import os
import sys

import numpy as np

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                   # noqa: E402

from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,       # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, use_style)

OUT = os.environ.get("F3_OUT", "/home/claude/vle3/qmd/figures")
SLUG = "f3_02_partial_molar_volumes"

T = 298.15
CAS1, CAS2 = "64-17-5", "7732-18-5"

RK = dict(a0=-9.054199, a1=0.01572057,
          b0=-4.930763, b1=0.01241796,
          c0=5.286817, c1=-0.01989784)

PAWAR = np.array([
    [0.0000, 0.9970], [0.0719, 0.9706], [0.1483, 0.9490], [0.2300, 0.9249],
    [0.3168, 0.9005], [0.4104, 0.8779], [0.5089, 0.8572], [0.6187, 0.8383],
    [0.7358, 0.8202], [0.8622, 0.8038], [1.0000, 0.7861]])


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def wrapped(text, width):
    """Wrap a caption on spaces, never inside a $...$ span.

    `bbox_inches='tight'` grows the canvas around any text that overflows the
    figure, which silently rescales everything else on the slide. Wrapping the
    footnote to the figure width is the only way to keep the rendered PNG the
    size the script asked for.
    """
    out = []
    for para in text.split("\n"):
        cur, n, inmath = [], 0, False
        for w in para.split(" "):
            if cur and not inmath and n + 1 + len(w) > width:
                out.append(" ".join(cur))
                cur, n = [], 0
            cur.append(w)
            n += len(w) + (1 if n else 0)
            if w.count("$") % 2 == 1:
                inmath = not inmath
        out.append(" ".join(cur))
    return "\n".join(out)



# --------------------------------------------------------------------------
def rk_eval(coef, x):
    x = np.atleast_1d(np.asarray(x, dtype=float))
    z = 1.0 - 2.0 * x
    return x * (1 - x) * (np.vander(z, len(coef), increasing=True) @ coef)


def make():
    from chemicals import MW
    from thermo.volume import VolumeLiquid

    V1 = float(VolumeLiquid(CASRN=CAS1).calculate(T, "HEOS_FIT")) * 1e6
    V2 = float(VolumeLiquid(CASRN=CAS2).calculate(T, "HEOS_FIT")) * 1e6
    M1, M2 = float(MW(CAS1)), float(MW(CAS2))
    A = RK["a0"] + RK["a1"] * T
    B = RK["b0"] + RK["b1"] * T
    C = RK["c0"] + RK["c1"] * T
    coef_ref = np.array([A, B, C])

    def VE(x1):
        return rk_eval(coef_ref, x1)

    def V(x1):
        x1 = np.atleast_1d(np.asarray(x1, dtype=float))
        return x1 * V1 + (1 - x1) * V2 + VE(x1)

    def dVdx(x1, h=1e-6):
        x1 = np.atleast_1d(np.asarray(x1, dtype=float))
        return (V(x1 + h) - V(x1 - h)) / (2 * h)

    def partials(x1):
        x1 = np.atleast_1d(np.asarray(x1, dtype=float))
        v, d = V(x1), dVdx(x1)
        return v + (1 - x1) * d, v - x1 * d

    # ---------------------------------------------------- the measured set
    xp, rp = PAWAR[:, 0], PAWAR[:, 1]
    Vp = (xp * M1 + (1 - xp) * M2) / rp
    V1p, V2p = M1 / rp[-1], M2 / rp[0]
    VEp = Vp - (xp * V1p + (1 - xp) * V2p)
    x_lo, x_hi = float(xp[1]), float(xp[-2])       # measured interior span

    m = (xp > 0) & (xp < 1)
    fits = {}
    for n in (3, 4, 5):
        z = 1.0 - 2.0 * xp[m]
        Amat = np.vander(z, n, increasing=True) * ((xp[m] * (1 - xp[m]))[:, None])
        coef, *_ = np.linalg.lstsq(Amat, VEp[m], rcond=None)
        h = 1e-6
        d0 = float(rk_eval(coef, h)[0]) / h                   # dV^E/dx1 at 0
        d1 = -float(rk_eval(coef, 1 - h)[0]) / h              # dV^E/dx1 at 1
        fits[n] = dict(coef=coef,
                       rms=float(np.sqrt(np.mean(
                           (rk_eval(coef, xp[m]) - VEp[m]) ** 2))),
                       V1inf=V1p + d0, V2inf=V2p - d1)

    # -------------------------------------------------- infinite dilution
    eps = 1e-10
    V1inf = float(partials(eps)[0][0])
    V2inf = float(partials(1 - eps)[1][0])

    # ------------------------------------------------------- 1 L + 1 L
    n1, n2 = 1000.0 / V1, 1000.0 / V2
    xmix = n1 / (n1 + n2)
    Vmix = float((n1 + n2) * V(xmix)[0])

    xg = np.linspace(0, 1, 20001)
    ve = VE(xg)
    j = int(np.argmin(ve))

    return dict(V1=V1, V2=V2, M1=M1, M2=M2, A=A, B=B, C=C, V=V, VE=VE,
                partials=partials, dVdx=dVdx, xp=xp, Vp=Vp, VEp=VEp,
                V1p=V1p, V2p=V2p, x_lo=x_lo, x_hi=x_hi, fits=fits,
                V1inf=V1inf, V2inf=V2inf, n1=n1, n2=n2, xmix=xmix, Vmix=Vmix,
                VEmin=float(ve[j]), xmin=float(xg[j]))


# --------------------------------------------------------------------------
def build(d):
    use_style()
    fig = plt.figure(figsize=(15.0, 8.6))
    gs = fig.add_gridspec(2, 2, width_ratios=[1.30, 1.0],
                          height_ratios=[1.0, 1.0],
                          left=0.058, right=0.988, top=0.828, bottom=0.205,
                          wspace=0.20, hspace=0.36)
    a1 = fig.add_subplot(gs[0, 0])
    a2 = fig.add_subplot(gs[1, 0])
    a3 = fig.add_subplot(gs[:, 1])
    for a in (a1, a2, a3):
        a.grid(True, zorder=0)
        a.set_axisbelow(True)

    xs = np.linspace(1e-9, 1 - 1e-9, 1201)
    Vb1, Vb2 = d["partials"](xs)
    V1, V2 = d["V1"], d["V2"]

    for ax, y, Vpure, col, sym, who in (
            (a1, Vb1, V1, AMBER, r"$\bar V_1$", "ethanol"),
            (a2, Vb2, V2, TEAL, r"$\bar V_2$", "water")):
        ax.axvspan(0.0, d["x_lo"], color=MIST, alpha=0.40, zorder=1)
        ax.axvspan(d["x_hi"], 1.0, color=MIST, alpha=0.40, zorder=1)
        ax.fill_between(xs, y, Vpure, color=col, alpha=0.16, zorder=2)
        ax.axhline(Vpure, color=GRAPHITE, lw=1.8, ls="--", zorder=4)
        ax.plot(xs, y, "-", color=col, lw=2.8, zorder=5)
        ax.set_xlim(0, 1)

    # ---------------------------------------------------------- panel a1
    a1.set_ylim(51.4, 60.2)
    a1.set_ylabel(r"$\bar V_1$ (ethanol) / cm$^3$ mol$^{-1}$")
    a1.set_title("ethanol in the mixture   (grey: extrapolated)",
                 fontsize=13.0, pad=7, loc="left", x=0.0)
    a1.text(0.50, V1 + 0.30, f"pure ethanol,  $V_1$ = {V1:.2f}", fontsize=11.4,
            color=GRAPHITE, ha="center", va="bottom", zorder=7,
            bbox=dict(boxstyle="round,pad=0.18", fc=PAPER, ec="none",
                      alpha=0.88))
    a1.annotate(f"$\\bar V_1^\\infty$ = {d['V1inf']:.2f}\n"
                f"{100 * (V1 - d['V1inf']) / V1:.1f} % below pure",
                xy=(0.0, d["V1inf"]), xytext=(0.305, 53.60),
                ha="left", va="bottom", fontsize=11.4, color=AMBER, zorder=8,
                linespacing=1.4,
                bbox=dict(boxstyle="round,pad=0.24", fc=PAPER, ec=AMBER,
                          lw=1.1, alpha=0.96),
                arrowprops=dict(arrowstyle="-", color=AMBER, lw=1.2,
                                shrinkA=4, shrinkB=6))
    lo = min(f["V1inf"] for f in d["fits"].values())
    hi = max(f["V1inf"] for f in d["fits"].values())
    a1.plot([0.010, 0.010], [lo, hi], "-", color=RUST, lw=4.0, zorder=9,
            solid_capstyle="butt")
    a1.annotate("3-, 4- and 5-term fits to the\n"
                f"measured points put $\\bar V_1^\\infty$\n"
                f"between {lo:.2f} and {hi:.2f}: the\n"
                "intercept is an extrapolation",
                xy=(0.010, 0.5 * (lo + hi)), xytext=(0.972, 51.62),
                ha="right", va="bottom", fontsize=10.4, color=RUST, zorder=8,
                linespacing=1.5,
                bbox=dict(boxstyle="round,pad=0.24", fc=PAPER, ec=RUST,
                          lw=1.0, alpha=0.96),
                arrowprops=dict(arrowstyle="-", color=RUST, lw=1.1,
                                shrinkA=4, shrinkB=6))

    # ---------------------------------------------------------- panel a2
    a2.set_ylim(13.2, 19.4)
    a2.set_xlabel("$x_1$   (mole fraction ethanol)")
    a2.set_ylabel(r"$\bar V_2$ (water) / cm$^3$ mol$^{-1}$")
    a2.set_title("water in the mixture   (grey: extrapolated)",
                 fontsize=13.0, pad=7, loc="left", x=0.0)
    a2.text(0.42, V2 + 0.22, f"pure water,  $V_2$ = {V2:.2f}", fontsize=11.4,
            color=GRAPHITE, ha="center", va="bottom", zorder=7,
            bbox=dict(boxstyle="round,pad=0.18", fc=PAPER, ec="none",
                      alpha=0.88))
    a2.annotate(f"$\\bar V_2^\\infty$ = {d['V2inf']:.2f}\n"
                f"{100 * (V2 - d['V2inf']) / V2:.0f} % below pure water",
                xy=(1.0, d["V2inf"]), xytext=(0.055, 14.55),
                ha="left", va="top", fontsize=11.4, color=TEAL, zorder=8,
                linespacing=1.4,
                bbox=dict(boxstyle="round,pad=0.24", fc=PAPER, ec=TEAL,
                          lw=1.1, alpha=0.96),
                arrowprops=dict(arrowstyle="-", color=TEAL, lw=1.2,
                                shrinkA=4, shrinkB=6))
    lo2 = min(f["V2inf"] for f in d["fits"].values())
    hi2 = max(f["V2inf"] for f in d["fits"].values())
    a2.plot([0.990, 0.990], [lo2, hi2], "-", color=RUST, lw=4.0, zorder=9,
            solid_capstyle="butt")

    # ---------------------------------------------------------- panel a3
    xf = np.linspace(0, 1, 601)
    a3.axhline(0.0, color=GRAPHITE, lw=1.2, zorder=3)
    a3.plot(xf, d["VE"](xf), "-", color=NAVY, lw=2.8, zorder=4,
            label="$V^E$, Redlich-Kister of ICT densities")
    a3.plot(d["xp"], d["VEp"], "o", color=INK, mfc=PAPER, mew=1.7, ms=7.0,
            zorder=6, label="measured, independent lab")
    a3.plot([d["xmin"]], [d["VEmin"]], "v", color=RUST, ms=10, zorder=7)
    a3.plot([d["xmix"]], [float(d["VE"](d["xmix"])[0])], "o", color=RUST,
            ms=10, mec=PAPER, mew=1.5, zorder=7)
    a3.set_xlim(0, 1)
    a3.set_ylim(-1.62, 1.18)
    a3.set_xlabel("$x_1$   (mole fraction ethanol)")
    a3.set_ylabel("$V^E$  /  cm$^3$ mol$^{-1}$", labelpad=12)
    a3.set_title("the excess volume that produces both curves",
                 fontsize=13.0, pad=7, loc="left", x=0.0)
    a3.legend(loc="lower left", fontsize=10.4, labelspacing=0.5,
              bbox_to_anchor=(0.015, 0.012))
    a3.annotate(f"minimum {d['VEmin']:.3f} cm$^3$/mol\nat $x_1$ = "
                f"{d['xmin']:.3f}",
                xy=(d["xmin"], d["VEmin"]), xytext=(0.715, -1.19),
                ha="left", va="top", fontsize=10.6, color=RUST, zorder=8,
                linespacing=1.4,
                bbox=dict(boxstyle="round,pad=0.20", fc=PAPER, ec="none",
                          alpha=0.90),
                arrowprops=dict(arrowstyle="-", color=RUST, lw=1.0,
                                shrinkA=3, shrinkB=4))
    a3.annotate(
        "On a bench:\n"
        f"1.000 L ethanol ({d['n1']:.2f} mol)\n"
        f"+ 1.000 L water ({d['n2']:.2f} mol)\n"
        f"    $x_1$ = {d['xmix']:.4f}\n"
        f"    = {d['Vmix'] / 1000:.3f} L, not 2.000 L\n"
        f"    the mixture loses {2000 - d['Vmix']:.1f} cm$^3$",
        xy=(d["xmix"], float(d["VE"](d["xmix"])[0])),
        xytext=(0.985, 1.12), textcoords="data",
        ha="right", va="top", fontsize=11.4, color=INK, zorder=9,
        linespacing=1.55,
        bbox=dict(boxstyle="round,pad=0.30", fc=PAPER, ec=GRAPHITE, lw=1.0,
                  alpha=0.96),
        arrowprops=dict(arrowstyle="-|>", color=RUST, lw=1.3, shrinkA=6,
                        shrinkB=5))

    fig.text(0.5, 0.955,
             "A partial molar volume is not the molar volume of the pure "
             "substance — and it is not even close",
             ha="center", va="center", fontsize=16.5, color=INK)
    fig.text(0.5, 0.902,
             "ethanol (1) + water (2) at 298.15 K;  dashed lines are the "
             "pure-component molar volumes",
             ha="center", va="center", fontsize=12.5, color=SLATE)

    fig.text(0.5, 0.012, wrapped(
             "MEASURED DATA. $V^E$ from the Redlich-Kister correlation of "
             "Danahy, Minnick & Shiflett, $Fermentation$ 2018, 4(3), 72 "
             "(open access), regressed on >700 measured density-composition "
             "points from the International Critical Tables; validity "
             "283.15-313.15 K, 0-100 wt%. Circles: Pawar & Aher, IJSRSET "
             "2017, 3(6), 432-447, Table 2.\n"
             "EXTRAPOLATED, AND LABELLED AS SUCH: no measurement exists "
             f"below $x_1$ = {d['x_lo']:.4f} or above $x_1$ = "
             f"{d['x_hi']:.4f} (shaded). Refitting the measured points with "
             "3, 4 and 5 Redlich-Kister terms moves $\\bar V_1^\\infty$ "
             f"over {max(f['V1inf'] for f in d['fits'].values()) - min(f['V1inf'] for f in d['fits'].values()):.2f}"
             " cm$^3$/mol and $\\bar V_2^\\infty$ over "
             f"{max(f['V2inf'] for f in d['fits'].values()) - min(f['V2inf'] for f in d['fits'].values()):.2f}"
             " cm$^3$/mol (red bars). Pure $V_1$, $V_2$: `thermo` HEOS_FIT.", 181),
             ha="center", va="bottom", fontsize=10.2, color=SLATE,
             linespacing=1.6)
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = make()
    print(f"ethanol (1) + water (2) at T = {T} K")
    print(f"  pure (thermo HEOS_FIT): V1 = {d['V1']:.4f}, V2 = {d['V2']:.4f} "
          f"cm3/mol")
    print(f"  Redlich-Kister (Danahy et al. 2018) at {T} K: "
          f"A = {d['A']:.6f}, B = {d['B']:.6f}, C = {d['C']:.6f} cm3/mol")
    print(f"  V^E minimum {d['VEmin']:.4f} cm3/mol at x1 = {d['xmin']:.4f}")
    print("  partial molar volumes:")
    print("      x1      V        dV/dx1    Vbar_ethanol   Vbar_water")
    for x in (1e-10, 0.05, 0.10, 0.2354, 0.30, 0.50, 0.70, 0.90, 1 - 1e-10):
        v = float(d["V"](x)[0])
        dd = float(d["dVdx"](x)[0])
        b1, b2 = d["partials"](x)
        print(f"    {x:7.4f}  {v:8.4f}  {dd:8.4f}    {float(b1[0]):8.4f}     "
              f"{float(b2[0]):8.4f}")
    print(f"  infinite dilution: Vbar_ethanol(inf) = {d['V1inf']:.4f} "
          f"({100 * (d['V1'] - d['V1inf']) / d['V1']:.2f} % below pure "
          f"{d['V1']:.4f})")
    print(f"                     Vbar_water(inf)   = {d['V2inf']:.4f} "
          f"({100 * (d['V2'] - d['V2inf']) / d['V2']:.2f} % below pure "
          f"{d['V2']:.4f})")
    print("  same intercepts from Redlich-Kister refits of the MEASURED "
          "points only:")
    for n, f in d["fits"].items():
        print(f"    {n}-term: rms {f['rms']:.4f} cm3/mol, "
              f"Vbar_ethanol(inf) = {f['V1inf']:.3f}, "
              f"Vbar_water(inf) = {f['V2inf']:.3f}")
    print(f"  1.000 L ethanol ({d['n1']:.4f} mol) + 1.000 L water "
          f"({d['n2']:.4f} mol): x1 = {d['xmix']:.5f}, "
          f"V = {d['Vmix']:.2f} cm3 = {d['Vmix'] / 1000:.4f} L, "
          f"contraction {2000 - d['Vmix']:.2f} cm3")
    for p in write(build(d), SLUG):
        print("wrote", p)
