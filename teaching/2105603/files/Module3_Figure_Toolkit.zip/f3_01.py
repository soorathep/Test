#!/usr/bin/env python3
"""F3.1  The tangent-intercept construction, on measured mixture volumes.

2105603 Advanced Chemical Engineering Thermodynamics — Module 3
Soorathep Kheawhom, Chulalongkorn University

    Mbar_i = M + (1 - x_i) dM/dx_i

is an algebraic statement with a picture attached, and the picture is the
whole content of it: draw the tangent to M(x_1) at one composition and read
off where it cuts x_1 = 0 and x_1 = 1. Those two intercepts *are* the two
partial molar properties at that composition. Nothing else is needed — no
differentiation of a mixture property with respect to mole number, no
Euler theorem, just a ruler.

The property here is the molar volume of ethanol (1) + water (2) at 298.15 K,
because volume is the one partial molar property a student can see in a
measuring cylinder. Two panels, two tangent points: the intercepts move when
the tangent point moves, which is the entire content of F3.2 stated in
advance.

DATA — what is measured and what is correlated
----------------------------------------------
CURVE.  V(x1) = x1 V1 + x2 V2 + V^E(x1), with V^E from the Redlich-Kister
    correlation of

        Danahy, B. B.; Minnick, D. L.; Shiflett, M. B.
        "Computing the Composition of Ethanol-Water Mixtures Based on
        Experimental Density and Temperature Measurements."
        Fermentation 2018, 4(3), 72.  doi:10.3390/fermentation4030072
        (open access, CC-BY)

    Their Table 1 gives V^E = x2(1-x2)[A + B(1-2x2) + C(1-2x2)^2] with
    A = a0 + a1 T, B = b0 + b1 T, C = c0 + c1 T, regressed on more than 700
    measured density-composition points from the International Critical
    Tables (1926); stated validity 283.15-313.15 K and 0-100 wt% ethanol,
    AARD 0.09 % in density. 298.15 K is inside that window.

POINTS. An independent laboratory dataset, measured with a bicapillary
    pycnometer over the whole composition range at 298.15 K:

        Pawar, R. R.; Aher, C. S. "Molecular Interactions in Binary Solvent
        Mixtures and Catechol in Pure, Binary Solvent Mixtures at 293.15 to
        313.15 K with DFT Study." Int. J. Sci. Res. Sci. Eng. Technol.
        (IJSRSET) 2017, 3(6), 432-447. Table 2, water + ethanol at 298.15 K.

    Eleven (x1, rho) pairs are transcribed below. They were checked twice:
    (i) V = (x1 M1 + x2 M2)/rho recomputed from the tabulated densities
    reproduces the paper's own tabulated V^E to 0.0011 cm3/mol rms, so the
    transcription is arithmetically self-consistent; (ii) they agree with the
    Danahy correlation to 0.035 cm3/mol rms. Both numbers are printed by this
    script and the second is printed on the figure.

PURE COMPONENTS. V1 and V2 are computed at run time from `thermo`'s
    HEOS_FIT liquid-volume correlations (fits to the reference multiparameter
    equations of state), not typed in. Because V^E vanishes at both ends, the
    curve passes exactly through them whatever their source.

NOTHING ON THIS FIGURE IS ASSUMED OR ILLUSTRATIVE.

Run:  python3 f3_01.py
"""
from __future__ import annotations

import os
import sys

import numpy as np

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                   # noqa: E402

from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,       # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, use_style)

OUT = os.environ.get("F3_OUT", "/home/claude/vle3/qmd/figures")
SLUG = "f3_01_tangent_intercepts"

T = 298.15
CAS1, CAS2 = "64-17-5", "7732-18-5"          # ethanol, water
X_STAR = (0.30, 0.70)                        # the two tangent points

# Danahy et al. (2018) Table 1, cm3/mol and cm3/(mol K)
RK = dict(a0=-9.054199, a1=0.01572057,
          b0=-4.930763, b1=0.01241796,
          c0=5.286817, c1=-0.01989784)

# Pawar & Aher (2017) Table 2: x(ethanol), rho / g cm^-3, at 298.15 K
PAWAR = np.array([
    [0.0000, 0.9970], [0.0719, 0.9706], [0.1483, 0.9490], [0.2300, 0.9249],
    [0.3168, 0.9005], [0.4104, 0.8779], [0.5089, 0.8572], [0.6187, 0.8383],
    [0.7358, 0.8202], [0.8622, 0.8038], [1.0000, 0.7861]])
# the same paper's own tabulated V^E, used only as a transcription check
PAWAR_VE = np.array([0.0000, -0.3438, -0.7117, -0.9379, -1.0366, -1.0697,
                     -1.0267, -0.9517, -0.7632, -0.5166, 0.0000])


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def wrapped(text, width):
    """Wrap a caption on spaces, never inside a $...$ span.

    `bbox_inches='tight'` grows the canvas around any text that overflows the
    figure, which silently rescales everything else on the slide. Wrapping the
    footnote to the figure width is the only way to keep the rendered PNG the
    size the script asked for.
    """
    out = []
    for para in text.split("\n"):
        cur, n, inmath = [], 0, False
        for w in para.split(" "):
            if cur and not inmath and n + 1 + len(w) > width:
                out.append(" ".join(cur))
                cur, n = [], 0
            cur.append(w)
            n += len(w) + (1 if n else 0)
            if w.count("$") % 2 == 1:
                inmath = not inmath
        out.append(" ".join(cur))
    return "\n".join(out)



# --------------------------------------------------------------------------
def pure_volumes(T):
    """Pure liquid molar volumes in cm3/mol, from `thermo`, at run time."""
    from chemicals import MW
    from thermo.volume import VolumeLiquid
    out = {}
    for cas in (CAS1, CAS2):
        V = VolumeLiquid(CASRN=cas)
        out[cas] = (float(V.calculate(T, "HEOS_FIT")) * 1e6, float(MW(cas)))
    return out


def rk_ABC(T):
    return (RK["a0"] + RK["a1"] * T,
            RK["b0"] + RK["b1"] * T,
            RK["c0"] + RK["c1"] * T)


def make():
    pv = pure_volumes(T)
    V1, M1 = pv[CAS1]
    V2, M2 = pv[CAS2]
    A, B, C = rk_ABC(T)

    def VE(x1):
        x1 = np.asarray(x1, dtype=float)
        z = 1.0 - 2.0 * x1
        return x1 * (1 - x1) * (A + B * z + C * z ** 2)

    def V(x1):
        x1 = np.asarray(x1, dtype=float)
        return x1 * V1 + (1 - x1) * V2 + VE(x1)

    def dVdx(x1, h=1e-6):
        return (V(np.asarray(x1, float) + h) - V(np.asarray(x1, float) - h)) / (2 * h)

    # ---------------------------------------------------------- the points
    xp, rp = PAWAR[:, 0], PAWAR[:, 1]
    Vp = (xp * M1 + (1 - xp) * M2) / rp
    V1p, V2p = M1 / rp[-1], M2 / rp[0]
    VEp = Vp - (xp * V1p + (1 - xp) * V2p)
    check_rms = float(np.sqrt(np.mean((VEp - PAWAR_VE) ** 2)))
    agree_rms = float(np.sqrt(np.mean((VEp - VE(xp)) ** 2)))

    # ------------------------------------------------------ the tangents
    tang = []
    for xs in X_STAR:
        v = float(V(xs))
        d = float(dVdx(xs))
        tang.append(dict(x=xs, V=v, slope=d,
                         Vbar1=v + (1 - xs) * d,     # intercept at x1 = 1
                         Vbar2=v - xs * d))          # intercept at x1 = 0

    return dict(V1=V1, V2=V2, M1=M1, M2=M2, A=A, B=B, C=C, V=V, VE=VE,
                dVdx=dVdx, xp=xp, Vp=Vp, VEp=VEp, V1p=V1p, V2p=V2p,
                check_rms=check_rms, agree_rms=agree_rms, tang=tang)


# --------------------------------------------------------------------------
def build(d):
    use_style()
    fig = plt.figure(figsize=(14.6, 8.2))
    gs = fig.add_gridspec(1, 2, width_ratios=[1.0, 1.32],
                          left=0.052, right=0.988, top=0.835, bottom=0.225,
                          wspace=0.20)
    axA = fig.add_subplot(gs[0, 0])
    axB = fig.add_subplot(gs[0, 1])
    for a in (axA, axB):
        a.grid(True, zorder=0)
        a.set_axisbelow(True)

    V1, V2 = d["V1"], d["V2"]
    xs = np.linspace(0.0, 1.0, 801)
    t0, t1 = d["tang"]

    # =============================================== A: the honest V picture
    ylo, yhi = 12.0, 64.0
    axA.plot([0, 1], [V2, V1], ":", color=SLATE, lw=2.0, zorder=2,
             label="ideal solution  $x_1V_1+x_2V_2$")
    axA.plot(xs, d["V"](xs), "-", color=NAVY, lw=2.8, zorder=4,
             label="$V$, Redlich-Kister of ICT densities")
    axA.plot(d["xp"], d["Vp"], "o", color=INK, mfc=PAPER, mew=1.7, ms=7.0,
             zorder=6, label="measured, independent lab")
    a0 = t0["Vbar2"]
    b0 = t0["Vbar1"]
    axA.plot([0, 1], [a0, b0], "-", color=RUST, lw=2.4, zorder=5,
             label=f"tangent at $x_1$ = {t0['x']:.2f}")
    axA.plot([t0["x"]], [t0["V"]], "o", color=RUST, ms=10, mec=PAPER, mew=1.6,
             zorder=8)
    axA.plot([0], [a0], "s", color=TEAL, ms=11, mec=PAPER, mew=1.5, zorder=9)
    axA.plot([1], [b0], "s", color=AMBER, ms=11, mec=PAPER, mew=1.5, zorder=9)
    axA.plot([0], [V2], "D", color=SLATE, ms=8, mec=PAPER, mew=1.3, zorder=7)
    axA.plot([1], [V1], "D", color=SLATE, ms=8, mec=PAPER, mew=1.3, zorder=7)
    axA.set_xlim(-0.05, 1.05)
    axA.set_ylim(ylo, yhi)
    axA.set_xlabel("$x_1$   (mole fraction ethanol)")
    axA.set_ylabel("$V$  /  cm$^3$ mol$^{-1}$")
    axA.set_title("as measured", fontsize=13.5, pad=8, loc="left", x=0.0)
    axA.legend(loc="upper left", fontsize=10.6, labelspacing=0.55,
               bbox_to_anchor=(0.015, 1.00))
    xg = 0.4239
    axA.annotate("$V$ and the ideal line differ by at most\n"
                 f"{abs(float(d['VE'](xg))):.2f} cm$^3$/mol over a "
                 f"{V1 - V2:.1f} cm$^3$/mol range.\n"
                 "Everything this figure is about is\n"
                 "inside that gap. Subtract the line.",
                 xy=(xg, 0.5 * (float(d["V"](xg))
                                + xg * V1 + (1 - xg) * V2)),
                 xytext=(0.985, 0.045), textcoords="axes fraction",
                 ha="right", va="bottom", fontsize=11.0, color=RUST,
                 zorder=11, linespacing=1.55,
                 bbox=dict(boxstyle="round,pad=0.30", fc=PAPER, ec=RUST,
                           lw=1.1, alpha=0.96),
                 arrowprops=dict(arrowstyle="-|>", color=RUST, lw=1.3,
                                 shrinkA=6, shrinkB=4))

    # ============================== B: the same construction, line removed
    axB.axhline(0.0, color=GRAPHITE, lw=1.2, zorder=2)
    axB.plot(xs, d["VE"](xs), "-", color=NAVY, lw=2.8, zorder=4,
             label="$V - (x_1V_1+x_2V_2) = V^E$")
    axB.plot(d["xp"], d["VEp"], "o", color=INK, mfc=PAPER, mew=1.7, ms=7.0,
             zorder=6, label="measured, independent lab")

    for t, col in ((t0, RUST), (t1, TEAL)):
        p0 = t["Vbar2"] - V2
        p1 = t["Vbar1"] - V1
        axB.plot([0, 1], [p0, p1], "-", color=col, lw=2.4, zorder=5,
                 label=f"tangent at $x_1$ = {t['x']:.2f}")
        axB.plot([t["x"]], [float(d["VE"](t["x"]))], "o", color=col, ms=10,
                 mec=PAPER, mew=1.6, zorder=8)
        axB.plot([0, 1], [p0, p1], "s", color=col, ms=11, mec=PAPER, mew=1.5,
                 zorder=9)

    ylo2, yhi2 = -2.62, 1.18
    axB.set_xlim(-0.05, 1.05)
    axB.set_ylim(ylo2, yhi2)
    axB.set_xlabel("$x_1$   (mole fraction ethanol)")
    axB.set_ylabel("$V - (x_1V_1+x_2V_2)$  /  cm$^3$ mol$^{-1}$")
    axB.set_title("the same two tangents, with the ideal line subtracted",
                  fontsize=13.5, pad=8, loc="left", x=0.0)
    axB.legend(loc="lower left", fontsize=10.6, labelspacing=0.55,
               bbox_to_anchor=(0.395, 0.012))

    # intercept labels: two on the left edge, two on the right edge, each
    # placed above or below its marker so no two boxes can touch
    lab = [
        (t0, 0.0, t0["Vbar2"] - V2, "left", 0.075, -0.60, TEAL if False else RUST,
         f"$\\bar V_2$ = {t0['Vbar2']:.2f}"),
        (t1, 0.0, t1["Vbar2"] - V2, "left", 0.075, -2.42, TEAL,
         f"$\\bar V_2$ = {t1['Vbar2']:.2f}"),
        (t0, 1.0, t0["Vbar1"] - V1, "right", 0.925, -1.55, RUST,
         f"$\\bar V_1$ = {t0['Vbar1']:.2f}"),
        (t1, 1.0, t1["Vbar1"] - V1, "right", 0.900, 0.62, TEAL,
         f"$\\bar V_1$ = {t1['Vbar1']:.2f}"),
    ]
    for t, xa, ya, ha, xt, yt, col, txt in lab:
        axB.annotate(f"{txt}\n$x_1$ = {t['x']:.2f}",
                     xy=(xa, ya), xytext=(xt, yt),
                     ha=ha, va="center", fontsize=11.8, color=col, zorder=12,
                     linespacing=1.4,
                     bbox=dict(boxstyle="round,pad=0.24", fc=PAPER, ec=col,
                               lw=1.1, alpha=0.96),
                     arrowprops=dict(arrowstyle="-", color=col, lw=1.2,
                                     shrinkA=4, shrinkB=7))

    axB.annotate(
        "$\\bar M_i = M + (1-x_i)\\,\\mathrm{d}M/\\mathrm{d}x_i$ is "
        "this picture.\n"
        "Left intercept + $V_2$ = $\\bar V_2$;  "
        "right intercept + $V_1$ = $\\bar V_1$.\n"
        "Move the tangent point and both intercepts move.",
        xy=(0.018, 0.985), xytext=(0.018, 0.985), xycoords="axes fraction",
        textcoords="axes fraction", ha="left", va="top", fontsize=11.5,
        color=INK, zorder=12, linespacing=1.6,
        bbox=dict(boxstyle="round,pad=0.30", fc=PAPER, ec=GRAPHITE, lw=1.0,
                  alpha=0.96))

    fig.text(0.5, 0.955,
             "The two intercepts of one tangent are the two partial molar "
             "volumes at that composition",
             ha="center", va="center", fontsize=16.5, color=INK)
    fig.text(0.5, 0.905, "ethanol (1) + water (2) at 298.15 K",
             ha="center", va="center", fontsize=12.5, color=SLATE)

    fig.text(0.5, 0.012, wrapped(
             "MEASURED DATA, NOTHING ASSUMED OR ILLUSTRATIVE.  Curve: $V^E$ "
             "from the Redlich-Kister correlation of Danahy, Minnick & "
             "Shiflett, $Fermentation$ 2018, 4(3), 72 (open access), "
             "regressed on >700 measured density-composition points from the "
             "International Critical Tables; stated validity 283.15-313.15 K, "
             "0-100 wt% ethanol.\n"
             "Circles: an independent pycnometric dataset, Pawar & Aher, "
             "IJSRSET 2017, 3(6), 432-447, Table 2. The two sources agree to "
             f"{d['agree_rms']:.3f} cm$^3$/mol rms; the transcribed densities "
             f"reproduce that paper's own $V^E$ column to "
             f"{d['check_rms']:.4f} cm$^3$/mol rms. "
             "Pure $V_1$, $V_2$ from `thermo` HEOS_FIT, computed at run time.", 176),
             ha="center", va="bottom", fontsize=10.2, color=SLATE,
             linespacing=1.6)
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = make()
    print(f"ethanol (1) + water (2) at T = {T} K")
    print(f"  pure molar volumes (thermo, HEOS_FIT): "
          f"V1 = {d['V1']:.4f}, V2 = {d['V2']:.4f} cm3/mol")
    print(f"  Redlich-Kister at {T} K: A = {d['A']:.6f}, B = {d['B']:.6f}, "
          f"C = {d['C']:.6f} cm3/mol   [Danahy et al. 2018]")
    print("  measured points (Pawar & Aher 2017, Table 2):")
    print("      x1      rho       V        V^E(recomputed)  V^E(their table)"
          "  V^E(correlation)")
    for x, r, v, ve, vt in zip(d["xp"], PAWAR[:, 1], d["Vp"], d["VEp"],
                               PAWAR_VE):
        print(f"    {x:6.4f}  {r:6.4f}  {v:8.4f}   {ve:+8.4f}       "
              f"{vt:+8.4f}        {float(d['VE'](x)):+8.4f}")
    print(f"  transcription check, rms |V^E(recomputed) - V^E(table)| = "
          f"{d['check_rms']:.5f} cm3/mol")
    print(f"  agreement between the two independent sources, rms = "
          f"{d['agree_rms']:.5f} cm3/mol")
    print(f"  their pure values: V1 = {d['V1p']:.4f}, V2 = {d['V2p']:.4f} "
          f"cm3/mol (vs {d['V1']:.4f}, {d['V2']:.4f} from thermo)")
    for t in d["tang"]:
        print(f"  tangent at x1 = {t['x']:.2f}: V = {t['V']:.4f}, "
              f"dV/dx1 = {t['slope']:.4f}, intercept at x1=1 "
              f"(Vbar_ethanol) = {t['Vbar1']:.4f}, intercept at x1=0 "
              f"(Vbar_water) = {t['Vbar2']:.4f} cm3/mol")
    for p in write(build(d), SLUG):
        print("wrote", p)
