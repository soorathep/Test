#!/usr/bin/env python3
"""F3.6  What each G^E model can and cannot do — every entry computed.

2105603 Advanced Chemical Engineering Thermodynamics — Module 3
Soorathep Kheawhom, Chulalongkorn University

A model-capability table is the easiest slide in the module to get wrong,
because every cell in it is a claim and the usual source for those claims is
the previous lecturer's slide. Nothing here is copied. Each column is the
output of a calculation this script runs:

PARAMETERS      len(model.param_names) for the vlekit class, so the count is
                the code's, not a recollection.

T DEPENDENCE    gE_RT(x, 298.15) and gE_RT(x, 348.15) are evaluated at the
                *same* parameters over 19 compositions and the largest
                difference is printed in the cell. For every parameterised
                model in `vlekit.models` it is exactly 0: the temperature
                dependence has to be put into the parameters by hand. For
                UNIFAC it is not, because Psi_mn = exp(-a_mn/T) is a function
                of T.

LIQUID-LIQUID   a parameter sweep, not an assertion. For each model a grid or
                seeded random sample of parameter sets is generated and
                `vlekit.flash.is_stable` is called on each; the number that
                produce an unstable liquid is reported, with one worked
                miscibility gap from `vlekit.flash.miscibility_gap`.

                The Wilson row is the one that matters and it gets a much
                larger sweep: 120 x 120 = 14400 pairs of Lambda values,
                log-spaced over [1e-3, 50]. Not one of them is unstable, and
                the smallest second derivative of Delta g_mix found anywhere
                on that grid is reported as a positive number. This
                reproduces, at higher resolution, the claim tested in
                `vlekit/tests/test_extensions.py::
                test_wilson_cannot_predict_a_split_whatever_the_parameters`.

EXTRAPOLATION   quantified rather than adjectival. Each model is fitted by
                `vlekit.fit` (Barker's method) to a P-x1-y1 set covering only
                x1 = 0.60 to 0.95, and is then asked for gamma_1 at infinite
                dilution — a composition the fit never saw. The reference
                answer is 4.792. The cell shows what each model says and by
                how much it is wrong. All six fit the window essentially
                perfectly (rms dP printed by the script); they disagree by
                65 percentage points about the far end.

REFERENCE SYSTEM. Ethanol (1) + water (2) at 298.15 K. The reference G^E is
modified UNIFAC (Dortmund) through `thermo.unifac.UNIFAC` (DOUFIP2006 /
DOUFSG); the fitted dataset is generated from it by `vlekit.generate` with an
ideal vapour and `vlekit.data.LIBRARY` Antoine constants, with no noise, so
the extrapolation column measures model form and nothing else. The UNIQUAC r
and q are the UNIFAC group sums stored on the components — molecular
constants, not fitted parameters.

The one thing on this figure that is NOT a calculation is the note that a
separate UNIFAC-LLE group-interaction table exists. That is verified only in
the weak sense that the file is present in the installed `thermo` package,
and the script checks for it and says so.

Run:  python3 f3_06.py       (about two minutes: the sweeps are real)
"""
from __future__ import annotations

import os
import sys
import time

import numpy as np

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                   # noqa: E402
from matplotlib.patches import Rectangle                          # noqa: E402

import vlekit as v                                                # noqa: E402
from vlekit import flash as FL                                    # noqa: E402
from vlekit.models import (Margules, FourSuffixMargules, NRTL,    # noqa: E402
                           UNIQUAC, VanLaar, Wilson)
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,       # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, use_style)
from vlekit.unifac import UNIFACModel                             # noqa: E402

OUT = os.environ.get("F3_OUT", "/home/claude/vle3/qmd/figures")
SLUG = "f3_06_model_capability_table"

T = 298.15
T2 = 348.15
NSWEEP = 40                      # 40 x 40 = 1600 parameter sets per model
NWILSON = 120                    # 120 x 120 = 14400 for the Wilson claim
WINDOW = (0.60, 0.95)
CHEMGROUPS = [{1: 1, 2: 1, 14: 1}, {16: 1}]


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def wrapped(text, width):
    """Wrap a caption on spaces, never inside a $...$ span.

    `bbox_inches='tight'` grows the canvas around any text that overflows the
    figure, which silently rescales everything else on the slide. Wrapping the
    footnote to the figure width is the only way to keep the rendered PNG the
    size the script asked for.
    """
    out = []
    for para in text.split("\n"):
        cur, n, inmath = [], 0, False
        for w in para.split(" "):
            if cur and not inmath and n + 1 + len(w) > width:
                out.append(" ".join(cur))
                cur, n = [], 0
            cur.append(w)
            n += len(w) + (1 if n else 0)
            if w.count("$") % 2 == 1:
                inmath = not inmath
        out.append(" ".join(cur))
    return "\n".join(out)



# --------------------------------------------------------------------------
def ref_ln_gamma(x1, Temp=T):
    from thermo.unifac import UNIFAC, DOUFIP2006, DOUFSG
    x1 = np.atleast_1d(np.asarray(x1, dtype=float))
    a = np.array([UNIFAC.from_subgroups(T=float(Temp), xs=[float(x), 1 - float(x)],
                                        chemgroups=CHEMGROUPS, version=1,
                                        interaction_data=DOUFIP2006,
                                        subgroups=DOUFSG).lngammas()
                  for x in x1])
    return a[:, 0], a[:, 1]


class Reference:
    name = "modified UNIFAC (Dortmund)"
    param_names = ()

    def ln_gamma(self, x1, Temp=None):
        return ref_ln_gamma(x1, T if Temp is None else np.mean(Temp))

    def gamma(self, x1, Temp=None):
        a, b = self.ln_gamma(x1, Temp)
        return np.exp(a), np.exp(b)

    def gE_RT(self, x1, Temp=None):
        x1 = np.atleast_1d(np.asarray(x1, dtype=float))
        a, b = self.ln_gamma(x1, Temp)
        return x1 * a + (1 - x1) * b


# --------------------------------------------------------------------------
def sweep(build_model, params, big=False):
    """How many of these parameter sets give a liquid that splits?"""
    x = np.linspace(1e-4, 1 - 1e-4, 801)
    n, tot, worst, example = 0, 0, np.inf, None
    for p in params:
        try:
            m = build_model(*p)
        except Exception:
            continue
        tot += 1
        try:
            d2 = FL.d2g_mix(m, x)
        except Exception:
            continue
        mn = float(np.min(d2))
        worst = min(worst, mn)
        if mn <= 0:
            n += 1
            if example is None and not big:
                g = FL.miscibility_gap(m)
                if g and 1e-3 < g["x1_phase_a"] < g["x1_phase_b"] < 1 - 1e-3:
                    example = (p, g["x1_phase_a"], g["x1_phase_b"])
    return dict(n=n, tot=tot, min_d2=worst, example=example)


def grid_pairs(g):
    return [(a, b) for a in g for b in g]


def make():
    t0 = time.time()
    et, wa = v.component("ethanol"), v.component("water")
    ref = Reference()

    # ------------------------------------------------ temperature dependence
    xs = np.linspace(0.05, 0.95, 19)
    probes = {
        "Margules-2": Margules([1.5, 0.9]),
        "Margules-3": FourSuffixMargules([1.2, 0.3, 0.1]),
        "van Laar": VanLaar([1.55, 0.95]),
        "Wilson": Wilson([0.236, 0.795]),
        "NRTL": NRTL([-0.031, 1.578]),
        "UNIQUAC": UNIQUAC([0.5, 0.9], r1=et.r, q1=et.q, r2=wa.r, q2=wa.q),
        "UNIFAC": UNIFACModel(et, wa),
    }
    tdep = {}
    for k, m in probes.items():
        a = np.asarray(m.gE_RT(xs, T), dtype=float)
        b = np.asarray(m.gE_RT(xs, T2), dtype=float)
        tdep[k] = float(np.max(np.abs(b - a)))
    tdep["mod-UNIFAC"] = float(np.max(np.abs(ref.gE_RT(xs, T2)
                                             - ref.gE_RT(xs, T))))

    # ------------------------------------------------------------- LLE sweeps
    gA = np.linspace(0.05, 6.0, NSWEEP)
    gW = np.geomspace(1e-3, 20.0, NSWEEP)
    gN = np.linspace(-6.0, 8.0, NSWEEP)
    gU = np.geomspace(1e-3, 5.0, NSWEEP)
    rng = np.random.default_rng(0)
    tri = list(zip(rng.uniform(0, 6, NSWEEP ** 2),
                   rng.uniform(-3, 3, NSWEEP ** 2),
                   rng.uniform(-2, 2, NSWEEP ** 2)))

    lle = {}
    lle["Margules-2"] = sweep(lambda a, b: Margules([a, b]), grid_pairs(gA))
    lle["Margules-3"] = sweep(lambda a, b, c: FourSuffixMargules([a, b, c]),
                              tri)
    lle["van Laar"] = sweep(lambda a, b: VanLaar([a, b]), grid_pairs(gA))
    lle["NRTL"] = sweep(lambda a, b: NRTL([a, b]), grid_pairs(gN))
    lle["UNIQUAC"] = sweep(
        lambda a, b: UNIQUAC([a, b], r1=et.r, q1=et.q, r2=wa.r, q2=wa.q),
        grid_pairs(gU))
    gWbig = np.geomspace(1e-3, 50.0, NWILSON)
    lle["Wilson"] = sweep(lambda a, b: Wilson([a, b]), grid_pairs(gWbig),
                          big=True)

    # UNIFAC is predictive: there are no parameters to sweep, so the question
    # is whether the published group table produces a split for a system that
    # is known to have one.
    hx, me = v.component("n-hexane"), v.component("methanol")
    uf = UNIFACModel(hx, me)
    uf_gap = FL.miscibility_gap(uf, T)
    uf_gap2 = FL.miscibility_gap(uf, 318.15)
    import thermo
    lle_table = os.path.join(os.path.dirname(thermo.__file__), "Phase Change",
                             "UNIFAC LLE interaction parameters.tsv")
    has_lle_table = os.path.exists(lle_table)

    # ------------------------------------------------------- extrapolation
    xw = np.linspace(WINDOW[0], WINDOW[1], 9)
    win = v.generate(ref, xw, T=T, c1=et, c2=wa, label="window")
    xf = np.linspace(0.02, 0.98, 21)
    full = v.generate(ref, xf, T=T, c1=et, c2=wa, label="full")
    g1ref = float(np.exp(ref.ln_gamma(np.array([1e-9]))[0][0]))

    extrap = {}
    for key, label in (("margules", "Margules-2"),
                       ("margules3", "Margules-3"),
                       ("vanlaar", "van Laar"),
                       ("wilson", "Wilson"),
                       ("nrtl", "NRTL"),
                       ("uniquac", "UNIQUAC")):
        fw = v.fit(win, key, objective="P")
        ff = v.fit(full, key, objective="P")
        gw = float(np.exp(fw.model.ln_gamma(np.array([1e-9]), T)[0][0]))
        gf = float(np.exp(ff.model.ln_gamma(np.array([1e-9]), T)[0][0]))
        extrap[label] = dict(window=gw, full=gf, rmsP=float(fw.rms_P),
                             err=100 * (gw - g1ref) / g1ref,
                             err_full=100 * (gf - g1ref) / g1ref,
                             params=fw.params,
                             names=fw.model.param_names)
    g1_unifac = float(np.exp(UNIFACModel(et, wa).ln_gamma(np.array([1e-9]),
                                                          T)[0][0]))
    from thermo.unifac import UNIFAC as TUNIFAC, UFIP, UFSG
    g1_unifac_thermo = float(np.exp(
        TUNIFAC.from_subgroups(T=T, xs=[1e-9, 1 - 1e-9],
                               chemgroups=CHEMGROUPS, version=0,
                               interaction_data=UFIP,
                               subgroups=UFSG).lngammas()[0]))

    return dict(tdep=tdep, lle=lle, extrap=extrap, g1ref=g1ref,
                g1_unifac=g1_unifac, g1_unifac_thermo=g1_unifac_thermo,
                uf_gap=uf_gap, uf_gap2=uf_gap2, has_lle_table=has_lle_table,
                elapsed=time.time() - t0, et=et, wa=wa)


# --------------------------------------------------------------------------
def rows(d):
    def ex(k):
        e = d["lle"][k]["example"]
        if not e:
            return ""
        p, xa, xb = e
        ps = ", ".join(f"{q:+.2f}" for q in p)
        return f"e.g. ({ps}) splits {xa:.2f} / {xb:.2f}"

    def sw(k):
        s = d["lle"][k]
        return f"yes — {s['n']} of {s['tot']} sampled\n{ex(k)}"

    def xp(k):
        e = d["extrap"][k]
        return (f"{e['window']:.2f}   ({e['err']:+.0f} %)\n"
                f"full-range fit: {e['full']:.2f} ({e['err_full']:+.0f} %)")

    w = d["lle"]["Wilson"]
    return [
        ("Margules,  2 parameter\n$G^E\\!/RT = x_1x_2(A_{21}x_1+A_{12}x_2)$",
         "2", f"none ({d['tdep']['Margules-2']:.0e})", sw("Margules-2"),
         xp("Margules-2"), False),
        ("Margules,  3 parameter\n(Redlich-Kister, $C\\,(x_1-x_2)^2$ term)",
         "3", f"none ({d['tdep']['Margules-3']:.0e})", sw("Margules-3"),
         xp("Margules-3"), False),
        ("van Laar\n$G^E\\!/RT = ABx_1x_2/(Ax_1+Bx_2)$",
         "2", f"none ({d['tdep']['van Laar']:.0e})", sw("van Laar"),
         xp("van Laar"), False),
        ("Wilson\n(local composition, $\\Lambda_{12},\\Lambda_{21}$)",
         "2", f"none ({d['tdep']['Wilson']:.0e})",
         f"NO — 0 of {w['tot']} sampled\n"
         f"min $\\mathrm{{d}}^2\\Delta g/\\mathrm{{d}}x_1^2$ on the grid = "
         f"{w['min_d2']:+.1e}",
         xp("Wilson"), True),
        ("NRTL\n($\\alpha$ fixed at 0.3, not fitted)",
         "2", f"none ({d['tdep']['NRTL']:.0e})", sw("NRTL"), xp("NRTL"),
         False),
        ("UNIQUAC\n($r$, $q$ from groups, not fitted)",
         "2", f"none ({d['tdep']['UNIQUAC']:.0e})", sw("UNIQUAC"),
         xp("UNIQUAC"), False),
        ("UNIFAC  (original, group table)\n"
         "$\\Psi_{mn} = \\exp(-a_{mn}/T)$",
         "0", f"YES ({d['tdep']['UNIFAC']:.1e})",
         "yes — n-hexane/methanol splits\n"
         f"{d['uf_gap']['x1_phase_a']:.2f} / "
         f"{d['uf_gap']['x1_phase_b']:.2f} at 298.15 K",
         f"nothing is fitted: predicts {d['g1_unifac']:.2f}\n"
         f"({100 * (d['g1_unifac'] - d['g1ref']) / d['g1ref']:+.0f} % vs the "
         "reference)", False),
    ]


COLS = [("model", 0.000, 0.212),
        ("adjustable\nbinary parameters", 0.212, 0.318),
        ("does $G^E\\!/RT$ carry\nits own $T$ dependence?\n"
         "max$|\\Delta|$, 298$\\rightarrow$348 K", 0.318, 0.500),
        ("can it produce a\nliquid-liquid split?\n"
         "(sweep, `flash.is_stable`)", 0.500, 0.760),
        ("extrapolation: $\\gamma_1^\\infty$ from a fit\n"
         "on $x_1 = 0.60$-$0.95$ only", 0.760, 1.000)]


def build(d):
    use_style()
    fig = plt.figure(figsize=(16.6, 9.2))
    ax = fig.add_axes([0.020, 0.205, 0.962, 0.645])
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    R = rows(d)
    nrow = len(R)
    head_h = 0.150
    row_h = (1.0 - head_h) / nrow
    pad = 0.007

    # header
    for name, a, b in COLS:
        ax.text(a + pad, 1.0 - 0.5 * head_h, name, fontsize=11.4,
                color=INK, ha="left", va="center", linespacing=1.5)
    ax.plot([0, 1], [1.0 - head_h] * 2, "-", color=GRAPHITE, lw=1.6,
            clip_on=False)

    for i, (model, npar, tdep, lle, extr, hl) in enumerate(R):
        y1 = 1.0 - head_h - i * row_h
        y0 = y1 - row_h
        if i % 2 == 0:
            ax.add_patch(Rectangle((0, y0), 1, row_h, facecolor=MIST,
                                   alpha=0.22, edgecolor="none", zorder=0))
        if hl:
            ax.add_patch(Rectangle((0, y0), 1, row_h, facecolor=RUST,
                                   alpha=0.10, edgecolor=RUST, lw=1.6,
                                   zorder=1))
        yc = 0.5 * (y0 + y1)
        cells = [(model, INK, 11.2), (npar, INK, 13.0),
                 (tdep, TEAL if tdep.startswith("YES") else SLATE, 11.0),
                 (lle, RUST if lle.startswith("NO") else TEAL, 10.6),
                 (extr, INK, 10.6)]
        for (txt, col, fs), (_, a, b) in zip(cells, COLS):
            ha = "center" if txt == npar else "left"
            xx = 0.5 * (a + b) if ha == "center" else a + pad
            ax.text(xx, yc, txt, fontsize=fs, color=col, ha=ha, va="center",
                    linespacing=1.55, zorder=4)
        ax.plot([0, 1], [y0] * 2, "-", color=MIST, lw=0.8, zorder=2)

    for _, a, b in COLS[1:]:
        ax.plot([a, a], [0, 1.0 - head_h + 0.5 * head_h], "-", color=MIST,
                lw=0.8, zorder=2)

    fig.text(0.5, 0.962,
             "What each $G^E$ model can do — every cell is the output of a "
             "calculation this script ran",
             ha="center", va="center", fontsize=16.5, color=INK)
    fig.text(0.5, 0.918,
             "reference system for the last two columns: ethanol (1) + "
             f"water (2) at 298.15 K, $\\gamma_1^\\infty$ = {d['g1ref']:.3f} "
             "from modified UNIFAC (Dortmund)",
             ha="center", va="center", fontsize=12.5, color=SLATE)

    w = d["lle"]["Wilson"]
    fig.text(0.5, 0.012, wrapped(
             "HOW EACH COLUMN WAS OBTAINED.  $T$ dependence: gE_RT evaluated "
             "at the same parameters at 298.15 and 348.15 K over 19 "
             "compositions; the number in the cell is the largest difference. "
             "Liquid-liquid: parameter sets are swept and "
             "`vlekit.flash.is_stable` / `flash.miscibility_gap` are called on "
             "each — "
             f"{NSWEEP}$\\times${NSWEEP} grids for Margules-2, van Laar, NRTL "
             f"and UNIQUAC, {NSWEEP ** 2} seeded random triples for "
             "Margules-3,\n"
             f"and {NWILSON}$\\times${NWILSON} = {w['tot']} log-spaced pairs "
             "over $\\Lambda \\in [10^{-3}, 50]$ for Wilson, which is the row "
             "that matters. Not one Wilson pair is unstable and the smallest "
             "$\\mathrm{d}^2\\Delta g_{\\rm mix}/\\mathrm{d}x_1^2$ found "
             "anywhere on that grid is "
             f"{w['min_d2']:+.2e}. Extrapolation: each model fitted by "
             "`vlekit.fit` (Barker) to nine points spanning $x_1$ = "
             f"{WINDOW[0]:.2f}-{WINDOW[1]:.2f} only, then asked for "
             "$\\gamma_1^\\infty$.\n"
             "The dataset is generated from the reference model with no "
             "noise, so the spread is model form alone. UNIQUAC $r$, $q$ are "
             "UNIFAC group sums stored on the components, not fitted. "
             "NOT A CALCULATION: the separate UNIFAC-LLE group-interaction "
             "table is verified here only by the presence of the file in the "
             f"installed `thermo` package — found: {d['has_lle_table']}.", 207),
             ha="center", va="bottom", fontsize=10.0, color=SLATE,
             linespacing=1.6)
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = make()
    print(f"reference: modified UNIFAC (Dortmund), ethanol/water at {T} K, "
          f"gamma_1^inf = {d['g1ref']:.4f}")
    print(f"  UNIQUAC r,q from groups: ethanol r={d['et'].r:.4f} "
          f"q={d['et'].q:.4f}, water r={d['wa'].r:.4f} q={d['wa'].q:.4f}")
    print()
    print("temperature dependence of gE_RT at FIXED parameters, "
          f"max|gE_RT({T2}) - gE_RT({T})| over 19 compositions:")
    for k, val in d["tdep"].items():
        print(f"    {k:14s} {val:.6e}")
    print()
    print("liquid-liquid sweeps (unstable = min d2(dgmix)/dx1^2 <= 0 "
          "on 801 points):")
    for k, s in d["lle"].items():
        e = ""
        if s["example"]:
            p, xa, xb = s["example"]
            e = ("  example " + ", ".join(f"{q:+.4f}" for q in p)
                 + f" -> split {xa:.4f} / {xb:.4f}")
        print(f"    {k:14s} {s['n']:6d} of {s['tot']:6d}   "
              f"min d2g/dx1^2 = {s['min_d2']:+.4e}{e}")
    print(f"    UNIFAC (original table), n-hexane/methanol: split "
          f"{d['uf_gap']['x1_phase_a']:.4f} / "
          f"{d['uf_gap']['x1_phase_b']:.4f} at {T} K, "
          f"{d['uf_gap2']['x1_phase_a']:.4f} / "
          f"{d['uf_gap2']['x1_phase_b']:.4f} at 318.15 K")
    print(f"    separate UNIFAC-LLE parameter table present in `thermo`: "
          f"{d['has_lle_table']}")
    print()
    print(f"extrapolation: fit on x1 = {WINDOW[0]}-{WINDOW[1]} only, then "
          f"gamma_1^inf (reference {d['g1ref']:.4f}):")
    for k, e in d["extrap"].items():
        ps = ", ".join(f"{n}={p:+.4f}" for n, p in zip(e["names"],
                                                       e["params"]))
        print(f"    {k:12s} window fit [{ps}] rms dP {e['rmsP']:.5g} kPa -> "
              f"gamma_1^inf {e['window']:7.3f} ({e['err']:+6.1f} %)   "
              f"full-range fit -> {e['full']:6.3f} ({e['err_full']:+5.1f} %)")
    print(f"    UNIFAC (original), predictive: {d['g1_unifac']:.4f} "
          f"({100 * (d['g1_unifac'] - d['g1ref']) / d['g1ref']:+.1f} %); "
          f"cross-check against thermo's own original-UNIFAC: "
          f"{d['g1_unifac_thermo']:.4f}")
    lo = min(e["window"] for e in d["extrap"].values())
    hi = max(e["window"] for e in d["extrap"].values())
    print(f"    spread of the six extrapolated gamma_1^inf: {lo:.3f} to "
          f"{hi:.3f}, i.e. {100 * (hi - lo) / d['g1ref']:.0f} percentage "
          f"points of the reference value")
    print(f"  [make() took {d['elapsed']:.1f} s]")
    for p in write(build(d), SLUG):
        print("wrote", p)
