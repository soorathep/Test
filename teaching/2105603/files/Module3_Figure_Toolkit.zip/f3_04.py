#!/usr/bin/env python3
"""F3.4  gamma_1 and gamma_2 are not two independent functions.

2105603 Advanced Chemical Engineering Thermodynamics — Module 3
Soorathep Kheawhom, Chulalongkorn University

The Gibbs-Duhem equation at constant T and P, written for a binary in the
variable every VLE table is tabulated in:

    x1 dln(gamma_1)/dx1 + x2 dln(gamma_2)/dx1 = 0

Two consequences, both drawn here:

  1. The two slopes always have opposite signs. Wherever one activity
     coefficient rises the other must fall — there is no composition at which
     both curves can go the same way.
  2. The ratio is not free either. Rearranged,

         -[dln(gamma_2)/dx1] / [dln(gamma_1)/dx1] = x1 / x2

     so at x1 = 0.15 the ratio of the slope magnitudes must be 0.1765, at
     x1 = 0.50 it must be 1, at x1 = 0.85 it must be 5.667. This script
     computes both sides at four compositions and prints them side by side.

Paired tangent segments are drawn at four compositions with their slopes on
the figure, the weighted contributions x1 s1 and x2 s2 are drawn as mirrored
bars, and the residual is plotted across the whole composition range.

WHY THE RESIDUAL IS NOT EXACTLY ZERO. Any model built from a single G^E
satisfies Gibbs-Duhem identically; what is left here is the truncation error
of the central difference used to get the slopes (h = 1e-6), and it is
~5e-10. To show that the constraint is a real and testable statement rather
than a tautology of the arithmetic, the same residual is recomputed with
ln(gamma_2) deliberately multiplied by 1.10 — a 10 % error in one of the two
curves and nothing else — and it rises by about eight orders of magnitude.
That perturbation is labelled on the figure as the artificial thing it is.

SYSTEM AND SOURCE. Ethanol (1) + water (2) at 298.15 K, activity coefficients
from modified UNIFAC (Dortmund) via `thermo.unifac.UNIFAC` with the DOUFIP2006
interaction table and DOUFSG subgroups. No parameter is fitted or assumed
here; the two species enter as UNIFAC subgroups (CH3 + CH2 + OH(P); H2O).

Run:  python3 f3_04.py
"""
from __future__ import annotations

import os
import sys

import numpy as np

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                   # noqa: E402

from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,       # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, use_style)

OUT = os.environ.get("F3_OUT", "/home/claude/vle3/qmd/figures")
SLUG = "f3_04_gibbs_duhem_tangents"

T = 298.15
H = 1e-6
X_TAN = (0.15, 0.35, 0.60, 0.85)
HALF = 0.075                      # half-length of a drawn tangent segment
PERTURB = 1.10                    # the deliberate 10 % error in ln gamma_2
CHEMGROUPS = [{1: 1, 2: 1, 14: 1}, {16: 1}]


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def wrapped(text, width):
    """Wrap a caption on spaces, never inside a $...$ span.

    `bbox_inches='tight'` grows the canvas around any text that overflows the
    figure, which silently rescales everything else on the slide. Wrapping the
    footnote to the figure width is the only way to keep the rendered PNG the
    size the script asked for.
    """
    out = []
    for para in text.split("\n"):
        cur, n, inmath = [], 0, False
        for w in para.split(" "):
            if cur and not inmath and n + 1 + len(w) > width:
                out.append(" ".join(cur))
                cur, n = [], 0
            cur.append(w)
            n += len(w) + (1 if n else 0)
            if w.count("$") % 2 == 1:
                inmath = not inmath
        out.append(" ".join(cur))
    return "\n".join(out)



# --------------------------------------------------------------------------
def ln_gamma(x1):
    from thermo.unifac import UNIFAC, DOUFIP2006, DOUFSG
    x1 = float(x1)
    m = UNIFAC.from_subgroups(T=T, xs=[x1, 1 - x1], chemgroups=CHEMGROUPS,
                              version=1, interaction_data=DOUFIP2006,
                              subgroups=DOUFSG)
    a = m.lngammas()
    return float(a[0]), float(a[1])


def slopes(x1, h=H, k2=1.0):
    p1, p2 = ln_gamma(x1 + h)
    m1, m2 = ln_gamma(x1 - h)
    return (p1 - m1) / (2 * h), k2 * (p2 - m2) / (2 * h)


def make():
    xs = np.linspace(0.004, 0.996, 249)
    lg = np.array([ln_gamma(x) for x in xs])

    xr = np.linspace(0.02, 0.98, 97)
    s = np.array([slopes(x) for x in xr])
    res = xr * s[:, 0] + (1 - xr) * s[:, 1]
    sp = np.array([slopes(x, k2=PERTURB) for x in xr])
    res_p = xr * sp[:, 0] + (1 - xr) * sp[:, 1]

    tan = []
    for x in X_TAN:
        l1, l2 = ln_gamma(x)
        s1, s2 = slopes(x)
        tan.append(dict(x=x, l1=l1, l2=l2, s1=s1, s2=s2,
                        w1=x * s1, w2=(1 - x) * s2, sum=x * s1 + (1 - x) * s2,
                        ratio=-s2 / s1, xratio=x / (1 - x)))

    g1inf = float(np.exp(ln_gamma(1e-9)[0]))
    g2inf = float(np.exp(ln_gamma(1 - 1e-9)[1]))

    return dict(xs=xs, lg=lg, xr=xr, res=res, res_p=res_p, tan=tan,
                worst=float(np.max(np.abs(res))),
                worst_p=float(np.max(np.abs(res_p))),
                g1inf=g1inf, g2inf=g2inf)


# --------------------------------------------------------------------------
def build(d):
    use_style()
    fig = plt.figure(figsize=(15.2, 10.0))
    gs = fig.add_gridspec(2, 2, height_ratios=[1.60, 1.0],
                          width_ratios=[1.0, 1.0],
                          left=0.056, right=0.988, top=0.858, bottom=0.180,
                          hspace=0.36, wspace=0.20)
    ax = fig.add_subplot(gs[0, :])
    ab = fig.add_subplot(gs[1, 0])
    ar = fig.add_subplot(gs[1, 1])
    for a in (ax, ab, ar):
        a.grid(True, zorder=0)
        a.set_axisbelow(True)

    # ================================================= the two curves
    ax.plot(d["xs"], d["lg"][:, 0], "-", color=AMBER, lw=3.0, zorder=5,
            label=r"$\ln\gamma_1$  (ethanol)")
    ax.plot(d["xs"], d["lg"][:, 1], "-", color=TEAL, lw=3.0, zorder=5,
            label=r"$\ln\gamma_2$  (water)")
    ax.axhline(0.0, color=GRAPHITE, lw=1.1, zorder=3)
    ax.set_xlim(0, 1)
    ax.set_ylim(-0.10, 2.42)
    ax.set_xlabel("$x_1$   (mole fraction ethanol)")
    ax.set_ylabel(r"$\ln\gamma_i$")
    ax.legend(loc="center right", fontsize=12.0, labelspacing=0.6,
              bbox_to_anchor=(0.988, 0.50))

    box_x = (0.004, 0.252, 0.500, 0.748)
    for t, bx in zip(d["tan"], box_x):
        x = t["x"]
        ax.plot([x, x], [t["l2"], t["l1"]], ":", color=SLATE, lw=1.0, zorder=3)
        for l, sl, col in ((t["l1"], t["s1"], AMBER), (t["l2"], t["s2"], TEAL)):
            xa, xb = x - HALF, x + HALF
            ax.annotate("", xy=(xb, l + sl * HALF), xytext=(xa, l - sl * HALF),
                        arrowprops=dict(arrowstyle="<|-|>", color=col, lw=2.4,
                                        mutation_scale=16, shrinkA=0,
                                        shrinkB=0), zorder=8)
            ax.plot([x], [l], "o", color=col, ms=8, mec=PAPER, mew=1.5,
                    zorder=9)

        ax.annotate(
            f"$x_1$ = {x:.2f}\n"
            f"slopes  {t['s1']:+.3f}  /  {t['s2']:+.3f}\n"
            f"$-s_2/s_1$ = {t['ratio']:.4f} = $x_1/x_2$",
            xy=(x, t["l1"] + t["s1"] * HALF * 0.35), xytext=(bx, 0.995),
            textcoords="axes fraction", ha="left", va="top", fontsize=11.0,
            color=INK,
            zorder=11, linespacing=1.45,
            bbox=dict(boxstyle="round,pad=0.24", fc=PAPER, ec=GRAPHITE,
                      lw=1.0, alpha=0.96),
            arrowprops=dict(arrowstyle="-", color=SLATE, lw=1.0, shrinkA=5,
                            shrinkB=5))

    ax.annotate("wherever one curve rises the other falls,\n"
                "and the ratio of the slopes is fixed by $x_1/x_2$",
                xy=(0.50, 1.62), xytext=(0.50, 1.62), ha="center", va="center",
                fontsize=12.5, color=RUST, zorder=11, linespacing=1.5,
                bbox=dict(boxstyle="round,pad=0.28", fc=PAPER, ec=RUST,
                          lw=1.1, alpha=0.96))

    # =============================================== the weighted bars
    ypos = np.arange(len(d["tan"]))[::-1]
    hgt = 0.32
    for y, t in zip(ypos, d["tan"]):
        ab.barh(y + 0.5 * hgt + 0.02, t["w1"], height=hgt, color=AMBER,
                zorder=4)
        ab.barh(y - 0.5 * hgt - 0.02, t["w2"], height=hgt, color=TEAL,
                zorder=4)
        ab.text(1.32, y, f"sum = {t['sum']:+.1e}", fontsize=10.6,
                color=GRAPHITE, ha="right", va="center", zorder=8)
    ab.axvline(0.0, color=GRAPHITE, lw=1.2, zorder=5)
    ab.set_yticks(ypos)
    ab.set_yticklabels([f"$x_1$ = {t['x']:.2f}" for t in d["tan"]])
    ab.set_xlim(-0.80, 1.36)
    ab.set_ylim(-0.62, len(d["tan"]) - 0.38)
    ab.set_xlabel("weighted slope")
    ab.set_title("$x_1\\,\\mathrm{d}\\ln\\gamma_1/\\mathrm{d}x_1$ (amber) and "
                 "$x_2\\,\\mathrm{d}\\ln\\gamma_2/\\mathrm{d}x_1$ (teal):\n"
                 "equal and opposite at every composition, not approximately",
                 fontsize=12.2, pad=7, loc="left", x=0.0)

    # ==================================================== the residual
    ar.semilogy(d["xr"], np.abs(d["res_p"]), "-", color=RUST, lw=2.4,
                zorder=5,
                label=f"same, after multiplying $\\ln\\gamma_2$ by "
                      f"{PERTURB:.2f}")
    ar.semilogy(d["xr"], np.abs(d["res"]), "-", color=NAVY, lw=2.4, zorder=6,
                label="$|x_1s_1 + x_2s_2|$ from the model")
    ar.set_xlim(0, 1)
    ar.set_ylim(1e-12, 3e0)
    ar.set_xlabel("$x_1$")
    ar.set_ylabel("$|x_1 s_1 + x_2 s_2|$")
    ar.set_title("the residual, on a log axis", fontsize=12.5, pad=7,
                 loc="left", x=0.0)
    ar.text(0.030, 0.66, "after multiplying $\\ln\\gamma_2$ by "
            f"{PERTURB:.2f} — a deliberate error",
            transform=ar.transAxes, fontsize=10.8, color=RUST, ha="left",
            va="bottom", zorder=8,
            bbox=dict(boxstyle="round,pad=0.18", fc=PAPER, ec="none",
                      alpha=0.92))
    ar.text(0.030, 0.24, "from the model", transform=ar.transAxes,
            fontsize=10.8, color=NAVY, ha="left", va="bottom", zorder=8,
            bbox=dict(boxstyle="round,pad=0.18", fc=PAPER, ec="none",
                      alpha=0.92))

    fig.text(0.5, 0.968,
             r"$x_1\,\mathrm{d}\ln\gamma_1/\mathrm{d}x_1 + "
             r"x_2\,\mathrm{d}\ln\gamma_2/\mathrm{d}x_1 = 0$:  "
             "the second activity coefficient is not free",
             ha="center", va="center", fontsize=16.5, color=INK)
    fig.text(0.5, 0.925,
             f"ethanol (1) + water (2) at {T:.2f} K, modified UNIFAC "
             f"(Dortmund);  $\\gamma_1^\\infty$ = {d['g1inf']:.3f}, "
             f"$\\gamma_2^\\infty$ = {d['g2inf']:.3f}",
             ha="center", va="center", fontsize=12.5, color=SLATE)

    fig.text(0.5, 0.012, wrapped(
             "Activity coefficients from `thermo.unifac.UNIFAC`, DOUFIP2006 "
             "table, DOUFSG subgroups; nothing fitted, nothing assumed. "
             f"Slopes by central difference, $h$ = {H:g}. The $\\times$"
             f"{PERTURB:.2f} curve in the right-hand panel is a DELIBERATE "
             "ARTIFICIAL ERROR introduced to show the constraint has "
             "content: it is not a property of any fluid.\n"
             f"Residual from the model: max {d['worst']:.1e} over 97 "
             f"compositions — the truncation error of the difference, not "
             f"physics. With the 10 % error in $\\ln\\gamma_2$: max "
             f"{d['worst_p']:.3f}, {d['worst_p'] / d['worst']:.0e} times "
             "larger.", 184),
             ha="center", va="bottom", fontsize=10.2, color=SLATE,
             linespacing=1.6)
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = make()
    print(f"ethanol (1) + water (2) at {T} K, modified UNIFAC (Dortmund)")
    print(f"  gamma_1^inf = {d['g1inf']:.4f},  gamma_2^inf = {d['g2inf']:.4f}")
    print(f"  slopes by central difference with h = {H:g}")
    print("     x1    ln g1     ln g2      s1        s2      x1 s1     "
          "x2 s2       sum        -s2/s1     x1/x2")
    for t in d["tan"]:
        print(f"   {t['x']:.2f}  {t['l1']:+7.4f}  {t['l2']:+7.4f}  "
              f"{t['s1']:+8.4f}  {t['s2']:+7.4f}  {t['w1']:+8.5f}  "
              f"{t['w2']:+8.5f}  {t['sum']:+10.3e}  {t['ratio']:9.5f}  "
              f"{t['xratio']:9.5f}")
    print(f"  max |x1 s1 + x2 s2| over 97 compositions: {d['worst']:.3e}")
    print(f"  same after multiplying ln(gamma_2) by {PERTURB:g}: "
          f"{d['worst_p']:.4f}  "
          f"({d['worst_p'] / d['worst']:.2e} times larger)")
    for p in write(build(d), SLUG):
        print("wrote", p)
