"""f29_mean_activity -- mean ionic activity coefficient vs sqrt(ionic
strength). Two curves are real, standard textbook correlations for a 1:1
aqueous electrolyte at 25 C (constants stated below); the third
(concentrated-electrolyte upturn) is SCHEMATIC/ILLUSTRATIVE and labelled
as such.

Debye-Huckel limiting law:      log10(gamma_pm) = -A |z+ z-| sqrt(I)
Extended Debye-Huckel:          log10(gamma_pm) = -A |z+ z-| sqrt(I) / (1 + B a_ion sqrt(I))
  A = 0.509 (mol/L)^-1/2, B = 0.328 (mol/L)^-1/2 angstrom^-1 (water, 25 C,
  standard values, e.g. Sandler 2017 / Prausnitz et al. 1999, SPEC.md
  reference list); a_ion = 4.0 angstrom (typical Kielland ion-size
  parameter); z+ = z- = 1 (1:1 electrolyte).

Concentrated-electrolyte curve: extended DH plus an illustrative linear
"salting-out" term C*I with C chosen only to produce a qualitative minimum
and upturn (SCHEMATIC, not fitted to any real salt).
"""
import sys
sys.path.insert(0, "/home/claude/eos_lecture/code")
from eosstyle import *

A = 0.509
B = 0.328
a_ion = 4.0
z = 1

I = np.linspace(0.0001, 4.0, 400)
sqrtI = np.sqrt(I)

log_g_dhll = -A * z**2 * sqrtI
log_g_edh  = -A * z**2 * sqrtI / (1 + B * a_ion * sqrtI)

C_illustrative = 0.12
log_g_conc = log_g_edh + C_illustrative * I

# Canvas widened and made taller (8.0 x 6.0 in) purely to open up clean
# regions for the annotations; the annotation point size is raised in step
# (10.5 -> 12.0) so the font-size / canvas-width ratio is unchanged.
fig, ax = newfig(8.0, 6.0)

FS_ANN = 12.0

ax.plot(sqrtI, log_g_dhll, color=NAVY, lw=2.1)
ax.plot(sqrtI, log_g_edh, color=SKYBLUE, lw=2.1)
ax.plot(sqrtI, log_g_conc, color=AMBER, lw=2.1)
ax.axhline(0.0, color=MIST, lw=1.0, zorder=1)

# Each label lives in a region no curve enters, and every leader leaves its
# text block on the side facing its own curve:
#   * concentrated-electrolyte label -> band above all three curves
#   * extended DH label              -> wedge between the extended-DH and
#                                       limiting-law curves, at the right
#                                       where that wedge is widest
#   * limiting-law label             -> open area below the limiting law
ax.annotate("Debye-Huckel limiting law\n" r"$\log_{10}\gamma_\pm=-A\sqrt{I}$",
            xy=(0.55, np.interp(0.55, sqrtI, log_g_dhll)), xytext=(0.68, -0.62),
            fontsize=FS_ANN, color=NAVY, ha="center", va="top", linespacing=1.35,
            arrowprops=dict(arrowstyle="-", color=NAVY, lw=0.9))
ax.annotate("extended Debye-Huckel\n" r"$\log_{10}\gamma_\pm=-A\sqrt{I}/(1+Ba\sqrt{I})$",
            xy=(1.55, np.interp(1.55, sqrtI, log_g_edh)), xytext=(1.655, -0.40),
            fontsize=FS_ANN, color=SKYBLUE, ha="center", va="top", linespacing=1.35,
            arrowprops=dict(arrowstyle="-", color=SKYBLUE, lw=0.9))
ax.annotate("concentrated electrolyte: ion pairing and\nhydration deplete free water, "
            r"$\gamma_\pm$"
            "\npasses through a minimum and rises again",
            xy=(1.80, np.interp(1.80, sqrtI, log_g_conc)), xytext=(2.02, 0.30),
            fontsize=FS_ANN, color=AMBER, ha="right", va="bottom", linespacing=1.35,
            arrowprops=dict(arrowstyle="-", color=AMBER, lw=0.9))

# caption box: three lines so it no longer runs past the right end of the
# axes, parked in the empty corner well below the limiting-law line
ax.text(0.025, 0.03, "concentrated-electrolyte curve is schematic (illustrative);\n"
        "DH limiting law and extended DH use\n"
        "standard $A=0.509$, $B=0.328$ (water, 25$^\\circ$C)",
        transform=ax.transAxes, ha="left", va="bottom", fontsize=FS_ANN, color=RUST,
        linespacing=1.4,
        bbox=dict(boxstyle="round,pad=0.3", fc="white", ec=RUST, lw=1.1))

ax.set_xlabel(r"$\sqrt{I}$   [(mol L$^{-1}$)$^{1/2}$]")
ax.set_ylabel(r"$\log_{10}\gamma_\pm$")
ax.set_xlim(0, 2.05)
ax.set_ylim(-1.55, 0.70)

save(fig, "f29_mean_activity")
