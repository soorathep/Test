"""f27_saft_vs_cubic -- SCHEMATIC (ILLUSTRATIVE) comparison of predicted
saturated liquid density for a strongly associating fluid (e.g. an
alcohol): a cubic EOS (navy, no association term) systematically
overpredicts the liquid molar volume, while a molecular/SAFT-type EOS
(amber, carries a_assoc) tracks a "reference" curve closely. No real
cubic or SAFT calculation, no real substance data: all three curves are
smooth illustrative shapes only, explicitly labelled as such.
"""
import sys
sys.path.insert(0, "/home/claude/eos_lecture/code")
from eosstyle import *

Tr = np.linspace(0.5, 0.98, 200)

# illustrative shapes only (not computed from any EOS or dataset)
V_ref   = 60 + 140 * Tr**2.2                 # "reference" liquid volume trend
V_cubic = V_ref + 55 * (1 - 0.5*Tr) * (Tr - 0.35)   # cubic: high-side bias, worst at low Tr
V_saft  = V_ref + 4 * np.sin(3*Tr) * (1 - Tr)       # SAFT-type: closely tracks reference

fig, ax = newfig(6.8, 4.6)

ax.plot(Tr, V_ref, color=GRAPHITE, lw=1.8, linestyle=(0, (4, 2)))
ax.plot(Tr, V_cubic, color=NAVY, lw=2.2)
ax.plot(Tr, V_saft, color=AMBER, lw=2.2)

ax.annotate("reference (e.g. experiment)", xy=(0.565, np.interp(0.565, Tr, V_ref)),
            xytext=(0.52, 215), fontsize=10.5, color=GRAPHITE, ha="left", va="center",
            arrowprops=dict(arrowstyle="-", color=GRAPHITE, lw=0.9))
ax.annotate("cubic EOS: overpredicts\nliquid volume (no association term)",
            xy=(0.86, np.interp(0.86, Tr, V_cubic)), xytext=(0.52, 190),
            fontsize=10.5, color=NAVY, ha="left", va="center", linespacing=1.3,
            arrowprops=dict(arrowstyle="-", color=NAVY, lw=0.9))
ax.annotate("SAFT-type EOS: tracks the reference\n"
            r"($a_{assoc}$ captures H-bonding)",
            xy=(0.90, np.interp(0.90, Tr, V_saft)), xytext=(0.52, 65),
            fontsize=10.5, color=AMBER, ha="left", va="center", linespacing=1.3,
            arrowprops=dict(arrowstyle="-", color=AMBER, lw=0.9))

ax.text(0.03, 0.97, "schematic (illustrative)\nnot a real cubic or SAFT calculation",
        transform=ax.transAxes, ha="left", va="top", fontsize=10.5, color=RUST,
        weight="bold", linespacing=1.35,
        bbox=dict(boxstyle="round,pad=0.35", fc="white", ec=RUST, lw=1.3))

ax.set_xlabel(r"Reduced temperature, $T_r$")
# single line was taller than the axes and got clipped mid-word; two lines fit
ax.set_ylabel("Saturated liquid molar volume\n(illustrative units)", linespacing=1.4)
ax.set_xlim(0.5, 0.98)
ax.set_ylim(50, 260)

save(fig, "f27_saft_vs_cubic")
