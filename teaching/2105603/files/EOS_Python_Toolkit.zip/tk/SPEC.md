# SHARED DESIGN SPEC — "Evolution of Equations of State: A Physics-Driven Perspective"

Graduate lecture package (M.Sc./Ph.D. Chemical Engineering). All contributors MUST
follow this file exactly so the notes, slides and figures form one coherent package.

## 0. Author / course context
- Course: Advanced Chemical Engineering Thermodynamics (graduate level).
- Register: formal, objective, textbook-grade. US English. **NO em dashes anywhere.**
  Use commas, colons, semicolons or parentheses instead.
- Avoid informal expressions, storytelling, and analogies used as substitutes for physics.
- Every chapter answers the six pedagogical questions:
  (1) What problem existed? (2) Why did the previous EOS fail? (3) What new physics
  was introduced? (4) How was the mathematics modified? (5) What limitations remain?
  (6) Why was another EOS developed?

## 1. Colour palette (fixed)
Academic blue/gray on white. Hex values:

| role | name | hex |
|---|---|---|
| text | ink | #1C242B |
| axes, rules, reference lines (never pure black) | graphite | #333F4A |
| secondary text, captions | slate | #66727C |
| gridlines, light fills | mist | #B9C1C6 |
| background | paper | #FFFFFF |
| primary accent (titles, headers, main curve) | navy | #1F4E79 |
| secondary curve / data series 2 | skyblue | #5A91BE |
| emphasis, "the new physics", highlighted result | amber | #E29A2D |
| tertiary series | teal | #0F6E6B |
| negative deviation / attraction | rust | #BE654C |
| shaded bands, CI, two-phase region fill | sand | #DFC98F |

Categorical series order: navy, amber, teal, skyblue, rust, slate.
Semantics held constant across the whole package:
- **navy** = the reference / ideal / previous model
- **amber** = the new physics being introduced on that slide or figure
- **rust** = attractive forces; **teal** = repulsive / excluded volume
- **sand** = two-phase envelope shading

## 2. Typography
- Slides: Calibri (fallback Arial). Title 30 pt bold navy; body 18-20 pt ink;
  equations rendered as images (see §4); captions 12 pt slate.
- Notes (LaTeX): 11 pt, Times-like (mathptmx), \geometry{a4paper, margin=2.4cm}.
  Section headings navy, small-caps-ish via titlesec.
- Numbers: use SI units, `\SI{}{}` in LaTeX. R = 8.314 J mol^-1 K^-1.

## 3. Figure rules (matplotlib)
- Output BOTH `figs/<name>.pdf` (for LaTeX) and `figs/<name>.png` at 600 dpi (for PPTX).
- White background, no top/right spines, graphite spines of width 0.9,
  gridlines mist at alpha 0.5 and linewidth 0.6, ink tick labels.
- Line width >= 1.8 pt, marker size >= 5 pt. Font size 11 (labels), 10 (ticks).
- No titles inside the figure (the slide/caption supplies the title) UNLESS the figure is
  a schematic/concept map where an internal heading aids reading.
- Default size 6.4 x 4.2 in for plots; schematics may use 8 x 4.5 in.
- Label curves directly on the plot where possible instead of using a legend box.

## 4. Equation rendering for slides
Equations on slides are rendered with matplotlib mathtext to transparent-background PNG at
600 dpi and placed as pictures. Helper: `code/eqpng.py`, function
`eq(latex_string, outfile, fontsize=28, color="#1C242B")`.

## 5. Notation (use identically everywhere)
- P pressure, T temperature, V molar volume (underline omitted, state "molar volume"),
  v = V/N when a distinction is needed, rho = 1/V molar density, n moles.
- Z = PV/(RT) compressibility factor.
- a, b: attraction and co-volume parameters. alpha(T) or alpha(T_r, omega): the
  temperature-dependent alpha function.
- T_r = T/T_c, P_r = P/P_c, V_r = V/V_c reduced properties.
- omega Pitzer acentric factor; omega = -1 - log10(P_r^sat at T_r = 0.7).
- B, C: second and third virial coefficients (volume-explicit expansion),
  B', C': pressure-series coefficients.
- phi fugacity coefficient, f fugacity, mu chemical potential, K_i = y_i/x_i.
- A = aP/(R^2 T^2), B = bP/(RT) dimensionless EOS groups (state explicitly when used
  to avoid clash with virial B; in the virial chapter use B_2 for the virial coefficient).
- SAFT: a_res = a_hs + a_chain + a_disp + a_assoc; segment number m, segment diameter
  sigma, segment energy epsilon/k, association energy epsilon^AB/k, association volume kappa^AB.

## 6. Canonical chapter storyline (13 chapters)
1. Why an EOS? PVT closure, density, fugacity/phase equilibrium, process simulation.
2. Ideal gas: point particles, no interactions. Fails at high rho and near saturation.
3. van der Waals 1873: excluded volume + mean-field attraction; cubic; critical point.
4. Compressibility factor Z: the deviation bookkeeper; Z<1 attraction-dominated,
   Z>1 repulsion-dominated; Boyle temperature; generalized charts.
5. Virial: rigorous density expansion from statistical mechanics; B_2 from the pair
   potential; truncation limits it to moderate density.
6. Corresponding states: two-parameter universality; works for simple fluids, fails for
   polar/elongated/hydrogen-bonding molecules.
7. Pitzer acentric factor: third parameter capturing non-sphericity via the vapour
   pressure slope.
8. Redlich-Kwong 1949: a/sqrt(T) temperature dependence; better vapour-phase Z, poor
   liquid density and no omega.
9. Soave 1972: replaces a/sqrt(T) with a_c alpha(T_r, omega) fitted to vapour pressures,
   enabling quantitative VLE.
10. Peng-Robinson 1976: modified volume dependence improves liquid density and Z_c;
    industrial standard; RK vs SRK vs PR comparison.
11. SAFT: perturbation theory on a molecular reference; hard sphere + chain + dispersion
    + association; PC-SAFT (Gross-Sadowski 2001); transferable molecular parameters.
12. Electrolyte EOS: long-range Coulomb, Born solvation, MSA/DH terms, ion pairing,
    hydration; eSAFT/ePC-SAFT; battery electrolyte applications.
13. Future: molecular simulation, ML/physics-informed EOS, thermodynamic-consistency
    constraints, electrochemical thermodynamics.

## 7. Reference list (canonical, cite by these keys)
- Smith, Van Ness, Abbott & Swihart, *Introduction to Chemical Engineering Thermodynamics*, 9th ed., McGraw-Hill, 2022.
- Prausnitz, Lichtenthaler & de Azevedo, *Molecular Thermodynamics of Fluid-Phase Equilibria*, 3rd ed., Prentice Hall, 1999.
- Poling, Prausnitz & O'Connell, *The Properties of Gases and Liquids*, 5th ed., McGraw-Hill, 2001.
- Sandler, *Chemical, Biochemical, and Engineering Thermodynamics*, 5th ed., Wiley, 2017.
- Kontogeorgis & Folas, *Thermodynamic Models for Industrial Applications*, Wiley, 2010.
- van der Waals, doctoral thesis, Leiden, 1873.
- Redlich & Kwong, *Chem. Rev.* 44 (1949) 233.
- Pitzer et al., *J. Am. Chem. Soc.* 77 (1955) 3427 and 3433.
- Soave, *Chem. Eng. Sci.* 27 (1972) 1197.
- Peng & Robinson, *Ind. Eng. Chem. Fundam.* 15 (1976) 59.
- Chapman, Gubbins, Jackson & Radosz, *Ind. Eng. Chem. Res.* 29 (1990) 1709.
- Gross & Sadowski, *Ind. Eng. Chem. Res.* 40 (2001) 1244.
- Wertheim, *J. Stat. Phys.* 35 (1984) 19, 35 (1984) 35, 42 (1986) 459, 42 (1986) 477.
- Mathias & Copeman, *Fluid Phase Equilib.* 13 (1983) 91.
- Peneloux, Rauzy & Freze, *Fluid Phase Equilib.* 8 (1982) 7.
- Held, Reschke, Mohammad, Luza & Sadowski, *Chem. Eng. Res. Des.* 92 (2014) 2884 (ePC-SAFT).

## 8. Numerical constants used in examples (fix these values everywhere)
R = 8.314 J mol^-1 K^-1 = 83.14 cm^3 bar mol^-1 K^-1.

| species | T_c / K | P_c / bar | omega |
|---|---|---|---|
| methane | 190.6 | 45.99 | 0.012 |
| ethane | 305.3 | 48.72 | 0.100 |
| propane | 369.8 | 42.48 | 0.152 |
| n-butane | 425.1 | 37.96 | 0.200 |
| CO2 | 304.2 | 73.83 | 0.224 |
| nitrogen | 126.2 | 34.00 | 0.038 |
| water | 647.1 | 220.55 | 0.345 |
| ammonia | 405.7 | 112.80 | 0.253 |
| benzene | 562.2 | 48.98 | 0.210 |

Cubic EOS constants:
- vdW: a = 27 R^2 T_c^2 / (64 P_c), b = R T_c / (8 P_c), Z_c = 3/8 = 0.375
- RK: a = 0.42748 R^2 T_c^2.5 / P_c, b = 0.08664 R T_c / P_c, Z_c = 1/3 = 0.3333
- SRK: a_c = 0.42748 R^2 T_c^2 / P_c, b = 0.08664 R T_c / P_c,
  alpha = [1 + m(1 - sqrt(T_r))]^2, m = 0.480 + 1.574 omega - 0.176 omega^2, Z_c = 0.3333
- PR: a_c = 0.45724 R^2 T_c^2 / P_c, b = 0.07780 R T_c / P_c,
  alpha = [1 + kappa(1 - sqrt(T_r))]^2, kappa = 0.37464 + 1.54226 omega - 0.26992 omega^2,
  Z_c = 0.3074

**Every numerical result must be computed in Python, not estimated by hand.**
