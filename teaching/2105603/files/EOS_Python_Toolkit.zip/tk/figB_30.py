"""f30_battery_electrolyte -- concept map: electrolyte EOS outputs
(activity coefficients, solvation structure, transference, solubility
limits) mapped to battery design targets (voltage window, SEI chemistry,
salt precipitation, low-temperature operation). Left-to-right reading
order. Pure schematic (matplotlib primitives only).
"""
import sys
sys.path.insert(0, "/home/claude/eos_lecture/code")
from eosstyle import *
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

fig, ax = blank(11.5, 6.4)

def box(cx, cy, w, h, text, fc=PAPER, ec=GRAPHITE, tc=INK, fs=10.2, lw=1.2, weight="normal"):
    b = FancyBboxPatch((cx - w/2, cy - h/2), w, h,
                        boxstyle="round,pad=0.012,rounding_size=0.018",
                        linewidth=lw, edgecolor=ec, facecolor=fc, zorder=3)
    ax.add_patch(b)
    ax.text(cx, cy, text, ha="center", va="center", fontsize=fs, color=tc,
             zorder=4, weight=weight, linespacing=1.3)
    return b

def arrow(p0, p1, color=GRAPHITE, lw=1.6):
    a = FancyArrowPatch(p0, p1, arrowstyle="-|>", mutation_scale=13,
                         linewidth=lw, color=color, zorder=2,
                         shrinkA=2, shrinkB=2, connectionstyle="arc3,rad=0.0")
    ax.add_patch(a)

cx0 = 0.115
box(cx0, 0.52, 0.17, 0.24, "Electrolyte EOS\n(eSAFT / ePC-SAFT)", fc=NAVY, tc="white",
    fs=11.5, weight="bold")

outputs = [
    (0.375, 0.855, "Mean ionic activity\ncoefficients $\\gamma_\\pm$"),
    (0.375, 0.635, "Solvation structure\n(hydration, ion pairing)"),
    (0.375, 0.415, "Ion transference\nnumbers $t_+$"),
    (0.375, 0.185, "Salt solubility limits\n(saturation, $K_{sp}$)"),
]
targets = [
    (0.855, 0.855, "Electrochemical\nvoltage window"),
    (0.855, 0.635, "SEI\nchemistry / stability"),
    (0.855, 0.415, "Salt precipitation\nrisk"),
    (0.855, 0.185, "Low-temperature\noperating limit"),
]

for (ox, oy, otxt), (tx, ty, ttxt) in zip(outputs, targets):
    box(ox, oy, 0.235, 0.145, otxt, fc=AMBER, ec=GRAPHITE, tc="white", fs=9.6)
    box(tx, ty, 0.225, 0.145, ttxt, fc="#F4F6F7", ec=GRAPHITE, tc=INK, fs=9.6)
    arrow((cx0 + 0.088, 0.52 + (oy - 0.52)*0.35), (ox - 0.122, oy), color=GRAPHITE, lw=1.3)
    arrow((ox + 0.122, oy), (tx - 0.117, ty), color=GRAPHITE, lw=1.3)

ax.text(cx0, 0.855 + 0.0, "", alpha=0)  # spacer no-op
ax.text(0.115, 0.99, "input", ha="center", va="top", fontsize=10.5, color=SLATE, style="italic")
ax.text(0.375, 0.99, "electrolyte-property outputs", ha="center", va="top", fontsize=10.5, color=SLATE, style="italic")
ax.text(0.855, 0.99, "battery design targets", ha="center", va="top", fontsize=10.5, color=SLATE, style="italic")

ax.text(0.5, 1.09, "From electrolyte thermodynamics to battery design",
        ha="center", va="top", fontsize=13.5, color=NAVY, weight="bold")
ax.set_ylim(0, 1.12)

save(fig, "f30_battery_electrolyte")
