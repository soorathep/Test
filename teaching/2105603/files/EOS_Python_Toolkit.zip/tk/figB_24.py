"""f24_model_compare -- heat-map style comparison table: rows vdW, RK, SRK,
PR; columns vapour Z, liquid density, vapour pressure, near-critical
behaviour, polar/associating fluids, computational cost. Cell shading runs
mist (poor) to navy (good).

Ratings are a qualitative pedagogical synthesis of the well-established,
textbook-level characterisation of these four cubic EOS (consistent with
SPEC.md section 6 storyline and with the quantitative comparisons computed
in f19-f23 of this package: PR's lower Z_c and volume-translation-like
behaviour giving better liquid density, none of the four cubics carrying
polar/association terms, etc.), not a numerical score computed from a
single metric. Encoded on a 0(poor)-3(excellent) scale for the colour map.
"""
import sys
sys.path.insert(0, "/home/claude/eos_lecture/code")
from eosstyle import *
from matplotlib.colors import LinearSegmentedColormap

rows = ["vdW (1873)", "RK (1949)", "SRK (1972)", "PR (1976)"]
cols = ["Vapour $Z$", "Liquid\ndensity", "Vapour\npressure", "Near-critical\nbehaviour",
        "Polar /\nassociating", "Computational\ncost"]

# scale: 0 = poor, 1 = fair, 2 = good, 3 = excellent (cost column: 3 = cheapest)
score = np.array([
    #  Z    rho    Psat   crit   polar  cost
    [1,     0,     0,     1,     0,     3],   # vdW
    [2,     1,     1,     1,     0,     3],   # RK
    [2,     1,     2,     1,     0,     3],   # SRK
    [2,     2,     2,     2,     0,     3],   # PR
])
labels = np.array([
    ["fair", "poor", "poor", "fair", "none", "excellent"],
    ["good", "fair", "fair", "fair", "none", "excellent"],
    ["good", "fair", "good", "fair", "none", "excellent"],
    ["good", "good", "good", "good", "none", "excellent"],
])

cmap = LinearSegmentedColormap.from_list("mist_navy", [MIST, "#7C97AA", "#3D6B8F", NAVY])

fig, ax = newfig(9.2, 4.6)
ax.grid(False)
ax.set_xlim(0, len(cols))
ax.set_ylim(0, len(rows))
ax.set_xticks([])
ax.set_yticks([])
for spine in ax.spines.values():
    spine.set_visible(False)

for i, row in enumerate(rows):
    yc = len(rows) - 1 - i
    for j, col in enumerate(cols):
        c = cmap(score[i, j] / 3)
        ax.add_patch(plt.Rectangle((j, yc), 1, 1, facecolor=c, edgecolor="white", linewidth=2.0))
        txt_color = "white" if score[i, j] >= 2 else INK
        ax.text(j + 0.5, yc + 0.5, labels[i, j], ha="center", va="center",
                fontsize=10.5, color=txt_color, weight="medium")
    ax.text(-0.15, yc + 0.5, row, ha="right", va="center", fontsize=10.5, color=INK, weight="bold")

for j, col in enumerate(cols):
    ax.text(j + 0.5, len(rows) + 0.12, col, ha="center", va="bottom", fontsize=10.5, color=GRAPHITE,
            linespacing=1.2)

ax.set_xlim(-1.40, len(cols) + 0.1)
ax.set_ylim(-1.05, len(rows) + 0.65)

# colour-scale key along the bottom: mist (poor) -> navy (good/excellent)
key_labels = ["poor", "fair", "good", "excellent"]
kx0, ky0, kw = 0.0, -0.85, 0.9
for k in range(4):
    c = cmap(k / 3)
    ax.add_patch(plt.Rectangle((kx0 + k*kw, ky0), kw*0.86, 0.42, facecolor=c,
                                 edgecolor="white", linewidth=1.2))
    ax.text(kx0 + k*kw + kw*0.43, ky0 - 0.10, key_labels[k], ha="center", va="top",
            fontsize=10.5, color=GRAPHITE)
ax.text(kx0 - 0.15, ky0 + 0.21, "rating:", ha="right", va="center", fontsize=10.5, color=INK)

save(fig, "f24_model_compare")
