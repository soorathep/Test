"""f08_vdw_reduced_Zc -- bar chart of predicted Z_c: vdW 3/8 = 0.375,
RK/SRK 1/3 = 0.3333, PR 0.3074 (SPEC.md), against the experimental range
0.23-0.29 (well-established literature band, drawn as a shaded mist band
labelled "experimental range for most fluids", per the one permitted
exception in the data-integrity rule).
"""
import sys
sys.path.insert(0, "/home/claude/eos_lecture/code")
from eosstyle import *

models = ["vdW\n(1873)", "RK / SRK\n(1949 / 1972)", "PR\n(1976)"]
Zc = [3/8, 1/3, 0.3074]
colors = [NAVY, SKYBLUE, AMBER]

fig, ax = newfig(6.6, 4.3)
ax.grid(axis="y", zorder=0)
ax.grid(axis="x", visible=False)

x = np.arange(len(models))
bars = ax.bar(x, Zc, width=0.5, color=colors, zorder=3, edgecolor="white", linewidth=0.6)

# experimental band
ax.axhspan(0.23, 0.29, color=MIST, alpha=0.65, zorder=1)
# label sits in the empty strip to the right of the PR bar (xlim extended for it)
ax.text(2.38, 0.26, "experimental range\nfor most fluids\n(0.23-0.29)", fontsize=10.5,
        color=INK, ha="left", va="center", linespacing=1.3, zorder=5,
        bbox=dict(facecolor="white", edgecolor="none", alpha=0.92, pad=2.5))

for xi, z in zip(x, Zc):
    ax.text(xi, z + 0.006, f"{z:.4f}" if abs(z-1/3) < 1e-9 else f"{z:.3f}", ha="center",
            va="bottom", fontsize=10.5, color=INK, weight="bold")

ax.set_xticks(x)
ax.set_xticklabels(models, fontsize=10.5)
ax.set_ylabel(r"Predicted critical compressibility, $Z_c$")
ax.set_ylim(0, 0.42)
ax.set_xlim(-0.55, 3.85)

save(fig, "f08_vdw_reduced_Zc")
