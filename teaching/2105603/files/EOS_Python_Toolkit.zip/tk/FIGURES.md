# FIGURE MANIFEST (fixed filenames — do not rename)

Each entry: `name` — content. Produce `figs/<name>.pdf` and `figs/<name>.png` (600 dpi).
Use `code/eosstyle.py` helpers (`newfig`, `blank`, `save`, `Zroots`, `P_of_V`, `SPECIES`).

**Data-integrity rule.** Every curve must be either (a) computed from an equation defined in
SPEC.md, (b) computed from a standard correlation whose constants you state in the script
comments, or (c) explicitly annotated on the figure as "schematic (illustrative)".
Do not invent experimental data points and present them as measurements.

## Set A (Chapters 1-6)
- `f01_eos_role` — concept map: EOS box in the centre, arrows to molar density/volume,
  residual enthalpy and entropy, fugacity coefficient, VLE / K-values, process simulation
  (compressors, flash drums, pipelines), safety and metering.
- `f02_timeline` — horizontal timeline 1662 -> 2020s: Boyle 1662, ideal gas 1834,
  Andrews critical point 1869, van der Waals 1873, virial (Kamerlingh Onnes) 1901,
  corresponding states 1873/1939, Redlich-Kwong 1949, Pitzer omega 1955, Soave 1972,
  Peng-Robinson 1976, Wertheim 1984-86, SAFT 1990, PC-SAFT 2001, ePC-SAFT 2000s,
  ML/physics-informed EOS 2010s-2020s. Colour code: navy = classical, amber = molecular,
  teal = data-driven.
- `f03_ideal_vs_real_Z` — Z vs P (0-400 bar) at T = 300 K for methane, CO2, ethane and
  nitrogen computed with PR; horizontal navy dashed Z = 1 line labelled "ideal gas".
- `f04_ideal_fail_map` — contour map of |Z - 1| in the (T_r, P_r) plane for a simple fluid
  (PR with omega = 0), with the 1 percent and 5 percent contours highlighted in amber;
  shade the region where the ideal gas law is acceptable.
- `f05_vdw_molecular` — two-panel schematic: (left) excluded volume, two hard spheres of
  diameter sigma with the excluded sphere of radius sigma drawn in teal, annotation
  b = 2 pi N_A sigma^3 / 3; (right) a central molecule with an amber attraction shell and
  arrows from neighbours, annotation "mean-field attraction -> -a/V^2".
- `f06_vdw_isotherms` — P-V isotherms for CO2 from vdW at T_r = 0.85, 0.90, 0.95, 1.00, 1.10;
  sand-shaded two-phase dome from the Maxwell construction; critical point marked.
- `f07_maxwell` — enlarged subcritical vdW loop with the equal-area construction, the
  mechanically unstable branch (dP/dV > 0) in rust, metastable branches dashed.
- `f08_vdw_reduced_Zc` — bar chart of predicted Z_c: vdW 0.375, RK/SRK 0.3333, PR 0.3074,
  against the experimental range 0.23-0.29 shown as a mist band.
- `f09_Z_meaning` — Z vs P for CO2 (PR) at several temperatures showing the initial
  negative slope, the minimum, and the crossover to Z > 1; annotate "attraction dominates"
  (rust) and "repulsion dominates" (teal).
- `f10_boyle` — second virial coefficient B(T) of a Lennard-Jones fluid (use the standard
  reduced-temperature LJ B2* correlation computed by numerical integration of the Mayer
  function) with the Boyle temperature marked; inset or second panel: initial slope of Z
  vs P changing sign at T_B.
- `f11_generalized_chart` — generalized compressibility chart: Z vs P_r for
  T_r = 1.0, 1.05, 1.1, 1.2, 1.4, 1.6, 2.0, 3.0 computed with PR at omega = 0;
  curves labelled directly on the plot.
- `f12_virial_B` — B_2(T) computed from the Lennard-Jones pair potential by numerical
  integration, plotted in reduced form, with the high-T repulsive plateau annotated.
- `f13_pair_potential` — Lennard-Jones u(r) and the Mayer function f(r) = exp(-u/kT) - 1
  at two temperatures, twin axes; mark sigma and epsilon.
- `f14_virial_range` — Z vs reduced density for the two-term and three-term virial
  truncations against a "full" reference (use the PR isotherm as the reference and label
  it as such), showing where truncation breaks down.
- `f15_corresponding_states` — Z vs P_r at T_r = 1.10 for methane, nitrogen, ethane
  (simple, near-collapse) and water, ammonia (clear departure); all computed with PR so the
  comparison is like-for-like, and annotate that departure grows with omega.
- `f16_psat_reduced` — log10(P_r^sat) vs 1/T_r from the PR EOS for methane, propane,
  n-butane, water; near-linear lines with different slopes, all passing near (1, 0).

## Set B (Chapters 7-13)
- `f17_acentric_definition` — same axes as f16 with a vertical line at 1/T_r = 1/0.7,
  the simple-fluid reference line log10 P_r^sat = -1.0, and amber arrows showing
  omega = -1 - log10(P_r^sat)|_{T_r = 0.7} for two fluids.
- `f18_omega_vs_shape` — horizontal bar chart of omega for argon, methane, nitrogen,
  ethane, propane, n-butane, n-octane, benzene, CO2, ammonia, water, methanol,
  grouped and coloured by family (spherical, chain, polar, associating).
- `f19_rk_vs_vdw` — Z vs P_r at T_r = 1.2 and 0.9 (vapour branch) for propane computed with
  vdW, RK and PR; PR labelled as the modern reference.
- `f20_alpha_functions` — a(T)/a_c vs T_r for vdW (constant), RK (T_r^-0.5),
  SRK and PR (omega = 0.15), plus SRK/PR at omega = 0.35 dashed.
- `f21_srk_psat` — predicted reduced vapour pressure of propane vs T_r from RK, SRK and PR,
  plotted as relative deviation from the SRK result used as reference; state clearly in the
  caption/annotation that SRK is the reference curve, not experiment.
- `f22_pr_liquid_density` — saturated liquid molar volume of propane vs T_r from SRK and PR,
  with the PR volume translation effect annotated; mark that PR gives the smaller
  (more realistic) liquid volume.
- `f23_pvt_envelope_compare` — density-temperature coexistence envelope (rho_liq and rho_vap
  vs T) for propane from SRK and PR on the same axes, critical point marked.
- `f24_model_compare` — heat-map style comparison table figure, rows = vdW, RK, SRK, PR,
  columns = vapour Z, liquid density, vapour pressure, near-critical, polar/associating,
  computational cost; cells shaded from mist (poor) to navy (good) with text labels.
- `f25_saft_terms` — four-panel schematic of the SAFT construction: (1) hard-sphere fluid,
  (2) chain formation by bonding segments, (3) dispersion attraction between segments,
  (4) association through short-range directional sites A and B. Amber highlights the
  physics added at each step.
- `f26_saft_contributions` — stacked/line plot of the residual Helmholtz contributions
  a_hs, a_chain, a_disp, a_assoc as a function of reduced density; schematic (illustrative)
  label required if not computed from a real implementation.
- `f27_saft_vs_cubic` — schematic (illustrative) comparison of predicted liquid density
  for an associating fluid: cubic EOS overpredicts volume, molecular EOS follows the
  reference; annotate clearly as illustrative.
- `f28_electrolyte_terms` — schematic of an ion in solvent showing: Born solvation cavity,
  Debye-Huckel ionic atmosphere, primary hydration shell, contact ion pair, and the
  corresponding Helmholtz contribution labels (a_Born, a_DH/MSA, a_hydration, a_assoc).
- `f29_mean_activity` — mean ionic activity coefficient vs sqrt(ionic strength):
  Debye-Huckel limiting law (navy straight line), extended DH (skyblue), and a curve with
  a minimum and upturn representing concentrated electrolytes (amber); annotate the
  physics responsible for the upturn. Label as illustrative.
- `f30_battery_electrolyte` — concept map: electrolyte EOS outputs (activity coefficients,
  solvation structure, transference, solubility limits) mapped to battery design targets
  (voltage window, SEI chemistry, salt precipitation, low-temperature operation).
- `f31_future_map` — concept map of future directions: molecular simulation,
  physics-informed machine learning, thermodynamic-consistency constraints,
  electrochemical thermodynamics, high-throughput parameterisation.
- `f32_ml_eos` — schematic of a physics-informed ML EOS: inputs (T, rho, molecular
  descriptors) -> neural Helmholtz function -> automatic differentiation to P, mu, c_v,
  with hard constraints (limiting ideal-gas behaviour, Maxwell equal area, positivity of
  c_v) shown as guard rails.
- `f33_hierarchy` — master diagram of the whole package: a vertical ladder from ideal gas
  upward, each rung labelled with the physics added (excluded volume, mean-field
  attraction, temperature-dependent attraction, molecular shape via omega, improved volume
  dependence, chain connectivity, association, electrostatics) and the EOS that introduced
  it, with the accuracy/complexity axis on the right.
- `f34_Z_landscape` — filled contour map of Z in the (T_r, P_r) plane from PR at omega = 0,
  with the Z = 1 contour highlighted in amber and the saturation line drawn.
