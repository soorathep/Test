#!/usr/bin/env python3
"""F5.3  A ternary liquid-liquid diagram computed from NRTL: tie lines,
binodal, plait point.

2105603 Advanced Chemical Engineering Thermodynamics — Module 5
Soorathep Kheawhom, Chulalongkorn University

Nothing on this diagram is drawn by hand. Each tie line is the answer to one
two-liquid flash (`vlekit.multi.tie_lines`, which is successive substitution on
K_i = gamma_i^I / gamma_i^II started from a stability test); the binodal is the
locus of their end points (`binodal_from_tielines`); the plait point is the
extrapolation of tie-line length to zero (`plait_point`).

Two diagnostics are printed on the figure because they are what makes the
picture trustworthy:

    material balance   max | beta x^I + (1-beta) x^II - z |  over all tie lines
    isoactivity        max | gamma_i^I x_i^I - gamma_i^II x_i^II |

The first is arithmetic and should be at machine precision. The second is the
equilibrium condition itself and is limited by the flash tolerance.

ILLUSTRATIVE INPUT: the NRTL tau and alpha matrices below are a teaching
parameter set chosen to produce a clean type-I dome on one screen. They are NOT
fitted to any measured ternary and the components are deliberately unnamed.

Run:  python3 f5_03.py
"""
import os
import sys

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, "/home/claude/vlekit")
from vlekit.multi import (NRTLMulti, binodal_from_tielines,      # noqa: E402
                          plait_point, tie_lines, to_xy)
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,      # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, use_style)

OUT = os.environ.get("F5_OUT", "/home/claude/vle5/qmd/figures")
SLUG = "f5_03_ternary_lle_tielines"

# ILLUSTRATIVE ternary NRTL — see the docstring
TAU = np.array([[0.00, 0.60, 3.20],
                [0.35, 0.00, 0.90],
                [2.80, 0.55, 0.00]])
ALPHA = np.array([[0.0, 0.30, 0.20],
                  [0.30, 0.0, 0.30],
                  [0.20, 0.30, 0.0]])

X2_FEEDS = np.linspace(0.02, 0.58, 23)      # feeds on the x1 = x3 line
HIGHLIGHT = 8                               # which tie line carries the lever

S3 = np.sqrt(3) / 2


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def xy(x):
    """One composition (or many) to Cartesian, via the vlekit helper."""
    return to_xy(np.atleast_2d(np.asarray(x, dtype=float)))


# --------------------------------------------------------------------------
def make():
    m = NRTLMulti(TAU, ALPHA)
    feeds = [np.array([(1 - a) / 2, a, (1 - a) / 2]) for a in X2_FEEDS]
    lines, dropped = tie_lines(m, feeds, rich_in=0)
    A, B = binodal_from_tielines(lines)
    pp, Lmin = plait_point(lines)

    mb = max(float(np.max(np.abs(l["beta"] * l["xI"]
                                 + (1 - l["beta"]) * l["xII"] - l["z"])))
             for l in lines)
    iso = max(float(np.max(np.abs(np.exp(m.ln_gamma(l["xI"])) * l["xI"]
                                  - np.exp(m.ln_gamma(l["xII"])) * l["xII"])))
              for l in lines)
    L = np.array([float(np.linalg.norm(l["xI"] - l["xII"])) for l in lines])
    return dict(m=m, feeds=feeds, lines=lines, dropped=dropped, A=A, B=B,
                pp=pp, Lmin=Lmin, mb=mb, iso=iso, L=L)


# --------------------------------------------------------------------------
def triangle(ax):
    """The simplex, its gridlines and its edge scales."""
    V = np.array([[0.0, 0.0], [1.0, 0.0], [0.5, S3]])       # 1, 2, 3
    ax.add_patch(plt.Polygon(V, closed=True, fill=False, edgecolor=GRAPHITE,
                             lw=1.8, zorder=6))

    for c in np.arange(0.1, 0.91, 0.1):
        for i in range(3):
            a = np.zeros(3)
            b = np.zeros(3)
            a[i] = b[i] = c
            a[(i + 1) % 3] = 1 - c
            b[(i + 2) % 3] = 1 - c
            p, q = xy(a)[0], xy(b)[0]
            ax.plot([p[0], q[0]], [p[1], q[1]], "-", color=MIST, lw=0.7,
                    alpha=0.85, zorder=1)

    # edge scales: x2 along the bottom, x3 up the right, x1 down the left.
    # 0 and 1 are omitted because they sit on the vertices, where the vertex
    # names already are.
    for c in np.arange(0.2, 0.81, 0.2):
        p = xy([1 - c, c, 0.0])[0]                          # bottom edge
        ax.text(p[0], p[1] - 0.040, f"{c:.1f}", ha="center", va="top",
                fontsize=11.5, color=GRAPHITE)
        p = xy([0.0, 1 - c, c])[0]                          # right edge
        ax.text(p[0] + 0.032, p[1] + 0.018, f"{c:.1f}", ha="left",
                va="center", fontsize=11.5, color=GRAPHITE)
        p = xy([c, 0.0, 1 - c])[0]                          # left edge
        ax.text(p[0] - 0.032, p[1] + 0.018, f"{c:.1f}", ha="right",
                va="center", fontsize=11.5, color=GRAPHITE)

    # axis names, pushed out along each edge's outward normal so that they
    # clear the longest tick label rather than being nudged into place
    ax.text(0.5, -0.125, r"$x_2 \longrightarrow$", ha="center", va="center",
            fontsize=13, color=INK)
    ax.text(0.75 + 0.22 * 0.866, 0.433 + 0.22 * 0.5,
            r"$x_3 \longrightarrow$", ha="center", va="center",
            fontsize=13, color=INK, rotation=-60)
    ax.text(0.25 - 0.22 * 0.866, 0.433 + 0.22 * 0.5,
            r"$\longleftarrow x_1$", ha="center", va="center",
            fontsize=13, color=INK, rotation=60)

    for p, lab, ha, va, dx, dy in (
            (V[0], "component 1", "right", "top", -0.030, -0.055),
            (V[1], "component 2", "left", "top", 0.030, -0.055),
            (V[2], "component 3", "center", "bottom", 0.0, 0.032)):
        ax.text(p[0] + dx, p[1] + dy, lab, ha=ha, va=va, fontsize=13.5,
                color=INK, fontweight="bold")


def build(d):
    use_style()
    fig, ax = plt.subplots(figsize=(13.2, 8.0))
    ax.set_aspect("equal")
    ax.axis("off")
    ax.set_xlim(-0.16, 1.72)
    ax.set_ylim(-0.19, 0.98)
    triangle(ax)

    # ---- tie lines
    for k, l in enumerate(d["lines"]):
        p, q = xy(l["xI"])[0], xy(l["xII"])[0]
        first = (k == 0)
        ax.plot([p[0], q[0]], [p[1], q[1]], "-", color=AMBER, lw=1.6,
                alpha=0.95, zorder=3,
                label=f"{len(d['lines'])} tie lines (one LLE flash each)"
                if first else None)

    # ---- binodal through the tie-line ends, closed through the plait point
    A, B, pp = d["A"], d["B"], d["pp"]
    oa = np.argsort(A[:, 1])
    ob = np.argsort(B[:, 1])
    branch = np.vstack([A[oa], pp[None, :], B[ob][::-1]])
    P = to_xy(branch)
    ax.plot(P[:, 0], P[:, 1], "-", color=NAVY, lw=2.6, zorder=5,
            label="binodal (locus of the tie-line ends)")
    for M, mk in ((A, "o"), (B, "o")):
        Q = to_xy(M)
        ax.plot(Q[:, 0], Q[:, 1], mk, color=NAVY, ms=5.0, mfc=PAPER, mew=1.3,
                zorder=7)

    # ---- one tie line drawn with its feed, to show the lever rule at work
    l = d["lines"][HIGHLIGHT]
    p, q, z = xy(l["xI"])[0], xy(l["xII"])[0], xy(l["z"])[0]
    ax.plot([p[0], q[0]], [p[1], q[1]], "-", color=RUST, lw=3.0, zorder=8,
            label="one tie line and its overall feed")
    ax.plot([z[0]], [z[1]], "D", color=RUST, ms=10, mec=PAPER, mew=1.5,
            zorder=9)

    # ---- plait point
    pxy = xy(pp)[0]
    ax.plot([pxy[0]], [pxy[1]], "*", color=TEAL, ms=22, mec=PAPER, mew=1.2,
            zorder=10, label="plait point (extrapolated)")

    # ======================================================================
    # every label lives in the empty column to the right of the simplex, so
    # nothing can land on a tie line
    # ======================================================================
    xcol = 1.10
    ax.legend(loc="upper left", bbox_to_anchor=(xcol - 0.03, 0.955),
              bbox_transform=ax.transData, fontsize=11, labelspacing=0.75,
              handlelength=2.4)

    ax.annotate(
        "plait point\n"
        f"$x$ = ({pp[0]:.3f}, {pp[1]:.3f}, {pp[2]:.3f})\n"
        f"linear extrapolation of tie-line\nlength to zero, from lines as\n"
        f"short as {d['Lmin']:.3f} — an estimate,\nnot a converged critical "
        "point",
        xy=(pxy[0], pxy[1]), xytext=(xcol, 0.325),
        ha="left", va="top", fontsize=11, color=TEAL, zorder=12,
        linespacing=1.5,
        bbox=dict(boxstyle="round,pad=0.32", fc=PAPER, ec=TEAL, lw=1.0,
                  alpha=0.96),
        arrowprops=dict(arrowstyle="-", color=TEAL, lw=1.3, shrinkA=6,
                        shrinkB=10))

    lh = d["lines"][HIGHLIGHT]
    ax.annotate(
        "highlighted tie line\n"
        f"feed $z$ = ({lh['z'][0]:.3f}, {lh['z'][1]:.3f}, {lh['z'][2]:.3f})\n"
        f"$x^{{\\rm I}}$ = ({lh['xI'][0]:.3f}, {lh['xI'][1]:.3f}, "
        f"{lh['xI'][2]:.3f})\n"
        f"$x^{{\\rm II}}$ = ({lh['xII'][0]:.3f}, {lh['xII'][1]:.3f}, "
        f"{lh['xII'][2]:.3f})\n"
        f"phase I fraction  $\\beta$ = {lh['beta']:.4f}",
        xy=(z[0], z[1]), xytext=(xcol, 0.655),
        ha="left", va="top", fontsize=11, color=RUST, zorder=12,
        linespacing=1.5,
        bbox=dict(boxstyle="round,pad=0.32", fc=PAPER, ec=RUST, lw=1.0,
                  alpha=0.96),
        arrowprops=dict(arrowstyle="-", color=RUST, lw=1.3, shrinkA=6,
                        shrinkB=8))

    # the run's own diagnostics, in the empty wedge outside the left edge
    ax.text(-0.15, 0.955,
            f"{len(X2_FEEDS)} feeds on $x_1 = x_3$, "
            f"$x_2$ = {X2_FEEDS[0]:.2f}–{X2_FEEDS[-1]:.2f}\n"
            f"{len(d['lines'])} split, {d['dropped']} did not\n"
            f"tie-line length {d['L'].min():.3f} to {d['L'].max():.3f}\n"
            f"material balance to {d['mb']:.1e}\n"
            f"isoactivity to {d['iso']:.1e}",
            ha="left", va="top", fontsize=11, color=INK, linespacing=1.6,
            zorder=12,
            bbox=dict(boxstyle="round,pad=0.34", fc=PAPER, ec=MIST, lw=1.0,
                      alpha=0.96))

    ax.set_title("Type-I liquid-liquid equilibrium from a ternary NRTL: "
                 "every line here is a converged flash",
                 fontsize=14.5, pad=6, loc="left", x=-0.02)
    fig.text(0.5, 0.012,
             "ILLUSTRATIVE PARAMETERS: NRTL with tau = [[0, 0.60, 3.20], "
             "[0.35, 0, 0.90], [2.80, 0.55, 0]] and alpha_13 = 0.20, "
             "alpha_12 = alpha_23 = 0.30.  A teaching parameter set chosen "
             "to give a clean type-I dome;\nit is not fitted to any measured "
             "ternary, which is why the components are left unnamed.  The two "
             "closure figures above are the residuals of this run, not quoted "
             "tolerances.",
             ha="center", va="top", fontsize=10, color=SLATE, linespacing=1.55)
    fig.tight_layout(rect=(0, 0.055, 1, 1))
    return fig


if __name__ == "__main__":
    d = make()
    m = d["m"]
    print("ternary NRTL (illustrative): Gibbs-Duhem residual "
          f"{m.check_gibbs_duhem():.2e}, pure-component limit "
          f"{m.check_pure_limit():.2e}")
    print(f"{len(X2_FEEDS)} feeds on x1 = x3, x2 = {X2_FEEDS[0]:.2f} to "
          f"{X2_FEEDS[-1]:.2f}: {len(d['lines'])} split, "
          f"{d['dropped']} dropped")
    print(f"tie-line length {d['L'].min():.4f} to {d['L'].max():.4f}")
    print(f"material balance max residual  {d['mb']:.3e}")
    print(f"isoactivity     max residual  {d['iso']:.3e}")
    pp = d["pp"]
    print(f"plait point estimate x = [{pp[0]:.5f}, {pp[1]:.5f}, {pp[2]:.5f}] "
          f"from tie lines down to length {d['Lmin']:.4f}")
    l = d["lines"][HIGHLIGHT]
    print(f"highlighted tie line: z = {np.round(l['z'], 4)}  "
          f"xI = {np.round(l['xI'], 4)}  xII = {np.round(l['xII'], 4)}  "
          f"beta = {l['beta']:.5f}")
    for p in write(build(d), SLUG):
        print("wrote", p)
