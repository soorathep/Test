#!/usr/bin/env python3
"""F5.1  Gibbs energy of mixing: common tangent, binodal, spinodal, and the
four regions they cut the composition axis into.

2105603 Advanced Chemical Engineering Thermodynamics — Module 5
Soorathep Kheawhom, Chulalongkorn University

One curve and two constructions on it.

    common tangent   the only line that touches Delta g_mix twice. Its points
                     of tangency are the two phases that actually coexist, and
                     they are found from the geometry, not from an equilibrium
                     equation. (vlekit.flash.miscibility_gap)

    spinodal         where d2(Delta g_mix)/dx1^2 changes sign. Between the two
                     roots no composition survives an infinitesimal
                     fluctuation. (vlekit.flash.spinodal)

Between the binodal and the spinodal the mixture is *metastable*: locally it is
the lowest state available, globally it is not. That band is not a bookkeeping
artefact — it is where a supersaturated solution sits while it waits for a
nucleus. The figure makes it visible by drawing the tangent at one metastable
composition and showing what a fluctuation has to do to escape it: climb a
small barrier, then fall a long way. Both numbers are computed.

ILLUSTRATIVE INPUT: the three-suffix Margules pair A12 = 2.6, A21 = 2.0 is a
teaching parameter set chosen to put a partially miscible binary on one screen.
It is not fitted to any measured system, and the figure says so on its face.

Run:  python3 f5_01.py
"""
import os
import sys

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, "/home/claude/vlekit")
import vlekit as v                                                # noqa: E402
from vlekit.flash import (g_mix, miscibility_gap,                 # noqa: E402
                          spinodal)
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,       # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, use_style)

OUT = os.environ.get("F5_OUT", "/home/claude/vle5/qmd/figures")
SLUG = "f5_01_gmix_binodal_spinodal"

A_MARGULES = [2.6, 2.0]            # ILLUSTRATIVE — see the docstring


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


# --------------------------------------------------------------------------
def make():
    m = v.Margules(A_MARGULES)
    gap = miscibility_gap(m)
    if gap is None:
        raise RuntimeError("no miscibility gap for these parameters")
    xa, xb = gap["x1_phase_a"], gap["x1_phase_b"]
    sp = sorted(spinodal(m))
    s1, s2 = sp[0], sp[-1]

    x = np.linspace(1e-5, 1 - 1e-5, 20001)
    g = g_mix(m, x)

    ga = float(g_mix(m, np.array([xa]))[0])
    gb = float(g_mix(m, np.array([xb]))[0])
    slope = (gb - ga) / (xb - xa)
    chord = ga + slope * (x - xa)

    # the metastable composition whose local tangent is drawn: the midpoint of
    # the left metastable band, so that it is not chosen to flatter the picture
    xm = 0.5 * (xa + s1)
    h = 1e-6
    gm = float(g_mix(m, np.array([xm]))[0])
    dgm = float((g_mix(m, np.array([xm + h]))[0]
                 - g_mix(m, np.array([xm - h]))[0]) / (2 * h))
    local = gm + dgm * (x - xm)
    tpd = g - local                      # tangent plane distance from xm

    right = (x > xm) & (x < 0.98)
    xr, tr = x[right], tpd[right]
    j = int(np.argmin(tr))
    x_drop, t_drop = float(xr[j]), float(tr[j])          # deepest descent
    up = xr < x_drop
    k = int(np.argmax(tr[up]))
    x_bar, t_bar = float(xr[up][k]), float(tr[up][k])    # the barrier crest

    return dict(m=m, x=x, g=g, xa=xa, xb=xb, ga=ga, gb=gb, s1=s1, s2=s2,
                slope=slope, chord=chord, xm=xm, gm=gm, local=local,
                x_drop=x_drop, t_drop=t_drop, x_bar=x_bar, t_bar=t_bar,
                gs1=float(g_mix(m, np.array([s1]))[0]),
                gs2=float(g_mix(m, np.array([s2]))[0]),
                g_drop=float(g_mix(m, np.array([x_drop]))[0]))


# --------------------------------------------------------------------------
def build(d):
    use_style()
    fig, ax = plt.subplots(figsize=(12.4, 6.9))
    ax.grid(True, zorder=0)
    ax.set_axisbelow(True)

    x, g = d["x"], d["g"]
    xa, xb, s1, s2 = d["xa"], d["xb"], d["s1"], d["s2"]
    gmin = float(np.min(g))

    # ---- vertical extent, and the ribbon of region names above the curve.
    # The bottom of the axis is set well below the common tangent on purpose:
    # the wedge under the chord is empty by construction (the tangent is the
    # lower convex envelope, so the curve can never enter it) and every label
    # that would otherwise sit on the curve is parked there.
    ax.set_ylim(1.48 * gmin, 0.135 * abs(gmin))
    ax.set_xlim(0, 1)
    rib_lo, rib_hi = 0.032 * abs(gmin), 0.105 * abs(gmin)

    bands = [(0.0, xa, "stable", SKYBLUE),
             (xa, s1, "metastable", AMBER),
             (s1, s2, "unstable", RUST),
             (s2, xb, "metastable", AMBER),
             (xb, 1.0, "stable", SKYBLUE)]
    for lo, hi, name, col in bands:
        ax.axvspan(lo, hi, color=col, alpha=0.13, lw=0, zorder=1)
        ax.add_patch(plt.Rectangle((lo, rib_lo), hi - lo, rib_hi - rib_lo,
                                   facecolor=col, alpha=0.85, lw=0, zorder=6))
        ax.text(0.5 * (lo + hi), 0.5 * (rib_lo + rib_hi), name, ha="center",
                va="center", fontsize=11.5, color=PAPER, zorder=7,
                fontweight="bold")
    for b in (xa, s1, s2, xb):
        ax.plot([b, b], [1.48 * gmin, rib_lo], ls=(0, (4, 3)), color=SLATE,
                lw=1.0, zorder=2)

    # ---- the curve, the common tangent, the two constructions on it
    ax.axhline(0.0, color=GRAPHITE, lw=1.0, zorder=3)
    ax.plot(x, d["chord"], ls="--", color=GRAPHITE, lw=2.0, zorder=4,
            label="common tangent")
    ax.plot(x, g, "-", color=NAVY, lw=2.8, zorder=6,
            label=r"$\Delta g_{\rm mix}/RT$")
    ax.plot([xa, xb], [d["ga"], d["gb"]], "o", color=NAVY, ms=11, mec=PAPER,
            mew=1.6, zorder=8)
    ax.plot([s1, s2], [d["gs1"], d["gs2"]], "s", color=RUST, ms=10, mec=PAPER,
            mew=1.6, zorder=8)

    # ---- what "metastable" costs, drawn from the tangent at one such point
    ax.plot(x, d["local"], ls=(0, (6, 3)), color=TEAL, lw=1.9, zorder=5,
            label=f"tangent at the metastable $x_1$ = {d['xm']:.3f}")
    ax.plot([d["xm"]], [d["gm"]], "D", color=TEAL, ms=9, mec=PAPER, mew=1.4,
            zorder=9)
    ytop_drop = float(np.interp(d["x_drop"], x, d["local"]))
    ax.plot([d["x_drop"], d["x_drop"]], [ytop_drop, d["g_drop"]], "-",
            color=TEAL, lw=2.2, zorder=7)
    ax.plot([d["x_drop"]], [d["g_drop"]], "v", color=TEAL, ms=9, mec=PAPER,
            mew=1.2, zorder=9)

    # ======================================================================
    # labels. Every offset below is computed from the curve, the chord or the
    # axis limits, never chosen by eye.
    # ======================================================================
    lo_y, hi_y = ax.get_ylim()
    span = hi_y - lo_y
    below = lambda xx: float(np.interp(xx, x, d["chord"]))   # noqa: E731
    BOX = dict(boxstyle="round,pad=0.24", fc=PAPER, ec="none", alpha=0.88)

    # binodal: both labels under the chord, on the empty side of their point
    ax.annotate(f"binodal  $x_1^{{\\rm I}}$ = {xa:.3f}",
                xy=(xa, d["ga"]),
                xytext=(xa + 0.020, below(xa + 0.020) - 0.115 * span),
                ha="left", va="top", fontsize=11, color=NAVY, zorder=10,
                bbox=BOX, arrowprops=dict(arrowstyle="-", color=NAVY, lw=1.1,
                                          shrinkA=2, shrinkB=4))
    ax.annotate(f"binodal  $x_1^{{\\rm II}}$ = {xb:.3f}",
                xy=(xb, d["gb"]),
                xytext=(xb + 0.060, below(xb + 0.060) - 0.135 * span),
                ha="left", va="center", fontsize=11, color=NAVY, zorder=10,
                bbox=BOX, arrowprops=dict(arrowstyle="-", color=NAVY, lw=1.1,
                                          shrinkA=2, shrinkB=4))

    # spinodal: the left one above the curve (the bowl is empty there), the
    # right one under the chord, so the two never share a neighbourhood
    ax.annotate(f"spinodal  {s1:.3f}", xy=(s1, d["gs1"]),
                xytext=(s1, d["gs1"] + 0.130 * span),
                ha="center", va="bottom", fontsize=11, color=RUST, zorder=10,
                bbox=BOX, arrowprops=dict(arrowstyle="-", color=RUST, lw=1.1,
                                          shrinkA=2, shrinkB=4))
    ax.annotate(f"spinodal  {s2:.3f}", xy=(s2, d["gs2"]),
                xytext=(s2, below(s2) - 0.055 * span),
                ha="center", va="top", fontsize=11, color=RUST, zorder=10,
                bbox=BOX, arrowprops=dict(arrowstyle="-", color=RUST, lw=1.1,
                                          shrinkA=2, shrinkB=4))

    # the depth of the descent, written beside the bar that draws it, in the
    # lens between the local tangent and the curve — which is empty by the
    # same argument as the wedge under the chord
    ax.annotate(f"$-{abs(d['t_drop']):.3f}\\,RT$",
                xy=(d["x_drop"], 0.5 * (ytop_drop + d["g_drop"])),
                xytext=(d["x_drop"] - 0.022,
                        0.5 * (ytop_drop + d["g_drop"])),
                ha="right", va="center", fontsize=11, color=TEAL, zorder=10,
                bbox=BOX, arrowprops=dict(arrowstyle="-", color=TEAL, lw=1.1,
                                          shrinkA=2, shrinkB=2))

    ax.text(0.012, lo_y + 0.030 * span,
            f"Metastable, not stable.  From $x_1$ = {d['xm']:.3f} every small "
            f"fluctuation raises $g$: the curve lies above its own tangent "
            f"there.\nOnly a fluctuation that first climbs "
            f"{d['t_bar']:+.4f}$RT$ (crest at $x_1$ = {d['x_bar']:.3f}) "
            f"reaches the descent to $x_1$ = {d['x_drop']:.3f}.\n"
            "That barrier is why a metastable liquid can sit clear for hours "
            "and then go cloudy all at once.",
            ha="left", va="bottom", fontsize=10.5, color=INK, zorder=11,
            linespacing=1.5,
            bbox=dict(boxstyle="round,pad=0.36", fc=PAPER, ec=MIST, lw=1.0,
                      alpha=0.96))

    ax.set_xlabel("$x_1$")
    ax.set_ylabel(r"$\Delta g_{\rm mix}/RT$")
    ax.legend(loc="upper center", fontsize=10.5, ncol=1,
              bbox_to_anchor=(0.50, 0.895), labelspacing=0.45)
    ax.set_title("Where the two liquid phases come from: a curve, "
                 "one tangent line, and one change of curvature",
                 fontsize=14.5, pad=9)

    fig.text(0.5, -0.045,
             f"ILLUSTRATIVE PARAMETERS: three-suffix Margules with "
             f"$A_{{12}}$ = {A_MARGULES[0]:g}, $A_{{21}}$ = "
             f"{A_MARGULES[1]:g}, chosen to place a partially miscible binary "
             "on one screen. They are not fitted to any measured mixture.\n"
             "Every number printed above is computed from that one $G^E$: the "
             "binodal by vlekit.flash.miscibility_gap, the spinodal by "
             "vlekit.flash.spinodal, the barrier and the descent by "
             "differencing the curve against its own tangent.",
             ha="center", va="center", fontsize=10, color=SLATE,
             linespacing=1.55)
    fig.tight_layout()
    return fig


if __name__ == "__main__":
    d = make()
    print(f"Margules A12 = {A_MARGULES[0]:g}, A21 = {A_MARGULES[1]:g} "
          "(illustrative)")
    print(f"binodal   x1 = {d['xa']:.5f} / {d['xb']:.5f}   "
          f"(g/RT = {d['ga']:+.5f} / {d['gb']:+.5f})")
    print(f"spinodal  x1 = {d['s1']:.5f} / {d['s2']:.5f}")
    print(f"metastable bands  {d['xa']:.4f}-{d['s1']:.4f}  and  "
          f"{d['s2']:.4f}-{d['xb']:.4f}   "
          f"(widths {d['s1'] - d['xa']:.4f}, {d['xb'] - d['s2']:.4f})")
    print(f"unstable band     {d['s1']:.4f}-{d['s2']:.4f}   "
          f"(width {d['s2'] - d['s1']:.4f})")
    print(f"common tangent slope d(g/RT)/dx1 = {d['slope']:+.5f}")
    print(f"tangent drawn at metastable x1 = {d['xm']:.4f}: "
          f"barrier {d['t_bar']:+.5f} RT at x1 = {d['x_bar']:.4f}, "
          f"deepest descent {d['t_drop']:+.5f} RT at x1 = {d['x_drop']:.4f}")
    for p in write(build(d), SLUG):
        print("wrote", p)
