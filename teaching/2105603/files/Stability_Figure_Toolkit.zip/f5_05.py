"""F5.5 — Mixture phase envelope: the critical point is not the top of the dome.

2105603 Advanced Chemical Engineering Thermodynamics, Module 5.
Chulalongkorn University. Soorathep Kheawhom.

The figure exists to break one misconception. For a pure substance the critical
point ends the vapour pressure curve and is simultaneously the highest
temperature and the highest pressure at which two phases can coexist. Students
carry that picture into mixtures, where all three statements are false: the
mixture critical point sits on the flank of the envelope, the cricondentherm is
warmer, the cricondenbar is higher, and between the critical temperature and the
cricondentherm the two-phase region is bounded above and below by the dew
curve. Dropping the pressure there condenses liquid.

The right-hand panel is the point of the figure. It is a sequence of isothermal
flash calculations, not an illustration: the liquid fraction plotted is what
`vlekit.cubic.flash_TP` returns at each pressure.

Everything is computed by `vlekit.cubic` (Peng-Robinson, van der Waals
one-fluid quadratic mixing rule, Michelsen continuation for the envelope). No
number on the figure is typed in by hand.

Run:  python3 f5_05.py
"""
from __future__ import annotations

import os
import sys

import numpy as np

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import vlekit as v
from vlekit import cubic as C
from vlekit.plots import (use_style, NAVY, AMBER, TEAL, RUST,
                          GRAPHITE, INK, SLATE, PAPER)

OUT = "/home/claude/vle5/qmd/figures"
SLUG = "retrograde_envelope"

# --------------------------------------------------------------------------
# The system. Methane with n-butane is the classical teaching pair: wide
# boiling range, a large retrograde region, and — the reason it cannot be done
# with the gamma-phi route of Modules 1-4 — methane is supercritical over most
# of the envelope, so it has no vapour pressure to put into Raoult's law.
#
# k_12 = 0. That is an assumption, not a measurement: no binary VLE data were
# regressed for this figure, and a fitted k_12 for methane/n-butane is of order
# a few times 0.01, which moves the critical pressure by a per cent or two. It
# is labelled as assumed on the figure because a binary interaction parameter
# quoted without a source is the most common untraceable number in this
# subject.
# --------------------------------------------------------------------------
LIGHT, HEAVY = "methane", "n-butane"
Z_LIGHT = 0.60
KIJ = 0.0

BAR = 100.0            # kPa per bar; the figure is drawn in bar


def build():
    mix = C.PengRobinson([v.component(LIGHT), v.component(HEAVY)],
                         kij=[[0.0, KIJ], [KIJ, 0.0]])
    z = np.array([Z_LIGHT, 1 - Z_LIGHT])
    env = C.envelope(mix, z, P_start=101.325, dS_max=0.08, n_max=900)
    return mix, z, env


# --------------------------------------------------------------------------
def retrograde_band(env, n=160):
    """The shaded region: for each T between Tc and the cricondentherm, the two
    pressures at which the dew curve is crossed."""
    Tc, Tct = C.retrograde_window(env)
    Ts = np.linspace(Tc, Tct, n)
    lo, hi, keep = [], [], []
    for T in Ts:
        p = C.dew_branch_at_T(env, T)
        if p.size == 2:
            keep.append(T)
            lo.append(p[0])
            hi.append(p[1])
    # Close the band on the two points that define it. On the left it is a
    # vertical edge at T = Tc running from the lower dew branch up to the
    # critical pressure; on the right it pinches to a single point at the
    # cricondentherm, where the two dew pressures have merged.
    edge = C.dew_branch_at_T(env, Tc)
    if edge.size == 2:
        keep = [Tc] + keep
        lo = [edge[0]] + lo
        hi = [env.critical[1]] + hi
    Pct = env.cricondentherm[1]
    keep = keep + [Tct]
    lo = lo + [Pct]
    hi = hi + [Pct]
    return np.array(keep), np.array(lo), np.array(hi)


def main():
    use_style()
    mix, z, env = build()
    Tc, Pc = env.critical
    Tct, Pct = env.cricondentherm
    Tcb, Pcb = env.cricondenbar

    Tb, Pb = env.bubble
    Td, Pd = env.dew
    # draw both branches right into the critical point so they visibly meet
    Tb = np.append(Tb, Tc)
    Pb = np.append(Pb, Pc)
    Td = np.insert(Td, 0, Tc)
    Pd = np.insert(Pd, 0, Pc)

    Tband, Plo, Phi = retrograde_band(env)

    # the retrograde isotherm, halfway across the window
    T_iso = 0.5 * (Tc + Tct)
    P_dew_lo, P_dew_hi = C.dew_branch_at_T(env, T_iso)
    Pw, L = C.liquid_dropout(mix, z, T_iso, 0.995 * P_dew_lo,
                             1.005 * P_dew_hi, n=90)
    good = np.isfinite(L)
    i_max = int(np.nanargmax(L))
    P_Lmax, L_max = Pw[i_max], L[i_max]

    # ------------------------------------------------------------------ plot
    fig, (ax, bx) = plt.subplots(
        1, 2, figsize=(12.6, 6.6),
        gridspec_kw={"width_ratios": [1.58, 1.0], "wspace": 0.20})

    # ---------------- left: the envelope -----------------------------------
    ax.set_xlim(105, 445)
    ax.set_ylim(0, 150)

    ax.fill_between(Tband, Plo / BAR, Phi / BAR, color=AMBER, alpha=0.45,
                    lw=0, zorder=1)
    # the left edge of the region is not a curve but a definition: the
    # vertical line through the mixture critical temperature
    ax.plot([Tband[0], Tband[0]], [Plo[0] / BAR, Phi[0] / BAR], "-",
            color=AMBER, lw=1.8, zorder=3)

    # guide lines for the two extrema, under everything
    ax.plot([Tct, Tct], [0, Pct / BAR], ":", color=TEAL, lw=1.4, zorder=2)
    ax.plot([105, Tcb], [Pcb / BAR, Pcb / BAR], ":", color=TEAL, lw=1.4,
            zorder=2)

    ax.plot(Tb, Pb / BAR, "-", color=NAVY, lw=2.4, zorder=4,
            label="bubble curve (first bubble of vapour)")
    ax.plot(Td, Pd / BAR, "--", color=RUST, lw=2.4, zorder=4,
            label="dew curve (first drop of liquid)")

    ax.plot([Tcb], [Pcb / BAR], "^", color=TEAL, ms=10, zorder=6)
    ax.plot([Tct], [Pct / BAR], "s", color=TEAL, ms=9, zorder=6)
    ax.plot([Tc], [Pc / BAR], "o", color=INK, ms=12, mfc=PAPER, mew=2.6,
            zorder=7)

    # the isotherm the right-hand panel walks along
    ax.annotate("", xy=(T_iso, P_dew_lo / BAR + 1.5),
                xytext=(T_iso, P_dew_hi / BAR - 1.5),
                arrowprops=dict(arrowstyle="-|>", color=GRAPHITE, lw=2.0,
                                shrinkA=0, shrinkB=0), zorder=6)

    ax.set_xlabel("$T$ / K")
    ax.set_ylabel("$P$ / bar")
    ax.grid(True, zorder=0)
    ax.set_axisbelow(True)

    # ---- labels, each in a region the curves do not enter
    ax.annotate(f"mixture critical point\n{Tc:.1f} K, {Pc / BAR:.1f} bar\n"
                f"not the hottest point,\nnot the highest",
                xy=(Tc, Pc / BAR), xytext=(300, 138),
                fontsize=10.5, color=INK, ha="left", va="center", zorder=8,
                bbox=dict(boxstyle="round,pad=0.30", fc=PAPER, ec=INK, lw=1.2),
                arrowprops=dict(arrowstyle="-|>", color=INK, lw=1.4,
                                shrinkA=4, shrinkB=8))
    ax.annotate(f"cricondentherm\n{Tct:.1f} K, {Pct / BAR:.1f} bar",
                xy=(Tct, Pct / BAR), xytext=(388, 52),
                fontsize=10.5, color=TEAL, ha="left", va="center", zorder=8,
                bbox=dict(boxstyle="round,pad=0.26", fc=PAPER, ec=TEAL, lw=1.1),
                arrowprops=dict(arrowstyle="-|>", color=TEAL, lw=1.3,
                                shrinkA=4, shrinkB=6))
    ax.annotate(f"cricondenbar\n{Tcb:.1f} K, {Pcb / BAR:.1f} bar",
                xy=(Tcb, Pcb / BAR), xytext=(190, 108),
                fontsize=10.5, color=TEAL, ha="left", va="center", zorder=8,
                bbox=dict(boxstyle="round,pad=0.26", fc=PAPER, ec=TEAL, lw=1.1),
                arrowprops=dict(arrowstyle="-|>", color=TEAL, lw=1.3,
                                shrinkA=4, shrinkB=6))
    ax.annotate(f"retrograde region\n{Tc:.1f} – {Tct:.1f} K",
                xy=(T_iso - 1.5, 0.62 * (P_dew_lo + P_dew_hi) / BAR),
                xytext=(300, 60),
                fontsize=10.5, color=RUST, ha="center", va="center", zorder=8,
                bbox=dict(boxstyle="round,pad=0.26", fc=PAPER, ec=AMBER, lw=1.4),
                arrowprops=dict(arrowstyle="-|>", color=RUST, lw=1.3,
                                shrinkA=4, shrinkB=4))

    ax.text(185, 78, "liquid", fontsize=12, color=SLATE, ha="center",
            style="italic", zorder=3)
    ax.text(300, 90, "two phase", fontsize=12, color=SLATE, ha="center",
            style="italic", zorder=3)
    ax.text(415, 22, "gas", fontsize=12, color=SLATE, ha="center",
            style="italic", zorder=3)

    ax.legend(loc="upper left", fontsize=10.5, handlelength=2.4,
              bbox_to_anchor=(0.004, 1.002))
    ax.set_title(f"P–T envelope, {Z_LIGHT:.2f} {LIGHT} / "
                 f"{1 - Z_LIGHT:.2f} {HEAVY} (mole)", fontsize=13, pad=8)

    # ---------------- right: liquid dropout along the isotherm -------------
    bx.set_xlim(118, 38)                  # left to right is falling pressure
    bx.set_ylim(0, 25)

    bx.axvline(P_dew_hi / BAR, color=SLATE, lw=1.3, ls=":", zorder=2)
    bx.axvline(P_dew_lo / BAR, color=SLATE, lw=1.3, ls=":", zorder=2)
    bx.plot(Pw[good] / BAR, 100 * L[good], "-", color=RUST, lw=2.6, zorder=4)
    bx.plot([P_Lmax / BAR], [100 * L_max], "o", color=RUST, ms=10, mfc=PAPER,
            mew=2.4, zorder=6)

    bx.set_xlabel("$P$ / bar")
    bx.set_ylabel("liquid dropout / mol %")
    bx.grid(True, zorder=0)
    bx.set_axisbelow(True)

    bx.text(P_dew_hi / BAR + 3.4, 1.2,
            f"upper dew point, {P_dew_hi / BAR:.1f} bar",
            rotation=90, fontsize=10, color=SLATE, ha="center", va="bottom",
            zorder=8)
    bx.text(P_dew_lo / BAR - 3.0, 1.2,
            f"lower dew point, {P_dew_lo / BAR:.1f} bar",
            rotation=90, fontsize=10, color=SLATE, ha="center", va="bottom",
            zorder=8)
    bx.annotate(f"{100 * L_max:.1f} mol % liquid at {P_Lmax / BAR:.1f} bar",
                xy=(P_Lmax / BAR, 100 * L_max), xytext=(0.60, 0.90),
                textcoords="axes fraction",
                fontsize=10.5, color=RUST, ha="center", va="center", zorder=8,
                bbox=dict(boxstyle="round,pad=0.26", fc=PAPER, ec=RUST, lw=1.2),
                arrowprops=dict(arrowstyle="-|>", color=RUST, lw=1.3,
                                shrinkA=4, shrinkB=6))

    bx.set_title(f"Isothermal expansion at $T$ = {T_iso:.1f} K:\n"
                 f"the gas condenses, then boils dry again",
                 fontsize=12.5, pad=8)

    # ---------------- provenance -------------------------------------------
    fig.text(0.006, 0.008,
             "Peng-Robinson (1976 $\\alpha$), van der Waals one-fluid quadratic "
             "mixing rule. $k_{12} = 0$ — ASSUMED, not fitted: no binary VLE "
             "data were regressed for this figure.\n"
             "Setting $k_{12}$ = 0.0133 instead raises the critical pressure "
             "by 1.7% and lowers the critical temperature by 0.44 K "
             "(computed here). $T_c$, $P_c$, $\\omega$ from Poling, "
             "Prausnitz & O'Connell.\n"
             "Antoine coefficients checked against the normal boiling point. "
             "Envelope by Michelsen continuation; dropout from isothermal "
             "flash.\n"
             "Every number shown was computed by vlekit.cubic; "
             "none is transcribed.",
             fontsize=10, color=SLATE, ha="left", va="bottom",
             linespacing=1.35)

    fig.subplots_adjust(left=0.052, right=0.988, top=0.885, bottom=0.185)

    os.makedirs(OUT, exist_ok=True)
    png = f"{OUT}/f5_05_{SLUG}.png"
    pdf = f"{OUT}/f5_05_{SLUG}.pdf"
    fig.savefig(png, dpi=300, facecolor=PAPER)
    fig.savefig(pdf, dpi=300, facecolor=PAPER)
    plt.close(fig)

    # ---------------- what was computed ------------------------------------
    print(f"F5.5  {Z_LIGHT:.2f} {LIGHT} / {1 - Z_LIGHT:.2f} {HEAVY}, "
          f"Peng-Robinson, k12 = {KIJ:g} (assumed)")
    print(f"  envelope traced with {len(env)} points, "
          f"{len(env.bubble[0])} on the bubble branch, "
          f"{len(env.dew[0])} on the dew branch")
    print(f"  mixture critical point   {Tc:8.2f} K   {Pc / BAR:8.2f} bar")
    print(f"  cricondentherm           {Tct:8.2f} K   {Pct / BAR:8.2f} bar   "
          f"(+{Tct - Tc:.2f} K hotter than critical)")
    print(f"  cricondenbar             {Tcb:8.2f} K   {Pcb / BAR:8.2f} bar   "
          f"(+{(Pcb - Pc) / BAR:.2f} bar higher than critical)")
    print(f"  retrograde window        {Tc:.2f} - {Tct:.2f} K  "
          f"({Tct - Tc:.2f} K wide)")
    print(f"  isotherm  T = {T_iso:.2f} K:  dew points at "
          f"{P_dew_lo / BAR:.2f} and {P_dew_hi / BAR:.2f} bar")
    print(f"  maximum liquid dropout   {100 * L_max:.2f} mol % at "
          f"{P_Lmax / BAR:.2f} bar, from {np.count_nonzero(good)} flashes")
    print(f"  pure-component check, PR vs Antoine at 0.6 < Tr < 0.85:")
    for i, c in enumerate(mix.components):
        e = [abs(C.psat(mix, i, T) - c.Psat(T)) / c.Psat(T)
             for T in np.linspace(0.60 * c.Tc, 0.85 * c.Tc, 12)]
        print(f"      {c.name:10s} max {100 * max(e):5.2f} %   "
              f"median {100 * float(np.median(e)):5.2f} %")
    print(f"  wrote {png}")
    print(f"  wrote {pdf}")
    return png


if __name__ == "__main__":
    main()
