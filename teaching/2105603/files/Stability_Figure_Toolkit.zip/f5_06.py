#!/usr/bin/env python3
"""F5.6  A double azeotrope, and what a two-parameter model does with it.

2105603 Advanced Chemical Engineering Thermodynamics — Module 5
Soorathep Kheawhom, Chulalongkorn University

An azeotrope is a root of

    ln(gamma_1/gamma_2) + ln(P_1^sat/P_2^sat) = 0

so a *double* azeotrope needs a G^E whose ln(gamma_1/gamma_2) crosses a fixed
level twice inside 0 < x1 < 1. For the four-suffix (three-parameter) Margules
form, G^E/RT = x1 x2 [A + B z + C z^2] with z = x1 - x2,

    ln(gamma_1/gamma_2) = B/2 + (C - A) z - (3B/2) z^2 - 2 C z^3

which is a cubic in z and can do it. That model is `vlekit.FourSuffixMargules`,
added to the package for this figure after it passed `check_partial_molar`
(4.5e-11) and `gibbs_duhem_residual` (3.2e-11).

The claim this figure supports is narrower than the usual one, because the
usual one is not true and the calculation says so:

  * van Laar **cannot** produce a double azeotrope. Its
    ln(gamma_1/gamma_2) = AB (B x2^2 - A x1^2)/(A x1 + B x2)^2 has exactly one
    interior zero whenever A and B share a sign, and opposite signs put a pole
    inside the composition range. This is proved, not scanned.
  * NRTL **can**, in principle: a 321 x 321 grid over tau12, tau21 in [-8, 8]
    at alpha = 0.3 contains parameter sets with two interior azeotropes. What
    it cannot do is produce them *and* fit these data. Fitted from the best of
    36 starting points it leaves a pressure residual ~100 times the noise and
    puts both azeotropes in the wrong place.
  * The three-suffix Margules, also a two-parameter model, does keep two
    azeotropes but displaces both and leaves a residual 25 times the noise.
    The distinguishing property is the *form* of ln(gamma_1/gamma_2), not the
    number of parameters, and the figure says so.

`vlekit.flash.azeotrope` returns None for the generating model, because it
brackets a single root across the whole composition range. That is reported
rather than worked around: it is the same failure the fitted models make.

ILLUSTRATIVE INPUT: A = -0.42, B = -0.93, C = -0.32 for acetone (1) /
chloroform (2) at 313.15 K. These were constructed to put the two azeotropes at
z = -0.6 and z = +0.4 with the third root of the cubic outside the composition
range; they are NOT fitted to measured VLE. The Antoine constants are the real
ones from vlekit's library. The "measurements" are synthesised from the model
with sigma_P = 0.02 kPa and sigma_y = 0.002.

Run:  python3 f5_06.py
"""
import os
import sys

import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import brentq

sys.path.insert(0, "/home/claude/vlekit")
import vlekit as v                                              # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,     # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, use_style)

OUT = os.environ.get("F5_OUT", "/home/claude/vle5/qmd/figures")
SLUG = "f5_06_double_azeotrope_fit_failure"

T_SET = 313.15
NAMES = ("acetone", "chloroform")
ABC = [-0.42, -0.93, -0.32]              # ILLUSTRATIVE — see the docstring
NOISE = {"P": 0.02, "y": 0.002}
SEED = 5
NPTS = 33

NRTL_STARTS = [(a, b) for a in (-4, -2, -1, 0.5, 2, 4)
               for b in (-4, -2, -1, 0.5, 2, 4)]
VL_STARTS = [(a, b) for a in (-0.3, -1.0, -3.0, -6.0)
             for b in (-0.3, -1.0, -3.0, -6.0)]
VL_BOUNDS = ([-20.0, -20.0], [-1e-4, -1e-4])


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


# --------------------------------------------------------------------------
def curve(model, c1, c2, n=4001):
    x = np.linspace(1e-5, 1 - 1e-5, n)
    P, y = v.bubble_P(model, x, np.full_like(x, T_SET), c1, c2)
    return x, P, y


def azeotropes(model, c1, c2):
    """Every interior root of y1(x1) - x1 = 0, not just the first."""
    x, _, y = curve(model, c1, c2, 8001)
    f = y - x
    out = []
    for i in np.where(np.diff(np.sign(f)) != 0)[0]:
        def g(z):
            return float(v.bubble_P(model, np.array([z]),
                                    np.array([T_SET]), c1, c2)[1][0] - z)
        r = brentq(g, x[i], x[i + 1], xtol=1e-14)
        P = float(v.bubble_P(model, np.array([r]), np.array([T_SET]),
                             c1, c2)[0][0])
        out.append((r, P))
    return out


def nrtl_capability_scan(c1, c2, n=161, nx=401):
    """Can *any* NRTL give two azeotropes here? Asked rather than assumed.

    The answer is yes, which is why the claim on the figure is about the
    fitted model and not about the functional form. The same scan run on van
    Laar returns nothing, and for van Laar that is provable: with A and B of
    the same sign ln(gamma1/gamma2) = AB (B x2^2 - A x1^2)/(A x1 + B x2)^2 has
    exactly one interior zero, and with opposite signs the denominator
    vanishes inside the range.
    """
    L = float(np.log(c1.Psat(T_SET) / c2.Psat(T_SET)))
    x = np.linspace(1e-3, 1 - 1e-3, nx)
    grid = np.linspace(-8.0, 8.0, n)
    hits = []
    for t12 in grid:
        for t21 in grid:
            lg1, lg2 = v.NRTL([t12, t21], alpha=0.3).ln_gamma(x)
            if int(np.sum(np.diff(np.sign(lg1 - lg2 + L)) != 0)) >= 2:
                hits.append((float(t12), float(t21)))
    vl = 0
    for A in grid[::8]:
        for B in grid[::8]:
            if A * B <= 0:
                continue
            l1, l2 = v.VanLaar([A, B]).ln_gamma(x)
            vl = max(vl, int(np.sum(np.diff(np.sign(l1 - l2 + L)) != 0)))
    return dict(L=L, n=n, tried=n * n, hits=hits,
                example=hits[len(hits) // 2] if hits else None,
                vanlaar_max_zeros=vl)


def best_of_the_capable(dat, hits):
    """Of the NRTL pairs that *can* give two azeotropes, how well do they fit?

    Reported because 'NRTL cannot do it' would be false and 'the fit does not
    do it' would be weaker than it needs to be. This is the honest middle: the
    two-azeotrope region of NRTL parameter space is real, and every point in it
    is a bad fit to these data.
    """
    T = np.full(dat.n, T_SET)
    best, arg = np.inf, None
    for t12, t21 in hits:
        P, _ = v.bubble_P(v.NRTL([t12, t21], alpha=0.3), dat.x1, T,
                          dat.c1, dat.c2)
        r = float(np.sqrt(np.mean((P - dat.P) ** 2)))
        if r < best:
            best, arg = r, (t12, t21)
    return best, arg


def best_fit(dat, name, starts, **kw):
    best = None
    for p0 in starts:
        try:
            f = v.fit(dat, name, p0=list(p0), **kw)
        except Exception:
            continue
        if best is None or f.sse < best.sse:
            best = f
    return best


def make():
    c1, c2 = v.component(NAMES[0]), v.component(NAMES[1])
    true = v.FourSuffixMargules(ABC)
    pm_err, pm_ok = true.check_partial_molar()
    gd = true.gibbs_duhem_residual()

    dat = v.generate(true, np.linspace(0.02, 0.98, NPTS), T=T_SET, c1=c1,
                     c2=c2, kind="isothermal", noise=NOISE, seed=SEED,
                     label=f"{NAMES[0]}/{NAMES[1]}, synthesised")

    fits = {
        "NRTL": best_fit(dat, "nrtl", NRTL_STARTS),
        "van Laar": best_fit(dat, "vanlaar", VL_STARTS, bounds=VL_BOUNDS),
        "Margules-2": best_fit(dat, "margules",
                               [(a, b) for a in (-2, 0, 2) for b in (-2, 0, 2)]),
        "Margules-3": best_fit(dat, "margules3",
                               [(-0.4, -0.9, -0.3), (0.5, 0.0, 0.0),
                                (0.0, 0.0, 0.0)]),
    }
    az = {"true": azeotropes(true, c1, c2)}
    for k, f in fits.items():
        az[k] = azeotropes(f.model, c1, c2)

    scan = nrtl_capability_scan(c1, c2)
    scan["best_rmsP"], scan["best_tau"] = best_of_the_capable(dat,
                                                             scan["hits"])

    return dict(c1=c1, c2=c2, true=true, dat=dat, fits=fits, az=az,
                pm_err=pm_err, gd=gd, scan=scan,
                lib_azeotrope=v.flash.azeotrope(true, T_SET, c1, c2))


# --------------------------------------------------------------------------
def build(d):
    use_style()
    fig, (axL, axR) = plt.subplots(1, 2, figsize=(13.6, 6.0))
    c1, c2, dat = d["c1"], d["c2"], d["dat"]

    xt, Pt, yt = curve(d["true"], c1, c2)
    xn, Pn, yn = curve(d["fits"]["NRTL"].model, c1, c2)
    xv, Pv, yv = curve(d["fits"]["van Laar"].model, c1, c2)

    # ------------------------------------------------------------ (a) P-x-y
    axL.grid(True, zorder=0)
    axL.set_axisbelow(True)
    axL.plot(xt, Pt, "-", color=NAVY, lw=2.6, zorder=6,
             label="the system (four-suffix Margules)")
    axL.plot(yt, Pt, "--", color=NAVY, lw=1.9, zorder=6,
             label="its dew curve")
    axL.plot(dat.x1, dat.P, "o", color=INK, mfc=PAPER, mew=1.5, ms=6,
             zorder=7, label=f"$P$-$x_1$, {dat.n} synthetic points")
    axL.plot(xn, Pn, "-", color=RUST, lw=2.2, zorder=5,
             label=f"NRTL fit (rms $\\delta P$ "
                   f"{d['fits']['NRTL'].rms_P:.2f} kPa)")
    axL.plot(xv, Pv, "-", color=AMBER, lw=2.2, zorder=5,
             label=f"van Laar fit (rms $\\delta P$ "
                   f"{d['fits']['van Laar'].rms_P:.2f} kPa)")

    for xa, Pa in d["az"]["true"]:
        axL.plot([xa], [Pa], "*", color=TEAL, ms=20, mec=PAPER, mew=1.2,
                 zorder=9)

    axL.set_xlim(0, 1)
    lo = min(Pt.min(), Pn.min(), Pv.min())
    hi = max(Pt.max(), Pn.max(), Pv.max())
    axL.set_ylim(lo - 0.10 * (hi - lo), hi + 0.20 * (hi - lo))
    axL.set_xlabel("$x_1$, $y_1$   (acetone)")
    axL.set_ylabel("$P$ / kPa")
    axL.set_title("(a)  two stationary points in $P$, not one", fontsize=13,
                  pad=8)

    yl0, yl1 = axL.get_ylim()
    sp = yl1 - yl0
    a1, a2 = d["az"]["true"]
    axL.annotate(f"maximum-pressure azeotrope\n$x_1$ = {a1[0]:.4f}, "
                 f"$P$ = {a1[1]:.2f} kPa",
                 xy=a1, xytext=(0.035, yl1 - 0.035 * sp), ha="left", va="top",
                 fontsize=10.5, color=TEAL, zorder=11, linespacing=1.5,
                 bbox=dict(boxstyle="round,pad=0.28", fc=PAPER, ec=TEAL,
                           lw=1.0, alpha=0.95),
                 arrowprops=dict(arrowstyle="-", color=TEAL, lw=1.2,
                                 shrinkA=4, shrinkB=8))
    axL.annotate(f"minimum-pressure azeotrope\n$x_1$ = {a2[0]:.4f}, "
                 f"$P$ = {a2[1]:.2f} kPa",
                 xy=a2, xytext=(0.545, yl1 - 0.035 * sp), ha="left", va="top",
                 fontsize=10.5, color=TEAL, zorder=11, linespacing=1.5,
                 bbox=dict(boxstyle="round,pad=0.28", fc=PAPER, ec=TEAL,
                           lw=1.0, alpha=0.95),
                 arrowprops=dict(arrowstyle="-", color=TEAL, lw=1.2,
                                 shrinkA=4, shrinkB=8))

    # ------------------------------------------------- (b) the azeotrope test
    axR.grid(True, zorder=0)
    axR.set_axisbelow(True)
    axR.axhline(0.0, color=GRAPHITE, lw=1.2, zorder=3)
    axR.plot(xt, yt - xt, "-", color=NAVY, lw=2.8, zorder=6,
             label="the system")
    axR.plot(xn, yn - xn, "-", color=RUST, lw=2.4, zorder=5, label="NRTL fit")
    axR.plot(xv, yv - xv, "-", color=AMBER, lw=2.4, zorder=5,
             label="van Laar fit")
    axR.plot(dat.x1, dat.y1 - dat.x1, "o", color=INK, mfc=PAPER, mew=1.5,
             ms=6, zorder=7, label="synthetic points")

    for xa, _ in d["az"]["true"]:
        axR.plot([xa], [0.0], "*", color=TEAL, ms=20, mec=PAPER, mew=1.2,
                 zorder=9)
    for xa, _ in d["az"]["NRTL"]:
        axR.plot([xa], [0.0], "o", color=RUST, ms=9, mec=PAPER, mew=1.4,
                 zorder=9)
    for xa, _ in d["az"]["van Laar"]:
        axR.plot([xa], [0.0], "s", color=AMBER, ms=9, mec=PAPER, mew=1.4,
                 zorder=9)

    axR.set_xlim(0, 1)
    dy = np.concatenate([yt - xt, yn - xn, yv - xv])
    lo, hi = float(dy.min()), float(dy.max())
    axR.set_ylim(lo - 0.62 * (hi - lo), hi + 0.30 * (hi - lo))
    axR.set_xlabel("$x_1$   (acetone)")
    axR.set_ylabel("$y_1 - x_1$")
    axR.set_title("(b)  an azeotrope is a zero of $y_1-x_1$; "
                  "count them", fontsize=13, pad=8)

    yr0, yr1 = axR.get_ylim()
    spr = yr1 - yr0
    nz = ", ".join(f"{a:.4f}" for a, _ in d["az"]["NRTL"])
    vz = ", ".join(f"{a:.4f}" for a, _ in d["az"]["van Laar"])
    tz = ", ".join(f"{a:.4f}" for a, _ in d["az"]["true"])
    f_n, f_v = d["fits"]["NRTL"], d["fits"]["van Laar"]
    axR.text(0.015, yr0 + 0.030 * spr,
             f"system      zeros at {tz}\n"
             f"NRTL        zeros at {nz}   "
             f"(rms $\\delta P$ {f_n.rms_P:.2f} kPa, "
             f"$\\delta y$ {f_n.rms_y:.4f})\n"
             f"van Laar    zero  at {vz}   "
             f"(rms $\\delta P$ {f_v.rms_P:.2f} kPa, "
             f"$\\delta y$ {f_v.rms_y:.4f})\n"
             f"noise put into the data: $\\sigma_P$ = {NOISE['P']:g} kPa, "
             f"$\\sigma_y$ = {NOISE['y']:g}",
             ha="left", va="bottom", fontsize=10.5, color=INK, zorder=11,
             linespacing=1.6, family="DejaVu Sans Mono",
             bbox=dict(boxstyle="round,pad=0.32", fc=PAPER, ec=MIST, lw=1.0,
                       alpha=0.96))

    # ------------------------------------------------------------- furniture
    h1, l1 = axL.get_legend_handles_labels()
    fig.legend(h1, l1, loc="lower center", ncol=5, fontsize=10.5,
               bbox_to_anchor=(0.5, -0.045), frameon=False)

    fig.suptitle("Neither two-parameter fit reproduces the double azeotrope "
                 "— and one of them cannot, whatever its parameters",
                 fontsize=14.5, y=0.995)

    m2, m3 = d["fits"]["Margules-2"], d["fits"]["Margules-3"]
    m2z = ", ".join(f"{a:.4f}" for a, _ in d["az"]["Margules-2"])
    m3z = ", ".join(f"{a:.4f}" for a, _ in d["az"]["Margules-3"])
    fig.text(0.5, -0.095,
             "ILLUSTRATIVE SYSTEM: four-suffix Margules "
             f"$A$ = {ABC[0]:g}, $B$ = {ABC[1]:g}, $C$ = {ABC[2]:g} for "
             f"acetone (1) / chloroform (2) at {T_SET:g} K, constructed to "
             "place two azeotropes inside the range.  Not fitted to measured "
             "VLE; the Antoine constants are vlekit's.\n"
             "Honest small print, every number computed in this script.\n"
             "van Laar cannot give two interior azeotropes for any same-sign "
             "$A$, $B$: that is algebra, and the scan here finds at most "
             f"{d['scan']['vanlaar_max_zeros']} interior zero.\n"
             f"NRTL can — {len(d['scan']['hits'])} of "
             f"{d['scan']['tried']} pairs on a "
             f"{d['scan']['n']}$\\times${d['scan']['n']} grid over "
             r"$\tau\in[-8,8]$ give two — "
             f"but the best of those {len(d['scan']['hits'])} still leaves "
             f"rms $\\delta P$ = {d['scan']['best_rmsP']:.2f} kPa.\n"
             f"The three-suffix Margules, also two-parameter, keeps two "
             f"zeros ({m2z}) yet misplaces both, at rms $\\delta P$ = "
             f"{m2.rms_P:.2f} kPa.  Refitting the generating form recovers "
             f"({m3z}) at rms $\\delta P$ = {m3.rms_P:.3f} kPa.\n"
             "It is the shape of $G^E$ that decides, not the number of "
             "parameters.",
             ha="center", va="top", fontsize=10, color=SLATE, linespacing=1.6)
    fig.tight_layout()
    return fig


if __name__ == "__main__":
    d = make()
    print(f"generating model: four-suffix Margules A, B, C = {ABC} "
          f"(illustrative), {NAMES[0]}/{NAMES[1]} at {T_SET:g} K")
    print(f"  check_partial_molar {d['pm_err']:.2e}, "
          f"gibbs_duhem_residual {d['gd']:.2e}")
    print(f"  vlekit.flash.azeotrope returns {d['lib_azeotrope']} — it "
          "brackets one root over the whole range, so a double azeotrope is "
          "invisible to it")
    print("  azeotropes found by scanning y1 - x1:")
    for a, P in d["az"]["true"]:
        print(f"      x1 = {a:.6f}   P = {P:.4f} kPa")
    print(f"  synthetic data: {d['dat'].n} points, sigma_P = "
          f"{NOISE['P']:g} kPa, sigma_y = {NOISE['y']:g}, seed {SEED}, "
          f"P from {d['dat'].P.min():.2f} to {d['dat'].P.max():.2f} kPa")
    sc = d["scan"]
    print(f"  capability scan at ln(Psat1/Psat2) = {sc['L']:.5f}: "
          f"{len(sc['hits'])} of {sc['tried']} NRTL pairs on the "
          f"{sc['n']}x{sc['n']} grid over tau in [-8, 8] give two interior "
          f"azeotropes (e.g. tau = {np.round(sc['example'], 2)}); "
          f"van Laar gives at most {sc['vanlaar_max_zeros']}")
    print(f"  best fit among those {len(sc['hits'])} two-azeotrope NRTL "
          f"pairs: rms dP {sc['best_rmsP']:.4f} kPa at tau = "
          f"{np.round(sc['best_tau'], 2)}")
    for name in ("NRTL", "van Laar", "Margules-2", "Margules-3"):
        f = d["fits"][name]
        zz = ", ".join(f"{a:.5f}" for a, _ in d["az"][name])
        print(f"  {name:<11s} params {np.round(f.params, 5)}  "
              f"rms dP {f.rms_P:.4f} kPa  rms dy {f.rms_y:.5f}  "
              f"SSE {f.sse:.4g}  azeotropes at [{zz}]")
    for p in write(build(d), SLUG):
        print("wrote", p)
