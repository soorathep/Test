#!/usr/bin/env python3
"""F5.4  A residue curve map with its distillation boundary located by
bisection, and two feeds on opposite sides of it.

2105603 Advanced Chemical Engineering Thermodynamics — Module 5
Soorathep Kheawhom, Chulalongkorn University

The residue curve is the composition of the liquid left behind in a simple open
evaporation:  dx_i/d(xi) = x_i - y_i. Its fixed points are the pure components
and the azeotropes, and the curves that run between them divide the triangle
into regions. A batch still — and, to a good approximation, a simple
distillation column — cannot move a composition from one region to another. The
boundary is a hard constraint on a flowsheet, and it is invisible in the
K-values.

How the boundary here was found, in order:

    1. two feeds, [0.30, 0.30, 0.40] and [0.20, 0.20, 0.60], are integrated
       forward and end at *different* stable nodes;
    2. the segment joining them is bisected on which node the curve reaches,
       24 times, until the bracket is 6e-8 wide;
    3. the point in that bracket is integrated backwards (to the unstable node
       it came from) and forwards (into the saddle it is running towards);
    4. the saddle turns out to be a ternary azeotrope. `vlekit.multi.
       fixed_points` states in its own docstring that it does not search for
       ternary azeotropes, so this one is found here by a Newton solve on
       y(x) - x = 0 started from the end of that integration, and the residual
       is printed;
    5. the second branch of the boundary is the same integration started just
       the other side of the saddle along the same direction.

Nothing on the figure was drawn by eye.

ILLUSTRATIVE INPUT: the NRTL tau matrix and alpha = 0.30 for acetone (1) /
chloroform (2) / methanol (3) are a teaching parameter set. They reproduce the
qualitative behaviour this mixture is famous for — three binary azeotropes and
a ternary saddle — but they are NOT fitted to measured VLE, and the figure says
so on its face. The Antoine constants are the real ones from vlekit's library.

Run:  python3 f5_04.py      (about three minutes; it integrates ~30 curves)
"""
import os
import sys

import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import fsolve

sys.path.insert(0, "/home/claude/vlekit")
import vlekit as v                                              # noqa: E402
from vlekit.multi import (NRTLMulti, _bubble_T_multi,           # noqa: E402
                          fixed_points, residue_curve, to_xy)
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,     # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, use_style)

OUT = os.environ.get("F5_OUT", "/home/claude/vle5/qmd/figures")
SLUG = "f5_04_residue_curves_boundary"

NAMES = ("acetone", "chloroform", "methanol")
TAU = np.array([[0.00, -0.90, 0.60],           # ILLUSTRATIVE — see docstring
                [-0.75, 0.00, 1.30],
                [0.45, 1.10, 0.00]])
ALPHA = 0.30
P_SET = 101.325

FEED_A = np.array([0.30, 0.30, 0.40])
FEED_B = np.array([0.20, 0.20, 0.60])

STARTS = [(0.55, 0.15, 0.30), (0.40, 0.42, 0.18), (0.20, 0.55, 0.25),
          (0.10, 0.35, 0.55), (0.42, 0.10, 0.48), (0.62, 0.28, 0.10),
          (0.15, 0.15, 0.70), (0.30, 0.08, 0.62), (0.08, 0.55, 0.37),
          (0.25, 0.62, 0.13), (0.50, 0.35, 0.15), (0.07, 0.20, 0.73),
          (0.72, 0.10, 0.18), (0.34, 0.56, 0.10)]

S3 = np.sqrt(3) / 2


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def xy(x):
    return to_xy(np.atleast_2d(np.asarray(x, dtype=float)))


# --------------------------------------------------------------------------
def vapour_of(m, comps, x, P=P_SET):
    """y in equilibrium with x at the bubble temperature, by modified Raoult."""
    x = np.clip(np.asarray(x, dtype=float), 1e-12, None)
    x = x / x.sum()
    T = _bubble_T_multi(m, comps, x, P)
    y = x * m.gamma(x) * np.array([c.Psat(T) for c in comps]) / P
    return y / y.sum(), T


def ternary_azeotrope(m, comps, x0):
    """Newton on y(x) - x = 0 in the two free mole fractions."""
    def F(u):
        x = np.array([u[0], u[1], 1 - u[0] - u[1]])
        y, _ = vapour_of(m, comps, x)
        return [y[0] - x[0], y[1] - x[1]]

    u = fsolve(F, [x0[0], x0[1]], xtol=1e-13)
    x = np.array([u[0], u[1], 1 - u[0] - u[1]])
    y, T = vapour_of(m, comps, x)
    return x, T, float(np.max(np.abs(y - x)))


def full_curve(m, comps, x0, steps=2600, dxi=5e-3):
    """One residue curve, integrated both ways and joined."""
    fwd, Tf = residue_curve(m, comps, x0, P=P_SET, steps=steps, dxi=dxi,
                            forward=True)
    bwd, Tb = residue_curve(m, comps, x0, P=P_SET, steps=steps, dxi=dxi,
                            forward=False)
    path = np.vstack([bwd[::-1], fwd[1:]])
    return path, fwd[-1], bwd[-1]


def make():
    comps = [v.component(n) for n in NAMES]
    m = NRTLMulti(TAU, ALPHA)

    fps = fixed_points(m, comps, P=P_SET, grid=41)

    # ---- 1. the two feeds land on different stable nodes
    endA = residue_curve(m, comps, FEED_A, P=P_SET, steps=3000,
                         dxi=5e-3)[0][-1]
    endB = residue_curve(m, comps, FEED_B, P=P_SET, steps=3000,
                         dxi=5e-3)[0][-1]

    def which(x0):
        e = residue_curve(m, comps, x0, P=P_SET, steps=1800, dxi=1e-2)[0][-1]
        return 0 if np.linalg.norm(e - endA) < np.linalg.norm(e - endB) else 1

    # ---- 2. bisect the segment between them
    lo, hi = 0.0, 1.0
    for _ in range(24):
        mid = 0.5 * (lo + hi)
        if which((1 - mid) * FEED_A + mid * FEED_B) == 0:
            lo = mid
        else:
            hi = mid
    s = 0.5 * (lo + hi)
    x_star = (1 - s) * FEED_A + s * FEED_B

    # ---- 3. the branch that runs into the saddle, and the one that came from
    #         the unstable node
    into, _ = residue_curve(m, comps, x_star, P=P_SET, steps=5000, dxi=2.5e-3,
                            forward=True)
    back, _ = residue_curve(m, comps, x_star, P=P_SET, steps=6000, dxi=2.5e-3,
                            forward=False)

    # ---- 4. the saddle is a ternary azeotrope; locate it properly
    x_sad, T_sad, res_sad = ternary_azeotrope(m, comps, into[-1])

    # ---- 5. the other branch of the same stable manifold
    d = x_sad - into[-40]
    d = d / np.linalg.norm(d)
    x_other = np.clip(x_sad + 0.004 * d, 1e-9, None)
    x_other = x_other / x_other.sum()
    other, _ = residue_curve(m, comps, x_other, P=P_SET, steps=9000,
                             dxi=2.5e-3, forward=False)

    boundary = np.vstack([back[::-1], into, other])

    # ---- the map itself
    curves = []
    for x0 in STARTS:
        path, ef, eb = full_curve(m, comps, np.array(x0))
        side = 0 if np.linalg.norm(ef - endA) < np.linalg.norm(ef - endB) else 1
        curves.append(dict(path=path, end=ef, start=eb, side=side, x0=x0))

    pathA = residue_curve(m, comps, FEED_A, P=P_SET, steps=3000,
                          dxi=5e-3)[0]
    pathB = residue_curve(m, comps, FEED_B, P=P_SET, steps=3000,
                          dxi=5e-3)[0]

    # classification of the fixed points, taken from where the integrated
    # curves actually go rather than from a rule of thumb about temperature
    ends = [c["end"] for c in curves] + [endA, endB]
    starts = [c["start"] for c in curves]

    def kind_of(x):
        if any(np.linalg.norm(x - e) < 1e-2 for e in ends):
            return "stable node"
        if any(np.linalg.norm(x - e) < 1e-2 for e in starts):
            return "unstable node"
        return "saddle"

    for f in fps:
        f["role"] = kind_of(f["x"])

    return dict(m=m, comps=comps, fps=fps, endA=endA, endB=endB, s=s,
                x_star=x_star, boundary=boundary, x_sad=x_sad, T_sad=T_sad,
                res_sad=res_sad, curves=curves, pathA=pathA, pathB=pathB,
                bracket=hi - lo, kind_of=kind_of)


# --------------------------------------------------------------------------
def triangle(ax, names):
    V = np.array([[0.0, 0.0], [1.0, 0.0], [0.5, S3]])
    ax.add_patch(plt.Polygon(V, closed=True, fill=False, edgecolor=GRAPHITE,
                             lw=1.8, zorder=6))
    for c in np.arange(0.1, 0.91, 0.1):
        for i in range(3):
            a, b = np.zeros(3), np.zeros(3)
            a[i] = b[i] = c
            a[(i + 1) % 3] = 1 - c
            b[(i + 2) % 3] = 1 - c
            p, q = xy(a)[0], xy(b)[0]
            ax.plot([p[0], q[0]], [p[1], q[1]], "-", color=MIST, lw=0.7,
                    alpha=0.8, zorder=1)
    for c in np.arange(0.2, 0.81, 0.2):
        p = xy([1 - c, c, 0.0])[0]
        ax.text(p[0], p[1] - 0.040, f"{c:.1f}", ha="center", va="top",
                fontsize=11.5, color=GRAPHITE)
        p = xy([0.0, 1 - c, c])[0]
        ax.text(p[0] + 0.032, p[1] + 0.018, f"{c:.1f}", ha="left",
                va="center", fontsize=11.5, color=GRAPHITE)
        p = xy([c, 0.0, 1 - c])[0]
        ax.text(p[0] - 0.032, p[1] + 0.018, f"{c:.1f}", ha="right",
                va="center", fontsize=11.5, color=GRAPHITE)
    ax.text(0.5, -0.125, r"$x_2 \longrightarrow$", ha="center", va="center",
            fontsize=13, color=INK)
    ax.text(0.75 + 0.22 * 0.866, 0.433 + 0.22 * 0.5, r"$x_3 \longrightarrow$",
            ha="center", va="center", fontsize=13, color=INK, rotation=-60)
    ax.text(0.25 - 0.22 * 0.866, 0.433 + 0.22 * 0.5, r"$\longleftarrow x_1$",
            ha="center", va="center", fontsize=13, color=INK, rotation=60)
    # the two lower vertex names sit centred *under* their vertex rather than
    # beside it: beside it they run into the right-hand text column
    for p, lab, ha, va, dx, dy in (
            (V[0], f"1  {names[0]}", "center", "top", 0.005, -0.078),
            (V[1], f"2  {names[1]}", "center", "top", -0.005, -0.078),
            (V[2], f"3  {names[2]}", "center", "bottom", 0.0, 0.032)):
        ax.text(p[0] + dx, p[1] + dy, lab, ha=ha, va=va, fontsize=13.5,
                color=INK, fontweight="bold")


def build(d):
    use_style()
    fig, ax = plt.subplots(figsize=(13.6, 8.2))
    ax.set_aspect("equal")
    ax.axis("off")
    ax.set_xlim(-0.17, 1.86)
    ax.set_ylim(-0.19, 1.00)
    triangle(ax, NAMES)

    COL = (SKYBLUE, AMBER)
    LAB = ("towards the acetone/chloroform azeotrope",
           "towards pure methanol")
    seen = set()
    for c in d["curves"]:
        P = to_xy(c["path"])
        lab = LAB[c["side"]] if c["side"] not in seen else None
        seen.add(c["side"])
        ax.plot(P[:, 0], P[:, 1], "-", color=COL[c["side"]], lw=1.9,
                alpha=0.95, zorder=3, label=lab)
        k = int(0.62 * len(P))
        ax.annotate("", xy=(P[k + 6, 0], P[k + 6, 1]),
                    xytext=(P[k, 0], P[k, 1]), zorder=4,
                    arrowprops=dict(arrowstyle="-|>", mutation_scale=15,
                                    color=COL[c["side"]], lw=0))

    # ---- the boundary
    B = to_xy(d["boundary"])
    ax.plot(B[:, 0], B[:, 1], "-", color=RUST, lw=3.4, zorder=8,
            label="distillation boundary (located by bisection)")

    # ---- the two feeds, and where each one actually boils down to. Only the
    # forward half is drawn: the backward halves of the two run together and
    # would read as a single curve crossing the boundary, which is the one
    # thing this figure must not suggest.
    for path, feed, mk, lab in (
            (d["pathA"], FEED_A, "o", "feeds A and B, and where each boils to"),
            (d["pathB"], FEED_B, "s", None)):
        P = to_xy(path)
        ax.plot(P[:, 0], P[:, 1], "-", color=NAVY, lw=2.6, zorder=9,
                label=lab if mk == "o" else None)
        k = int(0.45 * len(P))
        ax.annotate("", xy=(P[k + 6, 0], P[k + 6, 1]),
                    xytext=(P[k, 0], P[k, 1]), zorder=10,
                    arrowprops=dict(arrowstyle="-|>", mutation_scale=17,
                                    color=NAVY, lw=0))
        p = xy(feed)[0]
        ax.plot([p[0]], [p[1]], mk, color=NAVY, ms=12, mec=PAPER, mew=1.8,
                zorder=11)

    # ---- fixed points, marked by the role the integration gave them
    MARK = {"stable node": ("o", TEAL, 13),
            "unstable node": ("s", RUST, 11),
            "saddle": ("^", GRAPHITE, 11)}
    for f in d["fps"]:
        p = xy(f["x"])[0]
        mk, col, ms = MARK[f["role"]]
        ax.plot([p[0]], [p[1]], mk, color=col, ms=ms, mec=PAPER, mew=1.5,
                zorder=12)
    ps = xy(d["x_sad"])[0]
    ax.plot([ps[0]], [ps[1]], "^", color=GRAPHITE, ms=11, mec=PAPER, mew=1.5,
            zorder=12)

    # ======================================================================
    # labels: the fixed-point temperatures go in a table in the right-hand
    # column, keyed by a short tag drawn at the point, so that no long string
    # ever sits inside the triangle
    # ======================================================================
    xcol = 1.16
    ax.legend(loc="upper left", bbox_to_anchor=(xcol - 0.03, 0.985),
              bbox_transform=ax.transData, fontsize=11, labelspacing=0.7,
              handlelength=2.4)

    rows = []
    for f in d["fps"]:
        nm = ("pure " + NAMES[f["which"][0]] if f["kind"] == "pure"
              else f"azeo {NAMES[f['which'][0]][:4]}/{NAMES[f['which'][1]][:4]}")
        rows.append((f["T"], nm, f["role"]))
    rows.append((d["T_sad"], "azeo ternary", d["kind_of"](d["x_sad"])))
    rows.sort()
    txt = "fixed points at 101.325 kPa, typed by\nwhere the integrated curves go\n"
    for T, nm, kind in rows:
        txt += (f"{T:7.2f} K  {nm:<18s}{kind}\n")
    ax.text(xcol, 0.775, txt.rstrip("\n"), ha="left", va="top",
            fontsize=10.5, color=INK,
            linespacing=1.55, family="DejaVu Sans Mono", zorder=12,
            bbox=dict(boxstyle="round,pad=0.34", fc=PAPER, ec=MIST, lw=1.0,
                      alpha=0.97))

    ax.annotate(
        f"ternary azeotrope, {d['T_sad']:.2f} K\n"
        f"$x$ = ({d['x_sad'][0]:.4f}, {d['x_sad'][1]:.4f}, "
        f"{d['x_sad'][2]:.4f})\n"
        f"max $|y-x|$ = {d['res_sad']:.1e}\n"
        "the saddle the boundary runs into —\n"
        "fixed_points does not return this one,\n"
        "and says so in its own docstring",
        xy=(xy(d["x_sad"])[0][0], xy(d["x_sad"])[0][1]),
        xytext=(xcol, 0.375), ha="left", va="top", fontsize=10.5,
        color=GRAPHITE, zorder=12, linespacing=1.5,
        bbox=dict(boxstyle="round,pad=0.32", fc=PAPER, ec=GRAPHITE, lw=1.0,
                  alpha=0.96),
        arrowprops=dict(arrowstyle="-", color=GRAPHITE, lw=1.2, shrinkA=5,
                        shrinkB=9))

    sep = np.abs(FEED_A - FEED_B)
    ax.text(xcol, 0.100,
            f"boundary crossed at $s$ = {d['s']:.6f}\n"
            f"on the segment A$\\to$B, bracket {d['bracket']:.0e}\n"
            f"$x^*$ = ({d['x_star'][0]:.5f}, {d['x_star'][1]:.5f}, "
            f"{d['x_star'][2]:.5f})\n"
            "A $\\to$ acetone/chloroform azeotrope\n"
            "B $\\to$ pure methanol\n"
            f"A and B differ by ({sep[0]:.2f}, {sep[1]:.2f}, "
            f"{sep[2]:.2f})\nand no simple still can cross between them",
            ha="left", va="top", fontsize=10.5, color=RUST, zorder=12,
            linespacing=1.5,
            bbox=dict(boxstyle="round,pad=0.32", fc=PAPER, ec=RUST, lw=1.0,
                      alpha=0.96))

    for feed, tag in ((FEED_A, "A"), (FEED_B, "B")):
        p = xy(feed)[0]
        ax.text(p[0] - 0.035, p[1] + 0.010, tag, ha="right", va="bottom",
                fontsize=13, color=NAVY, fontweight="bold", zorder=13,
                bbox=dict(boxstyle="round,pad=0.15", fc=PAPER, ec="none",
                          alpha=0.85))

    ax.set_title("A distillation boundary is a hard constraint: two "
                 "neighbouring feeds, two different products",
                 fontsize=14.5, pad=6, loc="left", x=-0.02)
    fig.text(0.5, 0.012,
             "ILLUSTRATIVE PARAMETERS: NRTL with tau = [[0, -0.90, 0.60], "
             "[-0.75, 0, 1.30], [0.45, 1.10, 0]] and alpha = 0.30 for all "
             "pairs.  A teaching set that reproduces the qualitative "
             "behaviour of acetone/chloroform/methanol —\nthree binary "
             "azeotropes and a ternary saddle — but it is not fitted to "
             "measured VLE, so the temperatures above are the model's, not "
             "the mixture's.  The Antoine constants are vlekit's library "
             "values.",
             ha="center", va="top", fontsize=10, color=SLATE, linespacing=1.55)
    fig.tight_layout(rect=(0, 0.055, 1, 1))
    return fig


if __name__ == "__main__":
    d = make()
    print(f"system: {NAMES} at {P_SET:g} kPa, NRTL alpha = {ALPHA}"
          " (illustrative)")
    print("fixed points from vlekit.multi.fixed_points:")
    for f in sorted(d["fps"], key=lambda f: f["T"]):
        print(f"   {f['T']:7.2f} K  {f['kind']:<18s} "
              f"x = {np.round(f['x'], 5)}")
    print(f"   {d['T_sad']:7.2f} K  ternary azeotrope   "
          f"x = {np.round(d['x_sad'], 5)}   (Newton, max|y-x| = "
          f"{d['res_sad']:.2e}; fixed_points does not look for this one)")
    print(f"feed A {FEED_A} -> {np.round(d['endA'], 5)}")
    print(f"feed B {FEED_B} -> {np.round(d['endB'], 5)}")
    print(f"boundary crossing on the A->B segment at s = {d['s']:.8f}, "
          f"bracket width {d['bracket']:.2e}")
    print(f"   x* = {np.round(d['x_star'], 6)}")
    print(f"boundary polyline: {len(d['boundary'])} points, from "
          f"{np.round(d['boundary'][0], 4)} to "
          f"{np.round(d['boundary'][-1], 4)}")
    print(f"{len(d['curves'])} residue curves drawn; "
          f"{sum(1 for c in d['curves'] if c['side'] == 0)} end at the "
          f"acetone/chloroform azeotrope, "
          f"{sum(1 for c in d['curves'] if c['side'] == 1)} at methanol")
    for p in write(build(d), SLUG):
        print("wrote", p)
