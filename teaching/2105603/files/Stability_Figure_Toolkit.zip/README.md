# Module 5 lecture figures — 2105603 Advanced Chemical Engineering Thermodynamics

Soorathep Kheawhom, Chulalongkorn University.

Standalone scripts, one per figure. Each writes a PNG **and** a PDF of the same
render into `/home/claude/vle5/qmd/figures/` at 300 dpi and prints, to stdout,
every number it computed and every path it wrote.

```
cd /home/claude/vle5/toolkit
python3 f5_01.py          # ... f5_02, f5_03, f5_04, f5_06
for f in f5_*.py; do python3 "$f"; done
```

Every script adds `/home/claude/vlekit` to `sys.path` and does its physics with
`vlekit` — `flash` (binary `g_mix`, `spinodal`, `miscibility_gap`,
`azeotrope`), `multi` (multicomponent NRTL, `tpd_curve`, `stability`,
`tie_lines`, `binodal_from_tielines`, `plait_point`, `residue_curve`,
`fixed_points`, `to_xy`), `regress` (`fit`, `generate`, `bubble_P`) and
`models`. Colours and rcParams come from `vlekit.plots` (NAVY, AMBER, TEAL,
RUST, GRAPHITE, INK, MIST, SLATE, SKYBLUE, PAPER — no others). The output
directory can be overridden with the `F5_OUT` environment variable.

`f5_05.py` (the Peng-Robinson mixture phase envelope) is maintained separately;
see its own docstring. It is listed below for completeness but its inputs are
not audited here.

**Rule for this set: no number printed on a figure was typed in.** Each is the
value a run of the code returned. Where a model *parameter* is illustrative
rather than fitted, the figure says so on its own face, in full, and the
relevant row below repeats it.

---

## The figures

| file | figure | the claim it supports | illustrative / assumed inputs |
|---|---|---|---|
| `f5_01.py` | F5.1 `f5_01_gmix_binodal_spinodal` | The binodal is where a single tangent line touches `Δg_mix` twice and the spinodal is where its curvature changes sign; between them the liquid is metastable — locally the best state available, globally not — and escaping that band costs a real, computable barrier. | **Three-suffix Margules `A12 = 2.6, A21 = 2.0`.** A teaching pair chosen to put a partially miscible binary on one screen; not fitted to any measured mixture. Stated on the figure. Nothing else is assumed. |
| `f5_02.py` | F5.2 `f5_02_tangent_plane_distance` | One negative tangent plane distance anywhere proves a feed is not a single phase; proving that it *is* one requires the global minimum over the whole simplex. | **Ternary NRTL `tau = [[0, 0.60, 3.20], [0.35, 0, 0.90], [2.80, 0.55, 0]]`, `alpha_13 = 0.20`, `alpha_12 = alpha_23 = 0.30`.** A teaching set giving a clean type-I dome; not fitted to any measured ternary, and the components are deliberately unnamed. The two feeds `z = (0.30, 0.30, 0.40)` and `(0.10, 0.70, 0.20)` are choices, not data. Stated on the figure. |
| `f5_03.py` | F5.3 `f5_03_ternary_lle_tielines` | A type-I ternary liquid-liquid diagram is not drawn — it is 22 converged flashes, and its binodal, tie lines and plait point all follow from one `G^E` with no ternary parameters. | Same ternary NRTL as F5.2 (illustrative, stated on the figure). Feeds are 23 points on the `x1 = x3` line, `x2 = 0.02` to `0.58` — a choice of grid, not data. |
| `f5_04.py` | F5.4 `f5_04_residue_curves_boundary` | A distillation boundary is a hard constraint: two feeds that differ by (0.10, 0.10, 0.20) in mole fraction boil down to different products, and no simple still can carry a composition across the separatrix between them. | **Ternary NRTL `tau = [[0, -0.90, 0.60], [-0.75, 0, 1.30], [0.45, 1.10, 0]]`, `alpha = 0.30` for all pairs**, for acetone (1) / chloroform (2) / methanol (3) at 101.325 kPa. It reproduces the qualitative behaviour this mixture is known for — three binary azeotropes and a ternary saddle — but it is **not fitted to measured VLE**, so the temperatures on the figure are the model's, not the mixture's. Stated on the figure. The Antoine constants **are** the real library values. The two feeds are choices. |
| `f5_05.py` | F5.5 `f5_05_retrograde_envelope` | (Maintained separately — Peng-Robinson mixture envelope; the mixture critical point is not the top of the dome.) | See that script's own docstring; not audited here. |
| `f5_06.py` | F5.6 `f5_06_double_azeotrope_fit_failure` | A double azeotrope is a property of the *shape* of `G^E`, not of the number of parameters: fitted to P-x-y data from a system with two azeotropes, neither NRTL nor van Laar reproduces them, and van Laar structurally cannot. | **Four-suffix Margules `A = -0.42, B = -0.93, C = -0.32`** for acetone (1) / chloroform (2) at 313.15 K, constructed so that the two azeotropes sit at `z = x1 - x2 = -0.6` and `+0.4` with the third root of the cubic outside the range. **Not fitted to measured VLE.** The "measurements" are synthesised by `vlekit.regress.generate` with `sigma_P = 0.02 kPa`, `sigma_y = 0.002`, seed 5, 33 points — a deliberate choice of noise level, stated on the figure. Antoine constants are the real library values. |

---

## What is computed rather than asserted

**F5.1** — binodal `x1 = 0.13315 / 0.74705` from `flash.miscibility_gap`;
spinodal `0.23567 / 0.61007` from `flash.spinodal`; the metastable bands are
therefore `0.1332–0.2357` (width 0.1025) and `0.6101–0.7470` (width 0.1370).
The tangent drawn at the metastable `x1 = 0.1844` is differenced against the
curve to give the escape barrier `+0.00161 RT` (crest at `x1 = 0.3009`) and the
descent `-0.05416 RT` at `x1 = 0.7908`. Common tangent slope `-0.09364`.

**F5.2** — for `z = (0.30, 0.30, 0.40)`: minimum on the drawn line
`TPD = -0.137846` at `w = (0.671, 0.300, 0.029)`; global minimum
`-0.190593` at `w = (0.8386, 0.1455, 0.0159)` from `multi.stability`, which is
*off* that line and is said to be. For `z = (0.10, 0.70, 0.20)`: the line's only
zero is the trivial one at `w = z` (TPD there is `7e-09`, i.e. zero to the
integration tolerance) and the global minimum is `+0.075477` at
`w = (0, 0.6525, 0.3475)`.

**F5.3** — 23 feeds, 22 split, 1 dropped as outside the dome (the count is
printed and shown). Tie-line length 0.2198 to 1.3516. Material balance
`max |beta xI + (1-beta) xII - z| = 1.665e-16`; isoactivity
`max |gamma_i^I x_i^I - gamma_i^II x_i^II| = 1.557e-11`. Plait point estimate
`x = (0.13368, 0.57378, 0.29254)`, extrapolated from tie lines down to length
0.2198 and labelled an estimate. Highlighted tie line: feed
`(0.3882, 0.2236, 0.3882)`, `xI = (0.7101, 0.2595, 0.0304)`,
`xII = (0.0287, 0.1836, 0.7877)`, `beta = 0.52757`.

**F5.4** — the boundary is *located*, not drawn: feed A `(0.30, 0.30, 0.40)`
ends at the acetone/chloroform azeotrope and feed B `(0.20, 0.20, 0.60)` at pure
methanol, so the segment A→B is bisected 24 times on which node the curve
reaches, giving `s* = 0.81321731` with a bracket `5.96e-08`, i.e.
`x* = (0.218678, 0.218678, 0.562643)`. Integrating backwards from `x*` reaches
the chloroform/methanol azeotrope; forwards it stalls at a saddle, which is a
**ternary azeotrope** — `vlekit.multi.fixed_points` states in its own docstring
that it does not search for these, so it is found here by Newton on `y(x) - x`:
`x = (0.29954, 0.14943, 0.55103)` at `329.494 K` with `max|y - x| = 2.8e-17`.
The second branch of the boundary is the same integration started the other side
of that saddle, and it reaches the acetone/methanol azeotrope, so the boundary
runs edge to edge. Fixed points are typed (stable node / unstable node / saddle)
from where the 14 integrated curves actually go, not from a temperature rule.

**F5.6** — the generating model passes `check_partial_molar` (4.5e-11) and
`gibbs_duhem_residual` (3.2e-11). Its azeotropes, found by scanning
`y1 - x1` and refining with Brent, are `x1 = 0.200063` (`P = 49.7557 kPa`,
maximum-pressure) and `x1 = 0.699898` (`P = 45.0144 kPa`, minimum-pressure).
`vlekit.flash.azeotrope` returns **None** for this model, because it brackets
one root over the whole range — reported rather than worked around. Fits, each
the best of a multi-start:

| model | parameters | rms δP / kPa | rms δy | azeotropes found |
|---|---|---|---|---|
| NRTL (36 starts) | `tau = (-1.86817, 4.53989)` | 1.9130 | 0.04652 | 0.10279, 0.53091 |
| van Laar (16 starts, both parameters negative) | `A, B = (-0.2194, -3.31003)` | 1.5619 | 0.03793 | 0.57905 |
| Margules-2 (9 starts) | `A12, A21 = (0.45119, -1.39429)` | 0.5055 | 0.01332 | 0.16688, 0.66278 |
| Margules-3 (the generating form, refitted) | `A, B, C = (-0.42049, -0.93096, -0.32026)` | 0.0170 | 0.00164 | 0.19994, 0.69994 |

against noise of `sigma_P = 0.02 kPa`. Two capability scans are run in the
script and printed on the figure: van Laar reaches at most **1** interior zero
of `ln(gamma1/gamma2) + ln(Psat1/Psat2)`, which is also provable from its
algebra; NRTL reaches two for **1564 of 25921** `(tau12, tau21)` pairs on a
161×161 grid over `[-8, 8]` at `alpha = 0.3`, but the best fit among those 1564
still leaves `rms δP = 1.955 kPa`.

## An honest correction to the usual lecture claim

The familiar statement "a two-parameter model cannot produce a double
azeotrope" is **false as stated**, and F5.6 says so rather than repeating it.

* **van Laar genuinely cannot.** With `A` and `B` of the same sign,
  `ln(gamma1/gamma2) = AB (B x2^2 - A x1^2)/(A x1 + B x2)^2` has exactly one
  interior zero; with opposite signs the denominator vanishes inside the
  composition range. This is proved in `tests/test_vlekit.py` over a grid as
  well.
* **NRTL can, in principle** — see the 1564 grid hits above — but no NRTL that
  fits these P-x data does.
* **The three-suffix Margules, also two-parameter, can and does**: its
  `ln(gamma1/gamma2)` is quadratic in `z = x1 - x2`. Fitted here it keeps two
  azeotropes but displaces both by 0.03–0.04 in `x1` and leaves a residual 25×
  the noise.

The discriminating property is the functional form of `ln(gamma1/gamma2)`, not
the parameter count. That is what the figure claims and what the printed numbers
support.

## Change made to `vlekit`

`vlekit.FourSuffixMargules` (`MODELS["margules3"]`, `name = "Margules-3"`) was
added to `vlekit/models.py` for F5.6:

```
G^E/RT = x1 x2 [ A + B z + C z^2 ],            z = x1 - x2
ln g1  = x2^2 Q + 2 x1 x2^2 D,   ln g2 = x1^2 Q - 2 x1^2 x2 D
Q = A + B z + C z^2,             D = B + 2 C z
```

It was added rather than kept local because it passes both of the package's own
model checks (`check_partial_molar` 4.5e-11, `gibbs_duhem_residual` 3.2e-11).
A start vector was registered in `regress._START` and the class is exported from
`vlekit/__init__.py`. Six tests were added in `tests/test_vlekit.py`: the three
parametrised model checks, plus reduction to `Margules` at `C = 0`, the
infinite-dilution limits `A - B + C` and `A + B + C`, and the double-azeotrope
capability together with the van Laar impossibility.
