#!/usr/bin/env python3
"""F5.2  The tangent plane distance for a stable feed and an unstable feed.

2105603 Advanced Chemical Engineering Thermodynamics — Module 5
Soorathep Kheawhom, Chulalongkorn University

The stability criterion is one-sided and that is what makes it usable:

    TPD(w) = sum_i w_i [ mu_i(w) - mu_i(z) ] / RT   >= 0  for every trial w
    <=>  the feed z is a single stable phase.

So a *proof of stability* needs the global minimum, but a *proof of
instability* needs one trial composition. One negative value anywhere ends the
argument, and it also names the phase that is about to appear.

Both panels scan the same kind of line: the trial compositions that keep
component 2 at its feed value and trade component 1 against component 3, which
is `vlekit.multi.tpd_curve(model, z, 0, 2, rest=z)`. The global minimum over the
whole simplex comes from `vlekit.multi.stability`, and is drawn as a separate
level because it does not in general lie on the line — for the unstable feed
the line already settles the question, and the full minimisation only sharpens
the answer.

ILLUSTRATIVE INPUT: the ternary NRTL tau and alpha matrices are a teaching
parameter set that produces a clean type-I liquid-liquid dome (the same one
used in F5.3). They are not fitted to any measured ternary, and the figure says
so on its face.

Run:  python3 f5_02.py
"""
import os
import sys

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, "/home/claude/vlekit")
from vlekit.multi import NRTLMulti, stability, tpd_curve      # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,   # noqa: E402
                          PAPER, RUST, SLATE, TEAL, use_style)

OUT = os.environ.get("F5_OUT", "/home/claude/vle5/qmd/figures")
SLUG = "f5_02_tangent_plane_distance"

# ILLUSTRATIVE ternary NRTL — see the docstring
TAU = np.array([[0.00, 0.60, 3.20],
                [0.35, 0.00, 0.90],
                [2.80, 0.55, 0.00]])
ALPHA = np.array([[0.0, 0.30, 0.20],
                  [0.30, 0.0, 0.30],
                  [0.20, 0.30, 0.0]])
NAMES = ("1", "2", "3")

Z_UNSTABLE = np.array([0.30, 0.30, 0.40])
Z_STABLE = np.array([0.10, 0.70, 0.20])


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def w_of(t, z):
    """The trial composition at parameter t on the line x2 = z2."""
    w = np.zeros(3)
    w[1] = z[1]
    w[0] = t * (1 - z[1])
    w[2] = (1 - t) * (1 - z[1])
    return w


def scan(m, z):
    t, c = tpd_curve(m, z, 0, 2, n=1201, rest=z)
    st = stability(m, z)
    j = int(np.argmin(c))
    return dict(z=z, t=t, c=c, st=st, t_min=float(t[j]), c_min=float(c[j]),
                w_min=w_of(float(t[j]), z),
                t_feed=float(z[0] / (z[0] + z[2])))


def make():
    m = NRTLMulti(TAU, ALPHA)
    return m, scan(m, Z_UNSTABLE), scan(m, Z_STABLE)


# --------------------------------------------------------------------------
def build(m, uns, sta):
    use_style()
    fig, axes = plt.subplots(1, 2, figsize=(13.2, 6.2), sharey=True)

    lo = min(uns["c"].min(), uns["st"]["tpd_min"], sta["c"].min())
    hi = max(uns["c"].max(), sta["c"].max())
    pad = 0.20 * (hi - lo)
    ylo, yhi = lo - 0.30 * (hi - lo), hi + pad
    span = yhi - ylo

    for ax, d, tag in ((axes[0], uns, "(a)"), (axes[1], sta, "(b)")):
        ax.grid(True, zorder=0)
        ax.set_axisbelow(True)
        t, c = d["t"], d["c"]
        ax.set_xlim(0, 1)
        ax.set_ylim(ylo, yhi)

        ax.fill_between(t, c, 0, where=c < 0, color=RUST, alpha=0.22,
                        interpolate=True, zorder=2)
        ax.axhline(0.0, color=GRAPHITE, lw=1.2, zorder=3)
        ax.plot(t, c, "-", color=NAVY, lw=2.6, zorder=5)

        # the trivial solution: TPD is zero at w = z for every feed, always
        ax.plot([d["t_feed"]], [0.0], "o", color=GRAPHITE, ms=10, mfc=PAPER,
                mew=2.0, zorder=7)

        stable = d["st"]["stable"]
        ax.set_xlabel("trial composition along the line $x_2 = z_2$:   "
                      r"$t = w_1/(w_1+w_3)$")
        z = d["z"]
        ax.set_title(f"{tag}  feed $z$ = ({z[0]:.2f}, {z[1]:.2f}, {z[2]:.2f})"
                     f"  —  {'STABLE' if stable else 'UNSTABLE'}",
                     fontsize=13, color=TEAL if stable else RUST, pad=8)

    axes[0].set_ylabel("tangent plane distance  TPD$(w)$")

    # ======================================================================
    # (a) the unstable feed. Everything above the curve's own maximum is empty
    # on this panel, so the two blocks go there, side by side and narrow enough
    # that their widths cannot meet in the middle.
    # ======================================================================
    ax = axes[0]
    d = uns
    g = d["st"]
    ytxt = yhi - 0.030 * span
    ax.plot([d["t_min"]], [d["c_min"]], "v", color=RUST, ms=13, mec=PAPER,
            mew=1.5, zorder=8)
    ax.annotate(
        "lowest point on this line\n"
        f"TPD = {d['c_min']:+.4f}\n"
        f"at $w$ = ({d['w_min'][0]:.3f}, {d['w_min'][1]:.3f}, "
        f"{d['w_min'][2]:.3f})\n"
        "one negative value ends it",
        xy=(d["t_min"], d["c_min"]), xytext=(0.985, ytxt),
        ha="right", va="top", fontsize=10.5, color=RUST, zorder=10,
        linespacing=1.5,
        bbox=dict(boxstyle="round,pad=0.30", fc=PAPER, ec=RUST, lw=1.0,
                  alpha=0.95),
        arrowprops=dict(arrowstyle="-", color=RUST, lw=1.2, shrinkA=4,
                        shrinkB=7))

    ax.axhline(g["tpd_min"], ls=(0, (5, 3)), color=AMBER, lw=1.9, zorder=4)
    ax.annotate(
        "global minimum, whole simplex\n"
        f"TPD = {g['tpd_min']:+.4f}\n"
        f"at $w$ = ({g['w'][0]:.3f}, {g['w'][1]:.3f}, {g['w'][2]:.3f})\n"
        "the incipient second phase",
        xy=(0.80, g["tpd_min"]), xytext=(0.015, ytxt),
        ha="left", va="top", fontsize=10.5, color=AMBER, zorder=10,
        linespacing=1.5,
        bbox=dict(boxstyle="round,pad=0.30", fc=PAPER, ec=AMBER, lw=1.0,
                  alpha=0.95),
        arrowprops=dict(arrowstyle="-", color=AMBER, lw=1.2, shrinkA=4,
                        shrinkB=4))
    ax.annotate("trivial solution $w = z$:  TPD $= 0$, certifies nothing.\n"
                "The shaded lobe is where TPD $<$ 0.",
                xy=(d["t_feed"], 0.0),
                xytext=(0.015, ylo + 0.035 * span),
                ha="left", va="bottom", fontsize=10.5, color=GRAPHITE,
                zorder=10, linespacing=1.5,
                bbox=dict(boxstyle="round,pad=0.28", fc=PAPER, ec=MIST,
                          lw=1.0, alpha=0.95),
                arrowprops=dict(arrowstyle="-", color=GRAPHITE, lw=1.1,
                                shrinkA=4, shrinkB=6))

    # ======================================================================
    # (b) the stable feed. The curve never goes below zero, so the whole lower
    # half of the panel is empty and carries the annotations.
    # ======================================================================
    ax = axes[1]
    d = sta
    g = d["st"]
    ax.plot([d["t_min"]], [d["c_min"]], "o", color=TEAL, ms=11, mfc=PAPER,
            mew=2.0, zorder=8)
    ax.axhline(g["tpd_min"], ls=(0, (5, 3)), color=TEAL, lw=1.9, zorder=4)

    ax.annotate(
        "the only zero on this line is the trivial one at $w = z$;\n"
        "every other trial composition raises the Gibbs energy",
        xy=(d["t_feed"], 0.0), xytext=(0.015, ytxt),
        ha="left", va="top", fontsize=10.5, color=GRAPHITE, zorder=10,
        linespacing=1.5,
        bbox=dict(boxstyle="round,pad=0.30", fc=PAPER, ec=MIST, lw=1.0,
                  alpha=0.95),
        arrowprops=dict(arrowstyle="-", color=GRAPHITE, lw=1.2, shrinkA=4,
                        shrinkB=7))
    ax.annotate(
        "global minimum, whole simplex\n"
        f"TPD = {g['tpd_min']:+.4f}\n"
        f"at $w$ = ({g['w'][0]:.3f}, {g['w'][1]:.3f}, {g['w'][2]:.3f})\n"
        "positive — no second phase anywhere",
        xy=(0.62, g["tpd_min"]), xytext=(0.985, ylo + 0.035 * span),
        ha="right", va="bottom", fontsize=10.5, color=TEAL, zorder=10,
        linespacing=1.5,
        bbox=dict(boxstyle="round,pad=0.30", fc=PAPER, ec=TEAL, lw=1.0,
                  alpha=0.95),
        arrowprops=dict(arrowstyle="-", color=TEAL, lw=1.2, shrinkA=4,
                        shrinkB=4))

    fig.suptitle("One negative value proves instability; only the global "
                 "minimum can prove stability",
                 fontsize=15, y=0.995)
    fig.text(0.5, -0.035,
             "ILLUSTRATIVE PARAMETERS: ternary NRTL with the tau and alpha "
             "matrices printed in the script header — a teaching set that "
             "gives a clean type-I dome, not a fit to any measured ternary.\n"
             "Both curves come from vlekit.multi.tpd_curve and both global "
             "minima from vlekit.multi.stability; no number on this figure was "
             "read off a graph.",
             ha="center", va="center", fontsize=10, color=SLATE,
             linespacing=1.55)
    fig.tight_layout()
    return fig


if __name__ == "__main__":
    m, uns, sta = make()
    print("ternary NRTL (illustrative), Gibbs-Duhem residual "
          f"{m.check_gibbs_duhem():.2e}, pure limit {m.check_pure_limit():.2e}")
    for tag, d in (("unstable", uns), ("stable", sta)):
        z, g = d["z"], d["st"]
        print(f"{tag:9s} feed z = {np.round(z, 3)}  ->  "
              f"stable = {g['stable']}")
        print(f"          slice minimum  TPD = {d['c_min']:+.6f} at "
              f"t = {d['t_min']:.4f}, w = {np.round(d['w_min'], 4)}")
        print(f"          global minimum TPD = {g['tpd_min']:+.6f} at "
              f"w = {np.round(g['w'], 4)}")
        print(f"          curve range {d['c'].min():+.5f} to "
              f"{d['c'].max():+.5f}; TPD at the feed itself "
              f"{np.interp(d['t_feed'], d['t'], d['c']):+.2e}")
    for p in write(build(m, uns, sta), SLUG):
        print("wrote", p)
