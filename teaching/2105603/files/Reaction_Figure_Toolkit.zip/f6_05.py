#!/usr/bin/env python3
"""F6.5 — Steam methane reforming: two independent routes to the same answer.

2105603 Advanced Chemical Engineering Thermodynamics — Module 6
Soorathep Kheawhom, Chulalongkorn University

Product distribution against temperature for CH4 + 3 H2O at 1 bar, computed
twice:

    Gibbs minimisation  `reaction.gibbs_minimise` over CH4, H2O, CO, CO2, H2
                        subject only to the C, H and O balances. No reaction
                        set is supplied.
    extent              two independent reactions —
                            R1  CH4 + H2O -> CO + 3 H2
                            R2  CO  + H2O -> CO2 + H2
                        solved simultaneously for (xi1, xi2) from K1(T), K2(T).

Five species and three elements leave two degrees of freedom, so the two
formulations describe exactly the same problem and must agree. Every
temperature is checked and the largest disagreement over the whole scan is
printed on the figure. Points where either solver failed are marked on the
figure rather than dropped.

SOLID CARBON. The minimisation above is a single gas phase. Carbon deposition
is checked afterwards with the element potential: graphite becomes stable when
lambda_C reaches its own standard Gibbs energy, because that is exactly the
condition mu_C(mixture) = mu_C(graphite). The check costs nothing — lambda_C
is already computed — and it needs no extra reaction. Graphite properties come
from `chemicals`: Hfs and S0s for CAS 7782-42-5 (0 J/mol by definition of the
element reference state, and 5.7 J/mol/K), with the JANAF tabulated solid Cp
interpolated. The two reactions this predicts, Boudouard and methane cracking,
are printed by the script and can be checked against a table.

Run:  python3 f6_05.py
"""
from __future__ import annotations

import os
import sys
import warnings

import numpy as np
from scipy.optimize import fsolve

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                   # noqa: E402

from vlekit.reaction import (Reaction, Species, element_matrix,   # noqa: E402
                             element_potentials, from_chemicals,
                             gibbs_minimise, moles_from_extent)
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,       # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, use_style)

warnings.filterwarnings("ignore", category=RuntimeWarning)

OUT = os.environ.get("F6_OUT", "/home/claude/vle6/qmd/figures")
SLUG = "f6_05_reforming_distribution"

NAMES = ["methane", "water", "carbon monoxide", "carbon dioxide", "hydrogen"]
LABEL = {"methane": "CH$_4$", "water": "H$_2$O", "carbon monoxide": "CO",
         "carbon dioxide": "CO$_2$", "hydrogen": "H$_2$"}
COLOUR = {"methane": NAVY, "water": SKYBLUE, "carbon monoxide": TEAL,
          "carbon dioxide": AMBER, "hydrogen": RUST}
SC_MAIN = 3.0                 # steam-to-carbon ratio of the main panel
SC_LOW = 1.0                  # the one that puts carbon on the diagram
P = 100.0                     # kPa = 1 bar
T_GRID = np.arange(600.0, 1301.0, 12.5)
T_MARK = np.arange(600.0, 1301.0, 50.0)

NU = np.array([[-1.0, -1.0, 1.0, 0.0, 3.0],       # R1 reforming
               [0.0, -1.0, -1.0, 1.0, 1.0]])      # R2 water-gas shift


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def memoise(sp):
    cH, cS = {}, {}
    H0, S0 = sp.H, sp.S

    def H(t):
        k = round(float(t), 9)
        if k not in cH:
            cH[k] = H0(t)
        return cH[k]

    def S(t):
        k = round(float(t), 9)
        if k not in cS:
            cS[k] = S0(t)
        return cS[k]

    sp.H, sp.S = H, S
    sp.G = lambda t: H(t) - float(t) * S(t)
    return sp


def graphite():
    """Graphite as a `Species`, built entirely from `chemicals`.

    Hfs('7782-42-5') returns 0.0 — that is the definition of the element
    reference state, not a measurement — and S0s returns 5.7 J/mol/K. The heat
    capacity is the JANAF solid table shipped with the package, interpolated;
    it runs from 8.517 J/mol/K at 298.15 K to 23.204 at 1300 K, which is the
    variation that would be lost by assuming a constant Cp.
    """
    from chemicals import heat_capacity as hc
    from chemicals.reaction import Hfs, S0s

    hc._load_Cp_data()
    Ts, Cps = hc.Cp_dict_JANAF_solid["7782-42-5"]
    Ts, Cps = np.asarray(Ts, float), np.asarray(Cps, float)

    def cp(T):
        return float(np.interp(float(T), Ts, Cps))

    cp.range = (float(Ts[1]), float(Ts[-1]))
    return Species(name="graphite", formula="C", Hf=float(Hfs("7782-42-5")),
                   S0=float(S0s("7782-42-5")), cp=cp, phase="s",
                   cas="7782-42-5",
                   source="chemicals: reaction.Hfs / reaction.S0s, "
                          "heat_capacity.Cp_dict_JANAF_solid")


# --------------------------------------------------------------------------
def extent_solution(n0, lnK1, lnK2, guess):
    """Solve the two simultaneous activity-quotient equations at 1 bar.

    The unknowns are transformed as

        xi1 = 1/(1+e^-a) * xi1_max      xi2 = 1/(1+e^-b) * xi1

    which enforces 0 < xi2 < xi1 < xi1_max identically, so the solver can
    never step to a negative mole number and take the logarithm of it. That is
    the only reason this converges at 1300 K, where xi1 is within 1e-5 of its
    limit.
    """
    n0 = np.asarray(n0, float)
    xi1max = min(n0[0], n0[1])

    def unpack(v):
        a, b = v
        xi1 = xi1max / (1.0 + np.exp(-a))
        xi2 = xi1 / (1.0 + np.exp(-b))
        return np.array([xi1, xi2])

    def f(v):
        n = moles_from_extent(n0, NU, unpack(v))
        if np.any(n <= 1e-300):
            return np.array([1e6, 1e6])
        la = np.log(n / n.sum())          # P = P0, so no pressure term
        return np.array([NU[0] @ la - lnK1, NU[1] @ la - lnK2])

    best = None
    for g in (guess, (0.0, 0.0), (3.0, 0.0), (6.0, -1.0), (-2.0, -2.0),
              (9.0, 1.0)):
        v, info, ier, msg = fsolve(f, np.asarray(g, float), full_output=True,
                                   xtol=1e-13)
        r = float(np.max(np.abs(f(v))))
        if best is None or r < best[0]:
            best = (r, v)
    r, v = best
    xi = unpack(v)
    n = moles_from_extent(n0, NU, xi)
    return dict(xi=xi, n=n, y=n / n.sum(), residual=r, v=v,
                ok=bool(r < 1e-8))


def run(sp, carbon, SC, cross_check=True):
    n0 = np.array([1.0, SC, 0.0, 0.0, 0.0])
    r1 = Reaction([sp[0], sp[1], sp[2], sp[4]], [-1, -1, 1, 3])
    r2 = Reaction([sp[2], sp[1], sp[3], sp[4]], [-1, -1, 1, 1])
    A, els = element_matrix(sp)
    iC = list(els).index("C")

    rows = []
    guess = (0.0, 0.0)
    for T in T_GRID:
        g = gibbs_minimise(sp, n0, T, P, restarts=5)
        lam = g["element_potentials"]
        row = dict(T=T, y=g["y"], n=g["n"], G=g["G"], ok=g["success"],
                   bal=g["residual"],
                   dC=float(lam[iC] - carbon.G(T)))
        if cross_check:
            e = extent_solution(n0, r1.lnK(T), r2.lnK(T), guess)
            if e["ok"]:
                guess = tuple(e["v"])
            row.update(y_ext=e["y"], xi=e["xi"], ext_ok=e["ok"],
                       ext_res=e["residual"],
                       dy=float(np.max(np.abs(g["y"] - e["y"]))))
        rows.append(row)
    return dict(SC=SC, rows=rows, r1=r1, r2=r2, els=els, n0=n0)


def make():
    sp = [memoise(from_chemicals(n)) for n in NAMES]
    carbon = memoise(graphite())
    boudouard = Reaction([carbon, sp[3], sp[2]], [-1, -1, 2], "Boudouard")
    cracking = Reaction([sp[0], carbon, sp[4]], [-1, 1, 2], "CH4 cracking")
    main = run(sp, carbon, SC_MAIN)
    low = run(sp, carbon, SC_LOW, cross_check=False)
    return dict(sp=sp, carbon=carbon, main=main, low=low,
                boudouard=boudouard, cracking=cracking)


# --------------------------------------------------------------------------
def build(d):
    use_style()
    fig = plt.figure(figsize=(13.8, 7.9))
    gs = fig.add_gridspec(2, 2, width_ratios=[1.55, 1.0],
                          height_ratios=[1.0, 1.0],
                          left=0.058, right=0.985, top=0.855, bottom=0.185,
                          wspace=0.22, hspace=0.46)
    ax = fig.add_subplot(gs[:, 0])
    a1 = fig.add_subplot(gs[0, 1])
    a2 = fig.add_subplot(gs[1, 1])
    for a in (ax, a1, a2):
        a.grid(True, zorder=0)
        a.set_axisbelow(True)

    m = d["main"]
    T = np.array([r["T"] for r in m["rows"]])
    Y = np.array([r["y"] for r in m["rows"]])
    Ye = np.array([r["y_ext"] for r in m["rows"]])
    dy = np.array([r["dy"] for r in m["rows"]])
    ext_ok = np.array([r["ext_ok"] for r in m["rows"]])
    gm_ok = np.array([r["ok"] for r in m["rows"]])
    jmax = int(np.argmax(dy))

    mark = np.array([bool(np.min(np.abs(t - T_MARK)) < 1e-9) for t in T])
    for i, n in enumerate(NAMES):
        ax.plot(T, Y[:, i], "-", color=COLOUR[n], lw=2.6, zorder=4)
        ax.plot(T[mark], Ye[mark, i], "o", color=COLOUR[n], ms=8, mfc=PAPER,
                mew=1.8, zorder=6)

    ax.set_xlim(T[0], T[-1])
    ax.set_ylim(0.0, 0.80)
    ax.set_xlabel("$T$ / K")
    ax.set_ylabel("equilibrium mole fraction  $y_i$")
    ax.set_title(f"CH$_4$ + {SC_MAIN:g} H$_2$O at 1 bar "
                 f"(steam-to-carbon {SC_MAIN:g})",
                 fontsize=13.5, pad=8, loc="left", x=0.0)

    # each curve named at the temperature where it is furthest from every
    # other curve, so the label sits in the widest gap available to it
    for i, n in enumerate(NAMES):
        others = np.delete(Y, i, axis=1)
        clear = np.min(np.abs(others - Y[:, [i]]), axis=1)
        inner = (T > T[0] + 60) & (T < T[-1] - 60)
        j = int(np.argmax(np.where(inner, clear, -1.0)))
        ax.text(T[j], Y[j, i] + 0.022, LABEL[n], color=COLOUR[n],
                fontsize=14, ha="center", va="bottom", zorder=8,
                bbox=dict(boxstyle="round,pad=0.20", fc=PAPER, ec="none",
                          alpha=0.88))

    ax.plot([], [], "-", color=GRAPHITE, lw=2.6,
            label="Gibbs minimisation (no reaction set)")
    ax.plot([], [], "o", color=GRAPHITE, ms=8, mfc=PAPER, mew=1.8,
            label="extent formulation, 2 reactions")
    # the band between the H2 and H2O curves at high temperature is the one
    # large empty rectangle in this panel; the legend goes there
    ax.legend(loc="upper right", fontsize=11.5, bbox_to_anchor=(0.985, 0.665))

    ax.text(0.985, 0.985,
            "the two routes agree to\n"
            f"max $|y^{{\\rm Gibbs}}_i - y^{{\\rm extent}}_i|$ = "
            f"{dy[np.isfinite(dy)].max():.2e}\n"
            f"(worst at $T$ = {T[jmax]:.0f} K)\n"
            f"atom balance closed to "
            f"{max(r['bal'] for r in m['rows']):.1e} mol\n"
            f"{int(gm_ok.sum())}/{len(T)} minimisations and "
            f"{int(ext_ok.sum())}/{len(T)} extent solves converged",
            transform=ax.transAxes, ha="right", va="top", fontsize=11.2,
            color=INK, linespacing=1.6, zorder=9,
            bbox=dict(boxstyle="round,pad=0.32", fc=PAPER, ec=MIST, lw=1.0,
                      alpha=0.96))

    # ------------------------------------------------------- disagreement
    a1.semilogy(T, np.maximum(dy, 1e-16), "-", color=NAVY, lw=2.2, zorder=3)
    good = gm_ok & ext_ok
    a1.plot(T[good], np.maximum(dy[good], 1e-16), "o", color=NAVY, ms=5,
            mfc=SKYBLUE, mew=1.0, zorder=5, label="both solvers converged")
    if (~good).any():
        a1.plot(T[~good], np.maximum(dy[~good], 1e-16), "s", color=RUST,
                ms=9, mfc=PAPER, mew=2.0, zorder=6,
                label="a solver reported failure (shown, not dropped)")
    a1.plot([T[jmax]], [dy[jmax]], "*", color=RUST, ms=18, mec=PAPER, mew=1.0,
            zorder=7, label=f"worst: {dy[jmax]:.1e} at {T[jmax]:.0f} K")
    a1.set_xlim(T[0], T[-1])
    a1.set_xlabel("$T$ / K")
    a1.set_ylabel(r"max$_i\,|y_i^{\rm Gibbs} - y_i^{\rm extent}|$")
    a1.set_ylim(float(np.min(dy)) * 0.35, float(np.max(dy)) * 60.0)
    a1.legend(loc="upper right", fontsize=9.6, labelspacing=0.4)
    a1.set_title("Do the two formulations agree, temperature by temperature?",
                 fontsize=12, pad=6, loc="left", x=0.0)

    # ------------------------------------------------------- carbon check
    for run_, lab, col in ((d["main"], f"S/C = {SC_MAIN:g}", NAVY),
                           (d["low"], f"S/C = {SC_LOW:g}", RUST)):
        t = np.array([r["T"] for r in run_["rows"]])
        dc = np.array([r["dC"] for r in run_["rows"]]) / 1000.0
        a2.plot(t, dc, "-", color=col, lw=2.4, label=lab)
        if (dc > 0).any():
            a2.fill_between(t, 0.0, dc, where=dc > 0, color=col, alpha=0.40,
                            interpolate=True)
            on = t[dc > 0]
            mid = 0.5 * (on[0] + on[-1])
            a2.annotate(f"graphite stable, {on[0]:.0f}–{on[-1]:.0f} K\n"
                        f"(up to {dc.max():.2f} kJ/mol)",
                        xy=(mid, 0.5 * dc.max()), xytext=(mid, 13.0),
                        ha="center", va="bottom", fontsize=10.5, color=col,
                        linespacing=1.45, zorder=7,
                        bbox=dict(boxstyle="round,pad=0.22", fc=PAPER, ec=col,
                                  lw=1.0, alpha=0.95),
                        arrowprops=dict(arrowstyle="-", color=col, lw=1.1,
                                        shrinkA=4, shrinkB=4))
    a2.axhline(0.0, color=GRAPHITE, lw=1.2)
    a2.set_xlim(T[0], T[-1])
    a2.set_ylim(-75.0, 30.0)
    a2.set_xlabel("$T$ / K")
    a2.set_ylabel(r"$\lambda_{\rm C} - G^\circ_{\rm graphite}(T)$"
                  "  /  kJ mol$^{-1}$")
    a2.legend(loc="lower left", fontsize=10.5)
    a2.set_title("Would solid carbon deposit? "
                 "(positive = yes, from $\\lambda_{\\rm C}$ alone)",
                 fontsize=12, pad=6, loc="left", x=0.0)

    fig.text(0.5, 0.968,
             "Two formulations of the same problem, five species and three "
             "elements, agreeing to "
             f"{dy[np.isfinite(dy)].max() * 1e7:.1f}"
             r"$\times 10^{-7}$ in mole fraction at every temperature",
             ha="center", va="center", fontsize=15, color=INK)
    bd, ck = d["boudouard"], d["cracking"]
    fig.text(0.5, 0.012,
             "All formation properties from `chemicals`; graphite from "
             "`Hfs`/`S0s` for CAS 7782-42-5 with the JANAF solid $C_p$ table. "
             "The check that graphite is right: "
             f"C + CO$_2$ $\\rightarrow$ 2 CO gives $\\Delta H^\\circ_{{298}}$ "
             f"= {bd.dH() / 1000:.1f}, $\\Delta G^\\circ_{{298}}$ = "
             f"{bd.dG() / 1000:.1f} kJ/mol (literature 172.5, 120.0)\n"
             f"and CH$_4$ $\\rightarrow$ C + 2 H$_2$ gives "
             f"{ck.dH() / 1000:.1f}, {ck.dG() / 1000:.1f} kJ/mol "
             "(literature 74.9, 50.8).  The main panel is a single gas phase: "
             f"at S/C = {SC_MAIN:g} graphite is never stable, so that is the "
             "true equilibrium; at S/C = "
             f"{SC_LOW:g} it is not, inside the shaded band.",
             ha="center", va="bottom", fontsize=10.2, color=SLATE,
             linespacing=1.6)
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = make()
    print(f"graphite: Hf = {d['carbon'].Hf:.1f} J/mol, "
          f"S0 = {d['carbon'].S0:.3f} J/mol/K, "
          f"Cp(298) = {d['carbon'].Cp(298.15):.3f}, "
          f"Cp(1300) = {d['carbon'].Cp(1300):.3f} J/mol/K")
    for r in (d["boudouard"], d["cracking"]):
        print(f"  {r.name:14s} dH298 = {r.dH() / 1000:8.3f} kJ/mol   "
              f"dG298 = {r.dG() / 1000:8.3f} kJ/mol")
    print("  (literature: Boudouard 172.5 / 120.0, cracking 74.9 / 50.8)")

    m = d["main"]
    print(f"\nS/C = {SC_MAIN:g}, P = {P:g} kPa, feed {m['n0']}")
    print("     T      yCH4     yH2O      yCO     yCO2      yH2   "
          "   xi1      xi2    max|dy|  gmin  ext")
    for r in m["rows"]:
        if abs(r["T"] % 100.0) > 1e-9:
            continue
        y = r["y"]
        print(f"  {r['T']:6.1f} " + " ".join(f"{v:8.5f}" for v in y)
              + f" {r['xi'][0]:8.5f} {r['xi'][1]:8.5f} {r['dy']:9.2e}"
              f"  {str(r['ok'])[0]}     {str(r['ext_ok'])[0]}")
    dy = np.array([r["dy"] for r in m["rows"]])
    j = int(np.argmax(dy))
    print(f"maximum disagreement over the scan: {dy.max():.4e} at "
          f"T = {m['rows'][j]['T']:.1f} K")
    print(f"atom balance worst residual: "
          f"{max(r['bal'] for r in m['rows']):.3e} mol")
    print(f"gibbs_minimise reported success at "
          f"{sum(r['ok'] for r in m['rows'])}/{len(m['rows'])} temperatures; "
          f"extent solve converged at "
          f"{sum(r['ext_ok'] for r in m['rows'])}/{len(m['rows'])}")
    for lab, run_ in (("S/C = %g" % SC_MAIN, d["main"]),
                      ("S/C = %g" % SC_LOW, d["low"])):
        dc = np.array([r["dC"] for r in run_["rows"]])
        t = np.array([r["T"] for r in run_["rows"]])
        if (dc > 0).any():
            on = t[dc > 0]
            print(f"{lab}: lambda_C exceeds G_graphite between {on[0]:.1f} "
                  f"and {on[-1]:.1f} K, by up to {dc.max() / 1000:.3f} kJ/mol "
                  "-> solid carbon is part of the true equilibrium there")
        else:
            print(f"{lab}: lambda_C - G_graphite stays negative "
                  f"(max {dc.max() / 1000:.3f} kJ/mol) -> no carbon anywhere "
                  "in the scan")
    for p in write(build(d), SLUG):
        print("wrote", p)
