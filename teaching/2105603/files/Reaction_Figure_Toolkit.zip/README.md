# Module 6 lecture figures — 2105603 Advanced Chemical Engineering Thermodynamics

Chemical equilibrium. Soorathep Kheawhom, Chulalongkorn University.

Standalone scripts, one per figure. Each writes a PNG **and** a PDF of the same
render into `/home/claude/vle6/qmd/figures/` at 300 dpi and prints, to stdout,
every number it computed and every path it wrote.

```
cd /home/claude/vle6/toolkit
python3 f6_01.py          # ... through f6_07.py
for f in f6_0*.py; do python3 "$f"; done
```

Every script adds `/home/claude/vlekit` to `sys.path` and does its physics with
`vlekit` — `reaction` (`from_chemicals`, `Reaction`, `K`, `K_vant_hoff`,
`extent_bounds`, `solve_extent`, `equilibrium_composition`, `total_G`,
`gibbs_minimise`, `element_potentials`, `element_potential_residual`,
`debye_huckel_A`, `dh_limiting`, `dh_extended`, `pitzer`, `cell_voltage`) and
`cubic` (`PengRobinson.ln_phi`). Colours and rcParams come from `vlekit.plots`
(NAVY, AMBER, TEAL, RUST, SKYBLUE, GRAPHITE, INK, MIST, SLATE, PAPER — no
others). The output directory can be overridden with the `F6_OUT` environment
variable.

**Nothing was added to `vlekit`.** The baseline test suite still reports
`192 passed`.

**Rule for this set: no thermochemical number printed on a figure was typed
in.** Every formation enthalpy, absolute entropy, heat-capacity correlation and
critical constant is read at run time from the `chemicals` package. Where an
input is *assumed* rather than measured or fitted, the figure says so on its own
face and the row below repeats it.

Each script caches `Species.H(T)` and `Species.S(T)` per temperature. That is a
speed device only — `Species.dH` integrates its `Cp` correlation with 200
Simpson points on every call and `total_G` is called thousands of times. The
cache is keyed on `T` and returns exactly what the integrator would.

---

## The figures

| file | figure | the claim it supports | assumed / illustrative inputs |
|---|---|---|---|
| `f6_01.py` | F6.1 `f6_01_gibbs_vs_extent` | The equilibrium composition is the minimum of `G` along the extent coordinate, and `solve_extent` — which solves `Ka(ξ) = K(T)` and never evaluates `G` — lands on the same point. `K(T)` is identical at 100 and 300 bar; the minimum is not. | **None.** Ideal gas is a stated modelling choice, not a fitted parameter. F6.3 removes it. |
| `f6_02.py` | F6.2 `f6_02_vant_hoff_departure` | The straight line of a van 't Hoff plot is an assumption about `ΔH°`, and it costs a factor of two in `K` by 523 K for steam reforming — well inside the range this course uses. | **None.** Three reactions were computed before one was chosen, and the other two stay on the figure so the choice is visible. |
| `f6_03.py` | F6.3 `f6_03_ammonia_kphi` | At the pressure ammonia is actually made, the fugacity coefficient is not a refinement: `K_φ` = 0.627 at 300 bar and the ideal-gas answer is 4.2 percentage points of conversion wrong. | **`k_ij` = 0 for N₂/H₂, N₂/NH₃ and H₂/NH₃ — ASSUMED, NOT FITTED.** No binary VLE data were regressed and no citable value was found. Recomputing with `k_ij = ±0.05` on every pair moves the answer by less than 0.01 points, and that is printed on the figure. Also stated on the figure: hydrogen sits at `Tr` = 21, far outside the range the Peng-Robinson `m(ω)` polynomial was fitted in. |
| `f6_04.py` | F6.4 `f6_04_element_potentials` | Seven chemical potentials are reproduced by four numbers: at equilibrium a species carries no information beyond the atoms it is made of. | **None.** O₂ and NO were *removed* from the species list and the figure says why — their equilibrium mole fractions are ~10⁻²⁵ and ~10⁻⁸ and the SLSQP minimiser cannot resolve `ln n` for a species that contributes nothing to `G`. |
| `f6_05.py` | F6.5 `f6_05_reforming_distribution` | Gibbs minimisation with no reaction set and the two-reaction extent formulation are the same problem, and they agree to 9.9 × 10⁻⁷ in mole fraction at every temperature. Solid carbon is settled by `λ_C` alone. | **None.** Graphite's `Hf = 0` is the definition of the element reference state, not a datum; `S°` = 5.7 J/mol/K and the `Cp` table come from `chemicals`. The steam-to-carbon ratios 3 and 1 are choices of operating point, not data. |
| `f6_06.py` | F6.6 `f6_06_activity_coefficient_models` | The Debye-Hückel limiting law is 5 % wrong by `I` = 0.031 mol/kg and the extended law by 0.386; three fitted Pitzer parameters carry the same solution to 6 mol/kg. | **The electrolyte is HCl, not NaCl or KCl** — see "What was and was not verified" below. **The ion-size parameter of the extended law is fitted here** (5.92 Å, on `I` ≤ 0.1) and the fitted value is on the figure. The NaCl panel's extended law is drawn at an **assumed** `a` = 4 Å and is labelled. |
| `f6_07.py` | F6.7 `f6_07_cell_voltage` | The activity coefficient is not a correction to a calculation — it is 11.6 mV on a voltmeter at 0.1 mol/kg, a thousand times the uncertainty of the measurement. | **Nothing assumed.** `E°`, the eight emf values and the eight `γ±` values are measured; the Pitzer parameters are published; the extended-law ion size is fitted here and printed. Beyond 0.1 mol/kg the curves are predictions with nothing to test them against and the figure shades where the data stop. |

---

## What is computed rather than asserted

### F6.1 — ammonia synthesis, 700 K, feed 1 : 3 : 0

`ΔH°₂₉₈ = −91.116 kJ/mol`, `ΔG°₂₉₈ = −32.052 kJ/mol`, `K₂₉₈ = 4.1243 × 10⁵`.
At 700 K, `ΔG° = +55.074 kJ/mol`, `K = 7.7703 × 10⁻⁵`. Feasible window from
`extent_bounds`: `ξ = 0` to `1` mol.

| P | ξ* (`solve_extent`) | ξ* (minimum of `total_G`) | difference | y(NH₃) | G(ξ*) − G(0) |
|---|---|---|---|---|---|
| 100 bar | 0.3172263 | 0.3172264 | 7.9 × 10⁻⁸ | 0.18851 | −4.863 kJ |
| 300 bar | 0.5251687 | 0.5251687 | 7.0 × 10⁻⁸ | 0.35609 | −10.248 kJ |

Sensitivity, computed by shifting `ΔG°` and re-solving: ∓1 kJ/mol moves `ξ*` at
300 bar by `+0.0157 / −0.0159` mol. One kJ/mol on `ΔG°` is a factor **1.19** in
`K` at 700 K and **1.50 — 50 %** at 298 K. The `chemicals` `ΔG°₂₉₈` of
−32.05 kJ/mol differs from the usual literature −32.8 by 0.75 kJ/mol, i.e.
30 % in `K`; that statement is on the figure.

### F6.2 — van 't Hoff, three candidate reactions

| reaction | `ΔH°₂₉₈` | `ΔH°₁₃₀₀` | change | factor of two at | ratio at 1300 K |
|---|---|---|---|---|---|
| CH₄ + H₂O → CO + 3 H₂ | +205.831 | +226.506 | +10.0 % | **523.3 K** | 0.0607 |
| CO + H₂O → CO₂ + H₂ | −41.127 | −31.876 | +22.5 % | never in 400–1300 K | 0.5065 |
| N₂ + 3 H₂ → 2 NH₃ | −91.116 | −111.195 | −22.0 % | **533.3 K** | 14.076 |

At the steam-reforming crossing, `K` exact = 9.3644 × 10⁻¹⁰ against
`K` van 't Hoff = 4.6822 × 10⁻¹⁰. Steam reforming was chosen for the main panel
because it carries the largest absolute movement in `ΔH°`; the other two stay in
the right-hand panels so the choice is auditable.

### F6.3 — ammonia to 600 bar, with and without `K_φ`

Peng-Robinson from `vlekit.cubic`, `alpha='1976'`, `k_ij = 0` (assumed).
Critical constants from `chemicals`: N₂ 126.192 K / 33.958 bar / ω = +0.0372;
H₂ 33.145 K / 12.964 bar / ω = −0.2190; NH₃ 405.560 K / 113.634 bar /
ω = +0.2560.

| P / bar | X ideal / % | X with φ̂ / % | gap / points | `K_φ` | Z | φ̂(N₂), φ̂(H₂), φ̂(NH₃) |
|---|---|---|---|---|---|---|
| 1 | 0.568 | 0.568 | +0.000 | 0.9990 | 1.0002 | 1.0003, 1.0002, 1.0000 |
| 50 | 20.336 | 20.764 | +0.428 | 0.9432 | 1.0111 | 1.0175, 1.0114, 0.9964 |
| 100 | 31.842 | 33.030 | +1.188 | 0.8786 | 1.0201 | 1.0365, 1.0241, 0.9890 |
| 150 | 39.298 | 41.277 | +1.979 | 0.8138 | 1.0277 | 1.0568, 1.0378, 0.9805 |
| **300** | **52.497** | **56.706** | **+4.209** | **0.6266** | 1.0482 | 1.1301, 1.0877, 0.9545 |
| 400 | 57.820 | 63.308 | +5.488 | 0.5168 | 1.0627 | 1.1905, 1.1281, 0.9398 |
| 600 | 64.355 | 71.695 | +7.340 | 0.3581 | 1.0956 | 1.3247, 1.2152, 0.9226 |

`y(NH₃)` at 300 bar goes from 0.35590 (ideal) to 0.39573 (with φ̂).

A hierarchy of what the inputs are worth at 300 bar, all computed by re-running:

* the fugacity coefficient itself: **+4.21 percentage points**
* ±1 kJ/mol on `ΔG°`: 58.31 % / 55.13 % against 56.71 %, i.e. **±1.6 points**
* `k_ij = ±0.05` on every pair: 56.702 % / 56.710 %, i.e. **±0.004 points**

The last of these is the reason the `k_ij` band is reported as a number rather
than drawn as a band: `K_φ` is a ratio of fugacity coefficients and the `k_ij`
contributions very nearly cancel in it.

### F6.4 — element potentials, C/H/N/O

CH₄ + 2 H₂O + N₂ at 1100 K, 1 bar, over CH₄, H₂O, H₂, CO, CO₂, N₂, NH₃.
`G = −1.60620580 × 10⁶ J`, atom balance closed to `1.1 × 10⁻¹⁶ mol`.

```
lambda_C = -43.208   lambda_H = -84.052
lambda_N = -123.027  lambda_O = -322.265   kJ per mol of atom
```

| species | y | μ / kJ mol⁻¹ | Σ a_ki λ_k | μ − Σ a_ki λ_k / J mol⁻¹ |
|---|---|---|---|---|
| CH₄ | 4.647 × 10⁻⁴ | −379.4151 | −379.4152 | +0.068 |
| H₂O | 0.13416 | −490.3686 | −490.3687 | +0.152 |
| H₂ | 0.53216 | −168.1034 | −168.1037 | +0.266 |
| CO | 0.13323 | −365.4728 | −365.4729 | +0.017 |
| CO₂ | 0.033135 | −687.7380 | −687.7379 | −0.085 |
| N₂ | 0.16681 | −246.0541 | −246.0543 | +0.185 |
| NH₃ | 4.867 × 10⁻⁵ | −375.1831 | −375.1827 | −0.369 |

`max |μᵢ − Σ aₖᵢλₖ| = 0.369 J/mol` against a mean `|μ|` of 387 kJ/mol, i.e.
`9.5 × 10⁻⁷` of it. The same check over 700–1300 K in 50 K steps gives a
residual between `0.046` and `30.1 J/mol`, rising at the hot end where CH₄ and
NH₃ fall below 10⁻⁵; the temperature at which SLSQP reported failure (900 K,
residual 0.689 J/mol) is drawn with a different marker rather than dropped.

### F6.5 — steam methane reforming, S/C = 3, 1 bar

Graphite check first, because the carbon result depends on it:
`C + CO₂ → 2 CO` gives `ΔH°₂₉₈ = 172.424`, `ΔG°₂₉₈ = 119.979 kJ/mol`
(literature 172.5, 120.0); `CH₄ → C + 2 H₂` gives `74.534`, `50.443 kJ/mol`
(literature 74.9, 50.8).

| T / K | y(CH₄) | y(H₂O) | y(CO) | y(CO₂) | y(H₂) | ξ₁ | ξ₂ | max\|Δy\| |
|---|---|---|---|---|---|---|---|---|
| 600 | 0.21619 | 0.67121 | 0.00011 | 0.02243 | 0.09006 | 0.09442 | 0.09397 | 5.2 × 10⁻⁸ |
| 700 | 0.16529 | 0.55466 | 0.00232 | 0.05415 | 0.22358 | 0.25466 | 0.24419 | 1.1 × 10⁻⁷ |
| 800 | 0.09350 | 0.40457 | 0.01972 | 0.08461 | 0.39760 | 0.52737 | 0.42766 | 2.3 × 10⁻⁸ |
| 900 | 0.02526 | 0.29193 | 0.06632 | 0.08350 | 0.53299 | 0.85573 | 0.47693 | 7.6 × 10⁻⁹ |
| 1000 | 0.00236 | 0.26995 | 0.09778 | 0.06732 | 0.56260 | 0.98592 | 0.40200 | 2.5 × 10⁻⁷ |
| 1100 | 0.00021 | 0.27853 | 0.11137 | 0.05516 | 0.55474 | 0.99873 | 0.33082 | 3.9 × 10⁻⁸ |
| 1200 | 0.00003 | 0.28722 | 0.12049 | 0.04616 | 0.54611 | 0.99984 | 0.27695 | 1.8 × 10⁻⁸ |
| 1300 | 0.00000 | 0.29396 | 0.12728 | 0.03938 | 0.53937 | 0.99997 | 0.23628 | 4.1 × 10⁻⁸ |

Over the whole 57-point scan (600–1300 K in 12.5 K steps) the **maximum
disagreement between the two formulations is 9.8901 × 10⁻⁷ in mole fraction, at
637.5 K**, and that number is on the figure. The worst atom-balance residual is
`2.294 × 10⁻¹² mol`. `gibbs_minimise` reported success at 56 of 57 temperatures
and the extent solve converged at 57 of 57; the one failure is marked on the
figure, not removed.

Carbon, from `λ_C` against `G°` of graphite:

* S/C = 3: `λ_C − G°(graphite)` stays negative everywhere (worst −5.168 kJ/mol),
  so the single-phase gas answer above **is** the equilibrium.
* S/C = 1: `λ_C` exceeds `G°(graphite)` between **712.5 and 1112.5 K**, by up to
  3.387 kJ/mol — solid carbon is part of the true equilibrium there and the
  gas-only answer is not. Said on the figure.

### F6.6 — γ± for HCl(aq) at 298.15 K

`vlekit.reaction.debye_huckel_A(298.15)` returns **0.510791**, against the
**0.5108** Hamer & Wu used — an independent check on the constant, since one is
computed from the solvent permittivity and the other was quoted in 1972.

Extended-law ion size fitted on `I` ≤ 0.1: **a = 5.9157 Å**.

| model | 1 % off at | 5 % off at | rms relative error, 10⁻³–6 mol/kg |
|---|---|---|---|
| Debye-Hückel limiting | `I` = 0.00542 | `I` = 0.03097 | 0.4305 |
| extended (a fitted) | `I` = 0.14914 | `I` = 0.38555 | 0.2308 |
| Pitzer (3 parameters) | `I` = 5.10049 | never below 6 | 0.0031 |

| m | reference | limiting | extended | Pitzer |
|---|---|---|---|---|
| 0.001 | 0.9654 | 0.9635 | 0.9656 | 0.9653 |
| 0.01 | 0.9052 | 0.8890 | 0.9062 | 0.9044 |
| 0.1 | 0.7972 | 0.6894 | 0.7942 | 0.7950 |
| 1 | 0.8105 | 0.3085 | 0.6705 | 0.8107 |
| 2 | 1.0087 | 0.1895 | 0.6415 | 1.0097 |
| 6 | 3.1959 | 0.0561 | 0.6063 | 3.2790 |

NaCl, models only: Pitzer γ± = 0.9650 (0.001), 0.9023 (0.01), 0.7773 (0.1),
0.6565 (1), 0.7131 (3), 0.9892 (6 mol/kg).

### F6.7 — Pt | H₂(1 bar) | HCl(m) | AgCl | Ag at 298.15 K

`E° = 0.22234 V` (Bates & Bower, stated uncertainty 0.01 mV).
`2RT/F = 0.0513852 V` per unit `ln a±`.

Closure test on the *data*: recomputing the tabulated emf from the tabulated
γ± through the Nernst equation agrees to **0.037 mV at worst** (0.007 mV at
m = 0.1). That is the floor for every model comparison below.

Model minus measured, in mV, at the eight measured molalities:

| m | γ± = 1 | limiting | extended | Pitzer |
|---|---|---|---|---|
| 0.001 | −1.794 | +0.117 | +0.007 | +0.023 |
| 0.005 | −3.805 | +0.468 | −0.048 | +0.017 |
| 0.010 | −5.143 | +0.901 | −0.082 | +0.022 |
| 0.020 | −6.830 | +1.717 | −0.125 | +0.024 |
| 0.050 | −9.514 | +4.000 | −0.092 | +0.058 |
| 0.100 | −11.671 | +7.440 | +0.169 | +0.115 |

rms over the eight points: **γ± = 1 → 7.381 mV, limiting → 3.616 mV,
extended → 0.088 mV, Pitzer → 0.054 mV.** Extrapolated to 6 mol/kg the
model-minus-reference voltages are +59.7, +207.7, +85.4 and −1.3 mV.

---

## What was and was not verified — F6.6 and F6.7

This is the part of the module where numbers are most often copied without a
source, so here is exactly what happened.

**Searched, in this order.** `chemicals` (v1.5.2) — its `Electrolytes` folder
holds conductivity, permittivity, Laliberté density/viscosity/heat-capacity and
CRC aqueous-ion thermodynamics, and **no activity coefficients and no Pitzer
parameters**. `thermo` (v0.6.1) `electrochem` — same conclusion. Then the web.

**Found and used.**

| quantity | source | how it was checked |
|---|---|---|
| γ± of HCl(aq) at 25 °C, 0.001–6 mol/kg | Hamer & Wu, *J. Phys. Chem. Ref. Data* **1**, 1047 (1972), Table 4: the recommended equation (`B* = 1.525`, `β = 1.0494 × 10⁻¹`, `C = 6.5360 × 10⁻³`, `D = −4.2058 × 10⁻⁴`, `E = −4.0700 × 10⁻⁶`, `A = 0.5108`) and eleven tabulated values. Retrieved from the NIST SRD reprint of the paper. | The equation reproduces its own table to ≤ 0.06 % at ten of eleven points. `A` = 0.5108 is reproduced independently by `vlekit.reaction.debye_huckel_A(298.15)` = 0.510791 from the solvent permittivity. |
| γ± of HCl(aq), 0.001–0.1 mol/kg, and the emf of the Ag/AgCl cell at the same molalities, and `E° = 0.22234 V` | Bates & Bower, *J. Res. NBS* **53**, 283 (1954), Tables 2 and 3, via the PMC reprint (*J. Res. NIST* **106**, 471, 2001). | Differenced against Hamer & Wu: the two agree to **0.00116 in γ±** at worst. The emf and γ± tables close on each other through the Nernst equation to **0.037 mV**. |
| Pitzer β⁰, β¹, C^φ for H⁺/Cl⁻ (0.1775, 0.2945, 0.0008) and Na⁺/Cl⁻ (0.07534, 0.2769, 0.00148) at 25 °C | PHREEQC `pitzer.dat` (USGS), read from the file shipped with the `phreeqpython` package. The H⁺/Cl⁻ triple is the Pitzer & Mayorga (1973) set. | The NaCl β⁰/β¹/C^φ = 0.0765 / 0.2664 / 0.00127 of Pitzer & Mayorga were also found on the open web and are close but not identical to the `pitzer.dat` values, which carry the temperature-dependence coefficients of a later parameterisation; the `pitzer.dat` values are the ones used and are the 298.15 K values of that formulation. With the H⁺/Cl⁻ set, Pitzer reproduces the Hamer & Wu reference to an rms of 0.3 % over 10⁻³–6 mol/kg. |

**Not found, and what was done instead.** No machine-readable, citable table of
**measured γ± for NaCl or KCl** could be retrieved. The Hamer & Wu paper does
contain them, but the PDF-to-text conversion available here reaches only the
hydrogen-halide tables at the front of the paper; the NaCl and KCl tables, and
the appendix of Pitzer, Peiper & Busey (*JPCRD* **13**, 1, 1984), were beyond
the retrievable portion. `srd.nist.gov` is blocked to this session's direct
HTTPS egress, so only the fetch-and-summarise route was available.

The module asked for NaCl or KCl. Rather than type γ± values from memory,
**F6.6 is drawn for HCl** — the one 1:1 aqueous electrolyte here with a
critically-evaluated table that could be retrieved *and* cross-checked against a
second independent source — and NaCl is kept in its own panel with its verified
Pitzer parameters, no data, and the missing data stated on the figure. It is
also the electrolyte of F6.7, so the activity coefficient and the measured
voltage are about the same solution.

**One flagged discrepancy.** The retrieved Hamer & Wu table value at
`m = 6 mol/kg` is 3.23; their own equation, with the parameters retrieved
separately, gives 3.196 — a 1.07 % gap, where every other point agrees to
0.06 %. That is almost certainly an error in the retrieval rather than in the
paper. It is **shown on the figure with the discrepancy stated**, not quietly
corrected, and the reference curve is the equation.

**Nothing on F6.7 is illustrative.** `E°`, the emf and the γ± are measured
values from a named paper; the Pitzer parameters are published; the only fitted
quantity is the ion-size parameter of the extended law, which is fitted here to
the measured γ± below 0.1 mol/kg and printed on the figure.

---

## Everything that is assumed, in one list

1. **F6.3, `k_ij` = 0** for all three pairs of the ammonia system. Assumed, not
   fitted; no citable value was found. Its worth is quantified on the figure
   (< 0.01 percentage points of conversion at 300 bar for `k_ij = ±0.05`).
2. **F6.3, Peng-Robinson applied to hydrogen at `Tr` = 21.** The 1976 `m(ω)`
   polynomial was fitted for `ω < 0.5` near-critical; H₂ is far outside it. The
   usual industrial fix (Newton's effective critical constants) is a different
   assumption, not a smaller one, and is not used. Stated on the figure.
3. **F6.6, NaCl panel, extended-law ion size `a` = 4 Å.** Assumed. The HCl
   extended-law `a` = 5.92 Å is *fitted* here and printed.
4. **F6.6, no measured γ± for NaCl.** Stated on the figure; the panel is models
   only.
5. **Ideal-gas basis for F6.1, F6.2, F6.4 and F6.5.** A modelling choice at
   1 bar rather than an unsupported number; F6.3 is the figure that removes it.
6. **Operating points** — 700 K for the ammonia figures, S/C = 3 and 1 for
   reforming, the feed compositions, the temperature ranges — are choices of
   where to look, not data.

## Known limitations

* `gibbs_minimise` uses SLSQP with finite-difference gradients on `ln n`. It
  cannot resolve species whose equilibrium mole fraction is below roughly
  10⁻¹⁰, because such a species contributes nothing to `G`. F6.4 documents this
  by removing O₂ and NO and saying why; F6.4's right-hand panel shows the
  identity residual growing from 0.05 to 30 J/mol as CH₄ and NH₃ fall away at
  1300 K. An element-potential (RAND) Newton refinement would fix it, but that
  is a change to `vlekit` and was not made here.
* F6.5's minimisation is a single gas phase. Solid carbon is diagnosed
  afterwards from `λ_C`, not included as a phase in the minimisation, so inside
  the S/C = 1 carbon window the gas composition drawn is not the true
  equilibrium. Stated on the figure.
* F6.7's measured emf stops at 0.1 mol/kg because Bates & Bower's table does.
  Everything above that molality on that figure is a prediction, and the shaded
  band marks where the data end.
