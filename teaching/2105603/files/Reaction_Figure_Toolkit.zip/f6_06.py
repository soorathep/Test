#!/usr/bin/env python3
"""F6.6 — Mean ionic activity coefficient: three models and where each stops.

2105603 Advanced Chemical Engineering Thermodynamics — Module 6
Soorathep Kheawhom, Chulalongkorn University

WHICH ELECTROLYTE, AND WHY. The module asks for NaCl or KCl. The figure is
drawn for HCl(aq) instead, and says so, because HCl is the one 1:1 aqueous
electrolyte for which a critically-evaluated gamma_pm table could actually be
retrieved and cross-checked here. The physics being shown — where the limiting
law fails, where the extended law fails, what the three fitted Pitzer
parameters buy — is identical, and the electrolyte is the same one used in
F6.7, so the activity coefficient and the measured cell voltage are about the
same solution. NaCl is kept on the figure in its own panel, with its verified
Pitzer parameters and no data, and the missing data is stated there.

WHAT WAS FOUND, AND WHERE
  measured / evaluated gamma_pm for HCl(aq) at 25 C
    (a) Hamer & Wu, J. Phys. Chem. Ref. Data 1, 1047 (1972), Table 4 — the
        recommended equation
            log10 gamma = -A sqrt(m)/(1 + B* sqrt(m)) + beta m + C m^2
                          + D m^3 + E m^4
        with B* = 1.525, beta = 1.0494e-1, C = 6.5360e-3, D = -4.2058e-4,
        E = -4.0700e-6, and the tabulated values at 11 molalities.
    (b) Bates & Bower, J. Res. NBS 53, 283 (1954), Table 3 — eight molalities
        from 0.001 to 0.1, from emf on the cell of F6.7.
    The two sources are independent and are differenced against each other by
    this script; they agree to 0.0012 in gamma_pm or better.
  Pitzer parameters
    PHREEQC `pitzer.dat` (USGS; distributed with the `phreeqpython` package),
    H+/Cl- pair: beta0 = 0.1775, beta1 = 0.2945, C0 = 0.0008. These are the
    Pitzer & Mayorga (1973) values. Na+/Cl-: 0.07534, 0.2769, 0.00148.
  NOT found
    a machine-readable, citable table of measured gamma_pm for NaCl or KCl.
    The `chemicals` and `thermo` packages carry no electrolyte activity data
    at all (checked); the NaCl and KCl tables of Hamer & Wu are in a part of
    the paper that could not be retrieved. Rather than type numbers from
    memory, the NaCl panel is drawn with models only and labelled.

ASSUMED: the ion-size parameter of the extended law. It is fitted here to the
reference gamma_pm below I = 0.1 mol/kg and the fitted value is printed on the
figure, so that the extended law is being judged at its best rather than at an
arbitrary 4 angstrom.

Run:  python3 f6_06.py
"""
from __future__ import annotations

import os
import sys
import warnings

import numpy as np
from scipy.optimize import brentq, minimize_scalar

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                   # noqa: E402

from vlekit.reaction import (debye_huckel_A, dh_extended,          # noqa: E402
                             dh_limiting, pitzer, water_permittivity)
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,       # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, use_style)

warnings.filterwarnings("ignore", category=RuntimeWarning)

OUT = os.environ.get("F6_OUT", "/home/claude/vle6/qmd/figures")
SLUG = "f6_06_activity_coefficient_models"

T = 298.15

# --- Hamer & Wu (1972), JPCRD 1, 1047, Table 4: HCl(aq) at 25 C -----------
HW_A = 0.5108                 # their Debye-Huckel constant
HW = dict(Bstar=1.525, beta=1.0494e-1, C=6.5360e-3, D=-4.2058e-4,
          E=-4.0700e-6)
HW_TABLE_M = np.array([0.001, 0.002, 0.005, 0.010, 0.020, 0.050,
                       0.100, 0.200, 1.000, 2.000, 6.000])
HW_TABLE_G = np.array([0.965, 0.952, 0.929, 0.905, 0.876, 0.832,
                       0.797, 0.768, 0.811, 1.009, 3.23])

# --- Bates & Bower (1954), J. Res. NBS 53, 283, Table 3 -------------------
BB_M = np.array([0.001, 0.002, 0.005, 0.010, 0.020, 0.050, 0.070, 0.100])
BB_G = np.array([0.9650, 0.9520, 0.9283, 0.9045, 0.8753, 0.8308, 0.8137,
                 0.7967])

# --- Pitzer parameters, PHREEQC pitzer.dat (USGS) -------------------------
PITZER = {"HCl": dict(b0=0.1775, b1=0.2945, Cphi=0.0008),
          "NaCl": dict(b0=0.07534, b1=0.2769, Cphi=0.00148)}

M_GRID = np.geomspace(1e-3, 6.0, 400)


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def hamer_wu(m):
    """The recommended HCl correlation, evaluated at molality m."""
    m = np.asarray(m, dtype=float)
    s = np.sqrt(m)
    log_g = (-HW_A * s / (1.0 + HW["Bstar"] * s)
             + HW["beta"] * m + HW["C"] * m ** 2
             + HW["D"] * m ** 3 + HW["E"] * m ** 4)
    return 10.0 ** log_g


def departure(model, ref=hamer_wu, tol=0.01, lo=1e-4, hi=6.0):
    """The molality at which a model first departs from the reference by tol."""
    def f(m):
        return abs(model(m) / ref(m) - 1.0) - tol
    if f(lo) > 0:
        return float("nan")
    if f(hi) < 0:
        return float("nan")
    return float(brentq(f, lo, hi, xtol=1e-10))


# --------------------------------------------------------------------------
def make():
    A = debye_huckel_A(T)

    def lim(m):
        return dh_limiting(m, 1, -1, T=T, A=A)

    # the one adjustable parameter of the extended law, fitted where the
    # extended law is supposed to work
    fit_mask = BB_M <= 0.1
    def sse(a):
        g = dh_extended(BB_M[fit_mask], 1, -1, a_ang=a, T=T, A=A)
        return float(np.sum((np.log(g) - np.log(BB_G[fit_mask])) ** 2))
    res = minimize_scalar(sse, bounds=(1.0, 12.0), method="bounded")
    a_fit = float(res.x)

    def ext(m):
        return dh_extended(m, 1, -1, a_ang=a_fit, T=T, A=A)

    p = PITZER["HCl"]

    def pit(m):
        return pitzer(m, m, 1, -1, p["b0"], p["b1"], p["Cphi"], T=T, A=A)

    pn = PITZER["NaCl"]

    def pit_na(m):
        return pitzer(m, m, 1, -1, pn["b0"], pn["b1"], pn["Cphi"], T=T, A=A)

    models = {"limiting": lim, "extended": ext, "pitzer": pit}
    dep = {k: {t: departure(v, tol=t) for t in (0.01, 0.05)}
           for k, v in models.items()}

    # the two independent data sources, differenced against each other
    cross = np.abs(BB_G - hamer_wu(BB_M))
    tabchk = HW_TABLE_G / hamer_wu(HW_TABLE_M) - 1.0

    # how well each model reproduces the reference, over the whole range
    rms = {k: float(np.sqrt(np.mean(
        (np.asarray(v(M_GRID)) / hamer_wu(M_GRID) - 1.0) ** 2)))
        for k, v in models.items()}

    return dict(A=A, a_fit=a_fit, models=models, pit_na=pit_na, dep=dep,
                cross=cross, tabchk=tabchk, rms=rms, sse=float(res.fun))


# --------------------------------------------------------------------------
def build(d):
    use_style()
    fig = plt.figure(figsize=(13.8, 8.0))
    gs = fig.add_gridspec(2, 2, width_ratios=[1.5, 1.0],
                          height_ratios=[1.0, 1.0],
                          left=0.058, right=0.985, top=0.855, bottom=0.185,
                          wspace=0.24, hspace=0.50)
    ax = fig.add_subplot(gs[:, 0])
    a1 = fig.add_subplot(gs[0, 1])
    a2 = fig.add_subplot(gs[1, 1])
    for a in (ax, a1, a2):
        a.grid(True, zorder=0)
        a.set_axisbelow(True)

    ref = hamer_wu(M_GRID)
    ax.semilogx(M_GRID, ref, "-", color=GRAPHITE, lw=3.2, zorder=3,
                label="Hamer & Wu (1972) recommended equation")
    ax.semilogx(M_GRID, d["models"]["limiting"](M_GRID), "--", color=RUST,
                lw=2.4, zorder=4, label="Debye-Huckel limiting law")
    ax.semilogx(M_GRID, d["models"]["extended"](M_GRID), "-.", color=AMBER,
                lw=2.4, zorder=4,
                label=f"extended law, $a$ = {d['a_fit']:.2f} $\\AA$ "
                      "(fitted, $I\\leq$ 0.1)")
    ax.semilogx(M_GRID, d["models"]["pitzer"](M_GRID), "-", color=NAVY,
                lw=2.4, zorder=5, label="Pitzer (3 fitted parameters)")
    ax.plot(BB_M, BB_G, "o", color=TEAL, ms=10, mfc=PAPER, mew=2.0, zorder=7,
            label="Bates & Bower (1954), from emf")
    ax.plot(HW_TABLE_M, HW_TABLE_G, "s", color=GRAPHITE, ms=8, mfc=PAPER,
            mew=1.8, zorder=6, label="Hamer & Wu (1972) tabulated")

    ax.set_xlim(1e-3, 6.0)
    ax.set_ylim(0.03, 3.6)
    ax.set_yscale("log")
    ax.set_xlabel(r"ionic strength $I$ = $m$  /  mol kg$^{-1}$   (log scale)")
    ax.set_ylabel(r"mean ionic activity coefficient  $\gamma_\pm$")
    ax.set_title("HCl in water at 298.15 K", fontsize=13.5, pad=8,
                 loc="left", x=0.0)
    ax.legend(loc="lower left", fontsize=10.8, labelspacing=0.55,
              bbox_to_anchor=(0.015, 0.015))

    # where each model leaves the reference by 5 %
    # these two callouts sit in the wedge BELOW every curve at their own
    # ionic strength — the only empty space near them, since the band above
    # the curves is where the summary block is
    for key, col, ylab in (("limiting", RUST, 0.40), ("extended", AMBER, 0.22)):
        m5 = d["dep"][key][0.05]
        if np.isfinite(m5):
            g = float(d["models"][key](m5))
            ax.plot([m5], [g], "v", color=col, ms=13, mec=PAPER, mew=1.4,
                    zorder=9)
            ax.annotate(f"5 % off at $I$ = {m5:.3f}",
                        xy=(m5, g), xytext=(m5, ylab),
                        ha="center", va="top", fontsize=11, color=col,
                        linespacing=1.45, zorder=10,
                        bbox=dict(boxstyle="round,pad=0.22", fc=PAPER, ec=col,
                                  lw=1.0, alpha=0.95),
                        arrowprops=dict(arrowstyle="-", color=col, lw=1.1,
                                        shrinkA=6, shrinkB=6))

    # ------------------------------------------------------ deviation panel
    for key, col, ls in (("limiting", RUST, "--"), ("extended", AMBER, "-."),
                         ("pitzer", NAVY, "-")):
        dev = np.abs(np.asarray(d["models"][key](M_GRID)) / ref - 1.0)
        a1.loglog(M_GRID, np.maximum(dev, 1e-8), ls, color=col, lw=2.3,
                  zorder=4)
    a1.axhline(0.01, color=GRAPHITE, lw=1.1, ls=":")
    a1.axhline(0.05, color=GRAPHITE, lw=1.1, ls=":")
    a1.text(1.1e-3, 0.0115, "1 %", fontsize=10, color=GRAPHITE, va="bottom")
    a1.text(1.1e-3, 0.057, "5 %", fontsize=10, color=GRAPHITE, va="bottom")
    a1.set_xlim(1e-3, 6.0)
    a1.set_ylim(1e-5, 30.0)
    a1.set_xlabel(r"$I$ / mol kg$^{-1}$")
    a1.set_ylabel(r"$|\gamma_\pm^{\rm model}/\gamma_\pm^{\rm ref} - 1|$")
    a1.set_title("Where each model stops working", fontsize=12, pad=6,
                 loc="left", x=0.0)
    lines = []
    for key, nm in (("limiting", "limiting law"), ("extended", "extended law"),
                    ("pitzer", "Pitzer")):
        d1, d5 = d["dep"][key][0.01], d["dep"][key][0.05]
        lines.append(f"{nm}: 1 % at $I$ = "
                     + (f"{d1:.4f}" if np.isfinite(d1) else "never")
                     + ",  5 % at "
                     + (f"{d5:.3f}" if np.isfinite(d5) else "never"))
    # the summary of the crossings belongs on the main panel: every corner of
    # this small panel has a curve running through it
    ax.text(0.025, 0.975, "\n".join(lines), transform=ax.transAxes,
            ha="left", va="top", fontsize=11, color=INK, linespacing=1.55,
            zorder=9,
            bbox=dict(boxstyle="round,pad=0.28", fc=PAPER, ec=MIST, lw=1.0,
                      alpha=0.95))

    # ------------------------------------------------------ NaCl panel
    a2.semilogx(M_GRID, d["models"]["limiting"](M_GRID), "--", color=RUST,
                lw=2.2, zorder=4)
    a2.semilogx(M_GRID, dh_extended(M_GRID, 1, -1, a_ang=4.0, T=T, A=d["A"]),
                "-.", color=AMBER, lw=2.2, zorder=4)
    a2.semilogx(M_GRID, d["pit_na"](M_GRID), "-", color=NAVY, lw=2.6, zorder=5)
    a2.set_xlim(1e-3, 6.0)
    a2.set_ylim(0.0, 1.95)
    a2.set_xlabel(r"$I$ / mol kg$^{-1}$")
    a2.set_ylabel(r"$\gamma_\pm$")
    a2.set_title("NaCl, the salt the module asks for — models only",
                 fontsize=12, pad=6, loc="left", x=0.0)
    a2.text(0.03, 0.975,
            "Pitzer $\\beta^0$ = %.5f, $\\beta^1$ = %.4f, $C^\\phi$ = %.5f\n"
            "(PHREEQC `pitzer.dat`, USGS) — VERIFIED.\n"
            "Extended law drawn at $a$ = 4 $\\AA$ — ASSUMED.\n"
            "NO measured $\\gamma_\\pm$ table for NaCl could be\n"
            "retrieved in a citable form, so none is drawn."
            % (PITZER["NaCl"]["b0"], PITZER["NaCl"]["b1"],
               PITZER["NaCl"]["Cphi"]),
            transform=a2.transAxes, ha="left", va="top", fontsize=10,
            color=INK, linespacing=1.5, zorder=9,
            bbox=dict(boxstyle="round,pad=0.26", fc=PAPER, ec=MIST, lw=1.0,
                      alpha=0.95))
    for lab, y, col in (("limiting", 0.12, RUST), ("extended", 0.47, AMBER),
                        ("Pitzer", 0.78, NAVY)):
        a2.text(4.2, y, lab, ha="right", va="center", fontsize=10.5,
                color=col, zorder=8,
                bbox=dict(boxstyle="round,pad=0.16", fc=PAPER, ec="none",
                          alpha=0.88))

    fig.text(0.5, 0.968,
             "The limiting law is finished by $I$ = "
             f"{d['dep']['limiting'][0.05]:.2f} mol/kg and the extended law "
             f"by {d['dep']['extended'][0.05]:.2f}; three fitted Pitzer "
             "parameters carry the same solution to 6 mol/kg",
             ha="center", va="center", fontsize=15, color=INK)

    fig.text(0.5, 0.010,
             "Reference $\\gamma_\\pm$: Hamer & Wu, J. Phys. Chem. Ref. Data "
             "1, 1047 (1972), Table 4 (equation and tabulated values), "
             "cross-checked against Bates & Bower, J. Res. NBS 53, 283 "
             f"(1954), Table 3 — the two agree to {d['cross'].max():.4f} in "
             "$\\gamma_\\pm$.\nPitzer parameters from PHREEQC `pitzer.dat` "
             "(USGS). Debye-Huckel $A$ = "
             f"{d['A']:.4f} from `reaction.debye_huckel_A`, against the "
             f"{HW_A:g} Hamer & Wu used. ONE FLAG: the retrieved table value "
             f"at $m$ = 6 ({HW_TABLE_G[-1]:g}) sits "
             f"{100 * d['tabchk'][-1]:+.1f} % from the retrieved equation "
             f"({hamer_wu(6.0):.3f});\nevery other point agrees to 0.06 %, so "
             "that one figure is most likely a retrieval error and is shown "
             "rather than quietly corrected.",
             ha="center", va="bottom", fontsize=10.0, color=SLATE,
             linespacing=1.6)
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = make()
    print(f"T = {T} K, water permittivity {water_permittivity(T):.3f}, "
          f"Debye-Huckel A = {d['A']:.6f} (Hamer & Wu used {HW_A})")
    print("\nHamer & Wu table against their own equation:")
    for m, g in zip(HW_TABLE_M, HW_TABLE_G):
        e = float(hamer_wu(m))
        print(f"  m = {m:6.3f}  table {g:7.4f}  equation {e:7.4f}  "
              f"{100 * (g / e - 1):+6.2f} %")
    print("\nBates & Bower (1954) against Hamer & Wu equation:")
    for m, g in zip(BB_M, BB_G):
        e = float(hamer_wu(m))
        print(f"  m = {m:6.3f}  B&B {g:7.4f}  H&W {e:7.4f}  "
              f"difference {g - e:+.5f}")
    print(f"  worst difference between the two sources: {d['cross'].max():.5f}")
    print(f"\nextended-law ion size fitted on I <= 0.1: a = {d['a_fit']:.4f} "
          f"angstrom (sum of squared residuals in ln gamma {d['sse']:.3e})")
    print("\nPitzer parameters used (PHREEQC pitzer.dat, USGS):")
    for k, v in PITZER.items():
        print(f"  {k:5s} beta0 = {v['b0']:.5f}  beta1 = {v['b1']:.4f}  "
              f"Cphi = {v['Cphi']:.5f}")
    print("\ndeparture from the reference:")
    for k in ("limiting", "extended", "pitzer"):
        d1, d5 = d["dep"][k][0.01], d["dep"][k][0.05]
        print(f"  {k:9s} 1 % at I = "
              + (f"{d1:.5f}" if np.isfinite(d1) else "never in 1e-4..6")
              + "   5 % at I = "
              + (f"{d5:.5f}" if np.isfinite(d5) else "never in 1e-4..6")
              + f"   rms relative error over 1e-3..6: {d['rms'][k]:.4f}")
    print("\ngamma_pm at selected molalities (HCl):")
    print("     m       reference  limiting  extended   Pitzer")
    for m in (0.001, 0.01, 0.1, 0.5, 1.0, 2.0, 4.0, 6.0):
        print(f"  {m:7.3f}  {float(hamer_wu(m)):9.4f} "
              f"{float(d['models']['limiting'](m)):9.4f} "
              f"{float(d['models']['extended'](m)):9.4f} "
              f"{float(d['models']['pitzer'](m)):9.4f}")
    print("\nNaCl (models only, no measured table retrieved):")
    for m in (0.001, 0.01, 0.1, 1.0, 3.0, 6.0):
        print(f"  m = {m:6.3f}  Pitzer gamma_pm = {float(d['pit_na'](m)):.4f}")
    for p in write(build(d), SLUG):
        print("wrote", p)
