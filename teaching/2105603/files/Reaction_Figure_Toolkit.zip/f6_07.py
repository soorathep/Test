#!/usr/bin/env python3
"""F6.7 — A measurable voltage, and what the activity coefficient is worth in it.

2105603 Advanced Chemical Engineering Thermodynamics — Module 6
Soorathep Kheawhom, Chulalongkorn University

The cell

    Pt | H2 (1 bar) | HCl(m) | AgCl | Ag

with the reaction  1/2 H2 + AgCl -> Ag + H+ + Cl-,  n = 1, so

    E = E0 - (2RT/F) ln( gamma_pm m / m0 )

That is `vlekit.reaction.cell_voltage` with n_electrons = 1 and nu_ions = 2.
Everything about the solution enters through gamma_pm, so the difference
between four electrolyte models is a difference in millivolts that a
voltmeter can see.

MEASURED DATA — all of it real, none of it illustrative
    Bates & Bower, J. Res. Natl. Bur. Stand. 53, 283 (1954), reprinted in
    J. Res. NIST 106, 471 (2001).
        E0 = 0.22234 absolute volt at 25 C, stated uncertainty 0.01 mV
        Table 2, smoothed emf at 25 C, eight molalities 0.001 to 0.1
        Table 3, gamma_pm at the same eight molalities
    Hamer & Wu, J. Phys. Chem. Ref. Data 1, 1047 (1972), Table 4, supplies
    the reference gamma_pm over the whole range to 6 mol/kg (the same
    correlation as F6.6).

    The script checks the two against each other: it recomputes the measured
    emf from the tabulated gamma_pm through the Nernst equation and prints
    the difference. That is a closure test on the data, not on the models.

ASSUMED: nothing on this figure. The Pitzer parameters are the PHREEQC
`pitzer.dat` (USGS) values for the H+/Cl- pair; the ion-size parameter of the
extended law is fitted here to the measured gamma_pm below I = 0.1 and the
fitted value is printed. The measured points stop at 0.1 mol/kg because that
is where Bates & Bower's table stops; beyond it the curves are predictions,
and the figure says so.

Run:  python3 f6_07.py
"""
from __future__ import annotations

import os
import sys
import warnings

import numpy as np
from scipy.optimize import minimize_scalar

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                   # noqa: E402

from vlekit.reaction import (F_FARADAY, R, cell_voltage,          # noqa: E402
                             debye_huckel_A, dh_extended, dh_limiting,
                             pitzer)
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,       # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, use_style)

warnings.filterwarnings("ignore", category=RuntimeWarning)

OUT = os.environ.get("F6_OUT", "/home/claude/vle6/qmd/figures")
SLUG = "f6_07_cell_voltage"

T = 298.15
E0 = 0.22234                      # V, Bates & Bower (1954)
E0_UNC = 1e-5                     # V, their stated 0.01 mV

# Bates & Bower (1954), Tables 2 and 3, 25 C
BB_M = np.array([0.001, 0.002, 0.005, 0.010, 0.020, 0.050, 0.070, 0.100])
BB_E = np.array([0.57909, 0.54418, 0.49840, 0.46412, 0.43019, 0.38579,
                 0.36957, 0.35233])
BB_G = np.array([0.9650, 0.9520, 0.9283, 0.9045, 0.8753, 0.8308, 0.8137,
                 0.7967])

# Hamer & Wu (1972) Table 4 correlation for HCl(aq) at 25 C
HW_A = 0.5108
HW = dict(Bstar=1.525, beta=1.0494e-1, C=6.5360e-3, D=-4.2058e-4,
          E=-4.0700e-6)

# PHREEQC pitzer.dat (USGS), H+/Cl- pair
PZ = dict(b0=0.1775, b1=0.2945, Cphi=0.0008)

M_GRID = np.geomspace(1e-3, 6.0, 400)


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def hamer_wu(m):
    m = np.asarray(m, dtype=float)
    s = np.sqrt(m)
    return 10.0 ** (-HW_A * s / (1.0 + HW["Bstar"] * s)
                    + HW["beta"] * m + HW["C"] * m ** 2
                    + HW["D"] * m ** 3 + HW["E"] * m ** 4)


def E_of(m, gamma):
    """Open-circuit voltage from `vlekit.reaction.cell_voltage`."""
    return cell_voltage(E0, T, 1, m, gamma, nu_ions=2)


# --------------------------------------------------------------------------
def make():
    A = debye_huckel_A(T)
    slope = 2.0 * R * T / F_FARADAY          # V per unit ln a_pm

    fit = BB_M <= 0.1

    def sse(a):
        g = dh_extended(BB_M[fit], 1, -1, a_ang=a, T=T, A=A)
        return float(np.sum((np.log(g) - np.log(BB_G[fit])) ** 2))

    a_fit = float(minimize_scalar(sse, bounds=(1.0, 12.0),
                                  method="bounded").x)

    models = {
        "ideal": lambda m: np.ones_like(np.asarray(m, float)),
        "limiting": lambda m: dh_limiting(m, 1, -1, T=T, A=A),
        "extended": lambda m: dh_extended(m, 1, -1, a_ang=a_fit, T=T, A=A),
        "pitzer": lambda m: pitzer(m, m, 1, -1, PZ["b0"], PZ["b1"],
                                   PZ["Cphi"], T=T, A=A),
    }

    # closure test on the DATA: does the Nernst equation reproduce the
    # measured emf from the measured activity coefficient?
    E_from_gamma = E_of(BB_M, BB_G)
    closure = 1000.0 * (E_from_gamma - BB_E)          # mV

    curves = {k: E_of(M_GRID, v(M_GRID)) for k, v in models.items()}
    curves["reference"] = E_of(M_GRID, hamer_wu(M_GRID))

    at_data = {k: 1000.0 * (E_of(BB_M, v(BB_M)) - BB_E)
               for k, v in models.items()}
    vs_ref = {k: 1000.0 * (curves[k] - curves["reference"])
              for k in models}

    return dict(A=A, a_fit=a_fit, slope=slope, models=models, curves=curves,
                closure=closure, at_data=at_data, vs_ref=vs_ref,
                E_from_gamma=E_from_gamma)


# --------------------------------------------------------------------------
STYLE = {"ideal": (SLATE, "--", r"$\gamma_\pm = 1$ (ideal solution)"),
         "limiting": (RUST, "--", "Debye-Huckel limiting law"),
         "extended": (AMBER, "-.", "extended law"),
         "pitzer": (NAVY, "-", "Pitzer")}


def build(d):
    use_style()
    fig = plt.figure(figsize=(13.8, 8.0))
    gs = fig.add_gridspec(2, 2, width_ratios=[1.5, 1.0],
                          height_ratios=[1.0, 1.0],
                          left=0.062, right=0.985, top=0.855, bottom=0.185,
                          wspace=0.26, hspace=0.50)
    ax = fig.add_subplot(gs[:, 0])
    a1 = fig.add_subplot(gs[0, 1])
    a2 = fig.add_subplot(gs[1, 1])
    for a in (ax, a1, a2):
        a.grid(True, zorder=0)
        a.set_axisbelow(True)

    ax.axvspan(BB_M[0], BB_M[-1], color=MIST, alpha=0.35, zorder=0,
               label=f"measured range, $m$ = {BB_M[0]:g}–{BB_M[-1]:g} mol/kg")
    ax.semilogx(M_GRID, d["curves"]["reference"], "-", color=GRAPHITE, lw=3.2,
                zorder=3, label="Hamer & Wu (1972) $\\gamma_\\pm$")
    for k in ("ideal", "limiting", "extended", "pitzer"):
        col, ls, lab = STYLE[k]
        ax.semilogx(M_GRID, d["curves"][k], ls, color=col, lw=2.4, zorder=4,
                    label=lab)
    ax.plot(BB_M, BB_E, "o", color=TEAL, ms=11, mfc=PAPER, mew=2.2, zorder=8,
            label="Bates & Bower (1954), measured emf")

    ax.set_xlim(1e-3, 6.0)
    ax.set_ylim(0.05, 0.66)
    ax.set_xlabel(r"HCl molality $m$  /  mol kg$^{-1}$   (log scale)")
    ax.set_ylabel("open-circuit voltage  $E$  /  V")
    ax.set_title("Pt | H$_2$(1 bar) | HCl($m$) | AgCl | Ag  at 298.15 K,  "
                 f"$E^\\circ$ = {E0:.5f} V", fontsize=13.5, pad=8,
                 loc="left", x=0.0)
    ax.legend(loc="lower left", fontsize=10.8, labelspacing=0.55,
              bbox_to_anchor=(0.015, 0.015))

    ideal_gap = 1000.0 * (d["curves"]["ideal"] - d["curves"]["reference"])
    j = int(np.argmin(np.abs(M_GRID - 0.1)))
    ax.annotate(
        "at $m$ = 0.1 mol/kg the activity coefficient\n"
        f"is worth {abs(ideal_gap[j]):.1f} mV — over a thousand times\n"
        "the 0.01 mV uncertainty Bates & Bower quote",
        xy=(M_GRID[j], 0.5 * (d["curves"]["ideal"][j]
                              + d["curves"]["reference"][j])),
        xytext=(0.030, 0.585), ha="left", va="top", fontsize=11.5,
        color=INK, linespacing=1.55, zorder=10,
        bbox=dict(boxstyle="round,pad=0.30", fc=PAPER, ec=MIST, lw=1.0,
                  alpha=0.96),
        arrowprops=dict(arrowstyle="-", color=GRAPHITE, lw=1.1, shrinkA=6,
                        shrinkB=4))
    ax.plot([M_GRID[j], M_GRID[j]],
            [d["curves"]["reference"][j], d["curves"]["ideal"][j]], "-",
            color=INK, lw=3.0, zorder=9)

    # -------------------------------------------- residual at the data points
    for k in ("ideal", "limiting", "extended", "pitzer"):
        col, ls, lab = STYLE[k]
        a1.semilogx(BB_M, np.abs(d["at_data"][k]), ls + "o", color=col,
                    lw=2.2, ms=6, mfc=PAPER, mew=1.4, zorder=4)
    a1.semilogx(BB_M, np.abs(d["closure"]), ":s", color=GRAPHITE, lw=1.8,
                ms=6, mfc=PAPER, mew=1.4, zorder=5)
    a1.axhline(1000.0 * E0_UNC, color=GRAPHITE, lw=1.1, ls=":")
    a1.set_yscale("log")
    a1.set_xlim(8e-4, 0.13)
    a1.set_ylim(9e-4, 60.0)
    a1.set_xlabel(r"$m$ / mol kg$^{-1}$")
    a1.set_ylabel(r"$|E_{\rm model} - E_{\rm measured}|$ / mV")
    a1.set_title("Against the eight measured points\n"
                 "dotted squares: emf recomputed from the tabulated "
                 "$\\gamma_\\pm$;  dotted line: their 0.01 mV",
                 fontsize=11.5, pad=6, loc="left", x=0.0)
    # four curves that never cross: each is named at its own right-hand end,
    # alternately above and below, so no legend box is needed
    for k, va, f in (("ideal", "bottom", 1.35), ("limiting", "top", 0.70)):
        col = STYLE[k][0]
        a1.text(0.118, abs(d["at_data"][k][-1]) * f,
                {"ideal": "$\\gamma_\\pm = 1$",
                 "limiting": "limiting law"}[k],
                ha="right", va=va, fontsize=10.5, color=col, zorder=7,
                bbox=dict(boxstyle="round,pad=0.16", fc=PAPER, ec="none",
                          alpha=0.88))
    # the extended-law and Pitzer curves tangle in the last decade, so their
    # labels go into the clear band below the 0.01 mV line and point back
    for k, xt, mi in (("extended", 4.5e-3, 0), ("pitzer", 6.5e-2, -1)):
        col = STYLE[k][0]
        a1.annotate({"extended": "extended law", "pitzer": "Pitzer"}[k],
                    xy=(BB_M[mi], abs(d["at_data"][k][mi])),
                    xytext=(xt, 2.2e-3), ha="center", va="center",
                    fontsize=10.5, color=col, zorder=7,
                    bbox=dict(boxstyle="round,pad=0.18", fc=PAPER, ec="none",
                              alpha=0.90),
                    arrowprops=dict(arrowstyle="-", color=col, lw=1.0,
                                    shrinkA=5, shrinkB=4))

    # -------------------------------------------- residual over the full range
    for k in ("ideal", "limiting", "extended", "pitzer"):
        col, ls, lab = STYLE[k]
        a2.semilogx(M_GRID, d["vs_ref"][k], ls, color=col, lw=2.3, zorder=4)
    a2.axhline(0.0, color=GRAPHITE, lw=1.2)
    a2.axvspan(BB_M[0], BB_M[-1], color=MIST, alpha=0.35, zorder=0)
    a2.set_xlim(1e-3, 6.0)
    a2.set_ylim(-70.0, 230.0)
    a2.set_xlabel(r"$m$ / mol kg$^{-1}$")
    a2.set_ylabel(r"$E_{\rm model} - E_{\rm reference}$ / mV")
    a2.set_title("Extrapolated past the data, in millivolts",
                 fontsize=12, pad=6, loc="left", x=0.0)
    for k, va in (("limiting", "bottom"), ("ideal", "top"),
                  ("extended", "bottom"), ("pitzer", "top")):
        col = STYLE[k][0]
        y = d["vs_ref"][k][-1]
        a2.text(5.4, y + (9.0 if va == "bottom" else -9.0),
                {"ideal": "$\\gamma_\\pm=1$", "limiting": "limiting",
                 "extended": "extended", "pitzer": "Pitzer"}[k],
                ha="right", va=va, fontsize=10.5, color=col, zorder=7,
                bbox=dict(boxstyle="round,pad=0.16", fc=PAPER, ec="none",
                          alpha=0.88))

    fig.text(0.5, 0.968,
             "The activity coefficient is not a correction to a calculation — "
             "it is "
             f"{abs(ideal_gap[j]):.0f} mV on a voltmeter at 0.1 mol/kg, and "
             f"{abs(ideal_gap[-1]):.0f} mV at 6",
             ha="center", va="center", fontsize=15, color=INK)
    fig.text(0.5, 0.010,
             "MEASURED, NOT ILLUSTRATIVE. $E^\\circ$ and the eight emf values "
             "are Bates & Bower, J. Res. NBS 53, 283 (1954), Tables 2 and 3; "
             "the reference $\\gamma_\\pm$ curve is Hamer & Wu, J. Phys. Chem. "
             "Ref. Data 1, 1047 (1972), Table 4.\nPitzer parameters from "
             "PHREEQC `pitzer.dat` (USGS). The extended-law ion size "
             f"$a$ = {d['a_fit']:.2f} $\\AA$ is fitted here to the measured "
             "$\\gamma_\\pm$ below 0.1 mol/kg. Recomputing the measured emf "
             "from the measured $\\gamma_\\pm$ through the Nernst equation "
             f"closes to {np.abs(d['closure']).max():.2f} mV,\nwhich is the "
             "internal consistency of the data set and the floor for every "
             "model comparison above. Beyond 0.1 mol/kg the curves are "
             "predictions with nothing to test them against, and the shaded "
             "band marks where the data end.",
             ha="center", va="bottom", fontsize=10.0, color=SLATE,
             linespacing=1.6)
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = make()
    print(f"cell: Pt|H2(1 bar)|HCl(m)|AgCl|Ag, T = {T} K")
    print(f"E0 = {E0} V (Bates & Bower 1954, uncertainty "
          f"{1000 * E0_UNC:.2f} mV)")
    print(f"2RT/F = {d['slope']:.7f} V per unit ln(a_pm)")
    print(f"Debye-Huckel A = {d['A']:.6f}; extended-law ion size fitted on "
          f"m <= 0.1: a = {d['a_fit']:.4f} angstrom")
    print("\ndata closure — Nernst from the tabulated gamma_pm against the "
          "tabulated emf:")
    print("     m      gamma_pm   E measured   E from gamma   difference/mV")
    for m, g, e, ec, dd in zip(BB_M, BB_G, BB_E, d["E_from_gamma"],
                               d["closure"]):
        print(f"  {m:6.3f}  {g:9.4f}  {e:11.5f}  {ec:13.5f}  {dd:+11.3f}")
    print(f"  worst {np.abs(d['closure']).max():.3f} mV")

    print("\nmodel minus measured, mV, at the eight measured molalities:")
    print("     m      ideal   limiting  extended   Pitzer")
    for i, m in enumerate(BB_M):
        print(f"  {m:6.3f} " + " ".join(
            f"{d['at_data'][k][i]:9.3f}"
            for k in ("ideal", "limiting", "extended", "pitzer")))
    print("  rms over the eight points, mV: " + ", ".join(
        f"{k} {np.sqrt(np.mean(d['at_data'][k] ** 2)):.3f}"
        for k in ("ideal", "limiting", "extended", "pitzer")))

    print("\nmodel minus reference, mV, extrapolated:")
    print("     m      ideal   limiting  extended   Pitzer")
    for m in (0.001, 0.01, 0.1, 1.0, 3.0, 6.0):
        i = int(np.argmin(np.abs(M_GRID - m)))
        print(f"  {M_GRID[i]:6.3f} " + " ".join(
            f"{d['vs_ref'][k][i]:9.3f}"
            for k in ("ideal", "limiting", "extended", "pitzer")))
    for p in write(build(d), SLUG):
        print("wrote", p)
