#!/usr/bin/env python3
"""F6.2 — van 't Hoff: where the constant-enthalpy approximation stops working.

2105603 Advanced Chemical Engineering Thermodynamics — Module 6
Soorathep Kheawhom, Chulalongkorn University

`Reaction.K` integrates Cp, so its dH is a function of temperature.
`Reaction.K_vant_hoff` freezes dH at its 298.15 K value, which is what the
familiar straight-line van 't Hoff plot assumes. Plotted against 1/T on a log
axis, the approximation is by construction a straight line; the exact result is
not, and the figure locates the temperature at which the two differ by a factor
of two.

Three reactions were computed before one was chosen (the numbers are printed
by the script and drawn in the two right-hand panels):

    ammonia synthesis   dH 298->1300 K:  -91.1 -> -111.2 kJ/mol
    water-gas shift                      -41.1 ->  -32.0 kJ/mol
    steam methane reforming             +205.8 -> +226.5 kJ/mol

Steam reforming carries the largest absolute change in dH and therefore the
largest departure, so it is the main panel; the other two are kept on the
figure so that the choice is visible rather than asserted.

DATA: `chemicals` via `reaction.from_chemicals` for every formation property
and every Cp correlation. Nothing typed in.

Run:  python3 f6_02.py
"""
from __future__ import annotations

import os
import sys
import warnings

import numpy as np
from scipy.optimize import brentq

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                   # noqa: E402

from vlekit.reaction import R, Reaction, from_chemicals            # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,        # noqa: E402
                          PAPER, RUST, SLATE, TEAL, use_style)

warnings.filterwarnings("ignore", category=RuntimeWarning)

OUT = os.environ.get("F6_OUT", "/home/claude/vle6/qmd/figures")
SLUG = "f6_02_vant_hoff_departure"

TLO, THI = 400.0, 1300.0


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def memoise(sp):
    """Cache H(T), S(T) — the Cp integral is the expensive part of every call."""
    cH, cS = {}, {}
    H0, S0 = sp.H, sp.S

    def H(t):
        k = round(float(t), 9)
        if k not in cH:
            cH[k] = H0(t)
        return cH[k]

    def S(t):
        k = round(float(t), 9)
        if k not in cS:
            cS[k] = S0(t)
        return cS[k]

    sp.H, sp.S = H, S
    sp.G = lambda t: H(t) - float(t) * S(t)
    return sp


# --------------------------------------------------------------------------
def make():
    names = ["methane", "water", "carbon monoxide", "carbon dioxide",
             "hydrogen", "nitrogen", "ammonia"]
    sp = {n: memoise(from_chemicals(n)) for n in names}
    smr = Reaction([sp["methane"], sp["water"], sp["carbon monoxide"],
                    sp["hydrogen"]], [-1, -1, 1, 3],
                   "CH$_4$ + H$_2$O $\\rightarrow$ CO + 3 H$_2$")
    wgs = Reaction([sp["carbon monoxide"], sp["water"],
                    sp["carbon dioxide"], sp["hydrogen"]], [-1, -1, 1, 1],
                   "CO + H$_2$O $\\rightarrow$ CO$_2$ + H$_2$")
    amm = Reaction([sp["nitrogen"], sp["hydrogen"], sp["ammonia"]],
                   [-1, -3, 2], "N$_2$ + 3 H$_2$ $\\rightarrow$ 2 NH$_3$")

    T = np.linspace(TLO, THI, 500)
    out = {}
    for key, rxn in (("smr", smr), ("wgs", wgs), ("amm", amm)):
        Ke = np.array([rxn.K(t) for t in T])
        Kv = np.array([rxn.K_vant_hoff(t) for t in T])
        dH = np.array([rxn.dH(t) for t in T])
        # temperature at which the two differ by a factor of two, either way
        cross = []
        for tgt in (np.log(2.0), -np.log(2.0)):
            f = lambda t, g=tgt: np.log(rxn.K_vant_hoff(t) / rxn.K(t)) - g
            if f(TLO) * f(THI) < 0:
                tc = brentq(f, TLO, THI, xtol=1e-8)
                cross.append((float(tc), float(rxn.K(tc)),
                              float(rxn.K_vant_hoff(tc)),
                              "over" if tgt > 0 else "under"))
        out[key] = dict(rxn=rxn, T=T, Ke=Ke, Kv=Kv, dH=dH, cross=cross,
                        dH298=rxn.dH(), dG298=rxn.dG(), K298=rxn.K(),
                        dHhi=rxn.dH(THI))
    return out


# --------------------------------------------------------------------------
def build(d):
    use_style()
    fig = plt.figure(figsize=(13.6, 7.6))
    gs = fig.add_gridspec(2, 2, width_ratios=[1.55, 1.0],
                          height_ratios=[0.88, 1.12],
                          left=0.062, right=0.985, top=0.800, bottom=0.135,
                          wspace=0.20, hspace=0.42)
    ax = fig.add_subplot(gs[:, 0])
    a1 = fig.add_subplot(gs[0, 1])
    a2 = fig.add_subplot(gs[1, 1])
    for a in (ax, a1, a2):
        a.grid(True, zorder=0)
        a.set_axisbelow(True)

    m = d["smr"]
    x = 1000.0 / m["T"]

    ax.semilogy(x, m["Ke"], "-", color=NAVY, lw=2.6, zorder=4,
                label="exact: $\\Delta H^\\circ(T)$ from integrated $C_p$\n"
                      "(`Reaction.K`)")
    ax.semilogy(x, m["Kv"], "--", color=AMBER, lw=2.6, zorder=3,
                label="van 't Hoff: $\\Delta H^\\circ$ frozen at 298 K\n"
                      "(`Reaction.K_vant_hoff`) — a straight line by\n"
                      "construction")

    tc, Ke_c, Kv_c, sense = m["cross"][0]
    xc = 1000.0 / tc

    ymin, ymax = float(np.min(m["Kv"])), float(np.max(m["Ke"]))
    ax.set_ylim(ymin * 1e-2, ymax * 1e4)
    ax.set_xlim(1000.0 / THI, 1000.0 / TLO)

    # the marker line only spans the gap it measures, and the guide only
    # reaches down from it: an axvline across the whole panel would run
    # through the legend
    ax.plot([xc, xc], [ymin * 1e-2, min(Ke_c, Kv_c)], ":", color=RUST, lw=1.5,
            zorder=2)
    ax.plot([xc, xc], [Ke_c, Kv_c], "-", color=RUST, lw=3.0, zorder=6)
    ax.plot([xc, xc], [Ke_c, Kv_c], "o", color=RUST, ms=8, mec=PAPER, mew=1.4,
            zorder=7)

    # the empty corner of a van 't Hoff plot is the one the line runs away
    # from: low 1/T and low K
    ax.annotate(
        f"the two differ by a factor of two at $T$ = {tc:.1f} K\n"
        f"$K$ exact = {Ke_c:.4g},   van 't Hoff = {Kv_c:.4g}\n"
        f"ratio {Kv_c / Ke_c:.3f}    (and "
        f"{m['Kv'][-1] / m['Ke'][-1]:.3f} by {THI:.0f} K)",
        xy=(xc, np.sqrt(Ke_c * Kv_c)), xytext=(0.025, 0.045),
        textcoords="axes fraction", ha="left", va="bottom",
        fontsize=11.5, color=RUST, zorder=9, linespacing=1.55,
        bbox=dict(boxstyle="round,pad=0.32", fc=PAPER, ec=RUST, lw=1.1,
                  alpha=0.96),
        arrowprops=dict(arrowstyle="-", color=RUST, lw=1.2, shrinkA=6,
                        shrinkB=6))

    ax.set_xlabel(r"$1000\,/\,T$   /   K$^{-1}$")
    ax.set_ylabel("$K$")
    ax.legend(loc="upper right", fontsize=11, labelspacing=0.9,
              bbox_to_anchor=(1.0, 1.0))
    ax.set_title("Steam methane reforming:  " + m["rxn"].name,
                 fontsize=13.5, pad=30, loc="left", x=0.0)

    sec = ax.secondary_xaxis("top", functions=(lambda v: 1000.0 / v,
                                               lambda v: 1000.0 / v))
    sec.set_xlabel("$T$ / K", fontsize=13, labelpad=5)
    sec.set_xticks([400, 500, 600, 700, 900, 1300])
    sec.tick_params(labelsize=11.5, colors=GRAPHITE)

    # ---------------- right column: why this reaction ---------------------
    cols = {"smr": NAVY, "wgs": TEAL, "amm": RUST}
    short = {"smr": "steam reforming", "wgs": "water-gas shift",
             "amm": "ammonia synthesis"}
    for k in ("smr", "wgs", "amm"):
        c = d[k]
        a1.plot(c["T"], c["dH"] / 1000.0, "-", color=cols[k], lw=2.2)
        a2.semilogy(c["T"], c["Kv"] / c["Ke"], "-", color=cols[k], lw=2.2)

    # Curves are labelled where they end rather than in a legend box: three
    # nearly horizontal lines and a legend anywhere inside the panel is on top
    # of one of them.
    a1.set_ylim(-275.0, 320.0)
    a1.set_xlim(TLO, THI)
    for k, va, dy in (("smr", "top", -12.0), ("wgs", "bottom", 14.0),
                      ("amm", "top", -14.0)):
        c = d[k]
        a1.text(THI - 15.0, c["dH"][-1] / 1000.0 + dy,
                f"{short[k]}\n{c['dH298'] / 1000:+.1f} $\\rightarrow$ "
                f"{c['dHhi'] / 1000:+.1f} kJ/mol",
                ha="right", va=va, fontsize=10.0, color=cols[k],
                linespacing=1.45, zorder=6,
                bbox=dict(boxstyle="round,pad=0.20", fc=PAPER, ec="none",
                          alpha=0.85))
    a1.set_xlabel("$T$ / K")
    a1.set_ylabel(r"$\Delta H^\circ(T)$ / kJ mol$^{-1}$")
    a1.set_title("Why this reaction: how far $\\Delta H^\\circ$ moves",
                 fontsize=12, pad=6, loc="left", x=0.0)

    a2.axhline(2.0, color=GRAPHITE, lw=1.2, ls="--")
    a2.axhline(0.5, color=GRAPHITE, lw=1.2, ls="--")
    a2.axhline(1.0, color=GRAPHITE, lw=1.0)
    a2.set_xlim(TLO, THI)
    a2.set_ylim(0.035, 160.0)
    a2.text(700.0, 2.0, "factor 2", fontsize=9.8, color=GRAPHITE,
            ha="center", va="center",
            bbox=dict(boxstyle="round,pad=0.15", fc=PAPER, ec="none",
                      alpha=0.9))
    a2.text(820.0, 0.5, "factor 1/2", fontsize=9.8, color=GRAPHITE,
            ha="center", va="center",
            bbox=dict(boxstyle="round,pad=0.15", fc=PAPER, ec="none",
                      alpha=0.9))
    for k, f in (("amm", 1.35), ("wgs", 1.16), ("smr", 1.30)):
        c = d[k]
        a2.text(THI - 15.0, c["Kv"][-1] / c["Ke"][-1] * f, short[k],
                ha="right", va="bottom", fontsize=10.5, color=cols[k],
                zorder=6,
                bbox=dict(boxstyle="round,pad=0.20", fc=PAPER, ec="none",
                          alpha=0.88))
    a2.set_xlabel("$T$ / K")
    a2.set_ylabel(r"$K_{\rm van\ 't\ Hoff}\,/\,K_{\rm exact}$")
    nick = {"smr": "reforming", "amm": "ammonia", "wgs": "shift"}
    cr = ",  ".join(
        (f"{nick[k]} {d[k]['cross'][0][0]:.0f} K" if d[k]["cross"]
         else f"{nick[k]} never") for k in ("smr", "amm", "wgs"))
    a2.set_title("Ratio of the two, with the factor-of-two lines\n"
                 f"factor 2 reached at:  {cr}",
                 fontsize=11.5, pad=6, loc="left", x=0.0)

    fig.text(0.5, 0.972,
             "The straight line of the van 't Hoff plot is an assumption "
             "about $\\Delta H^\\circ$, and it is worth a factor of two in $K$ "
             "well inside the range this course uses",
             ha="center", va="center", fontsize=15, color=INK)
    fig.text(0.5, 0.012,
             "Every $\\Delta H^\\circ_f$, $S^\\circ$ and $C_p$ correlation is "
             "read from the `chemicals` package by "
             "`reaction.from_chemicals`; no thermochemical number on this "
             "figure was typed in.  The exact curve integrates $C_p$ over "
             "temperature,\nthe van 't Hoff curve does not — that single "
             "difference is a factor of two in $K$ by "
             f"{d['smr']['cross'][0][0]:.0f} K for steam reforming, and a "
             "factor of "
             f"{d['smr']['Kv'][-1] / d['smr']['Ke'][-1]:.3g} by {THI:.0f} K.",
             ha="center", va="bottom", fontsize=10.5, color=SLATE,
             linespacing=1.55)
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = make()
    for k in ("smr", "wgs", "amm"):
        c = d[k]
        print(f"--- {c['rxn']!r}")
        print(f"    dH298 = {c['dH298'] / 1000:8.3f} kJ/mol   "
              f"dG298 = {c['dG298'] / 1000:8.3f} kJ/mol   "
              f"K298 = {c['K298']:.5g}")
        print(f"    dH({THI:.0f}) = {c['dHhi'] / 1000:8.3f} kJ/mol   "
              f"(change {100 * (c['dHhi'] - c['dH298']) / abs(c['dH298']):+.1f} %)")
        for tc, ke, kv, sense in c["cross"]:
            print(f"    factor of two at T = {tc:8.2f} K: K_exact = {ke:.5g}, "
                  f"K_vant_hoff = {kv:.5g}, ratio {kv / ke:.4f}")
        if not c["cross"]:
            print(f"    no factor-of-two crossing in {TLO:.0f}-{THI:.0f} K")
        print(f"    ratio at {TLO:.0f} K = {c['Kv'][0] / c['Ke'][0]:.4f}, "
              f"at {THI:.0f} K = {c['Kv'][-1] / c['Ke'][-1]:.4f}")
    for p in write(build(d), SLUG):
        print("wrote", p)
