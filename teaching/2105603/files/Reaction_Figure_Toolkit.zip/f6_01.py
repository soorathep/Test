#!/usr/bin/env python3
"""F6.1 — Gibbs energy against extent of reaction: the minimum is the answer.

2105603 Advanced Chemical Engineering Thermodynamics — Module 6
Soorathep Kheawhom, Chulalongkorn University

Ammonia synthesis, N2 + 3 H2 -> 2 NH3, from a stoichiometric feed at 700 K.
The curve is `vlekit.reaction.total_G` evaluated along the feasible window
returned by `extent_bounds`; the marker is `solve_extent`, which never looks at
G at all — it solves Ka(xi) = K(T). The two agree, and the size of the
disagreement is printed on the figure. That agreement is the whole content of
the equilibrium criterion: "sum nu_i mu_i = 0" and "G is stationary" are the
same statement.

Two pressures are drawn because K(T) is identical for both — it is defined at
the standard state, 1 bar — while the minimum moves a long way. Nothing about
the reaction changed; the composition did, through the (P/P0)^dnu factor in the
activity quotient. dnu = -2 here, so pressure pushes the minimum to the right.

The figure is drawn ideal-gas. F6.3 repeats the 300 bar point with
Peng-Robinson fugacity coefficients and shows how much that is worth.

DATA: every formation property comes from `chemicals` through
`reaction.from_chemicals`. Nothing is typed in. The run prints dH, dG and K so
they can be checked against a table.

Run:  python3 f6_01.py
"""
from __future__ import annotations

import os
import sys
import warnings

import numpy as np

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                   # noqa: E402

from vlekit.reaction import (R, Reaction, extent_bounds,          # noqa: E402
                             from_chemicals, moles_from_extent,
                             solve_extent, total_G)
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,       # noqa: E402
                          PAPER, RUST, SLATE, TEAL, use_style)

warnings.filterwarnings("ignore", category=RuntimeWarning)

OUT = os.environ.get("F6_OUT", "/home/claude/vle6/qmd/figures")
SLUG = "f6_01_gibbs_vs_extent"

T = 700.0                       # K
P_BAR = (100.0, 300.0)          # bar
N0 = np.array([1.0, 3.0, 0.0])  # mol N2, H2, NH3 — stoichiometric feed
BAR = 100.0                     # kPa per bar


# --------------------------------------------------------------------------
def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def memoise(sp):
    """Cache H(T) and S(T) per species.

    `Species.dH` integrates the Cp correlation with 200 Simpson points every
    time it is called, and `total_G` is called a few thousand times here. The
    cache changes no number — it is keyed on T and returns the same value the
    integrator would.
    """
    cH, cS = {}, {}
    H0, S0 = sp.H, sp.S

    def H(t):
        k = round(float(t), 9)
        if k not in cH:
            cH[k] = H0(t)
        return cH[k]

    def S(t):
        k = round(float(t), 9)
        if k not in cS:
            cS[k] = S0(t)
        return cS[k]

    sp.H, sp.S = H, S
    sp.G = lambda t: H(t) - float(t) * S(t)
    return sp


# --------------------------------------------------------------------------
def make():
    sp = [memoise(from_chemicals(n))
          for n in ("nitrogen", "hydrogen", "ammonia")]
    rxn = Reaction(sp, [-1.0, -3.0, 2.0], "ammonia synthesis")

    lo, hi = extent_bounds(N0, rxn.nu)
    eps = 1e-6 * (hi - lo)
    xi = np.linspace(lo + eps, hi - eps, 1200)

    curves = []
    for Pb in P_BAR:
        P = Pb * BAR
        G = np.array([total_G(sp, moles_from_extent(N0, rxn.nu, x), T, P)
                      for x in xi])
        dG = G - G[0]                       # relative to the unreacted feed
        i = int(np.argmin(G))
        # parabola through the three points around the grid minimum: the grid
        # is fine but the sub-grid position is what is being compared with
        # solve_extent, so it is worth getting right
        a, b, c = G[i - 1], G[i], G[i + 1]
        h = xi[1] - xi[0]
        xi_grid = xi[i] + 0.5 * h * (a - c) / (a - 2 * b + c)
        xi_solve = solve_extent(rxn, N0, T, P)
        n = moles_from_extent(N0, rxn.nu, xi_solve)
        curves.append(dict(Pbar=Pb, P=P, xi=xi, dG=dG,
                           xi_grid=float(xi_grid), xi_solve=xi_solve,
                           dG_min=float(np.interp(xi_solve, xi, dG)),
                           y=n / n.sum(), n=n))

    # sensitivity of the answer to the standard Gibbs energy itself
    sens = []
    for c in curves:
        base = c["xi_solve"]
        for d in (-1000.0, +1000.0):        # J/mol on dG0
            shifted = Reaction(sp, rxn.nu)
            shifted.dG = (lambda T_, d=d, r=rxn: r.dH(T_) - T_ * r.dS(T_) + d)
            shifted.lnK = (lambda T_, s=shifted: -s.dG(T_) / (R * T_))
            shifted.K = (lambda T_, s=shifted: float(np.exp(s.lnK(T_))))
            sens.append((c["Pbar"], d, solve_extent(shifted, N0, T, c["P"])
                         - base))

    return dict(sp=sp, rxn=rxn, curves=curves, bounds=(lo, hi), sens=sens)


# --------------------------------------------------------------------------
def build(d):
    use_style()
    fig, (ax, tx) = plt.subplots(
        1, 2, figsize=(13.6, 7.6),
        gridspec_kw=dict(width_ratios=[1.95, 1.0], wspace=0.04))
    fig.subplots_adjust(left=0.068, right=0.995, top=0.925, bottom=0.145)
    ax.grid(True, zorder=0)
    ax.set_axisbelow(True)
    tx.axis("off")

    colours = (NAVY, AMBER)
    ylo = min(float(np.min(c["dG"])) for c in d["curves"]) / 1000.0
    yhi = max(float(np.max(c["dG"])) for c in d["curves"]) / 1000.0
    span = yhi - ylo
    ax.set_ylim(ylo - 0.10 * span, yhi + 0.05 * span)
    ax.set_xlim(d["bounds"][0], d["bounds"][1])
    ybase = ylo - 0.10 * span

    for c, col in zip(d["curves"], colours):
        ax.plot(c["xi"], c["dG"] / 1000.0, "-", color=col, lw=2.6, zorder=3)
        ax.plot([c["xi_solve"], c["xi_solve"]],
                [ybase, c["dG_min"] / 1000.0], ":", color=col, lw=1.5,
                zorder=2)
        ax.plot([c["xi_solve"]], [c["dG_min"] / 1000.0], "o", color=col,
                ms=13, mec=PAPER, mew=1.8, zorder=6)
        # name each curve on the curve itself, in the empty upper-left wedge
        j = int(np.argmin(np.abs(c["xi"] - 0.86)))
        ax.text(c["xi"][j] - 0.012, c["dG"][j] / 1000.0 + 0.02 * span,
                f"{c['Pbar']:g} bar", color=col, fontsize=13.5,
                ha="right", va="bottom", zorder=7,
                bbox=dict(boxstyle="round,pad=0.20", fc=PAPER, ec="none",
                          alpha=0.85))
        ax.annotate(f"$\\xi^*$ = {c['xi_solve']:.4f}",
                    xy=(c["xi_solve"], ybase), xytext=(0, 6),
                    textcoords="offset points", ha="center", va="bottom",
                    fontsize=11.5, color=col, zorder=7,
                    bbox=dict(boxstyle="round,pad=0.18", fc=PAPER, ec="none",
                              alpha=0.88))

    ax.set_xlabel(r"extent of reaction  $\xi$ / mol")
    ax.set_ylabel(r"$G(\xi) - G(0)$ / kJ   (each curve relative to its own feed)")

    # ======================================================================
    # everything verbal lives in the right panel, so nothing can land on a
    # curve, a marker or a gridline
    # ======================================================================
    rxn = d["rxn"]
    s = {(p, dd): v for p, dd, v in d["sens"]}
    hi_p = P_BAR[1]

    rows = []
    rows.append((0.995, INK, MIST,
                 "N$_2$ + 3 H$_2$ $\\rightarrow$ 2 NH$_3$\n"
                 f"feed 1 : 3 : 0 mol,  $T$ = {T:g} K,  ideal gas\n"
                 f"$\\Delta H^\\circ_{{298}}$ = {rxn.dH() / 1000:.2f} kJ/mol   "
                 f"$\\Delta G^\\circ_{{298}}$ = {rxn.dG() / 1000:.2f} kJ/mol\n"
                 f"$\\Delta G^\\circ$({T:g} K) = {rxn.dG(T) / 1000:.2f} kJ/mol\n"
                 f"$K$({T:g} K) = {rxn.K(T):.4g}  —  the same at both pressures\n"
                 "feasible window from `extent_bounds`:\n"
                 f"$\\xi$ = {d['bounds'][0]:.3f} to {d['bounds'][1]:.3f} mol"))
    for c, col in zip(d["curves"], colours):
        rows.append((None, col, col,
                     f"$P$ = {c['Pbar']:g} bar\n"
                     f"$\\xi^*$ = {c['xi_solve']:.5f} mol   "
                     f"$y_{{\\rm NH_3}}$ = {c['y'][2]:.4f}\n"
                     f"$G(\\xi^*) - G(0)$ = {c['dG_min'] / 1000:.3f} kJ\n"
                     "$|\\xi^*$ from `solve_extent` $-\\ \\xi^*$ from "
                     "min $G|$\n"
                     f"      = {abs(c['xi_solve'] - c['xi_grid']):.1e} mol"))
    rows.append((None, GRAPHITE, SLATE,
                 "What is $\\Delta G^\\circ$ worth?\n"
                 "1 kJ/mol on $\\Delta G^\\circ$ is a factor "
                 f"{np.exp(1000.0 / (R * T)):.2f} in $K$ at {T:g} K\n"
                 f"and a factor {np.exp(1000.0 / (R * 298.15)):.2f} — 50 % — "
                 "at 298 K.\n"
                 f"It moves $\\xi^*$ at {hi_p:g} bar by "
                 f"{s[(hi_p, -1000.0)]:+.4f} / {s[(hi_p, +1000.0)]:+.4f} mol.\n"
                 "`chemicals` gives $\\Delta G^\\circ_{298}$ = "
                 f"{rxn.dG() / 1000:.2f} against the usual\n"
                 "literature $-32.8$ kJ/mol: 0.75 kJ/mol, 30 % in $K$."))

    y = 0.995
    for _, fg, ec, txt in rows:
        t = tx.text(0.0, y, txt, transform=tx.transAxes, ha="left", va="top",
                    fontsize=11.0, color=fg, linespacing=1.60,
                    bbox=dict(boxstyle="round,pad=0.34", fc=PAPER, ec=ec,
                              lw=1.1, alpha=0.96))
        fig.canvas.draw()
        bb = t.get_window_extent().transformed(tx.transAxes.inverted())
        y = bb.y0 - 0.030

    ax.set_title("The equilibrium composition is where $G$ is a minimum — "
                 "and pressure moves it even though $K$ does not",
                 fontsize=14.5, pad=8, loc="left", x=-0.01)
    fig.text(0.37, 0.012,
             "Formation properties from `chemicals` via "
             "`reaction.from_chemicals`; nothing typed in.\n"
             "Curves are `total_G`; markers are `solve_extent`, which solves "
             "$K_a(\\xi) = K(T)$ and never evaluates $G$.",
             ha="center", va="bottom", fontsize=10.5, color=SLATE,
             linespacing=1.55)
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = make()
    rxn = d["rxn"]
    print(f"reaction: {rxn!r}")
    print(f"  element balance {rxn.element_balance() or 'closed'}")
    print(f"  dH298 = {rxn.dH() / 1000:.4f} kJ/mol   "
          f"dG298 = {rxn.dG() / 1000:.4f} kJ/mol   K298 = {rxn.K():.5g}")
    print(f"  dH({T:g}) = {rxn.dH(T) / 1000:.4f} kJ/mol   "
          f"dG({T:g}) = {rxn.dG(T) / 1000:.4f} kJ/mol   "
          f"K({T:g}) = {rxn.K(T):.5g}")
    print(f"  extent window {d['bounds'][0]:.6f} to {d['bounds'][1]:.6f} mol")
    for c in d["curves"]:
        print(f"P = {c['Pbar']:g} bar: xi* = {c['xi_solve']:.7f} (solve_extent), "
              f"{c['xi_grid']:.7f} (minimum of total_G), "
              f"difference {abs(c['xi_solve'] - c['xi_grid']):.2e}")
        print(f"    n = {np.round(c['n'], 6)}  y = {np.round(c['y'], 6)}  "
              f"G(xi*) - G(0) = {c['dG_min'] / 1000:.4f} kJ")
    for p, dd, v in d["sens"]:
        print(f"sensitivity: {dd / 1000:+.0f} kJ/mol on dG0 at {p:g} bar "
              f"moves xi* by {v:+.5f} mol")
    print(f"factor in K per kJ/mol of dG0: {np.exp(1000 / (R * T)):.4f} at "
          f"{T:g} K, {np.exp(1000 / (R * 298.15)):.4f} at 298.15 K")
    for p in write(build(d), SLUG):
        print("wrote", p)
