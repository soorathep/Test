#!/usr/bin/env python3
"""F6.4 — Element potentials: a species carries no information beyond its atoms.

2105603 Advanced Chemical Engineering Thermodynamics — Module 6
Soorathep Kheawhom, Chulalongkorn University

At the constrained minimum of G the Lagrange multipliers of the atom balances
satisfy, for every species at once,

    mu_i = sum_k a_ki lambda_k

Seven species, four elements: seven chemical potentials are reproduced by four
numbers. That is the claim, and the figure is the test — mu_i on one axis, the
reconstruction sum_k a_ki lambda_k on the other, and the 45 degree line.

The system is C/H/N/O reforming: CH4 + 2 H2O + N2 at 1 bar, equilibrated over
CH4, H2O, H2, CO, CO2, N2, NH3 by `reaction.gibbs_minimise`. The multipliers
come from `reaction.element_potentials` and the residual from
`reaction.element_potential_residual` — neither of which re-solves anything.
They are a check on the converged answer, which is exactly what makes them
useful.

A NOTE ON WHAT WAS LEFT OUT. O2 and NO were in an earlier version of this
species list and were removed. At this feed their equilibrium mole fractions
are of order 1e-25 and 1e-8; the SLSQP minimiser in `gibbs_minimise` cannot
resolve ln(n) for a species that contributes nothing to G, and the identity
above then fails by tens of kJ/mol for those two species while holding for the
rest. That is a property of the solver, not of thermodynamics, and it is
reported here rather than hidden: the identity is exact at the true minimum,
and how nearly it holds is a measure of how nearly the minimum was found.

Run:  python3 f6_04.py
"""
from __future__ import annotations

import os
import sys
import warnings

import numpy as np

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                   # noqa: E402

from vlekit.reaction import (chemical_potentials, element_matrix,  # noqa: E402
                             element_potential_residual,
                             element_potentials, from_chemicals,
                             gibbs_minimise)
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,       # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, use_style)

warnings.filterwarnings("ignore", category=RuntimeWarning)

OUT = os.environ.get("F6_OUT", "/home/claude/vle6/qmd/figures")
SLUG = "f6_04_element_potentials"

NAMES = ["methane", "water", "hydrogen", "carbon monoxide",
         "carbon dioxide", "nitrogen", "ammonia"]
LABEL = {"methane": "CH$_4$", "water": "H$_2$O", "hydrogen": "H$_2$",
         "carbon monoxide": "CO", "carbon dioxide": "CO$_2$",
         "nitrogen": "N$_2$", "ammonia": "NH$_3$"}
N0 = np.array([1.0, 2.0, 0.0, 0.0, 0.0, 1.0, 0.0])
T_MAIN = 1100.0
P = 100.0                       # kPa = 1 bar
T_SCAN = np.arange(700.0, 1301.0, 50.0)


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def memoise(sp):
    cH, cS = {}, {}
    H0, S0 = sp.H, sp.S

    def H(t):
        k = round(float(t), 9)
        if k not in cH:
            cH[k] = H0(t)
        return cH[k]

    def S(t):
        k = round(float(t), 9)
        if k not in cS:
            cS[k] = S0(t)
        return cS[k]

    sp.H, sp.S = H, S
    sp.G = lambda t: H(t) - float(t) * S(t)
    return sp


# --------------------------------------------------------------------------
def solve(sp, T, restarts=6, seed=0):
    A, els = element_matrix(sp)
    r = gibbs_minimise(sp, N0, T, P, restarts=restarts, seed=seed)
    mu = chemical_potentials(sp, r["n"], T, P)
    lam = element_potentials(sp, r["n"], T, P, A)
    pred = A.T @ lam
    return dict(T=T, A=A, els=els, res=r, mu=mu, lam=lam, pred=pred,
                delta=mu - pred,
                identity=element_potential_residual(sp, r["n"], T, P))


def make():
    sp = [memoise(from_chemicals(n)) for n in NAMES]
    main = solve(sp, T_MAIN)
    scan = [solve(sp, t) for t in T_SCAN]
    return dict(sp=sp, main=main, scan=scan)


# --------------------------------------------------------------------------
def _declutter(x, gap):
    """Push a sorted sequence apart until every neighbour is `gap` apart.

    Label positions computed from the data rather than nudged by hand: the
    species that sit closest together in chemical potential are exactly the
    ones whose labels would otherwise be on top of one another.
    """
    x = np.array(x, dtype=float)
    order = np.argsort(x)
    y = x[order].copy()
    for _ in range(400):
        moved = False
        for i in range(len(y) - 1):
            d = y[i + 1] - y[i]
            if d < gap:
                shift = 0.5 * (gap - d)
                y[i] -= shift
                y[i + 1] += shift
                moved = True
        if not moved:
            break
    out = np.empty_like(y)
    out[order] = y
    return out


def build(d):
    use_style()
    fig = plt.figure(figsize=(13.8, 7.8))
    gs = fig.add_gridspec(2, 2, width_ratios=[1.5, 1.0],
                          height_ratios=[1.0, 1.0],
                          left=0.062, right=0.985, top=0.855, bottom=0.195,
                          wspace=0.24, hspace=0.48)
    ax = fig.add_subplot(gs[:, 0])
    a1 = fig.add_subplot(gs[0, 1])
    a2 = fig.add_subplot(gs[1, 1])
    for a in (ax, a1, a2):
        a.grid(True, zorder=0)
        a.set_axisbelow(True)

    m = d["main"]
    mu = m["mu"] / 1000.0
    pr = m["pred"] / 1000.0
    lo = min(mu.min(), pr.min())
    hi = max(mu.max(), pr.max())
    pad = 0.16 * (hi - lo)
    ax.plot([lo - pad, hi + pad], [lo - pad, hi + pad], "-", color=GRAPHITE,
            lw=1.6, zorder=2,
            label="45$^\\circ$ line:  $\\mu_i = \\sum_k a_{ki}\\lambda_k$")
    ax.plot(pr, mu, "o", color=NAVY, ms=13, mfc=SKYBLUE, mew=1.8, zorder=5,
            label=f"seven species, {m['T']:g} K, 1 bar")
    ax.set_xlim(lo - pad, hi + pad)
    ax.set_ylim(lo - pad, hi + pad)

    # Every label goes BELOW-RIGHT of the 45 degree line and the whole
    # upper-left triangle is left free for the text. Positions along the line
    # are decluttered from the data, because the species that sit closest in
    # chemical potential are exactly the ones whose labels would collide.
    span = (hi + pad) - (lo - pad)
    rail = _declutter(pr, 0.075 * span)
    off = 0.055 * span
    for i, s_ in enumerate(d["sp"]):
        ax.annotate(LABEL[NAMES[i]],
                    xy=(pr[i], mu[i]),
                    xytext=(rail[i] + off, rail[i] - off),
                    ha="left", va="top", fontsize=13, color=NAVY,
                    zorder=7,
                    bbox=dict(boxstyle="round,pad=0.20", fc=PAPER, ec="none",
                              alpha=0.88),
                    arrowprops=dict(arrowstyle="-", color=SLATE, lw=0.9,
                                    shrinkA=2, shrinkB=7))

    ax.set_xlabel(r"$\sum_k a_{ki}\,\lambda_k$  /  kJ mol$^{-1}$"
                  "     (four numbers)")
    ax.set_ylabel(r"$\mu_i$  /  kJ mol$^{-1}$     (seven numbers)")
    ax.legend(loc="upper left", fontsize=11.5,
              bbox_to_anchor=(0.025, 0.605))

    lam_txt = ("    $\\lambda_{\\rm C}$ = %8.3f      $\\lambda_{\\rm H}$ = %8.3f\n"
               "    $\\lambda_{\\rm N}$ = %8.3f      $\\lambda_{\\rm O}$ = %8.3f"
               % tuple(v / 1000 for v in m["lam"]))
    ax.text(0.025, 0.975,
            f"CH$_4$ + 2 H$_2$O + N$_2$,  {m['T']:g} K,  1 bar,  ideal gas\n"
            "7 species, 4 elements (C, H, N, O)\n"
            "element potentials, kJ per mol of atom "
            "(`element_potentials`):\n"
            + lam_txt + "\n"
            f"max $|\\mu_i - \\sum_k a_{{ki}}\\lambda_k|$ = "
            f"{m['identity']:.3g} J/mol, against $|\\mu_i|$ of order\n"
            f"{np.abs(m['mu']).mean() / 1000:.0f} kJ/mol — "
            f"{m['identity'] / np.abs(m['mu']).mean():.1e} of it. Atom balance "
            f"closed to {m['res']['residual']:.0e} mol.",
            transform=ax.transAxes, ha="left", va="top", fontsize=11,
            color=INK, linespacing=1.6, zorder=9,
            bbox=dict(boxstyle="round,pad=0.34", fc=PAPER, ec=MIST, lw=1.0,
                      alpha=0.96))

    # ------------------------------------------------- residual per species
    idx = np.arange(len(NAMES))
    a1.bar(idx, m["delta"], color=RUST, width=0.62, zorder=3)
    a1.axhline(0.0, color=GRAPHITE, lw=1.0)
    a1.set_xticks(idx)
    a1.set_xticklabels([LABEL[n] for n in NAMES], fontsize=12)
    a1.set_ylabel(r"$\mu_i - \sum_k a_{ki}\lambda_k$  /  J mol$^{-1}$")
    a1.set_title(f"The residual, species by species, at {m['T']:g} K",
                 fontsize=12, pad=6, loc="left", x=0.0)
    lim = 1.55 * float(np.max(np.abs(m["delta"])))
    a1.set_ylim(-lim, lim)
    a1.text(0.98, 0.95,
            "note the unit: J/mol, not kJ/mol",
            transform=a1.transAxes, ha="right", va="top", fontsize=10,
            color=GRAPHITE, zorder=6,
            bbox=dict(boxstyle="round,pad=0.20", fc=PAPER, ec="none",
                      alpha=0.9))

    # ------------------------------------------------- residual vs T
    Ts = np.array([s["T"] for s in d["scan"]])
    rs = np.array([s["identity"] for s in d["scan"]])
    ok = np.array([s["res"]["success"] for s in d["scan"]])
    a2.semilogy(Ts, rs, "-", color=NAVY, lw=2.2, zorder=3)
    a2.plot(Ts[ok], rs[ok], "o", color=NAVY, ms=8, mfc=SKYBLUE, mew=1.5,
            zorder=5, label="SLSQP reported success")
    if (~ok).any():
        a2.plot(Ts[~ok], rs[~ok], "s", color=RUST, ms=9, mfc=PAPER, mew=2.0,
                zorder=6, label="SLSQP reported failure (shown, not dropped)")
    a2.set_xlabel("$T$ / K")
    a2.set_ylabel(r"max $|\mu_i - \sum_k a_{ki}\lambda_k|$ / J mol$^{-1}$")
    a2.set_title("The same check at every temperature",
                 fontsize=12, pad=6, loc="left", x=0.0)
    a2.legend(loc="upper left", fontsize=10)
    a2.set_ylim(rs.min() * 0.2, rs.max() * 60.0)

    fig.text(0.5, 0.965,
             "Seven chemical potentials, four numbers: at equilibrium a "
             "species carries no information beyond the atoms it is made of",
             ha="center", va="center", fontsize=15, color=INK)
    fig.text(0.5, 0.012,
             "Formation properties from `chemicals`. The minimisation is "
             "`reaction.gibbs_minimise` (SLSQP on $\\ln n$ subject to "
             "$A\\,n = b$); the multipliers are the least-squares solution of "
             "$A^{\\rm T}\\lambda = \\mu$ and are never used to obtain the "
             "composition, so the residual\nabove is an independent check. "
             "O$_2$ and NO were removed from the species list: their "
             "equilibrium mole fractions here are of order $10^{-25}$ and "
             "$10^{-8}$, and the minimiser cannot resolve $\\ln n$ for a "
             "species that contributes nothing to $G$.\n"
             f"Equilibrium composition at {m['T']:g} K, 1 bar:  "
             + ",   ".join(f"{LABEL[n]} {m['res']['y'][i]:.5g}"
                           for i, n in enumerate(NAMES)) + ".",
             ha="center", va="bottom", fontsize=10.2, color=SLATE,
             linespacing=1.6)
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = make()
    m = d["main"]
    print(f"feed {N0} mol of {NAMES}")
    print(f"T = {m['T']:g} K, P = {P:g} kPa")
    print(f"elements {m['els']}")
    print("A =\n", m["A"].astype(int))
    print(f"G = {m['res']['G']:.8e} J, atom balance residual "
          f"{m['res']['residual']:.3e}, success = {m['res']['success']}")
    for e, v in zip(m["els"], m["lam"]):
        print(f"  lambda_{e:<6s} = {v / 1000:12.5f} kJ per mol of atom")
    print(f"{'species':<20s}{'y':>13s}{'mu kJ/mol':>13s}"
          f"{'sum a_ki lam':>14s}{'delta J/mol':>14s}")
    for i, n in enumerate(NAMES):
        print(f"{n:<20s}{m['res']['y'][i]:13.5e}{m['mu'][i] / 1000:13.4f}"
              f"{m['pred'][i] / 1000:14.4f}{m['delta'][i]:14.4e}")
    print(f"max |mu - A^T lambda| = {m['identity']:.4e} J/mol "
          f"({m['identity'] / np.abs(m['mu']).mean():.2e} of the mean |mu|)")
    print("temperature scan:")
    for s in d["scan"]:
        print(f"  T = {s['T']:6.1f} K   identity residual "
              f"{s['identity']:.4e} J/mol   atom balance "
              f"{s['res']['residual']:.2e}   success = {s['res']['success']}")
    for p in write(build(d), SLUG):
        print("wrote", p)
