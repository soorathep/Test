#!/usr/bin/env python3
"""F6.3 — Ammonia synthesis to 600 bar: what the fugacity coefficient is worth.

2105603 Advanced Chemical Engineering Thermodynamics — Module 6
Soorathep Kheawhom, Chulalongkorn University

    Ka = K_phi * K_y * (P/P0)^dnu

Module 6 usually stops at K_y (P/P0)^dnu and calls K_phi = 1. Industrial
ammonia synthesis runs at 150-300 bar, which is exactly where that costs
something. This figure computes both answers with the same code path: the
`phi` argument of `vlekit.reaction.equilibrium_composition` is either None
(ideal) or a callable returning phi-hat_i from `vlekit.cubic.PengRobinson`,
which is the same Peng-Robinson object Module 5 used for phase envelopes. One
equation of state, two different constraints — that is the point.

BINARY INTERACTION PARAMETERS
    k_ij = 0 for all three pairs (N2/H2, N2/NH3, H2/NH3). ASSUMED, NOT FITTED:
    no binary VLE data were regressed for this figure and none was found in a
    citable form. The whole calculation is repeated with k_ij = -0.05 and
    +0.05 on every pair and the difference is quoted on the figure. It comes
    out below 0.01 percentage points of conversion at 300 bar, because K_phi
    is a ratio of fugacity coefficients and the k_ij contributions to it very
    nearly cancel — which is why the sensitivity is reported as a number
    rather than drawn as a band nobody could see. Tc, Pc and omega come from
    the `chemicals` package.

    Hydrogen is a quantum fluid with Tc = 33.1 K; at 700 K it sits at
    Tr = 21 and the Peng-Robinson alpha function is far outside the range its
    m(omega) polynomial was fitted in. This is stated on the figure. The usual
    industrial fix — Newton's effective critical constants for H2 — is a
    different assumption, not a smaller one, so it is not used here.

Run:  python3 f6_03.py
"""
from __future__ import annotations

import os
import sys
import warnings

import numpy as np

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                   # noqa: E402

from vlekit.cubic import PengRobinson                             # noqa: E402
from vlekit.data import Component                                 # noqa: E402
from vlekit.reaction import (R, Reaction, equilibrium_composition,  # noqa: E402
                             from_chemicals)
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,       # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, use_style)

warnings.filterwarnings("ignore", category=RuntimeWarning)

OUT = os.environ.get("F6_OUT", "/home/claude/vle6/qmd/figures")
SLUG = "f6_03_ammonia_kphi"

T = 700.0
N0 = np.array([1.0, 3.0, 0.0])
BAR = 100.0                       # kPa per bar
P_BAR = np.geomspace(1.0, 600.0, 130)
P_MARK = (150.0, 300.0)           # the industrial window
KIJ_BAND = 0.05                   # the assumed-parameter sensitivity
NAMES = ("nitrogen", "hydrogen", "ammonia")


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def memoise(sp):
    cH, cS = {}, {}
    H0, S0 = sp.H, sp.S

    def H(t):
        k = round(float(t), 9)
        if k not in cH:
            cH[k] = H0(t)
        return cH[k]

    def S(t):
        k = round(float(t), 9)
        if k not in cS:
            cS[k] = S0(t)
        return cS[k]

    sp.H, sp.S = H, S
    sp.G = lambda t: H(t) - float(t) * S(t)
    return sp


def pr_component(name):
    """A `data.Component` carrying only what Peng-Robinson needs.

    Tc, Pc and omega are read from `chemicals`; the Antoine constants are left
    NaN because the cubic route never asks for a vapour pressure here, and a
    placeholder correlation would be a number nobody checked.
    """
    from chemicals.acentric import omega as _omega
    from chemicals.critical import Pc as _Pc, Tc as _Tc
    from chemicals.identifiers import CAS_from_any

    cas = CAS_from_any(name)
    return Component(name=name, A=np.nan, B=np.nan, C=np.nan,
                     Tc=float(_Tc(cas)), Pc=float(_Pc(cas)) / 1e3,
                     omega=float(_omega(cas)),
                     source="chemicals: critical.Tc, critical.Pc, "
                            "acentric.omega")


# --------------------------------------------------------------------------
def make():
    sp = [memoise(from_chemicals(n)) for n in NAMES]
    rxn = Reaction(sp, [-1.0, -3.0, 2.0], "ammonia synthesis")
    comps = [pr_component(n) for n in NAMES]

    def mixture(k):
        kij = np.full((3, 3), float(k))
        np.fill_diagonal(kij, 0.0)
        return PengRobinson(comps, kij=kij)

    def phi_of(mix):
        def phi(y, T_, P_):
            lnphi, _ = mix.ln_phi(T_, P_, y, phase="vapour")
            return np.exp(lnphi)
        return phi

    mix0 = mixture(0.0)
    phi0 = phi_of(mix0)

    ideal, real = [], []
    Kphi, phis, Zs = [], [], []
    for Pb in P_BAR:
        P = Pb * BAR
        a = equilibrium_composition(rxn, N0, T, P)
        b = equilibrium_composition(rxn, N0, T, P, phi=phi0)
        ideal.append(a)
        real.append(b)
        lnphi, Z = mix0.ln_phi(T, P, b["y"], phase="vapour")
        f = np.exp(lnphi)
        phis.append(f)
        Zs.append(Z)
        Kphi.append(float(np.prod(f ** rxn.nu)))

    band = {}
    for k in (-KIJ_BAND, +KIJ_BAND):
        ph = phi_of(mixture(k))
        band[k] = np.array([equilibrium_composition(rxn, N0, T, Pb * BAR,
                                                    phi=ph)["xi"]
                            for Pb in P_BAR])

    xi_i = np.array([a["xi"] for a in ideal])
    xi_r = np.array([b["xi"] for b in real])
    y_i = np.array([a["y"] for a in ideal])
    y_r = np.array([b["y"] for b in real])

    marks = []
    for Pm in P_MARK:
        j = int(np.argmin(np.abs(P_BAR - Pm)))
        marks.append(dict(P=float(P_BAR[j]), j=j, xi_i=xi_i[j], xi_r=xi_r[j],
                          y_i=y_i[j, 2], y_r=y_r[j, 2], Kphi=Kphi[j],
                          phi=phis[j], Z=Zs[j],
                          lo=band[-KIJ_BAND][j], hi=band[+KIJ_BAND][j]))

    # what a 1 kJ/mol error in dG0 would do at 300 bar, for comparison
    sens = {}
    for dd in (-1000.0, +1000.0):
        shifted = Reaction(sp, rxn.nu)
        shifted.dG = lambda T_, d=dd, r=rxn: r.dH(T_) - T_ * r.dS(T_) + d
        shifted.lnK = lambda T_, s=shifted: -s.dG(T_) / (R * T_)
        shifted.K = lambda T_, s=shifted: float(np.exp(s.lnK(T_)))
        sens[dd] = equilibrium_composition(shifted, N0, T, 300.0 * BAR,
                                           phi=phi0)["xi"]

    return dict(rxn=rxn, mix=mix0, xi_i=xi_i, xi_r=xi_r, y_i=y_i, y_r=y_r,
                Kphi=np.array(Kphi), phis=np.array(phis), Z=np.array(Zs),
                band=band, marks=marks, sens=sens, comps=comps)


# --------------------------------------------------------------------------
def build(d):
    use_style()
    fig = plt.figure(figsize=(13.8, 7.8))
    gs = fig.add_gridspec(2, 2, width_ratios=[1.62, 1.0],
                          height_ratios=[1.0, 1.0],
                          left=0.060, right=0.985, top=0.845, bottom=0.145,
                          wspace=0.22, hspace=0.42)
    ax = fig.add_subplot(gs[:, 0])
    a1 = fig.add_subplot(gs[0, 1])
    a2 = fig.add_subplot(gs[1, 1])
    for a in (ax, a1, a2):
        a.grid(True, zorder=0)
        a.set_axisbelow(True)

    xi_i, xi_r = 100.0 * d["xi_i"], 100.0 * d["xi_r"]
    ax.fill_between(P_BAR, xi_i, xi_r, color=AMBER, alpha=0.22, zorder=2,
                    label="the correction: what $K_\\phi$ is worth")
    ax.semilogx(P_BAR, xi_i, "--", color=NAVY, lw=2.6, zorder=5,
                label="ideal gas: $K_\\phi = 1$")
    ax.semilogx(P_BAR, xi_r, "-", color=RUST, lw=2.8, zorder=6,
                label="Peng-Robinson $\\hat\\phi_i$, $k_{ij}=0$ (assumed)")

    ax.set_xlim(P_BAR[0], P_BAR[-1])
    ax.set_ylim(0.0, 100.0)
    ax.set_xlabel("$P$ / bar    (log scale)")
    ax.set_ylabel("conversion of N$_2$,  $100\\,\\xi^*/\\xi_{\\max}$  /  %")
    # the empty quarter of this panel is low-left-to-right under the curves,
    # so the legend goes there and every text block goes above them
    ax.legend(loc="upper left", fontsize=11.2, labelspacing=0.7,
              bbox_to_anchor=(0.015, 0.66))
    ax.set_title(f"N$_2$ + 3 H$_2$ $\\rightarrow$ 2 NH$_3$ at {T:g} K from a "
                 "1 : 3 feed", fontsize=13.5, pad=8, loc="left", x=0.0)

    for m, col in zip(d["marks"], (TEAL, RUST)):
        ax.plot([m["P"], m["P"]], [100 * m["xi_i"], 100 * m["xi_r"]], "-",
                color=col, lw=3.2, zorder=7)
        ax.plot([m["P"], m["P"]], [100 * m["xi_i"], 100 * m["xi_r"]], "o",
                color=col, ms=8, mec=PAPER, mew=1.4, zorder=8)
        ax.text(m["P"], 100 * m["xi_r"] + 3.0,
                f"{100 * (m['xi_r'] - m['xi_i']):+.2f} pts",
                ha="center", va="bottom", fontsize=11, color=col, zorder=9,
                bbox=dict(boxstyle="round,pad=0.20", fc=PAPER, ec="none",
                          alpha=0.88))

    m0, m1 = d["marks"]
    kw = max(abs(m1["hi"] - m1["lo"]), abs(m0["hi"] - m0["lo"])) * 100.0
    ax.annotate(
        f"at {m1['P']:.0f} bar\n"
        f"    ideal   {100 * m1['xi_i']:.2f} %   "
        f"($y_{{\\rm NH_3}}$ = {m1['y_i']:.4f})\n"
        f"    with $\\hat\\phi$  {100 * m1['xi_r']:.2f} %   "
        f"($y_{{\\rm NH_3}}$ = {m1['y_r']:.4f})\n"
        f"    gap {100 * (m1['xi_r'] - m1['xi_i']):+.2f} points,  "
        f"$K_\\phi$ = {m1['Kphi']:.4f},  $Z$ = {m1['Z']:.4f}\n"
        f"at {m0['P']:.0f} bar   gap "
        f"{100 * (m0['xi_r'] - m0['xi_i']):+.2f} points,  "
        f"$K_\\phi$ = {m0['Kphi']:.4f}\n"
        f"$k_{{ij}} = \\pm{KIJ_BAND:g}$ on every pair moves these by "
        f"< {kw:.3f} points:\n"
        f"    $K_\\phi$ is a ratio and the $k_{{ij}}$ terms nearly cancel",
        xy=(m1["P"], 100 * 0.5 * (m1["xi_i"] + m1["xi_r"])),
        xytext=(0.015, 0.985), textcoords="axes fraction",
        ha="left", va="top", fontsize=11.5, color=RUST, zorder=10,
        linespacing=1.55,
        bbox=dict(boxstyle="round,pad=0.34", fc=PAPER, ec=RUST, lw=1.1,
                  alpha=0.96),
        arrowprops=dict(arrowstyle="-", color=RUST, lw=1.2, shrinkA=8,
                        shrinkB=10))

    # ------------------------------------------------------ K_phi and phi_i
    a1.semilogx(P_BAR, d["Kphi"], "-", color=RUST, lw=2.4)
    a1.axhline(1.0, color=GRAPHITE, lw=1.1, ls="--")
    a1.set_xlim(P_BAR[0], P_BAR[-1])
    a1.set_xlabel("$P$ / bar")
    a1.set_ylabel(r"$K_\phi = \prod_i \hat\phi_i^{\,\nu_i}$")
    a1.text(1.25, 0.42, "$K_\\phi = 1$ (dashed)\nis the ideal-gas\nassumption",
            fontsize=10, color=GRAPHITE, ha="left", va="bottom",
            linespacing=1.45,
            bbox=dict(boxstyle="round,pad=0.18", fc=PAPER, ec="none",
                      alpha=0.85))
    for m in d["marks"]:
        a1.plot([m["P"]], [m["Kphi"]], "o", color=RUST, ms=7, mec=PAPER,
                mew=1.3, zorder=6)
    a1.set_title("The whole correction, in one number",
                 fontsize=12, pad=6, loc="left", x=0.0)

    # the three phi curves converge at low P, so each label is pushed off its
    # own curve in the direction that curve is heading
    for i, (nm, col, va, dy) in enumerate(
            zip(("N$_2$", "H$_2$", "NH$_3$"), (NAVY, TEAL, AMBER),
                ("bottom", "top", "top"), (0.012, -0.012, -0.010))):
        a2.semilogx(P_BAR, d["phis"][:, i], "-", color=col, lw=2.4)
        xl = 400.0
        a2.text(xl, float(np.interp(xl, P_BAR, d["phis"][:, i])) + dy, nm,
                ha="right", va=va, fontsize=11.5, color=col, zorder=6,
                bbox=dict(boxstyle="round,pad=0.16", fc=PAPER, ec="none",
                          alpha=0.88))
    a2.axhline(1.0, color=GRAPHITE, lw=1.1, ls="--")
    a2.set_xlim(P_BAR[0], P_BAR[-1])
    a2.set_xlabel("$P$ / bar")
    a2.set_ylabel(r"$\hat\phi_i$  at the equilibrium $y$")
    a2.set_title("Peng-Robinson fugacity coefficients "
                 "(`cubic.PengRobinson.ln_phi`)",
                 fontsize=12, pad=6, loc="left", x=0.0)

    fig.text(0.5, 0.965,
             "At 300 bar the fugacity coefficient is not a refinement: it is "
             f"{100 * (d['marks'][-1]['xi_r'] - d['marks'][-1]['xi_i']):+.1f} "
             "percentage points of conversion",
             ha="center", va="center", fontsize=15, color=INK)

    s = d["sens"]
    x300 = d["marks"][-1]["xi_r"]
    fig.text(0.5, 0.012,
             f"ASSUMED, NOT FITTED: $k_{{ij}} = 0$ for N$_2$/H$_2$, "
             "N$_2$/NH$_3$ and H$_2$/NH$_3$. No binary VLE data were "
             "regressed here, and none was found in a citable form. "
             f"Recomputing with $k_{{ij}} = \\pm{KIJ_BAND:g}$ on every pair "
             "changes nothing visible. $T_c$, $P_c$, $\\omega$ from "
             "`chemicals`.\n"
             "Hydrogen sits at $T_r$ = "
             f"{T / d['comps'][1].Tc:.0f} here, far outside the range the "
             "Peng-Robinson $m(\\omega)$ polynomial was fitted in — a known "
             "weakness, stated rather than corrected. For scale: "
             f"$\\pm$1 kJ/mol on $\\Delta G^\\circ$ moves the 300 bar answer "
             f"to {100 * s[-1000.0]:.1f} / {100 * s[+1000.0]:.1f} % "
             f"against {100 * x300:.1f} %.",
             ha="center", va="bottom", fontsize=10.2, color=SLATE,
             linespacing=1.6)
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = make()
    rxn = d["rxn"]
    print(f"{rxn!r}   T = {T:g} K, feed {N0}")
    print(f"  dG({T:g}) = {rxn.dG(T) / 1000:.4f} kJ/mol   K = {rxn.K(T):.6g}")
    print(f"  {d['mix']!r}, k_ij = 0 (ASSUMED)")
    for c in d["comps"]:
        print(f"    {c.name:10s} Tc = {c.Tc:8.3f} K  Pc = {c.Pc / 100:8.3f} bar"
              f"  omega = {c.omega:+.4f}   [{c.source}]")
    print("   P/bar   X_ideal    X_phi     gap     K_phi      Z      "
          "phi_N2  phi_H2  phi_NH3")
    for j, Pb in enumerate(P_BAR):
        if Pb < 1.001 or abs(Pb - 10) < 0.4 or abs(Pb - 50) < 1.2 \
                or abs(Pb - 100) < 2.5 or abs(Pb - 150) < 3 \
                or abs(Pb - 200) < 4 or abs(Pb - 300) < 6 \
                or abs(Pb - 400) < 8 or Pb > 599:
            f = d["phis"][j]
            print(f"  {Pb:7.1f}  {100 * d['xi_i'][j]:7.3f}  "
                  f"{100 * d['xi_r'][j]:7.3f}  "
                  f"{100 * (d['xi_r'][j] - d['xi_i'][j]):+7.3f}  "
                  f"{d['Kphi'][j]:8.4f}  {d['Z'][j]:6.4f}  "
                  f"{f[0]:6.4f}  {f[1]:6.4f}  {f[2]:6.4f}")
    for m in d["marks"]:
        print(f"mark {m['P']:.0f} bar: ideal {100 * m['xi_i']:.3f} %, "
              f"phi {100 * m['xi_r']:.3f} %, gap "
              f"{100 * (m['xi_r'] - m['xi_i']):+.3f} pts, "
              f"y_NH3 {m['y_i']:.5f} -> {m['y_r']:.5f}, "
              f"K_phi {m['Kphi']:.5f}; k_ij = -/+{KIJ_BAND:g} band "
              f"{100 * m['lo']:.3f} to {100 * m['hi']:.3f} %")
    print(f"dG0 sensitivity at 300 bar: -1 kJ/mol -> "
          f"{100 * d['sens'][-1000.0]:.3f} %, +1 kJ/mol -> "
          f"{100 * d['sens'][+1000.0]:.3f} %")
    for p in write(build(d), SLUG):
        print("wrote", p)
