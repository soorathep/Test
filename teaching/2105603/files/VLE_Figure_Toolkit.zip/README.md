# Module 4 lecture figures — 2105603 Advanced Chemical Engineering Thermodynamics

Soorathep Kheawhom, Chulalongkorn University.

Ten standalone scripts, one per figure. Each writes a PNG and a PDF of the same
render into `/home/claude/vle/qmd/figures/` at 300 dpi and prints the paths and
the numbers it computed.

```
cd /home/claude/vle/toolkit
python3 f4_01.py          # ... through f4_10.py
for f in f4_*.py; do python3 "$f"; done
```

Every script adds `/home/claude/vlekit` to `sys.path` and does its physics with
`vlekit` (`regress`, `consistency`, `flash`, `validate`, `plots`). Colours and
rcParams come from `vlekit.plots` — the Teal-Amber Lab Palette. The output
directory can be overridden with the `F4_OUT` environment variable.

**All datasets are synthesised with `vlekit.regress.generate` from a known
model.** None of them is an experimental measurement, and none of the numbers
on the figures is copied from the literature: each is the value a run of the
code returned. Where a *model parameter* is illustrative rather than fitted
(the ethanol/water Margules pair, the assumed excess enthalpy in F4.9) the
figure says so on its face.

| file | figure | the claim it supports | assumed inputs |
|---|---|---|---|
| `f4_01.py` | F4.1 `f4_01_vle_ladder` | Raoult → modified Raoult → gamma-phi → phi-phi is a ladder: each rung buys more physics with more parameters, more data and more computation. | Nothing computed — a concept map drawn with `FancyBboxPatch`/`FancyArrowPatch` in unit coordinates. |
| `f4_02.py` | F4.2 `f4_02_pxy_txy_azeotrope` | P-x-y and T-x-y are two sections through one surface; the azeotrope appears in both, and it is a root of gamma1 Psat1 = gamma2 Psat2, not a bump on a curve. | Margules-2 `A12 = 1.6, A21 = 0.9` for ethanol/water — illustrative teaching parameters from the course blueprint, labelled as such on the figure. |
| `f4_03.py` | F4.3 `f4_03_area_test` | The area test compares two lobe areas, so any error that grows both of them equally is invisible to it. | None beyond the generating model NRTL(0.35, 0.62). |
| `f4_04.py` | F4.4 `f4_04_point_test_residuals` | A consistent and an inconsistent set look similar apart; on one axis the bias is unmissable. | None. The inconsistent set is the consistent set plus `delta y1 = 0.30 x1 x2`. |
| `f4_05.py` | F4.5 `f4_05_three_datasets_tests` | Consistent, borderline and inconsistent are not one verdict but five, and the five scales are not calibrated against each other. | None. "Borderline" is `b = 0.10`, the bias that puts the direct-test index in the marginal band. |
| `f4_06.py` | F4.6 `f4_06_objective_functions` | Choosing the objective function moves the parameters further than the statistical uncertainty does, and moves the extrapolated predictions with them. | None beyond the generating model Margules-2 `[2.4, 2.0]`. |
| `f4_07.py` | F4.7 `f4_07_bootstrap_confidence_region` | Two parameters quoted with separate error bars describe a rectangle six times larger than the region the fit ever occupied. | None. 600 residual-resampling bootstraps, seed 2. |
| `f4_08.py` | F4.8 `f4_08_indistinguishable_fits_lle` | Two parameter sets one standard error apart fit the data identically and disagree about whether the liquid splits into two phases. | None beyond the generating model Margules-2 `[2.05, 1.98]`. |
| `f4_09.py` | F4.9 `f4_09_excess_enthalpy_term` | The `-(H^E/RT^2) dT/dx1` term an isobaric consistency test usually drops is negligible in mid-range and comparable to the tested residual at the dilute alcohol end. | **`H^E` is ASSUMED**: `H^E = 4 H^E_max x1 x2` with `H^E_max = 500 J/mol` (band 250–1000 J/mol). A plausible order of magnitude for an alcohol/water mixture near its boiling range, not a measurement; stated in full on the figure. The Margules pair is the illustrative one from F4.2. |
| `f4_10.py` | F4.10 `f4_10_rachford_rice` | The Rachford-Rice function is strictly decreasing, so it has at most one root and the signs of F(0) and F(1) decide the phase state before any iteration. | Margules-2 `A12 = 1.6, A21 = 0.9` (illustrative, as in F4.2), labelled on the figure. |

## What is computed rather than asserted

- F4.2 — the azeotrope from `vlekit.flash.azeotrope`; the isobaric azeotropic
  temperature by Brent on `azeotrope(T)["P"] - 101.325`.
- F4.3 — the two lobe areas from the same Redlich-Kister fit that `area_test`
  uses internally, so the printed `D` and the printed `A+`, `A-` are consistent.
- F4.5 — every cell of the table is a `TestResult` from
  `consistency.run_all`.
- F4.7 — the fraction of bootstrap replicates inside the linearised 95 %
  ellipse (94.7 %) and the ellipse-to-rectangle area ratio (0.169).
- F4.8 — the fraction of 300 bootstrap refits that predict a liquid-liquid
  split (71 %), each checked with `flash.miscibility_gap`.
- F4.9 — `dT/dx1` from `regress.bubble_T`; the left-hand side from
  `consistency.gibbs_duhem_residual`. Only `H^E` is assumed.
- F4.10 — `max dF/dV` differenced numerically over all three curves
  (-0.126, i.e. negative everywhere).
