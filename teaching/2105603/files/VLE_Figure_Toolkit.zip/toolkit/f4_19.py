#!/usr/bin/env python3
"""F4.19  A ternary assembled from binary parameters only, and what tests it.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

THE ARGUMENT. Every other figure in this module is binary, because binary VLE
is what gets measured and what gets tested for consistency. Industry does not
distil binaries. The practical reason NRTL and UNIQUAC displaced Margules and
van Laar is not that they fit a binary better — often they do not — it is that
they are written for N components and take NO ternary parameter: the same
tau_ij fitted on the 1-2 edge is the tau_ij that appears in the ternary sum.
This figure builds a three-component map out of nothing but binary numbers so
that claim can be checked rather than asserted.

THE SYSTEM. acetone (1) + chloroform (2) + 2-butanone (3), 101.3 kPa. It was
chosen because its three binaries are in exactly the state a real project is
in:

    1-2  acetone + chloroform      MEASURED at the map's own pressure,
                                   9 points, doi:10.3390/app8091519
    2-3  chloroform + 2-butanone   MEASURED, but isothermally at 303.15 K,
                                   22 points, doi:10.1021/je060150a — some 50 K
                                   below where the map needs it
    1-3  acetone + 2-butanone      NOT MEASURED anywhere in this module.
                                   Predicted by UNIFAC, then condensed into an
                                   NRTL pair so the ternary model is one object

WHAT THIS FIGURE IS NOT. An earlier attempt to source measured TERNARY P-x-y
for a system whose three binaries are all in `vlekit.datasets` failed: no
citable set could be retrieved. So nothing here is validated against a ternary
measurement, and the figure says so on its face. What it does show is the three
things that can honestly be shown:

    (a) which edges are fitted and which is predicted, marked on the edges;
    (b) that each fitted edge reproduces its own data — a real check, with the
        deviation printed and put on the figure;
    (c) that the interior is a prediction no measurement here tests, together
        with the one experiment that would test it.

As the only quantitative handle on (c) available without new data, the interior
is computed twice — once from the assembled binary NRTL and once from a direct
ternary UNIFAC (`unifac.gammas_multi`, added for this figure) — and the two
predictions are compared. Agreement between two models is NOT validation, and
the figure says that too; it is a lower bound on the uncertainty, nothing more.

WHAT THE MAP SHOWS. Residue curves: the composition path of the liquid left in
a still as a batch boils away, dx/dxi = x - y. Their fixed points are the pure
components and the azeotropes, and every one of them here is predicted from
binary parameters. The model finds two maximum-boiling azeotropes, hence two
unstable nodes (acetone and chloroform) and one stable node, and therefore a
distillation boundary — the separatrix leaving the acetone + chloroform
azeotrope. Which side of that line a feed falls on decides whether pure acetone
or pure chloroform can be taken overhead, and its position rests on no
measurement at all.

Run:  python3 f4_19.py       (about 90 s: every residue curve is an integration
                              with a bubble-point solve at every step)
"""
from __future__ import annotations

import os
import sys
import time

import numpy as np

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib                                                  # noqa: E402
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                    # noqa: E402
from scipy.optimize import least_squares                           # noqa: E402

import vlekit as v                                                 # noqa: E402
from vlekit import datasets as D                                   # noqa: E402
from vlekit import multi as M                                      # noqa: E402
from vlekit import unifac as U                                     # noqa: E402
from vlekit.data import component                                  # noqa: E402
from vlekit.models import NRTL                                     # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,  # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, use_style)

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_19_ternary_from_binaries"

P_MAP = 101.3            # kPa, the pressure of the ternary map
ALPHA = 0.3              # NRTL non-randomness, held fixed as everywhere else
EDGE_MARGIN = 0.05       # how far from an edge the "interior" starts
ROOT3_2 = np.sqrt(3) / 2


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def wrapped(text, width):
    """Wrap a caption on spaces, never inside a $...$ span."""
    out = []
    for para in text.split("\n"):
        cur, n, inmath = [], 0, False
        for w in para.split(" "):
            if cur and not inmath and n + 1 + len(w) > width:
                out.append(" ".join(cur))
                cur, n = [], 0
            cur.append(w)
            n += len(w) + (1 if n else 0)
            if w.count("$") % 2 == 1:
                inmath = not inmath
        out.append(" ".join(cur))
    return "\n".join(out)


# --------------------------------------------------------------------------
def bubble_T(gamma_of, comps, x, P=P_MAP, lo=280.0, hi=400.0, n=70):
    """Bubble temperature by bisection on sum_i x_i gamma_i Psat_i = P.

    `gamma_of(x, T)` is a callable rather than a model object so that the same
    routine serves the assembled NRTL — whose gamma does not depend on T once
    tau is fixed — and UNIFAC, whose group sums must be re-evaluated at every
    trial temperature. Writing it once is the point: the two predictions have
    to come out of identical arithmetic or the comparison between them means
    nothing.
    """
    x = np.clip(np.asarray(x, dtype=float), 1e-12, None)
    x = x / x.sum()
    for _ in range(n):
        mid = 0.5 * (lo + hi)
        g = gamma_of(x, mid)
        Pc = float(np.sum(x * g * np.array([c.Psat(mid) for c in comps])))
        if Pc < P:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def nrtl_from_unifac(c1, c2, T, n=49):
    """Condense a UNIFAC prediction for one pair into an NRTL parameter pair.

    UNIFAC is evaluated on a composition grid at one temperature and NRTL is
    least-squares fitted to the two ln gamma curves. This is exactly what a
    process simulator does when it fills a missing binary from UNIFAC, and it
    is worth being explicit that the result is a prediction wearing a fitted
    model's clothes: the rms of the condensation step is reported so the reader
    can see that this step adds nothing, and that all of the uncertainty is in
    the UNIFAC prediction itself.
    """
    xs = np.linspace(0.02, 0.98, n)
    lg1, lg2 = U.ln_gammas(xs, T, c1, c2)

    def resid(p):
        a, b = NRTL(p, alpha=ALPHA).ln_gamma(xs)
        return np.concatenate([a - lg1, b - lg2])

    sol = least_squares(resid, [0.1, 0.1])
    return sol.x, float(np.sqrt(np.mean(sol.fun ** 2)))


def interior_grid(step=12, margin=EDGE_MARGIN):
    """Composition points strictly inside the triangle, on a regular lattice."""
    out = []
    for i in range(step + 1):
        for j in range(step + 1 - i):
            x = np.array([i, j, step - i - j], dtype=float) / step
            if x.min() >= margin:
                out.append(x)
    return np.array(out)


def path(model, comps, x0, forward=True, steps=2600, dxi=1.2e-2):
    p, T = M.residue_curve(model, comps, x0, P=P_MAP, steps=steps, dxi=dxi,
                           forward=forward)
    return p


# --------------------------------------------------------------------------
def analyse():
    t0 = time.time()
    ac, ch, mek = (component("acetone"), component("chloroform"),
                   component("mek"))
    comps = [ac, ch, mek]
    names = ["acetone", "chloroform", "2-butanone"]

    # ---------------------------------------------------- the measured edges
    d12 = D.acetone_chloroform()
    d23 = D.chloroform_butanone()
    f12 = v.fit(d12, "nrtl")                      # Barker on T, isobaric
    f23 = v.fit(d23, "nrtl")                      # Barker on P, isothermal

    dev12_T = f12.T_calc - d12.T
    dev23_P = 100.0 * (f23.P_calc - d23.P) / d23.P

    # -------------------------------------------------- the predicted edge
    Tb = [c.Tsat(P_MAP) for c in comps]
    T13 = float(np.mean([Tb[0], Tb[2]]))          # the range this edge boils in
    tau13, rms13 = nrtl_from_unifac(ac, mek, T13)
    g13_inf = (float(U.gammas(np.array([1e-9]), T13, ac, mek)[0][0]),
               float(U.gammas(np.array([1 - 1e-9]), T13, ac, mek)[1][0]))

    # ------------------------------------------- the ternary, no new parameter
    tau = np.zeros((3, 3))
    tau[0, 1], tau[1, 0] = f12.params
    tau[1, 2], tau[2, 1] = f23.params
    tau[0, 2], tau[2, 0] = tau13
    tern = M.NRTLMulti(tau, ALPHA)

    def g_nrtl(x, T):
        return tern.gamma(x)

    def g_unifac(x, T):
        return U.gammas_multi(x, T, comps)

    fp = M.fixed_points(tern, comps, P=P_MAP, grid=41)
    az = [o for o in fp if o["kind"] == "binary azeotrope"]

    # ------------------------------------------------------- residue curves
    seeds = [np.array(s, dtype=float) for s in
             ([0.70, 0.16, 0.14], [0.46, 0.36, 0.18], [0.26, 0.52, 0.22],
              [0.12, 0.66, 0.22], [0.50, 0.14, 0.36], [0.28, 0.30, 0.42],
              [0.13, 0.47, 0.40], [0.30, 0.12, 0.58], [0.15, 0.27, 0.58],
              [0.10, 0.12, 0.78], [0.06, 0.40, 0.54], [0.55, 0.05, 0.40])]
    curves = []
    for s in seeds:
        back = path(tern, comps, s, forward=False)
        fwd = path(tern, comps, s, forward=True)
        curves.append(np.vstack([back[::-1], fwd[1:]]))

    # Node type read off the integrations themselves rather than asserted: a
    # fixed point that backward integration runs into is where residue curves
    # BEGIN (an unstable node), one that forward integration runs into is where
    # they END (a stable node), and anything the curves only pass by is a
    # saddle. This is the classification a distillation boundary depends on.
    starts = [c[0] for c in curves]
    ends = [c[-1] for c in curves]
    kind = {}
    for o in fp:
        near = lambda pts: any(np.max(np.abs(q - o["x"])) < 2e-3 for q in pts)
        kind[o["which"]] = ("unstable node" if near(starts) else
                            "stable node" if near(ends) else "saddle")

    # the separatrix: the unstable manifold of the acetone + chloroform
    # azeotrope, pushed a hair into the interior along the third component
    a12 = [o for o in az if o["which"] == (0, 1)][0]
    x0 = a12["x"] * (1 - 5e-4) + 5e-4 * np.array([0.0, 0.0, 1.0])
    sep = path(tern, comps, x0, forward=True, steps=6000, dxi=8e-3)

    # --------------------------------------- two predictions of one interior
    grid = interior_grid()
    Tn = np.array([bubble_T(g_nrtl, comps, x) for x in grid])
    Tu = np.array([bubble_T(g_unifac, comps, x) for x in grid])
    dT = Tn - Tu
    k = int(np.argmax(np.abs(dT)))

    # UNIFAC's error where there IS data, as the caveat on that comparison
    Tu_edge = np.array([bubble_T(lambda xx, TT: U.gammas_multi(xx, TT, comps),
                                 comps, [x1, 1 - x1, 0.0]) for x1 in d12.x1])
    unifac_edge = float(np.mean(np.abs(Tu_edge - d12.T)))

    return dict(comps=comps, names=names, d12=d12, d23=d23, f12=f12, f23=f23,
                dev12_T=dev12_T, dev23_P=dev23_P, tau=tau, tau13=tau13,
                rms13=rms13, g13_inf=g13_inf, T13=T13, Tb=Tb, tern=tern,
                fp=fp, az=az, kind=kind, curves=curves, sep=sep, grid=grid, Tn=Tn, Tu=Tu,
                dT=dT, worst=(grid[k], Tn[k], Tu[k], dT[k]),
                unifac_edge=unifac_edge, unifac_edge_T=Tu_edge,
                gd=float(tern.check_gibbs_duhem()),
                pure=float(tern.check_pure_limit()),
                elapsed=time.time() - t0)


# --------------------------------------------------------------------------
def tri(x):
    """Barycentric to Cartesian, one point or many (vlekit.multi.to_xy)."""
    return M.to_xy(x)


def draw_triangle(ax, d):
    V = tri(np.eye(3))
    edge_style = [
        ((0, 1), NAVY, "-", 3.4),        # acetone-chloroform: measured here
        ((1, 2), TEAL, "-", 3.4),        # chloroform-2-butanone: measured, 303 K
        ((0, 2), AMBER, (0, (5, 2.6)), 3.4),   # acetone-2-butanone: predicted
    ]
    for (i, j), col, ls, lw in edge_style:
        ax.plot(V[[i, j], 0], V[[i, j], 1], ls=ls, color=col, lw=lw, zorder=6,
                solid_capstyle="round")

    # gridlines of constant mole fraction, drawn from the geometry
    for f in np.arange(0.2, 0.81, 0.2):
        for a, b in ((0, 1), (1, 2), (2, 0)):
            p = np.zeros((2, 3))
            p[0, a], p[0, b] = f, 1 - f
            p[1, a] = f
            p[1, (3 - a - b)] = 1 - f
            q = tri(p)
            ax.plot(q[:, 0], q[:, 1], "-", color=MIST, lw=0.6, alpha=0.7,
                    zorder=1)


def build(d):
    use_style()
    fig = plt.figure(figsize=(16.2, 8.1))
    gs = fig.add_gridspec(3, 2, width_ratios=[1.52, 1.0],
                          left=0.020, right=0.988, top=0.918, bottom=0.302,
                          hspace=0.72, wspace=0.16)
    axT = fig.add_subplot(gs[:, 0])
    ax1 = fig.add_subplot(gs[0, 1])
    ax2 = fig.add_subplot(gs[1, 1])
    ax3 = fig.add_subplot(gs[2, 1])
    comps, names = d["comps"], d["names"]

    # ================================================== the ternary map, left
    axT.set_aspect("equal")
    axT.axis("off")
    draw_triangle(axT, d)

    for c in d["curves"]:
        q = tri(c)
        axT.plot(q[:, 0], q[:, 1], "-", color=SLATE, lw=1.05, alpha=0.72,
                 zorder=3)
        # one arrow per curve, at its midpoint, pointing the way the still moves
        m = len(q) // 2
        axT.annotate("", xy=q[m + 12], xytext=q[m],
                     arrowprops=dict(arrowstyle="-|>", color=SLATE, lw=1.0,
                                     mutation_scale=11), zorder=4)

    qs = tri(d["sep"])
    axT.plot(qs[:, 0], qs[:, 1], "-", color=RUST, lw=3.0, zorder=5)

    V = tri(np.eye(3))
    vlab = [("left", "right", (-0.105, -0.012)),
            ("right", "left", (0.105, -0.012)),
            ("center", "bottom", (0.0, 0.028))]
    for i, (ha, _va, off) in enumerate(vlab):
        va = "top" if i < 2 else "bottom"
        axT.text(V[i, 0] + off[0], V[i, 1] + off[1],
                 f"{names[i]}\n{d['Tb'][i]:.1f} K",
                 ha=ha, va=va, fontsize=11.0, color=INK, linespacing=1.35,
                 zorder=8)

    for o in d["fp"]:
        p = tri(o["x"])[0]
        if o["kind"] == "pure":
            axT.plot(*p, "o", color=INK, ms=7.0, mfc=PAPER, mew=1.8, zorder=9)
        else:
            axT.plot(*p, "D", color=RUST, ms=9.0, mfc=PAPER, mew=2.0, zorder=9)

    # Azeotrope labels live OUTSIDE the triangle, on the far side of the edge
    # they sit on, so that nothing is written over the residue curves. Both the
    # anchor and the label position come from the computed composition.
    cen = tri(np.full(3, 1 / 3.0))[0]
    az_off = {(0, 1): 0.135, (1, 2): 0.215}      # clearance, per edge
    for o in d["az"]:
        p = tri(o["x"])[0]
        i, j = o["which"]
        u = 0.5 * (V[i] + V[j]) - cen             # outward normal of that edge
        u = u / np.linalg.norm(u)
        axT.annotate(f"azeotrope {i + 1}-{j + 1}, predicted "
                     f"({d['kind'][o['which']]})\n"
                     f"$x_{i + 1}$ = {o['x'][i]:.3f},  {o['T']:.2f} K",
                     xy=p, xytext=p + az_off[o["which"]] * u,
                     ha="center", va="center",
                     fontsize=8.8, color=RUST, linespacing=1.4, zorder=10,
                     bbox=dict(boxstyle="round,pad=0.26", fc=PAPER, ec=RUST,
                               lw=1.0, alpha=0.96),
                     arrowprops=dict(arrowstyle="-", color=RUST, lw=1.0,
                                     shrinkA=2, shrinkB=4))

    # edge tags, rotated with their edge and pushed clear of the azeotropes
    tags = [((0, 1), NAVY, 0.30, 0.058, 0.0,
             f"MEASURED here · {len(d['d12'])} pts\ndoi:10.3390/app8091519"),
            ((1, 2), TEAL, 0.24, 0.048, -60.0,
             f"MEASURED at 303.15 K · {len(d['d23'])} pts\n"
             "doi:10.1021/je060150a"),
            ((0, 2), AMBER, 0.50, 0.048, 60.0,
             "NO DATA\nUNIFAC prediction")]
    for (i, j), col, t, off, rot, txt in tags:
        mid = (1 - t) * V[i] + t * V[j]
        u = mid - cen
        u = u / np.linalg.norm(u)
        axT.text(*(mid + off * u), txt, rotation=rot,
                 rotation_mode="anchor", ha="center", va="center",
                 fontsize=8.8, color=col, zorder=8, linespacing=1.4)

    axT.text(0.002, 0.998,
             "residue curves,\n"
             r"$\mathrm{d}x_i/\mathrm{d}\xi = x_i - y_i$"
             "\nfrom binary $\\tau_{ij}$ only —\n"
             "NRTL and UNIQUAC have\nno ternary parameter",
             transform=axT.transAxes, ha="left", va="top", fontsize=9.0,
             color=SLATE, linespacing=1.5, zorder=11)
    axT.text(0.002, 0.680,
             "the interior is a PREDICTION\nno measurement here tests.\n"
             f"assembled NRTL vs ternary\nUNIFAC, {len(d['grid'])} interior "
             "points:\n"
             f"mean $|\\Delta T_{{bub}}|$ = "
             f"{np.mean(np.abs(d['dT'])):.2f} K, max "
             f"{np.max(np.abs(d['dT'])):.2f} K\n"
             "— two models agreeing is\nnot a measurement",
             transform=axT.transAxes, ha="left", va="top", fontsize=9.0,
             color=GRAPHITE, linespacing=1.5, zorder=11,
             bbox=dict(boxstyle="round,pad=0.30", fc=PAPER, ec=SLATE, lw=1.0,
                       alpha=0.96))

    # the boundary, labelled where it runs: a third of the way up the
    # separatrix, with the text pushed into the sparse side of the map
    s = tri(d["sep"])[len(d["sep"]) // 3]
    axT.annotate("distillation boundary, predicted —\n"
                 "which side a feed falls on decides\n"
                 f"whether {names[0]} or {names[1]}\n"
                 "can be taken overhead",
                 xy=s, xytext=(0.315, 0.300), textcoords="axes fraction",
                 ha="center", va="center", fontsize=8.8, color=RUST,
                 linespacing=1.45, zorder=11,
                 bbox=dict(boxstyle="round,pad=0.28", fc=PAPER, ec=RUST,
                           lw=1.0, alpha=0.95),
                 arrowprops=dict(arrowstyle="-", color=RUST, lw=1.1,
                                 shrinkA=3, shrinkB=5))
    axT.set_title("(a)  acetone + chloroform + 2-butanone at 101.3 kPa, "
                  "assembled from three binary parameter sets",
                  fontsize=12.0, pad=2)
    axT.set_xlim(-0.46, 1.46)
    axT.set_ylim(-0.145, ROOT3_2 + 0.115)

    # ================================================ the three edges, right
    # (b) acetone + chloroform, fitted at the map's own pressure
    d12, f12 = d["d12"], d["f12"]
    xs = np.linspace(1e-4, 1 - 1e-4, 240)
    Tc, yc = v.bubble_T(f12.model, xs, np.full_like(xs, d12.P[0]),
                        d12.c1, d12.c2)
    ax1.plot(xs, Tc, "-", color=NAVY, lw=2.0, zorder=4, label="NRTL bubble")
    ax1.plot(yc, Tc, "--", color=SKYBLUE, lw=2.0, zorder=4, label="NRTL dew")
    ax1.plot(d12.x1, d12.T, "o", color=INK, mfc=PAPER, mew=1.5, ms=6.0,
             zorder=6, label="measured $x_1$")
    ax1.plot(d12.y1, d12.T, "s", color=RUST, mfc=PAPER, mew=1.5, ms=5.5,
             zorder=6, label="measured $y_1$")
    ax1.legend(loc="lower left", fontsize=8.2, ncol=2, handlelength=1.6,
               columnspacing=1.0, borderaxespad=0.3)
    ax1.set_title("(b)  edge 1-2 FITTED — and it reproduces its own data\n"
                  f"AAD {np.mean(np.abs(d['dev12_T'])):.3f} K in $T$, "
                  f"rms {f12.rms_y:.4f} in $y_1$",
                  fontsize=10.2, pad=4, color=NAVY)
    ax1.set_xlabel("$x_1$, $y_1$   (acetone)", fontsize=10.5, labelpad=1)
    ax1.set_ylabel("$T$ / K", fontsize=10.5)

    # (c) chloroform + 2-butanone, fitted 50 K away from where it is used
    d23, f23 = d["d23"], d["f23"]
    Pc, _ = v.bubble_P(f23.model, xs, np.full_like(xs, d23.T[0]),
                       d23.c1, d23.c2)
    ax2.plot(xs, Pc, "-", color=TEAL, lw=2.0, zorder=4,
             label="NRTL bubble at 303.15 K")
    ax2.plot(d23.x1, d23.P, "o", color=INK, mfc=PAPER, mew=1.5, ms=6.0,
             zorder=6, label="measured $P$-$x_2$")
    ax2.legend(loc="upper left", fontsize=8.2, handlelength=1.6,
               borderaxespad=0.3)
    ax2.set_title("(c)  edge 2-3 FITTED at 303.15 K, used "
                  f"{d['Tb'][2] - d23.T[0]:.0f} K higher\n"
                  f"AAD {np.mean(np.abs(d['dev23_P'])):.2f} % in $P$ — "
                  r"but $\tau$ held temperature-independent",
                  fontsize=10.2, pad=4, color=TEAL)
    ax2.set_xlabel("$x_2$   (chloroform)", fontsize=10.5, labelpad=1)
    ax2.set_ylabel("$P$ / kPa", fontsize=10.5)

    # (d) acetone + 2-butanone, predicted, no data anywhere
    xg = np.linspace(1e-3, 1 - 1e-3, 240)
    gu1, gu2 = U.gammas(xg, d["T13"], d["comps"][0], d["comps"][2])
    gn1, gn2 = NRTL(d["tau13"], alpha=ALPHA).gamma(xg)
    ax3.plot(xg, gu1, "-", color=AMBER, lw=2.4, zorder=4)
    ax3.plot(xg, gu2, "-", color=RUST, lw=2.4, zorder=4)
    ax3.plot(xg[::16], gn1[::16], "o", color=AMBER, ms=4.0, mfc=PAPER, mew=1.2,
             zorder=5)
    ax3.plot(xg[::16], gn2[::16], "o", color=RUST, ms=4.0, mfc=PAPER, mew=1.2,
             zorder=5)
    ax3.axhline(1.0, color=GRAPHITE, lw=1.0, zorder=3)
    ax3.set_title("(d)  edge 1-3 PREDICTED — there is no data to fit\n"
                  f"UNIFAC: $\\gamma^\\infty$ = {d['g13_inf'][0]:.4f} and "
                  f"{d['g13_inf'][1]:.4f} at {d['T13']:.1f} K",
                  fontsize=10.2, pad=4, color=AMBER)
    ax3.set_xlabel("$x_1$   (acetone)", fontsize=10.5,
                   labelpad=1)
    ax3.set_ylabel(r"$\gamma_i$", fontsize=10.5)
    lo3 = min(1.0, float(min(gu1.min(), gu2.min())))
    hi3 = float(max(gu1.max(), gu2.max()))
    ax3.set_ylim(lo3 - 0.10 * (hi3 - lo3), hi3 + 0.42 * (hi3 - lo3))
    ax3.text(0.02, gu1[0], r"$\gamma_1$ (acetone)", color=AMBER,
             fontsize=8.6, ha="left", va="bottom", zorder=9)
    ax3.text(0.98, gu2[-1], r"$\gamma_3$ (2-butanone)", color=RUST,
             fontsize=8.6, ha="right", va="bottom", zorder=9)
    ax3.text(0.5, 0.97,
             "lines UNIFAC, circles the NRTL pair fitted to them "
             f"(rms {d['rms13']:.1e} in $\\ln\\gamma$):\n"
             "the condensation adds nothing — all the risk is in UNIFAC",
             transform=ax3.transAxes, ha="center", va="top", fontsize=8.4,
             color=GRAPHITE, linespacing=1.4, zorder=9)

    for a in (ax1, ax2, ax3):
        a.grid(True, zorder=0)
        a.set_axisbelow(True)
        a.set_xlim(0, 1)
        a.tick_params(labelsize=9.5)

    fig.suptitle("The reason NRTL and UNIQUAC replaced Margules and van Laar: "
                 "a ternary needs no ternary parameter — "
                 "but a prediction still needs a measurement",
                 fontsize=14.0, y=0.985)
    fig.text(0.5, 0.016, wrapped(
        "acetone (1) + chloroform (2) + 2-butanone (3) at 101.3 kPa. NRTL "
        "($\\alpha$ = 0.3) on every pair; the ternary uses the three fitted "
        "pairs unchanged and adds NO parameter of its own. Edge 1-2: Barker on "
        "$T$, doi:10.3390/app8091519 (9 points, 101.3 kPa). Edge 2-3: Barker "
        "on $P$, doi:10.1021/je060150a (22 points, 303.15 K). Edge 1-3 has no "
        "measurement in this module and is predicted by original VLE UNIFAC "
        "(Fredenslund-Jones-Prausnitz form, Hansen et al. VLE table, the "
        "subset embedded in vlekit.unifac), then condensed to an NRTL pair at "
        "{T13:.1f} K.\n"
        "ASSUMPTIONS, stated because none of them is tested here: $\\tau$ is "
        "taken temperature-independent, so edge 2-3 is used {dTx:.0f} K above "
        "its data; the vapour is ideal and $\\Phi_i$ = 1; $\\alpha$ = 0.3 is "
        "assumed, not fitted; and the residue curves, the azeotropes, the "
        "boundary and the whole interior are PREDICTIONS. There is no measured "
        "ternary datum on this figure.\n"
        "WHAT WOULD TEST IT: measured ternary $P$-$x$-$y$ or $T$-$x$-$y$ for "
        "this system at 101.3 kPa, a ternary azeotrope search, or a measured "
        "residue curve. Absent those, the only handle is a second independent "
        "prediction: ternary UNIFAC on the same grid ({ng} points, every "
        "$x_i \\geq$ {mg:.2f}) sits within {mn:.2f} K on average and "
        "{mx:.2f} K at worst of the assembled NRTL — a consistency check "
        "between two models, NOT a validation. On edge 1-2, where measurements "
        "do exist, that same UNIFAC is off by {ue:.2f} K (F4.20).",
        190).format(
            T13=d["T13"], dTx=d["Tb"][2] - d["d23"].T[0], ng=len(d["grid"]),
            mg=EDGE_MARGIN, mn=float(np.mean(np.abs(d["dT"]))),
            mx=float(np.max(np.abs(d["dT"]))), ue=d["unifac_edge"]),
        ha="center", va="bottom", fontsize=9.4, color=SLATE, linespacing=1.6)
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = analyse()
    n = d["names"]
    print(f"F4.19  {n[0]} (1) + {n[1]} (2) + {n[2]} (3) at {P_MAP} kPa")
    print(f"  normal boiling points from vlekit.data Antoine: "
          + ", ".join(f"{a} {b:.2f} K" for a, b in zip(n, d["Tb"])))
    print()
    print("  the three binaries, and where each number came from:")
    d12, d23, f12, f23 = d["d12"], d["d23"], d["f12"], d["f23"]
    print(f"    1-2 {d12.label}   doi:{D.DOIS['acetone-chloroform']}   "
          f"{len(d12)} points, MEASURED at the map pressure")
    print(f"        NRTL by Barker on T: tau12 = {f12.params[0]:+.6f}, "
          f"tau21 = {f12.params[1]:+.6f}")
    print(f"        AAD {np.mean(np.abs(d['dev12_T'])):.4f} K in T "
          f"(max {np.max(np.abs(d['dev12_T'])):.4f} K), "
          f"rms {f12.rms_y:.5f} in y1")
    print(f"    2-3 {d23.label}   doi:{D.DOIS['chloroform-butanone']}   "
          f"{len(d23)} points, MEASURED {d['Tb'][2] - d23.T[0]:.0f} K below "
          f"where it is used")
    print(f"        NRTL by Barker on P: tau23 = {f23.params[0]:+.6f}, "
          f"tau32 = {f23.params[1]:+.6f}")
    print(f"        AAD {np.mean(np.abs(d['dev23_P'])):.4f} % in P "
          f"(max {np.max(np.abs(d['dev23_P'])):.4f} %), "
          f"rms {f23.rms_y:.5f} in y")
    print(f"    1-3 {n[0]} + {n[2]}: NO DATA in vlekit.datasets — predicted")
    print(f"        UNIFAC at {d['T13']:.2f} K: gamma_inf = "
          f"{d['g13_inf'][0]:.5f} ({n[0]} in {n[2]}) and "
          f"{d['g13_inf'][1]:.5f} ({n[2]} in {n[0]}) — essentially ideal, "
          f"because the pair differs by one CH2 and shares the CH3CO group")
    print(f"        condensed to NRTL: tau13 = {d['tau13'][0]:+.6f}, "
          f"tau31 = {d['tau13'][1]:+.6f}, rms {d['rms13']:.2e} in ln gamma "
          f"(the condensation adds nothing; the prediction is all of the risk)")
    print()
    print("  the assembled ternary NRTL, tau (no ternary parameter):")
    for i in range(3):
        print("      " + "  ".join(f"{d['tau'][i, j]:+9.6f}" for j in range(3))
              + f"    ({n[i]})")
    print(f"    Gibbs-Duhem residual {d['gd']:.2e}, "
          f"pure-limit residual {d['pure']:.2e}")
    print()
    print("  fixed points of the residue-curve map, ALL predicted:")
    for o in sorted(d["fp"], key=lambda o: o["T"]):
        which = ("pure " + n[o["which"][0]] if o["kind"] == "pure"
                 else f"{n[o['which'][0]]} + {n[o['which'][1]]} azeotrope")
        print(f"    {which:38s} x = ({o['x'][0]:.4f}, {o['x'][1]:.4f}, "
              f"{o['x'][2]:.4f})   T = {o['T']:.2f} K   "
              f"{d['kind'][o['which']]}")
    print("    -> two maximum-boiling azeotropes, so two unstable nodes "
          f"({n[0]}, {n[1]}) and one stable node "
          f"({n[1]} + {n[2]} azeotrope): a distillation boundary runs between "
          "them, and no measurement in this module fixes where it lies")
    print(f"    the separatrix was integrated from the {n[0]} + {n[1]} "
          f"azeotrope and ends at ({d['sep'][-1][0]:.4f}, "
          f"{d['sep'][-1][1]:.4f}, {d['sep'][-1][2]:.4f})")
    print()
    print(f"  the interior, two independent predictions "
          f"({len(d['grid'])} points, every x_i >= {EDGE_MARGIN}):")
    print(f"    assembled binary NRTL vs ternary UNIFAC "
          f"(unifac.gammas_multi): mean |dT_bub| = "
          f"{np.mean(np.abs(d['dT'])):.3f} K, max "
          f"{np.max(np.abs(d['dT'])):.3f} K at x = "
          f"({d['worst'][0][0]:.3f}, {d['worst'][0][1]:.3f}, "
          f"{d['worst'][0][2]:.3f}), where NRTL says {d['worst'][1]:.2f} K "
          f"and UNIFAC {d['worst'][2]:.2f} K")
    print(f"    CAVEAT: on edge 1-2, where data exists, that same UNIFAC is "
          f"off by {d['unifac_edge']:.3f} K on average, so agreement between "
          f"the two predictions bounds nothing by itself")
    print(f"  [analyse() took {d['elapsed']:.1f} s]")
    for p in write(build(d), SLUG):
        print("wrote", p)
