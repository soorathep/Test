#!/usr/bin/env python3
"""F4.15  The vapour-phase corrections to gamma, one rung at a time.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

An activity coefficient is not measured. What is measured is T, P, x and y, and
gamma follows only after a decision about the vapour:

    gamma_i = y_i Phi_i P / (x_i Psat_i),
    Phi_i   = phi_hat_i / phi_i^sat * exp[ -v_i^L (P - Psat_i) / RT ]

This figure switches the three pieces of Phi_i on one at a time and measures
what each one moves, on real data rather than on an argument.

    rung 0   gamma = y P / (x Psat)                 modified Raoult, Phi = 1
    rung 1   x phi_hat_i                            the mixture is a real gas
    rung 2   / phi_i^sat                            so is the pure saturated
                                                    vapour that the reference
                                                    fugacity is defined at
    rung 3   / Poynting factor                      the liquid is compressed
                                                    from Psat to P

The two panels on the right plot the INCREMENTAL change at each rung, not the
cumulative one, because the interesting fact is that rungs 1 and 2 push in
opposite directions and largely cancel: phi_hat_i and phi_i^sat are both less
than one and their ratio is much closer to one than either. A student who
applies phi_hat and forgets phi^sat is worse off than one who applies neither.

DATA.   ethanol (1) + water (2), 21 points at 101.3 kPa, 351-368 K,
Kamihama et al. 2012, https://doi.org/10.1021/je2008704 — the highest-pressure
set in `vlekit.datasets`, so it is where the corrections are largest. The same
ladder is computed for chloroform (1) + 2-butanone (2) at 303.15 K and 15-32
kPa (https://doi.org/10.1021/je060150a) and reported for contrast: an order of
magnitude less pressure, and the corrections scale with it.

ASSUMPTIONS, ALL STATED ON THE FIGURE
  * phi from the two-term virial equation with Pitzer-Curl / Tsonopoulos
    second virial coefficients, k_12 = 0 in the cross coefficient.
  * That correlation is built for non-polar and slightly polar species. Water
    and ethanol are neither. The polar and associating contributions to B are
    missing, so the phi values here are themselves uncertain by more than the
    Poynting factor they are being compared against. The honest reading of
    this figure is therefore about the SIZE of each rung, not the fourth
    decimal place of any one of them.
  * v_i^L taken as constant, from `vlekit.data.LIBRARY`.

Run:  python3 f4_15.py
"""
from __future__ import annotations

import os
import sys

import numpy as np

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib                                                  # noqa: E402
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                    # noqa: E402

from vlekit import datasets as D                                   # noqa: E402
from vlekit.data import (B_cross, phi_sat_virial, phi_virial,      # noqa: E402
                         poynting)
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY, PAPER,  # noqa: E402
                          RUST, SKYBLUE, SLATE, TEAL, use_style)

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_15_gamma_corrections_ladder"

MAIN = "ethanol-water"
CONTRAST = "chloroform-butanone"

RUNGS = [(r"rung 1:  $\times\ \hat\phi_i$   (real mixed vapour)", NAVY),
         (r"rung 2:  $/\ \phi_i^{\rm sat}$   (real pure saturated vapour)",
          TEAL),
         (r"rung 3:  $/\ \mathcal{F}_i$   (Poynting)", AMBER)]


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths



def wrapped(text, width):
    """Wrap a caption on spaces, never inside a $...$ span.

    `bbox_inches='tight'` grows the canvas around any text that overflows the
    figure, which silently rescales every panel on the slide. Wrapping the
    footnote to the figure width is the only way to keep the rendered PNG the
    shape the script asked for.
    """
    out = []
    for para in text.split("\n"):
        cur, n, inmath = [], 0, False
        for w in para.split(" "):
            if cur and not inmath and n + 1 + len(w) > width:
                out.append(" ".join(cur))
                cur, n = [], 0
            cur.append(w)
            n += len(w) + (1 if n else 0)
            if w.count("$") % 2 == 1:
                inmath = not inmath
        out.append(" ".join(cur))
    return "\n".join(out)


# --------------------------------------------------------------------------
def ladder(dat, k12=0.0):
    """gamma at each rung, and the incremental per-cent change at each step."""
    Ps1, Ps2 = dat.c1.Psat(dat.T), dat.c2.Psat(dat.T)
    with np.errstate(divide="ignore", invalid="ignore"):
        g1 = dat.y1 * dat.P / (dat.x1 * Ps1)
        g2 = (1 - dat.y1) * dat.P / ((1 - dat.x1) * Ps2)

    ph1, ph2 = phi_virial(dat.y1, dat.T, dat.P, dat.c1, dat.c2, k12)
    ps1, ps2 = phi_sat_virial(dat.T, dat.c1), phi_sat_virial(dat.T, dat.c2)
    pf1, pf2 = poynting(dat.T, dat.P, dat.c1), poynting(dat.T, dat.P, dat.c2)

    # the three multipliers, in the order they are switched on
    mult1 = [ph1, 1.0 / ps1, 1.0 / pf1]
    mult2 = [ph2, 1.0 / ps2, 1.0 / pf2]

    lev1, lev2 = [g1], [g2]
    for m in mult1:
        lev1.append(lev1[-1] * m)
    for m in mult2:
        lev2.append(lev2[-1] * m)

    step1 = [100.0 * (m - 1.0) * np.ones_like(dat.x1) for m in mult1]
    step2 = [100.0 * (m - 1.0) * np.ones_like(dat.x1) for m in mult2]
    net1 = 100.0 * (lev1[-1] / lev1[0] - 1.0)
    net2 = 100.0 * (lev2[-1] / lev2[0] - 1.0)

    return dict(dat=dat, lev1=lev1, lev2=lev2, step1=step1, step2=step2,
                net1=net1, net2=net2, phi=(ph1, ph2), phisat=(ps1, ps2),
                pf=(pf1, pf2),
                B=(dat.c1.B_virial(dat.T), dat.c2.B_virial(dat.T),
                   B_cross(dat.c1, dat.c2, dat.T, k12)))


def summarise(L):
    """Largest |incremental change| at each rung, over the interior points."""
    d = L["dat"]
    m = d.interior()
    out = []
    for i in range(3):
        out.append((float(np.nanmax(np.abs(L["step1"][i][m]))),
                    float(np.nanmax(np.abs(L["step2"][i][m])))))
    out.append((float(np.nanmax(np.abs(L["net1"][m]))),
                float(np.nanmax(np.abs(L["net2"][m])))))
    return out


def analyse():
    main = ladder(D.load(MAIN))
    other = ladder(D.load(CONTRAST))
    return dict(main=main, other=other, s_main=summarise(main),
                s_other=summarise(other))


# --------------------------------------------------------------------------
def build(d):
    use_style()
    fig, (axA, axB, axC) = plt.subplots(1, 3, figsize=(15.6, 6.9),
                                        gridspec_kw={"width_ratios":
                                                     [1.0, 1.12, 1.12]})
    L = d["main"]
    dat = L["dat"]
    m = dat.interior()

    # ------------------------------------------------------------- panel (a)
    axA.grid(True, zorder=0)
    axA.set_axisbelow(True)
    axA.plot(dat.x1[m], L["lev1"][0][m], "o", color=TEAL, mfc=PAPER, mew=1.7,
             ms=7, zorder=4, label=r"$\gamma_1$, rung 0 (Raoult vapour)")
    axA.plot(dat.x1[m], L["lev1"][3][m], "x", color=TEAL, mew=1.8, ms=7,
             zorder=5, label=r"$\gamma_1$, rung 3 (all corrections)")
    axA.plot(dat.x1[m], L["lev2"][0][m], "s", color=RUST, mfc=PAPER, mew=1.7,
             ms=6.5, zorder=4, label=r"$\gamma_2$, rung 0")
    axA.plot(dat.x1[m], L["lev2"][3][m], "+", color=RUST, mew=1.8, ms=9,
             zorder=5, label=r"$\gamma_2$, rung 3")
    axA.axhline(1.0, color=GRAPHITE, lw=1.0, ls=":", zorder=2)
    axA.set_yscale("log")
    axA.set_xlim(0, 1)
    axA.set_ylim(0.88, 18.0)
    axA.set_xlabel("$x_1$   (ethanol)")
    axA.set_ylabel(r"$\gamma_i$  from the measurements")
    axA.text(0.80, 1.44, r"$\gamma_1$   ethanol", fontsize=11.5, color=TEAL,
             ha="center", va="center", zorder=8,
             bbox=dict(boxstyle="round,pad=0.20", fc=PAPER, ec="none",
                       alpha=0.88))
    axA.text(0.25, 1.44, r"$\gamma_2$   water", fontsize=11.5, color=RUST,
             ha="center", va="center", zorder=8,
             bbox=dict(boxstyle="round,pad=0.20", fc=PAPER, ec="none",
                       alpha=0.88))
    axA.set_title("(a)  the whole correction, at the scale\n"
                  r"$\gamma$ is actually read at", fontsize=11.6, pad=6)

    # ------------------------------------------------- panels (b) and (c)
    for ax, key, steps, net, comp, lab in (
            (axB, 1, L["step1"], L["net1"], dat.c1.name, r"\gamma_1"),
            (axC, 2, L["step2"], L["net2"], dat.c2.name, r"\gamma_2")):
        ax.grid(True, zorder=0)
        ax.set_axisbelow(True)
        ax.axhline(0.0, color=GRAPHITE, lw=1.1, zorder=2)
        order = np.argsort(dat.x1[m])
        xs = dat.x1[m][order]
        for i, (name, col) in enumerate(RUNGS):
            ax.plot(xs, steps[i][m][order], "o-", color=col, lw=2.0, ms=4.5,
                    zorder=4 + i)
        ax.plot(xs, net[m][order], "s--", color=GRAPHITE, lw=2.0, ms=4.5,
                zorder=8)
        ax.set_xlim(0, 1)
        ax.set_xlabel("$x_1$   (ethanol)")
        ax.set_ylabel(f"change in ${lab}$ at each rung  /  per cent")
        ax.set_title(f"({'b' if key == 1 else 'c'})  ${lab}$  ({comp}) — "
                     "each rung on its own", fontsize=11.6, pad=6)

    # direct labels, put at the composition where the curves are furthest
    # apart so that no two of them land on top of one another
    for ax, steps, net in ((axB, L["step1"], L["net1"]),
                           (axC, L["step2"], L["net2"])):
        order = np.argsort(dat.x1[m])
        xs = dat.x1[m][order]
        stack = np.vstack([s[m][order] for s in steps] + [net[m][order]])
        j = int(np.argmax(np.ptp(stack, axis=0)))
        j = int(np.clip(j, 1, len(xs) - 2))
        rows = [(RUNGS[i][0], RUNGS[i][1], stack[i, j]) for i in range(3)]
        rows.append((r"net:  $\Phi_i$ altogether", GRAPHITE, stack[3, j]))
        lo, hi = ax.get_ylim()
        span = hi - lo
        ys = np.array([r[2] for r in rows])
        o = np.argsort(ys)
        placed = ys.astype(float).copy()
        for k in range(1, len(o)):
            a, b = o[k - 1], o[k]
            if placed[b] - placed[a] < 0.115 * span:
                placed[b] = placed[a] + 0.115 * span
        ax.set_ylim(lo, max(hi, placed.max() + 0.09 * span))
        for (txt, col, yv), yl in zip(rows, placed):
            ax.annotate(txt, xy=(xs[j], yv), xytext=(xs[j] + 0.05, yl),
                        ha="left", va="center", fontsize=9.2, color=col,
                        zorder=10,
                        bbox=dict(boxstyle="round,pad=0.20", fc=PAPER,
                                  ec="none", alpha=0.88),
                        arrowprops=dict(arrowstyle="-", color=col, lw=0.9,
                                        shrinkA=1, shrinkB=3))

    s, so = d["s_main"], d["s_other"]
    axA.text(0.985, 0.985,
             "open symbol = rung 0,   x and + = rung 3\n"
             "largest |change|, per cent\n"
             f"          ethanol+water   CHCl$_3$+MEK\n"
             f"          101.3 kPa           15–32 kPa\n"
             f"rung 1   {max(s[0]):5.2f}                 {max(so[0]):5.2f}\n"
             f"rung 2   {max(s[1]):5.2f}                 {max(so[1]):5.2f}\n"
             f"rung 3   {max(s[2]):5.2f}                 {max(so[2]):5.2f}\n"
             f"net       {max(s[3]):5.2f}                 {max(so[3]):5.2f}",
             transform=axA.transAxes, ha="right", va="top", fontsize=8.6,
             color=GRAPHITE, family="DejaVu Sans Mono", linespacing=1.5,
             zorder=9,
             bbox=dict(boxstyle="round,pad=0.30", fc=PAPER, ec=MIST, lw=0.9,
                       alpha=0.95))

    fig.suptitle(r"What each vapour-phase correction is actually worth:  "
                 r"$\gamma_i = y_i \Phi_i P / (x_i P_i^{\rm sat})$, "
                 r"one piece of $\Phi_i$ at a time",
                 fontsize=14.2, y=0.985)
    fig.text(0.5, 0.018, wrapped(
        "DATA: ethanol (1) + water (2), 21 points, 101.3 kPa, 351-368 K, "
        "doi:10.1021/je2008704.  Contrast set: chloroform + 2-butanone, "
        "22 points, 303.15 K, 15-32 kPa, doi:10.1021/je060150a.  Nothing "
        "here is fitted: every number is the measured $x$, $y$, $P$, $T$ put "
        "through the definition.\n"
        "$\\hat\\phi_i$ and $\\phi_i^{\\rm sat}$ from the two-term "
        "virial equation with Pitzer-Curl / Tsonopoulos $B(T)$ and "
        "$k_{12} = 0$; $v_i^L$ constant, from vlekit.data.LIBRARY.  THAT "
        "CORRELATION IS FOR NON-POLAR AND SLIGHTLY POLAR SPECIES: water and "
        "ethanol associate, the polar term is missing, and the "
        "$\\hat\\phi$ used here is itself uncertain by more than the "
        "Poynting rung it is being compared against. Read the figure for the "
        "size of each rung, not for the fourth decimal place of any one of "
        "them.", 168),
        ha="center", va="bottom", fontsize=9.6, color=SLATE, linespacing=1.6)
    fig.tight_layout(rect=(0.005, 0.245, 0.995, 0.930))
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = analyse()
    for tag, key in (("main", MAIN), ("other", CONTRAST)):
        L = d[tag]
        dat = L["dat"]
        m = dat.interior()
        print(f"{dat.label}   doi:{D.DOIS[key]}   {len(dat)} points, "
              f"P = {dat.P.min():.2f}-{dat.P.max():.2f} kPa, "
              f"T = {dat.T.min():.2f}-{dat.T.max():.2f} K")
        ph1, ph2 = L["phi"]
        ps1, ps2 = L["phisat"]
        pf1, pf2 = L["pf"]
        B11, B22, B12 = L["B"]
        print(f"    B11 {1e6*np.mean(B11):9.1f}  B22 {1e6*np.mean(B22):9.1f}  "
              f"B12 {1e6*np.mean(B12):9.1f} cm^3/mol (mean over the set)")
        print(f"    phi_hat_1 {ph1.min():.5f}-{ph1.max():.5f}   "
              f"phi_1^sat {float(np.min(ps1)):.5f}-{float(np.max(ps1)):.5f}   "
              f"Poynting_1 {float(np.min(pf1)):.6f}-{float(np.max(pf1)):.6f}")
        print(f"    phi_hat_2 {ph2.min():.5f}-{ph2.max():.5f}   "
              f"phi_2^sat {float(np.min(ps2)):.5f}-{float(np.max(ps2)):.5f}   "
              f"Poynting_2 {float(np.min(pf2)):.6f}-{float(np.max(pf2)):.6f}")
        s = summarise(L)
        names = ["rung 1  x phi_hat", "rung 2  / phi^sat", "rung 3  / Poynting",
                 "NET     all three"]
        for nm, (a, b) in zip(names, s):
            print(f"    {nm:20s} max |change| in gamma1 {a:7.3f} %   "
                  f"in gamma2 {b:7.3f} %")
        g1c, g2c = L["lev1"][0], L["lev2"][0]
        g1f, g2f = L["lev1"][3], L["lev2"][3]
        print(f"    gamma1 crude {np.nanmin(g1c[m]):.4f}-"
              f"{np.nanmax(g1c[m]):.4f}  ->  fully corrected "
              f"{np.nanmin(g1f[m]):.4f}-{np.nanmax(g1f[m]):.4f}")
        print(f"    gamma2 crude {np.nanmin(g2c[m]):.4f}-"
              f"{np.nanmax(g2c[m]):.4f}  ->  fully corrected "
              f"{np.nanmin(g2f[m]):.4f}-{np.nanmax(g2f[m]):.4f}")
        print()
    s = d["s_main"]
    print("the point of the figure, in one line: rungs 1 and 2 are each worth "
          f"up to {max(s[0]):.2f} % and {max(s[1]):.2f} % and they have "
          f"opposite signs, so the net is {max(s[3]):.2f} %; rung 3 is worth "
          f"{max(s[2]):.2f} % and can be dropped at almost any pressure this "
          "course works at.")
    for p in write(build(d), SLUG):
        print("wrote", p)
