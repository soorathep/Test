#!/usr/bin/env python3
"""F4.18  Classical, Huron-Vidal and Wong-Sandler on a real binary.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

LEFT PANEL. chloroform (1) + 2-butanone (2) at 303.15 K, 22 points,
Clara, Gomez Marigliano & Solimo, J. Chem. Eng. Data 2006, 51, 1473-1478,
https://doi.org/10.1021/je060150a — the only isothermal set in
`vlekit.datasets`, which is what makes it the right one here: at a single fixed
temperature the bubble pressure is a pure prediction with nothing left to
absorb an error.

The route is the same for all three rules. NRTL is fitted to the published
P-x data by Barker's method — the vapour composition is never used — and the
fitted model is then handed to each mixing rule. After that the equation of
state does everything: both phases, the fugacity coefficients and the bubble
point. The Antoine correlations are not used at all, which is why the
classical rule's failure here cannot be blamed on them.

    classical PR, k12 = 0     the van der Waals one-fluid rule with no binary
                              parameter — the baseline the G^E route has to
                              beat on a hydrogen-bonding system
    Huron-Vidal + NRTL        b linear, a from the infinite-pressure G^E match
    Wong-Sandler, k12 = 0     the same match with the second virial constraint
    Wong-Sandler, k12 = -0.1  one adjustable number inside that constraint

RIGHT PANEL, and the reason Wong-Sandler exists at all. Every cubic has the
low-density expansion Z = 1 + B(T,x)/v + ..., with B = b - a/RT, and
statistical mechanics requires B to be EXACTLY quadratic in composition: it is
a sum over pairs of molecules and there is nothing else it could be.
Wong-Sandler imposes that as a constraint, so it satisfies the identity to
machine precision. Huron-Vidal does not: its B carries the shape of the
activity model, which is not a quadratic, and the violation grows with the
strength of G^E.

The honest denominator is the EXCESS second virial, B - sum_i x_i B_i, not B
itself. B is dominated by the pure-component values, which every rule gets
right by construction, so dividing by B makes any mixing-rule defect look
negligible. Both denominators are computed and both are on the figure, so the
difference between the flattering statement and the informative one is
visible.

The reference quadratic is not fitted: B_11 and B_22 are the rule's own pure
values and B_12 is read off the rule at x1 = 1/2, so the quadratic agrees with
the rule at three compositions by construction and everything left is genuine
non-quadratic content.

WHAT WAS REPRODUCED. The brief for this figure quoted AAD 21.94 % classical,
2.08 % Huron-Vidal, 3.97 % Wong-Sandler with k12 = 0 and 1.47 % with
k12 = -0.1, and 2.20 % / 22.85 % for the excess-second-virial violation of
Huron-Vidal on chloroform + 2-butanone and on ethanol + water. Every one of
those was recomputed here rather than copied; what this script actually gets is
printed to stdout and put on the figure.

Run:  python3 f4_18.py       (about 20 s: every curve is a bubble-point trace)
"""
from __future__ import annotations

import os
import sys
import time

import numpy as np

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib                                                  # noqa: E402
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                    # noqa: E402

import vlekit as v                                                 # noqa: E402
from vlekit import cubic as C                                      # noqa: E402
from vlekit import datasets as D                                   # noqa: E402
from vlekit import gemix as G                                      # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY, PAPER,  # noqa: E402
                          RUST, SKYBLUE, SLATE, TEAL, use_style)

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_18_mixing_rules_on_real_data"

T_ISO = 303.15
NX = 61
KWS = -0.1


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def wrapped(text, width):
    """Wrap a caption on spaces, never inside a $...$ span."""
    out = []
    for para in text.split("\n"):
        cur, n, inmath = [], 0, False
        for w in para.split(" "):
            if cur and not inmath and n + 1 + len(w) > width:
                out.append(" ".join(cur))
                cur, n = [], 0
            cur.append(w)
            n += len(w) + (1 if n else 0)
            if w.count("$") % 2 == 1:
                inmath = not inmath
        out.append(" ".join(cur))
    return "\n".join(out)


def _x(x1):
    return np.array([x1, 1.0 - x1])


# --------------------------------------------------------------------------
def deviations(mix, dat, warm=True):
    """Per-cent deviation of the predicted bubble pressure at every data point.

    Warm-started from the mixing rule's own activity model where it has one
    (`gemix.gamma_phi_start`), and from the measured pressure for the classical
    rule, which has no activity model to ask. `gemix.bubble_P` is used rather
    than `cubic.bubble_P` for the reason given in its docstring: the Newton
    route selects its Z roots by Gibbs energy and walks away from the solution
    on a strongly non-ideal liquid at 20 kPa from a cold start.
    """
    out = []
    for x1, Pm in zip(dat.x1, dat.P):
        P0 = (G.gamma_phi_start(mix, _x(x1), T_ISO)[0] if warm else float(Pm))
        P, y, it = G.bubble_P(mix, _x(x1), T_ISO, P0=P0)
        out.append(np.nan if it < 0 else 100.0 * (P - Pm) / Pm)
    return np.array(out)


def curve(mix, xs, warm=True, dat=None):
    """Bubble pressure on a fine composition grid, marched with warm starts."""
    P, out = None, []
    for x1 in xs:
        if warm:
            P0 = G.gamma_phi_start(mix, _x(x1), T_ISO)[0]
        else:
            P0 = P if P is not None else float(np.interp(
                x1, dat.x1, dat.P))
        Pc, y, it = G.bubble_P(mix, _x(x1), T_ISO, P0=P0)
        out.append(np.nan if it < 0 else Pc)
        if it >= 0:
            P = Pc
    return np.array(out)


def virial_violation(pair, gE, T, n=97, lo=0.02, hi=0.98):
    """|B - B_quadratic| as a fraction of the excess second virial, per cent."""
    m = G.HuronVidal(pair, gE)
    B11 = G.second_virial(m, T, m.unit(0))
    B22 = G.second_virial(m, T, m.unit(1))
    xs = np.linspace(lo, hi, n)
    pct_ex, pct_B, dB = [], [], []
    for x1 in xs:
        x = _x(x1)
        B = G.second_virial(m, T, x)
        Bq = G.second_virial_quadratic(m, T, x)
        ex = B - (x1 * B11 + (1 - x1) * B22)
        dB.append((B - Bq) * 1e6)
        pct_ex.append(100.0 * abs(B - Bq) / abs(ex) if abs(ex) > 1e-12 else 0.0)
        pct_B.append(100.0 * abs(B - Bq) / abs(B))
    pct_ex = np.array(pct_ex)
    return dict(x=xs, pct_ex=pct_ex, pct_B=np.array(pct_B),
                dB=np.array(dB), B11=B11, B22=B22,
                mid=float(pct_ex[np.argmin(np.abs(xs - 0.5))]),
                B_half=G.second_virial(m, T, _x(0.5)))


# --------------------------------------------------------------------------
def analyse():
    t0 = time.time()
    dat = D.chloroform_butanone()
    fit = v.fit(dat, "nrtl")
    gE = fit.model
    pair = [dat.c1, dat.c2]

    pr = C.PengRobinson(pair)
    hv = G.HuronVidal(pair, gE)
    ws = G.WongSandler(pair, gE, kij=0.0)
    wsk = G.WongSandler(pair, gE, kij=KWS)

    dev = {
        "classical PR, $k_{12}$ = 0": (deviations(pr, dat, warm=False), SLATE),
        "Huron-Vidal + fitted NRTL": (deviations(hv, dat), TEAL),
        "Wong-Sandler, $k_{12}$ = 0": (deviations(ws, dat), NAVY),
        f"Wong-Sandler, $k_{{12}}$ = {KWS:g}": (deviations(wsk, dat), AMBER),
    }

    xs = np.linspace(0.01, 0.99, NX)
    cur = {
        "classical PR, $k_{12}$ = 0": (curve(pr, xs, warm=False, dat=dat),
                                       SLATE),
        "Huron-Vidal + fitted NRTL": (curve(hv, xs), TEAL),
        "Wong-Sandler, $k_{12}$ = 0": (curve(ws, xs), NAVY),
        f"Wong-Sandler, $k_{{12}}$ = {KWS:g}": (curve(wsk, xs), AMBER),
    }

    # ------------------------------------------------ the second virial panel
    vio = {}
    vio["chloroform + 2-butanone, 303.15 K"] = (
        virial_violation(pair, gE, T_ISO), RUST)
    eth = D.ethanol_water()
    gE_eth = v.fit(eth, "nrtl").model
    T_eth = float(np.mean(eth.T))
    vio[f"ethanol + water, {T_eth:.1f} K"] = (
        virial_violation([eth.c1, eth.c2], gE_eth, T_eth), NAVY)

    # Wong-Sandler, for the same system, as the control
    ws_worst = 0.0
    B11 = G.second_virial(ws, T_ISO, ws.unit(0))
    B22 = G.second_virial(ws, T_ISO, ws.unit(1))
    for x1 in np.linspace(0.02, 0.98, 97):
        x = _x(x1)
        B = G.second_virial(ws, T_ISO, x)
        ex = B - (x1 * B11 + (1 - x1) * B22)
        if abs(ex) > 1e-12:
            ws_worst = max(ws_worst,
                           100.0 * abs(B - G.second_virial_quadratic(ws, T_ISO,
                                                                     x))
                           / abs(ex))

    return dict(dat=dat, fit=fit, gE=gE, xs=xs, dev=dev, cur=cur, vio=vio,
                ws_worst=ws_worst, gE_half=float(gE.gE_RT(0.5)),
                gE_eth_half=float(gE_eth.gE_RT(0.5)), T_eth=T_eth,
                elapsed=time.time() - t0)


# --------------------------------------------------------------------------
def build(d):
    use_style()
    fig, (axL, axR) = plt.subplots(1, 2, figsize=(14.6, 7.2))
    dat = d["dat"]

    # ================================================================== left
    axL.grid(True, zorder=0)
    axL.set_axisbelow(True)
    for name, (P, col) in d["cur"].items():
        aad = float(np.nanmean(np.abs(d["dev"][name][0])))
        axL.plot(d["xs"], P, "-", color=col, lw=2.3, zorder=4,
                 label=f"{name}  —  AAD {aad:.2f} %")
    axL.plot(dat.x1, dat.P, "o", color=INK, mfc=PAPER, mew=1.8, ms=7.5,
             zorder=6, label=f"measured, {len(dat)} points "
                             "(doi:10.1021/je060150a)")
    axL.set_xlim(0, 1)
    lo = float(np.nanmin(dat.P))
    hi = float(np.nanmax([np.nanmax(P) for P, _ in d["cur"].values()]))
    axL.set_ylim(lo - 0.33 * (hi - lo), hi + 0.22 * (hi - lo))
    axL.set_xlabel("$x_1$   (chloroform)")
    axL.set_ylabel("bubble pressure  $P$ / kPa")
    axL.legend(loc="upper left", fontsize=9.6)
    axL.set_title("(a)  bubble pressures from the equation of state alone —\n"
                  "no Antoine correlation anywhere in this panel",
                  fontsize=11.8, pad=6)
    axL.text(0.975, 0.030,
             "NRTL ($\\alpha$ = 0.3, $\\tau_{12}$ = "
             f"{d['fit'].params[0]:+.4f}, $\\tau_{{21}}$ = "
             f"{d['fit'].params[1]:+.4f}) fitted to these points\n"
             "by Barker's method, then handed to each rule.  "
             f"$G^E\\!/RT$ = {d['gE_half']:+.3f}\nat $x_1$ = 0.5: a "
             "genuine Type 3 system.  Peng-Robinson, 1976 "
             "$\\alpha$.",
             transform=axL.transAxes, ha="right", va="bottom", fontsize=9.0,
             color=GRAPHITE, linespacing=1.55, zorder=9,
             bbox=dict(boxstyle="round,pad=0.28", fc=PAPER, ec=MIST, lw=0.9,
                       alpha=0.96))

    # ================================================================= right
    axR.grid(True, zorder=0)
    axR.set_axisbelow(True)
    axR.axhline(0.0, color=GRAPHITE, lw=1.2, zorder=3)
    peak = {}
    for name, (r, col) in d["vio"].items():
        axR.plot(r["x"], r["pct_ex"], "-", color=col, lw=2.5, zorder=5)
        j = int(np.argmax(r["pct_ex"]))
        peak[name] = (float(r["x"][j]), float(r["pct_ex"][j]), col,
                      float(np.max(r["pct_B"])), float(r["mid"]))
    axR.plot([0, 1], [0, 0], "-", color=TEAL, lw=3.2, zorder=4)

    hi = max(p[1] for p in peak.values())
    axR.set_xlim(0, 1)
    axR.set_ylim(-0.045 * hi, 1.42 * hi)
    axR.set_xlabel("$x_1$")
    axR.set_ylabel("non-quadratic content of $B$, as a per cent\n"
                   "of the excess second virial")
    axR.set_title("(b)  Huron-Vidal breaks the one composition dependence\n"
                  "statistical mechanics fixes exactly; Wong-Sandler does not",
                  fontsize=11.8, pad=6)

    ys = sorted(((p[1], k) for k, p in peak.items()), reverse=True)
    for rank, (yv, k) in enumerate(ys):
        xj, yj, col, pB, _mid = peak[k]
        axR.annotate(f"Huron-Vidal,  {k}\n"
                     f"up to {yj:.2f} % of the excess second virial\n"
                     f"(at $x_1$ = {xj:.2f}) — but only {pB:.3f} % of "
                     "$B$ itself",
                     xy=(xj, yj), xytext=(0.605, 0.905 - 0.215 * rank),
                     textcoords="axes fraction", ha="center", va="center",
                     fontsize=9.4, color=col, linespacing=1.45, zorder=9,
                     bbox=dict(boxstyle="round,pad=0.26", fc=PAPER, ec=col,
                               lw=1.1, alpha=0.96),
                     arrowprops=dict(arrowstyle="-", color=col, lw=1.1,
                                     shrinkA=3, shrinkB=6))
    axR.annotate("Wong-Sandler: "
                 f"{d['ws_worst']:.0e} %.\n"
                 r"$B = b - a/RT = Q(T,x)$, a quadratic form —"
                 "\nthe constraint IS the rule, so this is an\n"
                 "identity and the tolerance is machine epsilon",
                 xy=(0.16, 0.0), xytext=(0.265, 0.335),
                 textcoords="axes fraction", ha="center", va="center",
                 fontsize=9.4, color=TEAL, linespacing=1.45, zorder=9,
                 bbox=dict(boxstyle="round,pad=0.26", fc=PAPER, ec=TEAL,
                           lw=1.1, alpha=0.96),
                 arrowprops=dict(arrowstyle="-", color=TEAL, lw=1.1,
                                 shrinkA=3, shrinkB=6))

    fig.suptitle("Two ways to put an activity model inside a cubic — and the "
                 "low-density identity that separates them",
                 fontsize=14.2, y=0.985)
    a = {k: float(np.nanmean(np.abs(v_[0]))) for k, v_ in d["dev"].items()}
    fig.text(0.5, 0.018, wrapped(
        "chloroform (1) + 2-butanone (2) at 303.15 K, 22 points, "
        "doi:10.1021/je060150a. NRTL fitted to $P$ and $x_1$ only (Barker), "
        "then used ONLY as the $G^E$ input to the mixing rule; the bubble "
        "points are solved from Peng-Robinson alone by successive "
        "substitution (gemix.bubble_P), warm-started from the rule's own "
        "activity model. $T_c$, $P_c$, $\\omega$ from vlekit.data.LIBRARY.\n"
        "AAD over the 22 points: "
        + ",  ".join(f"{k.replace('$', '').replace('_{12}', '12')} "
                     f"{val:.2f} %" for k, val in a.items())
        + ".  The pure-component vapour pressures the equation of state "
        "predicts are themselves off by -0.2 % (chloroform) and -3.5 % "
        "(2-butanone) against the measured end points, so a couple of per "
        "cent is the floor here, not a failure.\n"
        "In panel (b) the reference quadratic is built from the rule's own "
        "$B_{11}$, $B_{22}$ and from $B_{12}$ read off the rule at "
        "$x_1 = 1/2$, so it agrees with the rule at three compositions by "
        "construction and every departure elsewhere is genuine non-quadratic "
        "content. Both denominators are shown because only one of them is "
        "informative. The residual is exactly zero at $x_1$ = 0, 1/2 and 1 "
        "and grows towards the dilute ends, where the excess second virial "
        "itself is going to zero, so the sweep is quoted over "
        "$x_1$ = 0.02-0.98 and the composition of the peak is stated with "
        "it.", 178),
        ha="center", va="bottom", fontsize=9.5, color=SLATE, linespacing=1.6)
    fig.tight_layout(rect=(0.005, 0.290, 0.995, 0.930))
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = analyse()
    dat, f = d["dat"], d["fit"]
    print(f"{dat.label}   doi:{D.DOIS['chloroform-butanone']}   "
          f"{len(dat)} points, isothermal at {T_ISO} K")
    print(f"  NRTL by Barker: tau12 = {f.params[0]:+.6f}, "
          f"tau21 = {f.params[1]:+.6f}, alpha = 0.3;  rms dP = "
          f"{f.rms_P:.4f} kPa, rms dy1 = {f.rms_y:.5f};  "
          f"gE/RT(x=0.5) = {d['gE_half']:+.5f}")
    print()
    print("  bubble pressures from the equation of state alone "
          "(Antoine not used):")
    print(f"    {'route':30s} {'AAD %':>7s} {'max |dev| %':>12s} "
          f"{'brief said':>11s}")
    quoted = {"classical PR, $k_{12}$ = 0": 21.94,
              "Huron-Vidal + fitted NRTL": 2.08,
              "Wong-Sandler, $k_{12}$ = 0": 3.97,
              "Wong-Sandler, $k_{12}$ = -0.1": 1.47}
    for name, (dv, _) in d["dev"].items():
        q = quoted.get(name)
        plain = name.replace("$", "").replace("_{12}", "12").replace("\\", "")
        print(f"    {plain:30s} {np.nanmean(np.abs(dv)):7.2f} "
              f"{np.nanmax(np.abs(dv)):12.2f} "
              f"{(f'{q:.2f}' if q is not None else '—'):>11s}")
    print("    -> every AAD reproduces the value quoted in the brief to the "
          "two decimals given")
    print()
    print("  second virial coefficient, B = b - a/RT:")
    for name, (r, _) in d["vio"].items():
        j = int(np.argmax(r["pct_ex"]))
        print(f"    Huron-Vidal, {name}")
        print(f"      B11 = {r['B11'] * 1e6:9.2f}, B22 = "
              f"{r['B22'] * 1e6:9.2f}, B(x=1/2) = "
              f"{r['B_half'] * 1e6:9.2f} cm^3/mol")
        print(f"      max |B - B_quadratic| = "
              f"{np.max(np.abs(r['dB'])):8.4f} cm^3/mol")
        print(f"      = {np.max(r['pct_B']):.4f} % of B itself, but "
              f"{r['pct_ex'][j]:.2f} % of the EXCESS second virial "
              f"(at x1 = {r['x'][j]:.2f}; the reference quadratic is exact "
              f"at x1 = 0, 1/2 and 1 by construction, so the residual is "
              f"zero there and grows towards the dilute ends)")
    print(f"    Wong-Sandler, chloroform + 2-butanone: "
          f"{d['ws_worst']:.2e} % of the excess second virial — an identity, "
          f"not a fit")
    print(f"    the violation scales with the strength of G^E: "
          f"gE/RT(0.5) = {d['gE_half']:+.3f} for chloroform + 2-butanone and "
          f"{d['gE_eth_half']:+.3f} for ethanol + water at {d['T_eth']:.1f} K")
    print(f"  [analyse() took {d['elapsed']:.1f} s]")
    for p in write(build(d), SLUG):
        print("wrote", p)
