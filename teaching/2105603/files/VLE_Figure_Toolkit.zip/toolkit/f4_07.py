#!/usr/bin/env python3
"""F4.7  The bootstrap cloud, the linearised ellipse, and the rectangle a pair
        of error bars actually describes.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

`vlekit.plots.bootstrap_plot` draws the cloud of refitted parameter pairs. Two
things are added here, and both are quantitative:

  * the 95 % joint confidence ellipse implied by the covariance matrix of the
    single Barker fit — the thing a regression package reports;
  * the rectangle spanned by the two marginal 95 % bootstrap intervals — the
    thing a reader constructs when the parameters are quoted as
    "tau12 = a +/- b, tau21 = c +/- d".

The area ratio and the fraction of replicates the ellipse actually contains are
computed from the run and printed on the figure, so the comparison is a
measurement rather than a claim.

Run:  python3 f4_07.py
"""
import os
import sys

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Ellipse, Rectangle

sys.path.insert(0, "/home/claude/vlekit")
import vlekit as v                                              # noqa: E402
from vlekit import plots as pl                                  # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,     # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, newfig)

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_07_bootstrap_confidence_region"

TRUE = [0.35, 0.62]
T_SET = 328.15
NPT = 9
NOISE = {"y": 0.008, "P": 0.25, "x": 0.001}
SEED = 3
N_BOOT = 600
CHI2_95_2DOF = 5.991


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def make():
    c1, c2 = v.component("2-propanol"), v.component("mek")
    dat = v.generate(v.NRTL(TRUE), np.linspace(0.05, 0.95, NPT), T=T_SET,
                     c1=c1, c2=c2, noise=NOISE, seed=SEED,
                     label="small, realistic dataset")
    boot = v.bootstrap(dat, "nrtl", n_boot=N_BOOT, seed=2)
    return dat, boot


def stats(boot):
    B, base = boot["samples"], boot["base"]
    cov = base.cov
    d = B - base.params
    md2 = np.einsum("ij,jk,ik->i", d, np.linalg.inv(cov), d)
    frac = float(np.mean(md2 <= CHI2_95_2DOF))
    lo, hi = boot["ci95"]
    rect_area = float((hi[0] - lo[0]) * (hi[1] - lo[1]))
    ev = np.linalg.eigvalsh(cov)
    ell_area = float(np.pi * CHI2_95_2DOF * np.sqrt(ev[0] * ev[1]))
    return {"frac_in_ellipse": frac, "rect_area": rect_area,
            "ellipse_area": ell_area, "ratio": ell_area / rect_area,
            "ci95": (lo, hi), "boot_std": B.std(axis=0, ddof=1),
            "lin_std": base.stderr, "corr": float(boot["corr"][0, 1])}


def build(boot, st):
    fig, ax = newfig(7.8, 6.2)
    pl.bootstrap_plot(boot, truth=TRUE, ax=ax)
    base = boot["base"]
    lo, hi = st["ci95"]

    # ---- the rectangle two separate error bars describe
    ax.add_patch(Rectangle((lo[0], lo[1]), hi[0] - lo[0], hi[1] - lo[1],
                           facecolor=AMBER, alpha=0.13, edgecolor=AMBER,
                           lw=1.8, ls=":", zorder=1,
                           label="rectangle from the two marginal 95 % "
                                 "intervals"))

    # ---- the 95 % ellipse the covariance matrix implies
    w, V = np.linalg.eigh(base.cov)
    o = np.argsort(w)[::-1]
    w, V = w[o], V[:, o]
    ax.add_patch(Ellipse(tuple(base.params),
                         2 * np.sqrt(CHI2_95_2DOF * w[0]),
                         2 * np.sqrt(CHI2_95_2DOF * w[1]),
                         angle=np.degrees(np.arctan2(V[1, 0], V[0, 0])),
                         facecolor="none", edgecolor=RUST, lw=2.2, ls="--",
                         zorder=6,
                         label="95 % ellipse from the covariance matrix"))

    names = base.model.param_labels
    ax.set_xlabel(names[0])
    ax.set_ylabel(names[1])
    span_x = hi[0] - lo[0]
    span_y = hi[1] - lo[1]
    ax.set_xlim(lo[0] - 0.35 * span_x, hi[0] + 0.35 * span_x)
    ax.set_ylim(lo[1] - 1.05 * span_y, hi[1] + 0.85 * span_y)

    h, l = ax.get_legend_handles_labels()
    order = [l.index(x) for x in
             ["bootstrap replicates", "best fit", "generating value",
              "rectangle from the two marginal 95 % intervals",
              "95 % ellipse from the covariance matrix"] if x in l]
    ax.legend([h[i] for i in order], [l[i] for i in order],
              loc="upper right", fontsize=10.5, labelspacing=0.6)

    ax.set_title(f"NRTL parameters from {N_BOOT} residual-resampling "
                 f"bootstraps of {NPT} points", fontsize=13)
    ax.text(0.015, 0.020,
            f"bootstrap correlation  $r$ = {st['corr']:+.3f}\n"
            f"ellipse area = {100 * st['ratio']:.0f} % of the rectangle: two "
            f"separate\n"
            f"error bars claim a region {1 / st['ratio']:.1f}$\\times$ larger "
            f"than the fit\n"
            f"ever occupied.  The ellipse holds "
            f"{100 * st['frac_in_ellipse']:.1f} % of the\n"
            f"replicates and is "
            f"{100 * (st['lin_std'][0] / st['boot_std'][0] - 1):.0f} % wider "
            f"in $\\tau_{{12}}$ than the cloud",
            transform=ax.transAxes, ha="left", va="bottom", fontsize=10.5,
            color=INK, linespacing=1.55,
            bbox=dict(boxstyle="round,pad=0.38", fc=PAPER, ec=MIST, lw=1.0,
                      alpha=0.95))
    fig.tight_layout()
    return fig


if __name__ == "__main__":
    dat, boot = make()
    st = stats(boot)
    base = boot["base"]
    print(f"data: n = {dat.n}, T = {T_SET} K, "
          f"P = {dat.P.min():.2f}-{dat.P.max():.2f} kPa")
    print(f"best fit  tau12 = {base.params[0]:+.4f}, "
          f"tau21 = {base.params[1]:+.4f}   (generating {TRUE})")
    print(f"linearised standard errors : {np.round(st['lin_std'], 4)}")
    print(f"bootstrap standard devs    : {np.round(st['boot_std'], 4)}")
    print(f"bootstrap 95 % intervals   : "
          f"tau12 [{st['ci95'][0][0]:+.4f}, {st['ci95'][1][0]:+.4f}], "
          f"tau21 [{st['ci95'][0][1]:+.4f}, {st['ci95'][1][1]:+.4f}]")
    print(f"bootstrap correlation      : {st['corr']:+.4f}")
    print(f"ellipse area / rectangle   : {st['ratio']:.4f}")
    print(f"replicates inside ellipse  : {100 * st['frac_in_ellipse']:.1f} %")
    for p in write(build(boot, st), SLUG):
        print("wrote", p)
