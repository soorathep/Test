#!/usr/bin/env python3
"""F4.21  K values, relative volatility, and what a constant alpha costs.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

WHY THIS FIGURE EXISTS. Everything before it produces gamma. Nothing before it
says what gamma is FOR. The engineering output of the whole module is two
numbers:

    K_i = y_i / x_i = gamma_i P_i^sat / P        (the gamma-phi route, Phi = 1)
    alpha_12 = K_1 / K_2

and the second one is what a column is sized on. A student who can regress NRTL
but cannot say what alpha does to a stage count has not finished the module.

THE TWO SYSTEMS are chosen to be opposite cases of the same calculation.

    benzene + toluene, 101.33 kPa    alpha moves from 2.33 to 2.63 across the
    doi:10.1016/j.fluid.2013.12.002  whole composition range — a factor of
                                     1.13. Constant alpha is very nearly true.

    ethanol + water, 101.3 kPa       alpha runs from 12.6 at infinite dilution
    doi:10.1021/je2008704            to 1 at the azeotrope and below 1 past it:
                                     a factor of 13.6, and a reversal of which
                                     component is the volatile one.

Both K and alpha are shown twice: as markers computed straight from the
MEASURED x and y — K_1 = y_1/x_1 needs no model at all — and as curves from
NRTL fitted to the same data by Barker's method. Where they differ, the model
is wrong, not the data.

THE COST OF THE SHORTCUT. Fenske gives the minimum number of equilibrium
stages, at total reflux, IF alpha is constant. The honest comparison is against
stepping the stages off one at a time with the real, composition-dependent
alpha — which at total reflux is just y_n+1 = x_n, so the stepping needs no
extra assumption beyond the model itself. Panel (c) is that comparison, in
stages, because "a number of stages" is what a student will be asked for.

For benzene + toluene the shortcut costs 0.09 of a stage at worst. For ethanol
+ water it is short by 2.2 stages at x_D = 0.81 and by 4.1 at x_D = 0.84, and
as the azeotrope is approached the true count diverges while
Fenske returns a finite number and no warning at all. That last property is the
one worth remembering: the shortcut does not fail loudly.

Run:  python3 f4_21.py       (a few seconds: the stage stepping is a
                              bubble-point solve per stage per specification)
"""
from __future__ import annotations

import os
import sys
import time

import numpy as np

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib                                                  # noqa: E402
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                    # noqa: E402
from matplotlib.lines import Line2D                                # noqa: E402
from scipy.optimize import brentq                                  # noqa: E402

import vlekit as v                                                 # noqa: E402
from vlekit import datasets as D                                   # noqa: E402
from vlekit.regress import bubble_T                                # noqa: E402
from vlekit.plots import (GRAPHITE, MIST, NAVY, PAPER, RUST,  # noqa: E402
                          SLATE, TEAL, use_style)

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_21_kvalues_and_relative_volatility"

#: (dataset, colour, bottom spec x_B, the x_D to call out on panel (c))
SYSTEMS = [("benzene-toluene", TEAL, 0.05, 0.98),
           ("ethanol-water", NAVY, 0.02, 0.85)]

NX = 241
NSTAGE_CAP = 60          # a stage count above this is reported as unreachable


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def wrapped(text, width):
    """Wrap a caption on spaces, never inside a $...$ span."""
    out = []
    for para in text.split("\n"):
        cur, n, inmath = [], 0, False
        for w in para.split(" "):
            if cur and not inmath and n + 1 + len(w) > width:
                out.append(" ".join(cur))
                cur, n = [], 0
            cur.append(w)
            n += len(w) + (1 if n else 0)
            if w.count("$") % 2 == 1:
                inmath = not inmath
        out.append(" ".join(cur))
    return "\n".join(out)


# --------------------------------------------------------------------------
def k_and_alpha(model, xs, P, c1, c2):
    """K_1, K_2 and alpha_12 along an isobaric bubble curve.

    The temperature is not a free choice: at fixed P it is whatever the bubble
    point says, and it moves by 30 K across benzene + toluene. Evaluating
    P_i^sat at a single 'average' temperature is the commonest way to get alpha
    wrong by more than the activity coefficients ever do.
    """
    T, y = bubble_T(model, xs, np.full_like(xs, P), c1, c2)
    g1, g2 = model.gamma(xs, T)
    Ps1 = np.array([c1.Psat(t) for t in T])
    Ps2 = np.array([c2.Psat(t) for t in T])
    K1 = g1 * Ps1 / P
    K2 = g2 * Ps2 / P
    return dict(T=T, y=y, K1=K1, K2=K2, alpha=K1 / K2)


def measured_k(dat):
    """K and alpha from the measured x and y alone — no model anywhere.

    K_1 = y_1/x_1 is a definition, not a correlation, so these markers are the
    only things on the figure that cannot be argued with.
    """
    m = dat.interior()
    x, y = dat.x1[m], dat.y1[m]
    K1 = y / x
    K2 = (1 - y) / (1 - x)
    return dict(x=x, K1=K1, K2=K2, alpha=K1 / K2)


def y_star(model, x, P, c1, c2):
    """Equilibrium vapour composition over a liquid of composition x."""
    _, y = bubble_T(model, np.atleast_1d(float(x)), np.array([P]), c1, c2)
    return float(y[0])


def stages_stepped(model, xB, xD, P, c1, c2, cap=NSTAGE_CAP):
    """Minimum stages at total reflux, stepped off with the real alpha(x).

    At total reflux the operating line is y = x, so the stage-to-stage march is
    simply: the vapour leaving a stage is in equilibrium with its liquid, and
    it becomes the liquid on the stage above. No constant-alpha assumption
    enters, which is exactly what makes this the right thing to compare Fenske
    against. The fractional last stage is interpolated in the separation
    coordinate ln[x/(1-x)], which is the coordinate Fenske itself is linear in.
    """
    def sep(z):
        return np.log(z / (1 - z))

    x, n = float(xB), 0
    while n < cap:
        y = y_star(model, x, P, c1, c2)
        if y <= x + 1e-12:                     # an azeotrope: no further gain
            return np.inf
        prev, x, n = x, y, n + 1
        if x >= xD:
            return n - 1 + (sep(xD) - sep(prev)) / (sep(x) - sep(prev))
    return np.inf


def fenske(alpha_bar, xB, xD):
    """N_min = ln[(x_D/(1-x_D)) ((1-x_B)/x_B)] / ln alpha_bar."""
    return np.log((xD / (1 - xD)) * ((1 - xB) / xB)) / np.log(alpha_bar)


def alpha_at(model, x, P, c1, c2):
    r = k_and_alpha(model, np.atleast_1d(float(x)), P, c1, c2)
    return float(r["alpha"][0])


def azeotrope_measured(dat):
    """Where the MEASURED y - x changes sign, by linear interpolation.

    Nothing is fitted to find it, so it is the right thing to hold the model's
    azeotrope up against — and on ethanol + water the two do not agree.
    """
    e = dat.y1 - dat.x1
    k = np.where(np.sign(e[:-1]) != np.sign(e[1:]))[0]
    if len(k) != 1:
        return None
    i = int(k[0])
    t = e[i] / (e[i] - e[i + 1])
    return float(dat.x1[i] + t * (dat.x1[i + 1] - dat.x1[i]))


def azeotrope_x(model, P, c1, c2, lo=0.05, hi=0.995):
    """Where y = x on the bubble curve, if it happens at all."""
    def f(z):
        return y_star(model, z, P, c1, c2) - z

    if f(lo) * f(hi) > 0:
        return None
    return float(brentq(f, lo, hi, xtol=1e-9))


# --------------------------------------------------------------------------
def analyse():
    t0 = time.time()
    out = {}
    for name, col, xB, xD_call in SYSTEMS:
        dat = D.load(name)
        fit = v.fit(dat, "nrtl")
        P = float(dat.P[0])
        xs = np.linspace(0.004, 0.996, NX)
        curve = k_and_alpha(fit.model, xs, P, dat.c1, dat.c2)
        meas = measured_k(dat)
        xaz = azeotrope_x(fit.model, P, dat.c1, dat.c2)
        xaz_meas = azeotrope_measured(dat)

        top = (xaz - 0.005) if xaz is not None else 0.985
        xDs = np.linspace(0.20, top, 22)
        rows = []
        for xD in xDs:
            aB = alpha_at(fit.model, xB, P, dat.c1, dat.c2)
            aD = alpha_at(fit.model, xD, P, dat.c1, dat.c2)
            ab = np.sqrt(aB * aD)                  # the textbook geometric mean
            rows.append(dict(xD=float(xD), alpha_B=aB, alpha_D=aD,
                             alpha_bar=float(ab),
                             N_exact=stages_stepped(fit.model, xB, xD, P,
                                                    dat.c1, dat.c2),
                             N_fenske=float(fenske(ab, xB, xD))))
        call = min(rows, key=lambda r: abs(r["xD"] - xD_call))

        out[name] = dict(dat=dat, fit=fit, P=P, colour=col, xs=xs,
                         curve=curve, meas=meas, xaz=xaz, xaz_meas=xaz_meas,
                         xB=xB, rows=rows,
                         call=call,
                         a_lo=float(np.min(curve["alpha"])),
                         a_hi=float(np.max(curve["alpha"])))
    return dict(sys=out, elapsed=time.time() - t0)


# --------------------------------------------------------------------------
def build(d):
    use_style()
    fig, (axA, axB, axC) = plt.subplots(1, 3, figsize=(17.0, 7.6),
                                        gridspec_kw={"width_ratios":
                                                     [1.0, 1.0, 1.42]})
    for a in (axA, axB, axC):
        a.grid(True, zorder=0)
        a.set_axisbelow(True)

    # ============================================================ (a) K values
    for name, col, _xB, _xD in SYSTEMS:
        S = d["sys"][name]
        axA.plot(S["xs"], S["curve"]["K1"], "-", color=col, lw=2.3, zorder=5)
        axA.plot(S["xs"], S["curve"]["K2"], "--", color=col, lw=2.0, zorder=4)
        axA.plot(S["meas"]["x"], S["meas"]["K1"], "o", color=col, mfc=PAPER,
                 mew=1.5, ms=6.0, zorder=6)
        axA.plot(S["meas"]["x"], S["meas"]["K2"], "s", color=col, mfc=PAPER,
                 mew=1.5, ms=5.5, zorder=6)
    axA.axhline(1.0, color=GRAPHITE, lw=1.4, zorder=3)
    axA.set_yscale("log")
    axA.set_xlim(0, 1)
    axA.set_xlabel("$x_1$   (the more volatile component of the pair)")
    axA.set_ylabel("$K_i = y_i / x_i = \\gamma_i P_i^{sat} / P$"
                   "      (solid $K_1$, dashed $K_2$)")
    lo = min(float(np.min(d["sys"][n]["curve"]["K2"]))
             for n, _, _, _ in SYSTEMS)
    hi = max(float(np.max(d["sys"][n]["curve"]["K1"]))
             for n, _, _, _ in SYSTEMS)
    axA.set_ylim(0.35 * lo, 1.6 * hi)
    axA.set_title("(a)  the K value is not a constant —\n"
                  "it moves with composition and with $T$",
                  fontsize=11.6, pad=6)
    handles = [(Line2D([], [], color=d["sys"][n]["colour"], lw=2.4),
                f"{d['sys'][n]['dat'].c1.name} (1) + "
                f"{d['sys'][n]['dat'].c2.name} (2), "
                f"{d['sys'][n]['P']:g} kPa")
               for n, _, _, _ in SYSTEMS]
    handles += [(Line2D([], [], color=GRAPHITE, lw=2.4), "NRTL, fitted"),
                (Line2D([], [], color=GRAPHITE, lw=0, marker="o", mfc=PAPER,
                        mew=1.5, ms=6.0),
                 "from measured $x$, $y$ — no model")]
    axA.legend([h for h, _ in handles], [t for _, t in handles],
               loc="lower right", fontsize=8.8, handlelength=1.8,
               labelspacing=0.42, borderaxespad=0.4, frameon=True,
               facecolor=PAPER, edgecolor=MIST, framealpha=0.95)

    # ==================================================== (b) alpha, the point
    for name, col, _xB, _xD in SYSTEMS:
        S = d["sys"][name]
        axB.plot(S["xs"], S["curve"]["alpha"], "-", color=col, lw=2.6,
                 zorder=5)
        axB.plot(S["meas"]["x"], S["meas"]["alpha"], "o", color=col, mfc=PAPER,
                 mew=1.5, ms=6.0, zorder=6)
        j = int(np.argmin(np.abs(S["xs"] - 0.62)))
        axB.annotate(f"{S['dat'].c1.name} + {S['dat'].c2.name}\n"
                     f"$\\alpha$ from {S['a_hi']:.2f} to {S['a_lo']:.2f} "
                     f"— a factor of {S['a_hi'] / S['a_lo']:.1f}",
                     xy=(S["xs"][j], S["curve"]["alpha"][j]),
                     xytext=(0.30, 0.93 if name == "ethanol-water" else 0.13),
                     textcoords="axes fraction", ha="center",
                     va="top" if name == "ethanol-water" else "bottom",
                     fontsize=9.2, color=col, linespacing=1.45, zorder=9,
                     bbox=dict(boxstyle="round,pad=0.28", fc=PAPER, ec=col,
                               lw=1.0, alpha=0.96),
                     arrowprops=dict(arrowstyle="-", color=col, lw=1.0,
                                     shrinkA=3, shrinkB=4))
        if S["xaz"] is not None:
            axB.plot([S["xaz"]], [1.0], "D", color=RUST, ms=8.5, mfc=PAPER,
                     mew=1.8, zorder=8)
            axB.annotate(f"$\\alpha$ = 1 at $x_1$ = {S['xaz']:.4f}:\n"
                         "the azeotrope, where no number\n"
                         "of stages separates anything.\n"
                         "That is the FITTED model; the\n"
                         f"measured points cross at "
                         f"{S['xaz_meas']:.4f}",
                         xy=(S["xaz"], 1.0), xytext=(0.735, 0.575),
                         textcoords="axes fraction", ha="center", va="center",
                         fontsize=9.2, color=RUST, linespacing=1.45, zorder=9,
                         bbox=dict(boxstyle="round,pad=0.28", fc=PAPER,
                                   ec=RUST, lw=1.0, alpha=0.96),
                         arrowprops=dict(arrowstyle="-", color=RUST, lw=1.1,
                                         shrinkA=3, shrinkB=6))
    axB.axhline(1.0, color=GRAPHITE, lw=1.4, zorder=3)
    axB.set_yscale("log")
    axB.set_xlim(0, 1)
    axB.set_xlabel("$x_1$")
    axB.set_ylabel(r"relative volatility  $\alpha_{12} = K_1 / K_2$")
    axB.set_title("(b)  one system where constant $\\alpha$ is nearly true,\n"
                  "one where it is not true anywhere",
                  fontsize=11.6, pad=6)

    # =========================================== (c) what the shortcut costs
    for name, col, xB, _xD in SYSTEMS:
        S = d["sys"][name]
        xd = np.array([r["xD"] for r in S["rows"]])
        ne = np.array([r["N_exact"] for r in S["rows"]])
        nf = np.array([r["N_fenske"] for r in S["rows"]])
        lab = f"{S['dat'].c1.name} + {S['dat'].c2.name}"
        axC.plot(xd, ne, "-o", color=col, lw=2.4, ms=5.5, mfc=PAPER, mew=1.5,
                 zorder=5)
        axC.plot(xd, nf, "--", color=col, lw=2.0, zorder=4)
        if S["xaz"] is not None:
            axC.axvline(S["xaz"], color=RUST, lw=1.4, ls=":", zorder=3)
        k = int(np.argmin(np.abs(np.array([r["xD"] for r in S["rows"]])
                                 - 0.62)))
        if name == "benzene-toluene":
            axC.text(0.982, 0.030, f"{lab}: the stepped count and Fenske "
                     f"agree to {np.max(np.abs(nf - ne)):.2f} of a stage "
                     "anywhere on this curve",
                     transform=axC.transAxes, color=col, fontsize=9.0,
                     ha="right", va="bottom", zorder=9,
                     bbox=dict(boxstyle="round,pad=0.24", fc=PAPER, ec=col,
                               lw=1.0, alpha=0.96))
        else:
            halo = dict(boxstyle="round,pad=0.16", fc=PAPER, ec="none",
                        alpha=0.92)
            axC.text(xd[-3], nf[-3], "  Fenske,\n  constant "
                     "$\\bar\\alpha$", color=col, fontsize=9.0, ha="left",
                     va="top", linespacing=1.45, zorder=9, bbox=halo)
            axC.text(xd[-5], ne[-5], "stepped with\nthe real "
                     "$\\alpha(x)$  ", color=col, fontsize=9.0, ha="right",
                     va="center", linespacing=1.45, zorder=9, bbox=halo)
        c = S["call"]
        if np.isfinite(c["N_exact"]):
            axC.annotate("", xy=(c["xD"], c["N_exact"]),
                         xytext=(c["xD"], c["N_fenske"]),
                         arrowprops=dict(arrowstyle="<->", color=RUST, lw=1.6),
                         zorder=8)
            axC.annotate(f"at $x_D$ = {c['xD']:.2f}: {c['N_exact']:.1f} "
                         f"stages really,\n{c['N_fenske']:.1f} from Fenske "
                         f"with $\\bar\\alpha$ = {c['alpha_bar']:.2f} —\n"
                         f"the shortcut is short by "
                         f"{c['N_exact'] - c['N_fenske']:.1f} stages",
                         xy=(c["xD"], 0.5 * (c["N_exact"] + c["N_fenske"])),
                         xytext=(0.300, 0.430), textcoords="axes fraction",
                         ha="center", va="center", fontsize=9.2, color=RUST,
                         linespacing=1.45, zorder=9,
                         bbox=dict(boxstyle="round,pad=0.28", fc=PAPER,
                                   ec=RUST, lw=1.0, alpha=0.96),
                         arrowprops=dict(arrowstyle="-", color=RUST, lw=1.1,
                                         shrinkA=3, shrinkB=6))
    ew = d["sys"]["ethanol-water"]
    axC.set_xlim(0.15, 1.0)
    # the axis is cut at the largest stage count either system reaches at its
    # own called-out specification: past that the ethanol + water curve is
    # diverging, and a scale that shows the divergence hides everything else
    hi = 1.45 * max(max(r["N_exact"] for r in d["sys"][n]["rows"]
                        if np.isfinite(r["N_exact"])
                        and r["xD"] <= d["sys"][n]["call"]["xD"] + 1e-9)
                    for n, _, _, _ in SYSTEMS)
    axC.set_ylim(0, hi)
    axC.set_xlabel("distillate specification  $x_D$")
    axC.set_ylabel("$N_{min}$ at total reflux")
    axC.set_title("(c)  the cost of assuming $\\alpha$ constant, in the "
                  "unit\nthe question is asked in: stages",
                  fontsize=11.6, pad=6)
    axC.text(ew["xaz"] - 0.006, 0.175 * hi,
             f"azeotrope at $x_1$ = {ew['xaz']:.4f}",
             ha="left", va="bottom", fontsize=9.0, color=RUST, rotation=90,
             zorder=9)
    axC.text(0.018, 0.982,
             r"$N_{min} = \ln[\,(x_D/(1-x_D))\,((1-x_B)/x_B)\,]"
             r"\,/\,\ln\bar\alpha$"
             "\nFENSKE ASSUMES, all four:\n"
             "  1  total reflux — no product drawn\n"
             r"  2  $\alpha$ constant over the column;"
             "\n      here "
             r"$\bar\alpha = \sqrt{\alpha_D\,\alpha_B}$" "\n"
             "  3  equilibrium (theoretical) stages\n"
             "  4  one binary pair, or two keys as one\n"
             "and $N_{min}$ counts the reboiler",
             transform=axC.transAxes, ha="left", va="top", fontsize=8.8,
             color=GRAPHITE, linespacing=1.65, zorder=9,
             bbox=dict(boxstyle="round,pad=0.30", fc=PAPER, ec=SLATE, lw=1.0,
                       alpha=0.96))

    fig.suptitle("What the activity coefficient is actually for: "
                 "$K_i$, $\\alpha_{12}$, and the stage count that follows "
                 "from them",
                 fontsize=14.2, y=0.985)
    bt, ew = d["sys"]["benzene-toluene"], d["sys"]["ethanol-water"]
    cb, ce = bt["call"], ew["call"]
    fig.text(0.5, 0.016, wrapped(
        "Curves: NRTL fitted by Barker's method to the cited data — benzene + "
        "toluene, 101.33 kPa, doi:10.1016/j.fluid.2013.12.002, rms "
        "{bt_rms:.3f} K; ethanol + water, 101.3 kPa, doi:10.1021/je2008704, "
        "rms {ew_rms:.3f} K. Markers: $K_1 = y_1/x_1$ and $\\alpha$ = "
        "$[y_1/(1-y_1)]/[x_1/(1-x_1)]$ straight from the measured pairs, with "
        "no model. $\\Phi_i$ = 1 (ideal vapour, no Poynting) is assumed "
        "throughout, so $K_i = \\gamma_i P_i^{{sat}}/P$; $P_i^{{sat}}$ from "
        "the Antoine sets in vlekit.data at the BUBBLE temperature of each "
        "composition, which itself moves by {bt_dT:.0f} K across benzene + "
        "toluene and {ew_dT:.0f} K across ethanol + water.\n"
        "Panel (c) holds $x_B$ fixed ({bt_xB:g} for benzene + toluene, "
        "{ew_xB:g} for ethanol + water) and sweeps $x_D$. The solid curve "
        "steps stages off one at a time at total reflux, where $y_{{n+1}} = "
        "x_n$, using the same NRTL — no constant-$\\alpha$ assumption is made "
        "anywhere in it; the last stage is interpolated in $\\ln[x/(1-x)]$. "
        "The dashed curve is Fenske with $\\bar\\alpha$ the geometric mean of "
        "the two end values, which is the textbook recipe.\n"
        "THE COST. benzene + toluene at $x_D$ = {bt_xD:.2f}: {bt_ne:.2f} "
        "stages stepped against {bt_nf:.2f} from Fenske, a difference of "
        "{bt_gap:.2f} of a stage — the shortcut is free. ethanol + water at "
        "$x_D$ = {ew_xD:.2f}: {ew_ne:.1f} against {ew_nf:.1f}, short by "
        "{ew_gap:.1f} stages, and the gap grows without bound as $x_D$ "
        "approaches the azeotrope at {ew_az:.4f} because the true count "
        "diverges there while Fenske stays finite. A constant $\\alpha$ is an "
        "ASSUMPTION about the mixture, not a property of the method, and it "
        "fails silently.", 200).format(
            bt_rms=bt["fit"].rms_T, ew_rms=ew["fit"].rms_T,
            bt_dT=np.ptp(bt["curve"]["T"]), ew_dT=np.ptp(ew["curve"]["T"]),
            bt_xB=bt["xB"], ew_xB=ew["xB"], bt_xD=cb["xD"],
            bt_ne=cb["N_exact"], bt_nf=cb["N_fenske"],
            bt_gap=abs(cb["N_exact"] - cb["N_fenske"]), ew_xD=ce["xD"],
            ew_ne=ce["N_exact"], ew_nf=ce["N_fenske"],
            ew_gap=ce["N_exact"] - ce["N_fenske"], ew_az=ew["xaz"]),
        ha="center", va="bottom", fontsize=9.5, color=SLATE, linespacing=1.6)
    fig.tight_layout(rect=(0.005, 0.268, 0.995, 0.935))
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = analyse()
    print("F4.21  K values, relative volatility and the Fenske stage count")
    print("  K_i = gamma_i Psat_i / P with Phi_i = 1; alpha_12 = K1/K2; "
          "Psat at the bubble temperature of each composition")
    print()
    for name, _, xB, _ in SYSTEMS:
        S = d["sys"][name]
        dat, fit = S["dat"], S["fit"]
        print(f"  {dat.label}   doi:{D.DOIS[name]}   {len(dat)} points")
        print(f"    NRTL by Barker: tau12 = {fit.params[0]:+.6f}, "
              f"tau21 = {fit.params[1]:+.6f}; rms dT = {fit.rms_T:.4f} K, "
              f"rms dy = {fit.rms_y:.5f}")
        print(f"    bubble temperature spans {np.min(S['curve']['T']):.2f} to "
              f"{np.max(S['curve']['T']):.2f} K over 0 < x1 < 1")
        print(f"    {'x1':>6s} {'T / K':>8s} {'K1':>8s} {'K2':>8s} "
              f"{'alpha':>8s}")
        for xq in (0.02, 0.1, 0.3, 0.5, 0.7, 0.9, 0.98):
            j = int(np.argmin(np.abs(S["xs"] - xq)))
            print(f"    {S['xs'][j]:6.3f} {S['curve']['T'][j]:8.2f} "
                  f"{S['curve']['K1'][j]:8.3f} {S['curve']['K2'][j]:8.3f} "
                  f"{S['curve']['alpha'][j]:8.3f}")
        print(f"    alpha runs {S['a_hi']:.3f} -> {S['a_lo']:.3f}, "
              f"a factor of {S['a_hi'] / S['a_lo']:.2f}")
        if S["xaz"] is not None:
            print(f"    alpha = 1 (azeotrope) at x1 = {S['xaz']:.5f} from the "
                  f"fitted NRTL; the measured points cross y = x at "
                  f"x1 = {S['xaz_meas']:.5f}")
        else:
            print("    alpha never reaches 1: no azeotrope")
        m = S["meas"]
        print(f"    from the measured x and y alone, with no model: "
              f"alpha spans {m['alpha'].min():.3f} to {m['alpha'].max():.3f} "
              f"over the {len(m['x'])} interior points")
        print()
        print(f"    minimum stages at total reflux, x_B = {xB}:")
        print(f"      {'x_D':>6s} {'alpha_B':>8s} {'alpha_D':>8s} "
              f"{'alpha_bar':>10s} {'stepped':>9s} {'Fenske':>8s} "
              f"{'error':>8s}")
        for r in S["rows"]:
            ne = ("inf" if not np.isfinite(r["N_exact"])
                  else f"{r['N_exact']:9.3f}")
            err = ("—" if not np.isfinite(r["N_exact"])
                   else f"{r['N_fenske'] - r['N_exact']:+8.3f}")
            print(f"      {r['xD']:6.3f} {r['alpha_B']:8.3f} "
                  f"{r['alpha_D']:8.3f} {r['alpha_bar']:10.3f} "
                  f"{ne:>9s} {r['N_fenske']:8.3f} {err:>8s}")
        c = S["call"]
        print(f"      -> at x_D = {c['xD']:.3f}: stepped {c['N_exact']:.3f}, "
              f"Fenske {c['N_fenske']:.3f}, "
              f"error {c['N_fenske'] - c['N_exact']:+.3f} stages")
        print()
    print("  Fenske assumes: total reflux; constant alpha over the column "
          "(taken here as the geometric mean of the two end values); "
          "equilibrium stages; a single binary pair. N_min counts equilibrium "
          "stages including the reboiler.")
    print(f"  [analyse() took {d['elapsed']:.1f} s]")
    for p in write(build(d), SLUG):
        print("wrote", p)
