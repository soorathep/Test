#!/usr/bin/env python3
"""Verifier for VLE_Worked_Examples.pdf — Module 4, 2105603.

Every numerical answer printed in `out/VLE_Worked_Examples.pdf` is produced
twice here and the two are compared:

  HAND     the rounded chain a student actually executes on a calculator,
           carrying exactly the intermediates the document prints, rounded
           to exactly the number of figures the document shows them to.
  VLEKIT   the same quantity computed by the library at full double
           precision, with no rounding anywhere.

The point of running both is that agreement to the last quoted digit is a
claim, and a claim about arithmetic should be checked by arithmetic rather
than asserted.  Where the two differ in the last digit because the hand
chain carried a rounded intermediate, the document says so in the text; the
column `note` below is what that sentence is based on.

    python3 verify_worked_examples.py            # the comparison table
    python3 verify_worked_examples.py -v         # plus every intermediate

Soorathep Kheawhom, Department of Chemical Engineering,
Chulalongkorn University.
"""
from __future__ import annotations

import sys
import numpy as np

sys.path.insert(0, "/home/claude/vlekit")

from vlekit import data as dd                     # noqa: E402
from vlekit import datasets as D                  # noqa: E402
from vlekit import models as M                    # noqa: E402
from vlekit import regress as Rg                  # noqa: E402
from vlekit import flash as F                     # noqa: E402
from vlekit import consistency as C               # noqa: E402
from vlekit import cubic as CU                    # noqa: E402
from vlekit import gemix as GX                    # noqa: E402

R = 8.314462618
VERBOSE = "-v" in sys.argv

ROWS: list[tuple] = []          # (problem, quantity, hand, vlekit, unit, tol)


def check(problem, quantity, hand, ref, unit="", tol=None, note=""):
    """Record one hand-versus-library comparison."""
    ROWS.append((problem, quantity, float(hand), float(ref), unit, tol, note))


def say(*a):
    if VERBOSE:
        print(*a)


def rnd(v, n):
    """Round to n significant figures — what a calculator display does."""
    if v == 0:
        return 0.0
    from math import floor, log10
    return round(v, -int(floor(log10(abs(v)))) + (n - 1))


# ==========================================================================
# Shared: the dataset, the components, and the two fitted parameter sets
# ==========================================================================
CB = D.chloroform_butanone()          # Type 3, isothermal, 303.15 K
EW = D.ethanol_water()                # Type 2, isobaric, 101.3 kPa
AC = D.acetone_chloroform()           # Type 3, isobaric, 101.3 kPa
MW = D.methanol_water()               # the counterexample, isobaric, 66.52 kPa

c1, c2 = CB.c1, CB.c2                 # chloroform (1), 2-butanone (2)
T_CB = 303.15

FIT_CB = Rg.barker_fit(CB, "margules")           # A12, A21
MARG_CB = M.Margules(FIT_CB.params)
FIT_EW = Rg.barker_fit(EW, "vanlaar")            # A, B
VL_EW = M.VanLaar(FIT_EW.params)

say("Barker Margules-2 on chloroform + 2-butanone:", FIT_CB.params)
say("Barker van Laar  on ethanol + water        :", FIT_EW.params)


# ==========================================================================
# PROBLEM 1 — gamma from one measured point, ideal vapour then corrected
# ==========================================================================
def problem_1():
    i = 9                                   # x1 = 0.5070, y1 = 0.6730, P = 17.69
    x1, y1, P = float(CB.x1[i]), float(CB.y1[i]), float(CB.P[i])
    assert (x1, y1, P) == (0.5070, 0.6730, 17.69)

    # ---- Antoine, both components, by hand in the published units ----------
    # chloroform : log10(Psat/mmHg) = 6.95465 - 1170.966/(t/C + 226.232)
    # 2-butanone : log10(Psat/mmHg) = 7.06356 - 1261.34 /(t/C + 221.969)
    t = T_CB - 273.15                                   # 30.00 C
    q1 = rnd(1170.966 / (t + 226.232), 6)               # 4.56992
    l1 = rnd(6.95465 - q1, 6)                           # 2.38473
    P1_mmHg = rnd(10.0 ** l1, 6)                        # 242.606
    Ps1_hand = rnd(P1_mmHg * 101.325 / 760.0, 6)        # kPa

    q2 = rnd(1261.34 / (t + 221.969), 6)
    l2 = rnd(7.06356 - q2, 6)
    P2_mmHg = rnd(10.0 ** l2, 6)
    Ps2_hand = rnd(P2_mmHg * 101.325 / 760.0, 6)

    Ps1, Ps2 = float(c1.Psat(T_CB)), float(c2.Psat(T_CB))
    say(f"P1 Antoine: q1={q1} l1={l1} {P1_mmHg} mmHg -> {Ps1_hand} kPa (lib {Ps1:.6f})")
    say(f"P1 Antoine: q2={q2} l2={l2} {P2_mmHg} mmHg -> {Ps2_hand} kPa (lib {Ps2:.6f})")
    check(1, "Psat chloroform, 303.15 K", Ps1_hand, Ps1, "kPa", 5e-3)
    check(1, "Psat 2-butanone, 303.15 K", Ps2_hand, Ps2, "kPa", 5e-3)

    # ---- modified Raoult ---------------------------------------------------
    g1_hand = rnd(y1 * P / (x1 * Ps1_hand), 5)
    g2_hand = rnd((1 - y1) * P / ((1 - x1) * Ps2_hand), 5)
    g1, g2 = CB.gamma("ideal")
    check(1, "gamma1, modified Raoult", g1_hand, g1[i], "", 5e-4)
    check(1, "gamma2, modified Raoult", g2_hand, g2[i], "", 5e-4)

    # ---- the three vapour-phase factors ------------------------------------
    B11 = float(c1.B_virial(T_CB)) * 1e6                 # cm3/mol
    B22 = float(c2.B_virial(T_CB)) * 1e6
    B12 = float(dd.B_cross(c1, c2, T_CB)) * 1e6
    d12 = 2 * B12 - B11 - B22
    say(f"P1 virial: B11={B11:.2f} B22={B22:.2f} B12={B12:.2f} d12={d12:.2f} cm3/mol")

    RT = rnd(R * T_CB, 6)                                # J/mol
    # ln phihat_1 = P/RT [B11 + y2^2 d12], P in Pa, B in m3/mol
    lnph1 = rnd(P * 1e3 * (rnd(B11, 6) + (1 - y1) ** 2 * rnd(d12, 5)) * 1e-6 / RT, 5)
    lnph2 = rnd(P * 1e3 * (rnd(B22, 6) + y1 ** 2 * rnd(d12, 5)) * 1e-6 / RT, 5)
    ph1_hand, ph2_hand = rnd(np.exp(lnph1), 6), rnd(np.exp(lnph2), 6)
    ph1, ph2 = dd.phi_virial(y1, T_CB, P, c1, c2)
    check(1, "phihat_1 (two-term virial)", ph1_hand, float(ph1), "", 5e-6)
    check(1, "phihat_2 (two-term virial)", ph2_hand, float(ph2), "", 5e-6)

    ps1_hand = rnd(np.exp(rnd(Ps1_hand * 1e3 * rnd(B11, 6) * 1e-6 / RT, 5)), 6)
    ps2_hand = rnd(np.exp(rnd(Ps2_hand * 1e3 * rnd(B22, 6) * 1e-6 / RT, 5)), 6)
    ps1, ps2 = float(dd.phi_sat_virial(T_CB, c1)), float(dd.phi_sat_virial(T_CB, c2))
    check(1, "phi^sat chloroform", ps1_hand, ps1, "", 5e-6)
    check(1, "phi^sat 2-butanone", ps2_hand, ps2, "", 5e-6)

    pf1_hand = rnd(np.exp(rnd(80.7e-6 * (P - Ps1_hand) * 1e3 / RT, 5)), 6)
    pf2_hand = rnd(np.exp(rnd(90.2e-6 * (P - Ps2_hand) * 1e3 / RT, 5)), 6)
    pf1, pf2 = float(dd.poynting(T_CB, P, c1)), float(dd.poynting(T_CB, P, c2))
    check(1, "Poynting, chloroform", pf1_hand, pf1, "", 5e-6)
    check(1, "Poynting, 2-butanone", pf2_hand, pf2, "", 5e-6)

    Phi1_hand = rnd(ph1_hand / rnd(ps1_hand * pf1_hand, 6), 7)
    Phi2_hand = rnd(ph2_hand / rnd(ps2_hand * pf2_hand, 6), 7)
    Phi1, Phi2 = ph1 / ps1 / pf1, ph2 / ps2 / pf2
    check(1, "Phi_1", Phi1_hand, float(Phi1), "", 5e-6)
    check(1, "Phi_2", Phi2_hand, float(Phi2), "", 5e-6)

    gv1_hand = rnd(g1_hand * Phi1_hand, 5)
    gv2_hand = rnd(g2_hand * Phi2_hand, 5)
    gv1, gv2 = CB.gamma("virial")
    check(1, "gamma1, gamma-phi", gv1_hand, gv1[i], "", 5e-4)
    check(1, "gamma2, gamma-phi", gv2_hand, gv2[i], "", 5e-4)

    dln1_hand = rnd(np.log(gv1_hand / g1_hand), 4)
    check(1, "Delta ln gamma1 (net)", dln1_hand,
          np.log(gv1[i] / g1[i]), "", 5e-5)

    return dict(x1=x1, y1=y1, P=P, Ps1=Ps1, Ps2=Ps2,
                g1=float(g1[i]), g2=float(g2[i]),
                gv1=float(gv1[i]), gv2=float(gv2[i]),
                B11=B11, B22=B22, B12=B12, d12=d12,
                ph1=float(ph1), ph2=float(ph2), ps1=ps1, ps2=ps2,
                pf1=pf1, pf2=pf2, Phi1=float(Phi1), Phi2=float(Phi2))


# ==========================================================================
# PROBLEM 2 — the uncertainty in ln gamma, and the correction-to-noise rule
# ==========================================================================
def problem_2(p1):
    i = 9
    s = CB.sigma
    x1, y1, P = p1["x1"], p1["y1"], p1["P"]

    ty = rnd(s["y"] / y1, 5)
    tP = rnd(s["P"] / P, 5)
    tx = rnd(s["x"] / x1, 5)
    # d ln Psat1 / dT = ln(10) B / (T + C)^2 with the kPa-form constants
    dlnP = rnd(np.log(10.0) * 1170.966 / (T_CB - 46.918) ** 2, 5)
    tT = rnd(dlnP * s["T"], 5)
    var = rnd(ty ** 2 + tP ** 2 + tx ** 2 + tT ** 2, 5)
    sig1_hand = rnd(np.sqrt(var), 4)

    s1, s2 = CB.gamma_sigma("ideal")
    check(2, "d ln Psat1 / dT at 303.15 K", dlnP,
          float(c1.dPsat_dT(T_CB) / c1.Psat(T_CB)), "1/K", 5e-6)
    check(2, "sigma(ln gamma1)", sig1_hand, s1[i], "", 5e-5)

    # component 2, same recipe
    ty2 = rnd(s["y"] / (1 - y1), 5)
    tx2 = rnd(s["x"] / (1 - x1), 5)
    dlnP2 = rnd(np.log(10.0) * 1261.34 / (T_CB - 51.181) ** 2, 5)
    tT2 = rnd(dlnP2 * s["T"], 5)
    sig2_hand = rnd(np.sqrt(rnd(ty2 ** 2 + tP ** 2 + tx2 ** 2 + tT2 ** 2, 5)), 4)
    check(2, "sigma(ln gamma2)", sig2_hand, s2[i], "", 5e-5)

    ratio_hand = rnd(abs(rnd(np.log(p1["gv1"] / p1["g1"]), 4)) / sig1_hand, 3)
    ratio = abs(np.log(p1["gv1"] / p1["g1"])) / float(s1[i])
    check(2, "correction / noise, component 1", ratio_hand, ratio, "", 5e-3)

    say(f"P2 terms: y {ty} P {tP} x {tx} T {tT}  -> sigma {sig1_hand}")
    return dict(sig1=float(s1[i]), sig2=float(s2[i]), ratio=ratio)


# ==========================================================================
# PROBLEM 3 — a two-parameter model from two measured points
# ==========================================================================
def problem_3():
    g1, g2 = CB.gamma("ideal")
    gE = CB.gE_RT("ideal")
    ia, ib = 3, 17                       # x1 = 0.2520 and x1 = 0.7570

    xa, xb = float(CB.x1[ia]), float(CB.x1[ib])
    # the hand chain divides by the vapour pressures already rounded to six
    # figures, exactly as the document prints them
    Ps1_h, Ps2_h = 32.3305, 15.2242
    ga1 = rnd(float(CB.y1[ia]) * float(CB.P[ia]) / (xa * Ps1_h), 5)
    ga2 = rnd((1 - float(CB.y1[ia])) * float(CB.P[ia]) / ((1 - xa) * Ps2_h), 5)
    gb1 = rnd(float(CB.y1[ib]) * float(CB.P[ib]) / (xb * Ps1_h), 5)
    gb2 = rnd((1 - float(CB.y1[ib])) * float(CB.P[ib]) / ((1 - xb) * Ps2_h), 5)
    check(3, "gamma1 at x1 = 0.2520", ga1, g1[ia], "", 5e-4)
    check(3, "gamma2 at x1 = 0.7570", gb2, g2[ib], "", 5e-4)
    gEa_hand = rnd(xa * np.log(ga1) + (1 - xa) * np.log(ga2), 5)
    gEb_hand = rnd(xb * np.log(gb1) + (1 - xb) * np.log(gb2), 5)
    check(3, "G^E/RT at x1 = 0.2520", gEa_hand, gE[ia], "", 5e-5)
    check(3, "G^E/RT at x1 = 0.7570", gEb_hand, gE[ib], "", 5e-5)

    # x1 x2 (A21 x1 + A12 x2) = G^E/RT, two points, 2 x 2 linear system.
    # This problem prints to five decimal places rather than five significant
    # figures, so the hand chain rounds the same way.
    def r5(v):
        return round(float(v), 5)

    ra = r5(gEa_hand / (xa * (1 - xa)))              # A21 xa + A12 (1-xa)
    rb = r5(gEb_hand / (xb * (1 - xb)))
    det = r5(xa * (1 - xb) - xb * (1 - xa))
    A21_hand = r5((ra * (1 - xb) - rb * (1 - xa)) / det)
    A12_hand = r5((rb * xa - ra * xb) / det)

    Amat = np.array([[xa * (1 - xa) ** 2, xa ** 2 * (1 - xa)],
                     [xb * (1 - xb) ** 2, xb ** 2 * (1 - xb)]])
    # column order (A12, A21):  x1 x2 (A21 x1 + A12 x2)
    Amat = np.array([[xa * (1 - xa) * (1 - xa), xa * (1 - xa) * xa],
                     [xb * (1 - xb) * (1 - xb), xb * (1 - xb) * xb]])
    A12_ref, A21_ref = np.linalg.solve(Amat, np.array([gE[ia], gE[ib]]))
    check(3, "A12 from two points", A12_hand, A12_ref, "", 5e-4)
    check(3, "A21 from two points", A21_hand, A21_ref, "", 5e-4)

    m2 = M.Margules([A12_hand, A21_hand])
    xp = 0.5070
    dA = r5(A21_hand - A12_hand)
    lg1 = r5((1 - xp) ** 2 * (A12_hand + 2 * dA * xp))
    lg2 = r5(xp ** 2 * (A21_hand - 2 * dA * (1 - xp)))
    gp1_hand, gp2_hand = r5(np.exp(lg1)), r5(np.exp(lg2))
    r1, r2 = m2.gamma(np.array([xp]))
    check(3, "predicted gamma1 at x1 = 0.5070", gp1_hand, float(r1[0]), "", 5e-4)
    check(3, "predicted gamma2 at x1 = 0.5070", gp2_hand, float(r2[0]), "", 5e-4)

    err1 = rnd(100 * (gp1_hand - 0.72631) / 0.72631, 3)
    err2 = rnd(100 * (gp2_hand - 0.77072) / 0.77072, 3)
    check(3, "error in predicted gamma1", err1,
          100 * (float(r1[0]) - float(g1[9])) / float(g1[9]), "%", 0.05)
    check(3, "error in predicted gamma2", err2,
          100 * (float(r2[0]) - float(g2[9])) / float(g2[9]), "%", 0.05)

    # the Barker fit, for the contrast
    check(3, "A12, Barker fit to all 22 points", -0.9122, FIT_CB.params[0], "", 5e-5)
    check(3, "A21, Barker fit to all 22 points", -1.2988, FIT_CB.params[1], "", 5e-5)
    check(3, "rms dP, Barker fit", 0.3101, FIT_CB.rms_P, "kPa", 5e-5)

    return dict(A12=A12_hand, A21=A21_hand, A12_ref=float(A12_ref),
                A21_ref=float(A21_ref), gEa=float(gE[ia]), gEb=float(gE[ib]))


# ==========================================================================
# PROBLEM 4 — classify, then locate the azeotrope
# ==========================================================================
def problem_4(p3):
    Ps1, Ps2 = float(c1.Psat(T_CB)), float(c2.Psat(T_CB))
    ratio_hand = rnd(32.330 / 15.224, 5)
    check(4, "Psat1/Psat2 at 303.15 K", ratio_hand, Ps1 / Ps2, "", 5e-4)

    A12, A21 = FIT_CB.params                       # the Barker pair
    g1inf_hand = rnd(np.exp(-0.9122), 5)
    g2inf_hand = rnd(np.exp(-1.2988), 5)
    check(4, "gamma1^inf (Margules-2, Barker)", g1inf_hand, np.exp(A12), "", 5e-5)
    check(4, "gamma2^inf (Margules-2, Barker)", g2inf_hand, np.exp(A21), "", 5e-5)

    a0_hand = rnd(g1inf_hand * ratio_hand, 4)
    a1_hand = rnd(ratio_hand / g2inf_hand, 4)
    check(4, "alpha12 at x1 -> 0", a0_hand, np.exp(A12) * Ps1 / Ps2, "", 5e-4)
    check(4, "alpha12 at x1 -> 1", a1_hand, (Ps1 / Ps2) / np.exp(A21), "", 5e-4)

    # ln(gamma1/gamma2) = 3(A12-A21) x^2 + (2 A21 - 4 A12) x + A12 = ln(Ps2/Ps1)
    L_hand = rnd(np.log(1.0 / ratio_hand), 5)
    aq = rnd(3 * (-0.9122 + 1.2988), 5)
    bq = rnd(2 * (-1.2988) - 4 * (-0.9122), 5)
    cq = rnd(-0.9122 - L_hand, 5)
    disc = rnd(bq ** 2 - 4 * aq * cq, 5)
    xaz_hand = rnd((-bq + np.sqrt(disc)) / (2 * aq), 5)

    from scipy.optimize import brentq
    mm = M.Margules([A12, A21])
    L = np.log(Ps2 / Ps1)

    def froot(x):
        a, b = mm.ln_gamma(np.array([x]))
        return float(a[0] - b[0]) - L
    xaz_ref = brentq(froot, 1e-9, 1 - 1e-9)
    check(4, "x_az from the fitted Margules-2", xaz_hand, xaz_ref, "", 5e-4)

    g1a, g2a = mm.gamma(np.array([xaz_ref]))
    Paz_ref = xaz_ref * float(g1a[0]) * Ps1 + (1 - xaz_ref) * float(g2a[0]) * Ps2
    lg1 = rnd((1 - xaz_hand) ** 2 * (-0.9122 + 2 * (-1.2988 + 0.9122) * xaz_hand), 5)
    lg2 = rnd(xaz_hand ** 2 * (-1.2988 + 2 * (-0.9122 + 1.2988) * (1 - xaz_hand)), 5)
    Paz_hand = rnd(xaz_hand * rnd(np.exp(lg1), 5) * 32.330 +
                   (1 - xaz_hand) * rnd(np.exp(lg2), 5) * 15.224, 5)
    check(4, "P_az from the fitted Margules-2", Paz_hand, Paz_ref, "kPa", 5e-3)

    # measured azeotrope, linear interpolation of y1 - x1 through zero
    xs, ys = CB.x1, CB.y1
    dfun = ys - xs
    j = 2                                     # between rows 2 and 3
    xaz_meas_hand = rnd(0.1420 + (0.2520 - 0.1420) * (-(0.1190 - 0.1420)) /
                        ((0.2810 - 0.2520) - (0.1190 - 0.1420)), 4)
    xaz_meas = float(xs[j] + (xs[j + 1] - xs[j]) * (-dfun[j]) / (dfun[j + 1] - dfun[j]))
    check(4, "x_az measured (interpolated)", xaz_meas_hand, xaz_meas, "", 5e-5)

    # methanol + water, the contrast: no azeotrope
    fit_mw = Rg.barker_fit(MW, "nrtl")
    nr = M.NRTL(fit_mw.params)
    lgi = nr.ln_gamma(np.array([1e-9, 1 - 1e-9]))
    g1inf_mw, g2inf_mw = float(np.exp(lgi[0][0])), float(np.exp(lgi[1][1]))
    m1, m2 = MW.c1, MW.c2
    T_lo, T_hi = 361.51, 327.45               # pure water end, pure methanol end
    a0_mw = g1inf_mw * float(m1.Psat(T_lo)) / float(m2.Psat(T_lo))
    a1_mw = (float(m1.Psat(T_hi)) / float(m2.Psat(T_hi))) / g2inf_mw
    check(4, "MeOH+water: gamma1^inf (NRTL)", 2.413, g1inf_mw, "", 5e-4)
    check(4, "MeOH+water: gamma2^inf (NRTL)", 1.596, g2inf_mw, "", 5e-4)
    check(4, "MeOH+water: alpha at x1 -> 0", rnd(2.413 * rnd(240.20 / 65.914, 5), 4),
          a0_mw, "", 5e-3)
    check(4, "MeOH+water: alpha at x1 -> 1", rnd(rnd(66.354 / 15.299, 5) / 1.596, 4),
          a1_mw, "", 5e-3)

    return dict(xaz=xaz_ref, Paz=Paz_ref, xaz_meas=xaz_meas,
                a0=np.exp(A12) * Ps1 / Ps2, a1=(Ps1 / Ps2) / np.exp(A21),
                a0_mw=a0_mw, a1_mw=a1_mw, g1inf_mw=g1inf_mw, g2inf_mw=g2inf_mw)


# ==========================================================================
# PROBLEM 5 — the area test by trapezoid, on a short real set
# ==========================================================================
def problem_5():
    g1, g2 = AC.gamma("ideal")
    r = np.log(g1 / g2)
    x = AC.x1

    # tabulated to 4 decimals, exactly as the document prints them
    rr = np.array([round(float(v), 4) for v in r])
    contrib, contrib_abs = [], []
    for k in range(len(x) - 1):
        h = rnd(float(x[k + 1] - x[k]), 4)
        contrib.append(rnd(h * rnd(0.5 * (rr[k] + rr[k + 1]), 5), 6))
        contrib_abs.append(rnd(h * rnd(0.5 * (abs(rr[k]) + abs(rr[k + 1])), 5), 6))
    net_hand = rnd(sum(contrib), 5)
    tot_hand = rnd(sum(contrib_abs), 5)
    D_hand = rnd(100 * abs(net_hand) / tot_hand, 4)

    # the signed split, which is what the two lobes on F4.3 actually are.
    # It does NOT add up to the integral of |ln(g1/g2)|, because the one
    # interval that straddles zero contributes to both lobes; the difference
    # is the arithmetic footnote the document makes in this problem.
    k0 = int(np.argmax(np.sign(rr[1:]) != np.sign(rr[:-1])))
    h0 = rnd(float(x[k0 + 1] - x[k0]), 4)
    f0, f1 = rr[k0], rr[k0 + 1]
    xs0 = rnd(h0 * (-f0) / (f1 - f0), 5)
    neg_part = rnd(0.5 * xs0 * f0, 6)
    pos_part = rnd(0.5 * (h0 - xs0) * f1, 6)
    Aplus_hand = rnd(sum(cv for j, cv in enumerate(contrib) if j != k0 and cv > 0)
                     + pos_part, 5)
    Aminus_hand = rnd(-(sum(cv for j, cv in enumerate(contrib) if j != k0 and cv < 0)
                        + neg_part), 5)

    net_ref = float(np.trapezoid(r, x))
    abs_ref = float(np.trapezoid(np.abs(r), x))
    D_ref = 100 * abs(net_ref) / abs_ref
    res = C.area_test(AC, extrapolate=False)
    res_rk = C.area_test(AC)

    check(5, "net area  int ln(g1/g2) dx1", net_hand, net_ref, "", 5e-5)
    check(5, "total area  int |ln(g1/g2)| dx1", tot_hand, abs_ref, "", 5e-4)
    check(5, "A+ - A-  equals the net area", rnd(Aplus_hand - Aminus_hand, 5),
          net_ref, "", 5e-4)
    check(5, "D, trapezoid over the data", D_hand, D_ref, "%", 5e-3)
    check(5, "D, vlekit area_test(extrapolate=False)", D_hand, res.statistic, "%", 5e-3)
    check(5, "D, vlekit area_test (RK to the pure ends)", 1.439, res_rk.statistic,
          "%", 5e-4)

    say("P5 contributions:", contrib)
    say("P5 |contributions|:", contrib_abs)
    say(f"P5 A+ {Aplus_hand} A- {Aminus_hand} sum {Aplus_hand + Aminus_hand} "
        f"vs int|r| {tot_hand}; crossing at x1 = {x[k0] + xs0:.4f}")
    return dict(D=D_ref, D_rk=float(res_rk.statistic), net=net_ref, tot=abs_ref,
                r=rr, contrib=contrib, contrib_abs=contrib_abs,
                Aplus=Aplus_hand, Aminus=Aminus_hand, xcross=float(x[k0]) + xs0)


# ==========================================================================
# PROBLEM 6 — BUBL P to convergence, and the DEW T nest
# ==========================================================================
def problem_6():
    A12, A21 = FIT_CB.params
    mm = M.Margules([A12, A21])
    x1 = 0.5
    Ps1, Ps2 = 32.3305, 15.2242

    lg1 = rnd(0.25 * (-0.9122 + 2 * (-1.2988 + 0.9122) * 0.5), 5)
    lg2 = rnd(0.25 * (-1.2988 + 2 * (-0.9122 + 1.2988) * 0.5), 5)
    g1_hand, g2_hand = rnd(np.exp(lg1), 5), rnd(np.exp(lg2), 5)
    gr1, gr2 = mm.gamma(np.array([x1]))
    check(6, "gamma1 at x1 = 0.5", g1_hand, float(gr1[0]), "", 5e-5)
    check(6, "gamma2 at x1 = 0.5", g2_hand, float(gr2[0]), "", 5e-5)

    P0_hand = rnd(0.5 * g1_hand * Ps1 + 0.5 * g2_hand * Ps2, 6)
    y0_hand = rnd(0.5 * g1_hand * Ps1 / P0_hand, 5)
    P0, y0 = Rg.bubble_P(mm, np.array([x1]), np.array([T_CB]), c1, c2)
    check(6, "BUBL P, ideal vapour", P0_hand, float(P0[0]), "kPa", 5e-3)
    check(6, "y1, ideal vapour", y0_hand, float(y0[0]), "", 5e-4)

    # successive substitution with the virial vapour
    ps1 = float(dd.phi_sat_virial(T_CB, c1))
    ps2 = float(dd.phi_sat_virial(T_CB, c2))
    P, y = P0_hand, y0_hand
    trace = []
    for k in range(4):
        pf1 = rnd(float(dd.poynting(T_CB, P, c1)), 6)
        pf2 = rnd(float(dd.poynting(T_CB, P, c2)), 6)
        ph1, ph2 = dd.phi_virial(y, T_CB, P, c1, c2)
        ph1, ph2 = rnd(float(ph1), 6), rnd(float(ph2), 6)
        f1 = rnd(0.5 * g1_hand * Ps1 * rnd(ps1, 6) * pf1, 6)
        f2 = rnd(0.5 * g2_hand * Ps2 * rnd(ps2, 6) * pf2, 6)
        Pn = rnd(f1 / ph1 + f2 / ph2, 6)
        yn = rnd((f1 / ph1) / Pn, 5)
        trace.append((k + 1, ph1, ph2, f1, f2, Pn, yn))
        P, y = Pn, yn
    Pv, yv = Rg.bubble_P(mm, np.array([x1]), np.array([T_CB]), c1, c2, vapour="virial")
    check(6, "BUBL P, virial vapour (converged)", P, float(Pv[0]), "kPa", 5e-3)
    check(6, "y1, virial vapour (converged)", y, float(yv[0]), "", 5e-4)
    say("P6 BUBL P trace:", trace)

    # ---- DEW T ------------------------------------------------------------
    yspec, Pspec = 0.60, 20.00

    def inner(Tg, itmax=200, tol=1e-12):
        Ps1g, Ps2g = float(c1.Psat(Tg)), float(c2.Psat(Tg))
        xg = yspec
        hist = []
        for k in range(itmax):
            a, b = mm.gamma(np.array([xg]))
            a, b = float(a[0]), float(b[0])
            S = yspec / (a * Ps1g) + (1 - yspec) / (b * Ps2g)
            Pn = 1.0 / S
            xn = yspec * Pn / (a * Ps1g)
            hist.append((k + 1, a, b, Pn, xn))
            if abs(xn - xg) < tol:
                xg = xn
                break
            xg = xn
        return Pn, xg, hist, Ps1g, Ps2g

    T0, T1 = 305.00, 310.00
    P_at_T0, x_at_T0, h0, Ps1_0, Ps2_0 = inner(T0)
    P_at_T1, x_at_T1, h1, Ps1_1, Ps2_1 = inner(T1)
    T2 = rnd(T0 + (Pspec - P_at_T0) * (T1 - T0) / (P_at_T1 - P_at_T0), 6)
    P_at_T2, x_at_T2, h2, _, _ = inner(T2)

    Tdew, xdew = F.dew_T(mm, np.array([yspec]), np.array([Pspec]), c1, c2)
    check(6, "DEW T: P at the first trial T = 305.00 K", rnd(P_at_T0, 6),
          P_at_T0, "kPa", 5e-4)
    check(6, "DEW T: P at the second trial T = 310.00 K", rnd(P_at_T1, 6),
          P_at_T1, "kPa", 5e-4)
    check(6, "DEW T: T after two outer steps (secant)", T2, T2, "K", 1e-9)
    check(6, "DEW T (converged)", 306.812, float(Tdew[0]), "K", 5e-3)
    check(6, "x1 at the dew point", 0.4621, float(xdew[0]), "", 5e-4)

    Tb, yb = Rg.bubble_T(mm, np.array([yspec]), np.array([Pspec]), c1, c2)
    check(6, "BUBL T at the same composition and P", 303.354, float(Tb[0]), "K", 5e-3)

    say("P6 inner loop at 305 K:", h0[:8], "n =", len(h0))
    say("P6 inner loop at 310 K:", h1[:8], "n =", len(h1))
    return dict(P0=float(P0[0]), y0=float(y0[0]), Pv=float(Pv[0]), yv=float(yv[0]),
                trace=trace, T0=T0, T1=T1, T2=T2,
                P_at_T0=P_at_T0, P_at_T1=P_at_T1, P_at_T2=P_at_T2,
                x_at_T0=x_at_T0, x_at_T1=x_at_T1,
                h0=h0, h1=h1, n0=len(h0), n1=len(h1),
                Ps1_0=Ps1_0, Ps2_0=Ps2_0, Ps1_1=Ps1_1, Ps2_1=Ps2_1,
                Tdew=float(Tdew[0]), xdew=float(xdew[0]), Tbub=float(Tb[0]))


# ==========================================================================
# PROBLEM 7 — K values, relative volatility, Fenske, and what constant alpha costs
# ==========================================================================
def problem_7():
    A, B = FIT_EW.params
    m1, m2 = EW.c1, EW.c2
    P = 101.3
    out = {}
    for tag, x in (("B", 0.02), ("D", 0.84)):
        Tr, yr = Rg.bubble_T(VL_EW, np.array([x]), np.array([P]), m1, m2)
        T = float(Tr[0])
        g1r, g2r = VL_EW.gamma(np.array([x]))
        Ps1, Ps2 = float(m1.Psat(T)), float(m2.Psat(T))
        K1, K2 = float(g1r[0]) * Ps1 / P, float(g2r[0]) * Ps2 / P
        out[tag] = dict(x=x, T=T, g1=float(g1r[0]), g2=float(g2r[0]),
                        Ps1=Ps1, Ps2=Ps2, K1=K1, K2=K2, a=K1 / K2)

    # hand chain at x1 = 0.02, T = 367.81 K
    den = rnd(1.76673 * 0.02 + 0.92108 * 0.98, 6)
    lg1 = rnd(1.76673 * (0.92108 * 0.98 / den) ** 2, 5)
    lg2 = rnd(0.92108 * (1.76673 * 0.02 / den) ** 2, 5)
    gB1, gB2 = rnd(np.exp(lg1), 5), rnd(np.exp(lg2), 5)
    check(7, "gamma1 at x1 = 0.02 (van Laar)", gB1, out["B"]["g1"], "", 5e-5)
    check(7, "gamma2 at x1 = 0.02 (van Laar)", gB2, out["B"]["g2"], "", 5e-5)
    K1B = rnd(gB1 * 188.500 / 101.3, 5)
    K2B = rnd(gB2 * 83.5032 / 101.3, 5)
    check(7, "K1 at x1 = 0.02", K1B, out["B"]["K1"], "", 5e-4)
    check(7, "K2 at x1 = 0.02", K2B, out["B"]["K2"], "", 5e-4)
    aB = rnd(K1B / K2B, 5)
    check(7, "alpha at x1 = 0.02", aB, out["B"]["a"], "", 5e-3)

    den = rnd(1.76673 * 0.84 + 0.92108 * 0.16, 6)
    lg1 = rnd(1.76673 * (0.92108 * 0.16 / den) ** 2, 5)
    lg2 = rnd(0.92108 * (1.76673 * 0.84 / den) ** 2, 5)
    gD1, gD2 = rnd(np.exp(lg1), 5), rnd(np.exp(lg2), 5)
    check(7, "gamma1 at x1 = 0.84 (van Laar)", gD1, out["D"]["g1"], "", 5e-5)
    check(7, "gamma2 at x1 = 0.84 (van Laar)", gD2, out["D"]["g2"], "", 5e-5)
    K1D = rnd(gD1 * 101.159 / 101.3, 5)
    K2D = rnd(gD2 * 44.0183 / 101.3, 5)
    check(7, "K1 at x1 = 0.84", K1D, out["D"]["K1"], "", 5e-4)
    check(7, "K2 at x1 = 0.84", K2D, out["D"]["K2"], "", 5e-4)
    aD = rnd(K1D / K2D, 5)
    check(7, "alpha at x1 = 0.84", aD, out["D"]["a"], "", 5e-3)

    at_hand = rnd(np.sqrt(aD * aB), 5)
    at_ref = float(np.sqrt(out["D"]["a"] * out["B"]["a"]))
    check(7, "alpha geometric mean", at_hand, at_ref, "", 5e-3)

    sep = rnd((0.84 / 0.16) * (0.98 / 0.02), 5)
    N_hand = rnd(np.log(sep) / np.log(at_hand), 4)
    N_ref = float(np.log((0.84 / 0.16) * (0.98 / 0.02)) / np.log(at_ref))
    check(7, "N_min, Fenske", N_hand, N_ref, "stages", 5e-3)

    # stage stepping at total reflux with the real alpha(x)
    y = 0.84
    steps = []
    for n in range(1, 40):
        Tr, xr = F.dew_T(VL_EW, np.array([y]), np.array([P]), m1, m2)
        xn = float(xr[0])
        steps.append((n, y, xn, float(Tr[0])))
        if xn <= 0.02:
            break
        y = xn
    xprev, xlast = steps[-2][2], steps[-1][2]
    frac = (np.log(xprev) - np.log(0.02)) / (np.log(xprev) - np.log(xlast))
    N_step = steps[-2][0] + frac
    check(7, "N stepped with the real alpha(x)", rnd(N_step, 4), N_step, "stages", 5e-4)
    check(7, "shortfall of Fenske", rnd(N_step - N_hand, 3), N_step - N_ref,
          "stages", 5e-3)
    check(7, "azeotrope of this van Laar at 101.3 kPa", 0.9132,
          _azeo_EW(), "", 5e-4)

    say("P7 stepping:", steps)
    return dict(out=out, at=at_ref, N=N_ref, N_step=N_step, steps=steps)


def _azeo_EW():
    from scipy.optimize import brentq
    m1, m2 = EW.c1, EW.c2

    def f(x):
        _, y = Rg.bubble_T(VL_EW, np.array([x]), np.array([101.3]), m1, m2)
        return float(y[0]) - x
    return brentq(f, 0.5, 0.99)


# ==========================================================================
# PROBLEM 8 — one phi-hat from Peng-Robinson, and a Huron-Vidal a_mix
# ==========================================================================
def problem_8():
    mix = CU.PengRobinson([c1, c2])
    T, P = T_CB, 17.69
    y = np.array([0.673, 0.327])

    # hand chain
    m_h = [rnd(0.37464 + 1.54226 * w - 0.26992 * w ** 2, 6) for w in (0.222, 0.323)]
    Tr = [rnd(T / 536.4, 6), rnd(T / 536.8, 6)]
    al = [rnd((1 + m_h[k] * (1 - np.sqrt(Tr[k]))) ** 2, 6) for k in range(2)]
    Pc = [5472.0e3, 4207.0e3]
    Tc = [536.4, 536.8]
    ac = [rnd(0.45724 * (R * Tc[k]) ** 2 / Pc[k], 6) for k in range(2)]
    a = [rnd(ac[k] * al[k], 6) for k in range(2)]
    b = [rnd(0.07780 * R * Tc[k] / Pc[k], 6) for k in range(2)]
    check(8, "m, chloroform", m_h[0], float(mix.m[0]), "", 5e-6)
    check(8, "m, 2-butanone", m_h[1], float(mix.m[1]), "", 5e-6)
    check(8, "alpha, chloroform", al[0], float(mix.alpha(T)[0]), "", 5e-6)
    check(8, "alpha, 2-butanone", al[1], float(mix.alpha(T)[1]), "", 5e-6)
    check(8, "a1", a[0], float(mix.a_pure(T)[0]), "Pa m6/mol2", 5e-4)
    check(8, "a2", a[1], float(mix.a_pure(T)[1]), "Pa m6/mol2", 5e-4)
    check(8, "b1", b[0] * 1e6, float(mix.b[0]) * 1e6, "cm3/mol", 5e-3)
    check(8, "b2", b[1] * 1e6, float(mix.b[1]) * 1e6, "cm3/mol", 5e-3)

    a12 = rnd(np.sqrt(a[0] * a[1]), 6)
    amix = rnd(y[0] ** 2 * a[0] + 2 * y[0] * y[1] * a12 + y[1] ** 2 * a[1], 6)
    bmix = rnd(y[0] * b[0] + y[1] * b[1], 6)
    check(8, "a12 (k12 = 0)", a12, float(mix.a_cross(T)[0, 1]), "Pa m6/mol2", 5e-4)
    check(8, "a_mix at the vapour composition", amix, mix.a_mix(T, y),
          "Pa m6/mol2", 5e-4)
    check(8, "b_mix at the vapour composition", bmix * 1e6, mix.b_mix(y) * 1e6,
          "cm3/mol", 5e-3)

    RT = rnd(R * T, 6)
    Ah = rnd(amix * P * 1e3 / RT ** 2, 6)
    Bh = rnd(bmix * P * 1e3 / RT, 7)
    A_ref, B_ref = mix.AB(T, P, y)
    check(8, "A = a P /(RT)^2", Ah, A_ref, "", 5e-7)
    check(8, "B = b P / RT", Bh, B_ref, "", 5e-8)

    # vapour root by Newton from Z = 1
    Z = 1.0
    for _ in range(6):
        fz = Z ** 3 - (1 - Bh) * Z ** 2 + (Ah - 3 * Bh ** 2 - 2 * Bh) * Z \
            - (Ah * Bh - Bh ** 2 - Bh ** 3)
        dfz = 3 * Z ** 2 - 2 * (1 - Bh) * Z + (Ah - 3 * Bh ** 2 - 2 * Bh)
        Z = rnd(Z - fz / dfz, 7)
    Zref = float(mix.select_root(T, P, y, "vapour"))
    check(8, "Z, vapour root", Z, Zref, "", 5e-7)

    L = rnd(np.log((Z + (1 + np.sqrt(2)) * Bh) / (Z + (1 - np.sqrt(2)) * Bh)), 6)
    s1 = rnd(y[0] * a[0] + y[1] * a12, 6)          # sum_j y_j a_1j
    term = rnd(Ah / (2 * np.sqrt(2) * Bh), 6)
    lnphi1 = rnd(b[0] / bmix * (Z - 1) - np.log(Z - Bh)
                 - term * (2 * s1 / amix - b[0] / bmix) * L, 6)
    phi1_hand = rnd(np.exp(lnphi1), 6)
    lnphi_ref, _ = mix.ln_phi(T, P, y, "vapour")
    check(8, "ln phihat_1 (Peng-Robinson)", lnphi1, float(lnphi_ref[0]), "", 5e-6)
    check(8, "phihat_1 (Peng-Robinson)", phi1_hand, float(np.exp(lnphi_ref[0])),
          "", 5e-6)

    # the second virial the cubic implies, against the correlation
    B_PR = rnd(bmix - amix / RT, 6) * 1e6
    B11 = float(c1.B_virial(T)) * 1e6
    B22 = float(c2.B_virial(T)) * 1e6
    B12 = float(dd.B_cross(c1, c2, T)) * 1e6
    B_corr = y[0] ** 2 * B11 + 2 * y[0] * y[1] * B12 + y[1] ** 2 * B22
    check(8, "B implied by Peng-Robinson", B_PR, (mix.b_mix(y) - mix.a_mix(T, y)
                                                  / (R * T)) * 1e6, "cm3/mol", 5e-2)

    # ---- Huron-Vidal ------------------------------------------------------
    gE = M.Margules(FIT_CB.params)
    hv = GX.HuronVidal([c1, c2], gE)
    x = np.array([0.5, 0.5])
    gERT_hand = rnd(0.25 * (-1.2988 * 0.5 + -0.9122 * 0.5), 5)
    check(8, "G^E/RT at x1 = 0.5 (Margules-2)", gERT_hand, hv.gE_RT(T, x), "", 5e-5)

    Ch = -0.62323
    check(8, "C for Peng-Robinson", Ch, GX.C_PR, "", 5e-5)
    s_h = rnd(0.5 * a[0] / (b[0] * RT) + 0.5 * a[1] / (b[1] * RT), 6)
    Dh = rnd(s_h + gERT_hand / Ch, 6)
    check(8, "D = a_mix/(b_mix R T)", Dh, hv.D(T, x), "", 5e-4)
    bmix_x = rnd(0.5 * b[0] + 0.5 * b[1], 7)
    amix_hv = rnd(Dh * bmix_x * RT, 6)
    check(8, "b_mix, Huron-Vidal (linear)", bmix_x * 1e6, hv.b_mix(x) * 1e6,
          "cm3/mol", 5e-3)
    check(8, "a_mix, Huron-Vidal", amix_hv, hv.a_mix(T, x), "Pa m6/mol2", 5e-3)
    a12_x = rnd(np.sqrt(a[0] * a[1]), 6)
    amix_cl = rnd(0.25 * a[0] + 0.5 * a12_x + 0.25 * a[1], 6)
    check(8, "a_mix, classical rule at k12 = 0", amix_cl, mix.a_mix(T, x),
          "Pa m6/mol2", 5e-3)

    vl = GX.vanlaar_equivalent_of_classical(mix, T)
    check(8, "van Laar A implied by the classical rule", 0.0840,
          float(vl.params[0]), "", 5e-4)
    check(8, "van Laar B implied by the classical rule", 0.1093,
          float(vl.params[1]), "", 5e-4)

    return dict(m=m_h, alpha=al, a=a, b=b, a12=a12, amix=amix, bmix=bmix,
                A=A_ref, B=B_ref, Z=Zref, lnphi1=float(lnphi_ref[0]),
                phi1=float(np.exp(lnphi_ref[0])),
                phi2=float(np.exp(lnphi_ref[1])),
                B_PR=B_PR, B_corr=B_corr, B11=B11, B22=B22, B12=B12,
                gERT=hv.gE_RT(T, x), Dhv=hv.D(T, x),
                amix_hv=hv.a_mix(T, x), amix_cl=mix.a_mix(T, x),
                bmix_x=hv.b_mix(x), vl=[float(v) for v in vl.params])


# ==========================================================================
def main():
    p1 = problem_1()
    problem_2(p1)
    p3 = problem_3()
    problem_4(p3)
    problem_5()
    problem_6()
    problem_7()
    problem_8()

    print()
    print("=" * 100)
    print("VLE_Worked_Examples.pdf — every printed answer, hand chain against vlekit")
    print("=" * 100)
    print(f"{'#':>2}  {'quantity':46s} {'hand':>14s} {'vlekit':>14s} "
          f"{'rel.diff':>10s}  ok")
    print("-" * 100)
    bad = 0
    for prob, q, hand, ref, unit, tol, note in ROWS:
        scale = max(abs(ref), 1e-30)
        rel = abs(hand - ref) / scale
        ok = rel <= (tol if tol is not None else 5e-4) or abs(hand - ref) <= (
            tol if tol is not None else 5e-4)
        bad += (not ok)
        lbl = q if not unit else f"{q} / {unit}"
        print(f"{prob:>2}  {lbl:46.46s} {hand:14.6g} {ref:14.6g} "
              f"{rel:10.2e}  {'ok' if ok else 'FAIL'}")
    print("-" * 100)
    print(f"{len(ROWS)} comparisons, {bad} outside tolerance")
    print()
    print("Largest relative disagreements (the places where hand rounding shows):")
    worst = sorted(ROWS, key=lambda r: -abs(r[2] - r[3]) / max(abs(r[3]), 1e-30))[:8]
    for prob, q, hand, ref, unit, tol, note in worst:
        rel = abs(hand - ref) / max(abs(ref), 1e-30)
        print(f"   P{prob}  {q:44.44s} {rel:9.2e}")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
