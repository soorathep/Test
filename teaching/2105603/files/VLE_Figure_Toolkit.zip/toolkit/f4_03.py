#!/usr/bin/env python3
"""F4.3  The area test, drawn as the two areas whose difference must vanish.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

`vlekit.plots.area_plot` draws the picture; this script calls it and then puts
the arithmetic of the test on the figure, because the arithmetic is the lesson.
D is not a measure of how well the data are described. It is the *imbalance*
between the shaded lobes, expressed as a percentage of their sum, so an error
that adds the same amount to both lobes leaves D untouched. The numbers printed
here are the two lobe areas obtained from the Redlich-Kister fit that the test
itself uses.

Dataset: 2-propanol (1) / 2-butanone (2) at 328.15 K, synthesised from
NRTL(0.35, 0.62) with realistic scatter, so its true consistency is known.

Run:  python3 f4_03.py
"""
import os
import sys

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, "/home/claude/vlekit")
import vlekit as v                                              # noqa: E402
from vlekit import plots as pl                                  # noqa: E402
from vlekit.consistency import (area_test, rk_eval,             # noqa: E402
                                rk_fit)
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,     # noqa: E402
                          PAPER, RUST, SLATE, TEAL, newfig)

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_03_area_test"

TRUE = [0.35, 0.62]
T_SET = 328.15
ORDER = 4


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def build():
    c1, c2 = v.component("2-propanol"), v.component("mek")
    dat = v.generate(v.NRTL(TRUE), np.linspace(0.02, 0.98, 21), T=T_SET,
                     c1=c1, c2=c2, label="realistic scatter",
                     noise={"y": 0.003, "P": 0.05, "x": 0.001}, seed=3)

    fig, ax = newfig(7.6, 5.2)
    pl.area_plot(dat, ax=ax, order=ORDER)

    # ---- redo the two lobe areas with the same RK fit the test uses, so the
    # ---- numbers on the figure are the numbers inside area_test()
    d = dat.sorted_by_x()
    g1, g2 = d.gamma("ideal")
    m = d.interior() & np.isfinite(g1) & np.isfinite(g2)
    coeff = rk_fit(d.x1[m], np.log(g1[m] / g2[m]), ORDER)
    xs = np.linspace(0.0, 1.0, 2001)
    rs = rk_eval(coeff, xs)
    A_pos = float(np.trapezoid(np.clip(rs, 0, None), xs))
    A_neg = float(-np.trapezoid(np.clip(rs, None, 0), xs))
    res = area_test(dat, order=ORDER)

    # ---- centroids of the two lobes, so the labels land inside the shading
    def centroid(sign):
        w = np.clip(rs, 0, None) if sign > 0 else -np.clip(rs, None, 0)
        if w.sum() == 0:
            return 0.5, 0.0
        xc = float(np.sum(w * xs) / np.sum(w))
        return xc, 0.5 * float(np.interp(xc, xs, rs))

    xp, yp = centroid(+1)
    xn, yn = centroid(-1)

    ax.annotate(f"$A_+$ = {A_pos:.4f}", xy=(xp, yp), ha="center",
                va="center", fontsize=13, color=TEAL, zorder=8,
                bbox=dict(boxstyle="round,pad=0.26", fc=PAPER, ec="none",
                          alpha=0.88))
    ax.annotate(f"$A_-$ = {A_neg:.4f}", xy=(xn, yn), ha="center",
                va="center", fontsize=13, color=RUST, zorder=8,
                bbox=dict(boxstyle="round,pad=0.26", fc=PAPER, ec="none",
                          alpha=0.88))

    lo, hi = ax.get_ylim()
    span = hi - lo
    ax.set_ylim(lo - 0.34 * span, hi + 0.16 * span)

    verdict = "pass" if res.passed else "FAIL"
    ax.text(0.985, 0.035,
            r"$D = 100\,\dfrac{|A_+ - A_-|}{A_+ + A_-}$"
            f"  $= {res.statistic:.2f}$   "
            f"(threshold {res.threshold:g}: {verdict})",
            transform=ax.transAxes, ha="right", va="bottom", fontsize=12.5,
            color=INK,
            bbox=dict(boxstyle="round,pad=0.40", fc=PAPER, ec=MIST, lw=1.0,
                      alpha=0.95))
    ax.text(0.985, 0.93,
            "$D$ compares the two lobes.\n"
            "An error that grows both by\nthe same amount is invisible to it.",
            transform=ax.transAxes, ha="right", va="top", fontsize=10.5,
            color=SLATE, linespacing=1.45)

    ax.set_title("Area (Redlich-Kister) test — 2-propanol (1) / "
                 "2-butanone (2), 328.15 K", fontsize=13.5)
    ax.legend(loc="lower left", fontsize=11)
    fig.tight_layout()
    return fig, res, A_pos, A_neg


if __name__ == "__main__":
    fig, res, A_pos, A_neg = build()
    print(f"positive lobe area  A+ = {A_pos:.6f}")
    print(f"negative lobe area  A- = {A_neg:.6f}")
    print(f"D = {res.statistic:.4f}  (threshold {res.threshold:g}, "
          f"{'pass' if res.passed else 'FAIL'})")
    print(f"RK order {res.detail['order']}, rms of the RK fit "
          f"{res.detail['rms_fit']:.5f}")
    for p in write(fig, SLUG):
        print("wrote", p)
