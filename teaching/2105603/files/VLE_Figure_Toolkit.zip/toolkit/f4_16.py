#!/usr/bin/env python3
"""F4.16  The SHAPE of G^E each model can draw — not a feature table.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

F3.6 already tabulates what each model can do. This figure asks a narrower and
sharper question: given the same two numbers at the two ends, what curve does
each functional form put in between? Nothing is fitted here, and that is the
whole design. Every model on the figure is a two-parameter model, so its two
parameters are exactly used up by matching the two infinite-dilution activity
coefficients

    ln gamma_1^inf = lim_{x1 -> 0} ln gamma_1,
    ln gamma_2^inf = lim_{x1 -> 1} ln gamma_2

Once both ends are pinned there is no freedom left. Whatever the curves do
between the ends is the FORM, and only the form. The residual of the endpoint
match is printed for every model so that the reader can confirm the pinning is
exact rather than approximate.

THE REDUCED FUNCTION, which is where the algebra becomes visible. Write

    Q(x1) = G^E / (R T x1 x2),        Q(0) = ln gamma_1^inf,
                                      Q(1) = ln gamma_2^inf

Then, as identities and not as observations:

    Margules-2   Q = A21 x1 + A12 x2         a STRAIGHT LINE. With both ends
                                             pinned, Margules-2 has no
                                             remaining freedom at all: it is
                                             the chord, always.
    van Laar     Q = AB/(A x1 + B x2)        a hyperbola, monotone, with
                                             d2Q/dx1^2 = 2AB(A-B)^2/(...)^3 of
                                             fixed sign: NO interior
                                             inflection, ever.
    Wilson,      Q contains logarithms of composition and can bend either way.
    NRTL,
    UNIQUAC

The script checks both identities numerically over parameter sweeps instead of
asserting them, and prints the result.

PANEL (c) is the shape Wilson cannot make. All five models are pinned to the
same STRONG symmetric ends, ln gamma_i^inf = 2.4 in both directions, and the
Gibbs energy of mixing is drawn. Four of them fall below their own chord and
split into two liquid phases. Wilson does not, and cannot: a sweep of
140 x 140 = 19600 pairs of Lambda values, log-spaced over [1e-3, 60], finds not
one unstable point, and the smallest second derivative of Delta g_mix found
anywhere on that grid is reported as a positive number. This is a property of
the algebra of the Wilson equation, not of the fitting.

REFERENCE CURVE. The target in panels (a) and (b) is the original UNIFAC
prediction for ethanol (1) + water (2) at 323.15 K, from the published group
table embedded in `vlekit.unifac`. It is a prediction, not a measurement, and
the figure says so; its only role is to be a real, published, strongly skewed
G^E that none of the five two-parameter forms can reach once their ends are
pinned. The measured G^E/RT of the module's own ethanol + water dataset
(doi:10.1021/je2008704) is plotted with it, as points.

Run:  python3 f4_16.py
"""
from __future__ import annotations

import os
import sys
import time

import numpy as np
from scipy.optimize import least_squares

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib                                                  # noqa: E402
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                    # noqa: E402

import vlekit as v                                                 # noqa: E402
from vlekit import datasets as D                                   # noqa: E402
from vlekit import flash as FL                                     # noqa: E402
from vlekit.models import (NRTL, UNIQUAC, Margules, VanLaar,       # noqa: E402
                           Wilson)
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY, PAPER,  # noqa: E402
                          RUST, SKYBLUE, SLATE, TEAL, use_style)
from vlekit.unifac import UNIFACModel                              # noqa: E402

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_16_model_shape_capability"

T_REF = 323.15
EPS = 1e-10
NSWEEP = 60           # 60 x 60 grids for the inflection sweeps
NWILSON = 140         # 140 x 140 for the Wilson stability claim
STRONG = (2.4, 2.4)   # the symmetric ends used in panel (c)

COL = {"Margules-2": NAVY, "van Laar": SKYBLUE, "Wilson": RUST,
       "NRTL": TEAL, "UNIQUAC": AMBER}


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def wrapped(text, width):
    """Wrap a caption on spaces, never inside a $...$ span."""
    out = []
    for para in text.split("\n"):
        cur, n, inmath = [], 0, False
        for w in para.split(" "):
            if cur and not inmath and n + 1 + len(w) > width:
                out.append(" ".join(cur))
                cur, n = [], 0
            cur.append(w)
            n += len(w) + (1 if n else 0)
            if w.count("$") % 2 == 1:
                inmath = not inmath
        out.append(" ".join(cur))
    return "\n".join(out)


# ==========================================================================
def ends(m):
    """(ln gamma_1^inf, ln gamma_2^inf) of a model."""
    return (float(m.ln_gamma(np.array([EPS]))[0][0]),
            float(m.ln_gamma(np.array([1 - EPS]))[1][0]))


def BUILDERS(et, wa):
    return {
        "Margules-2": (lambda p: Margules(p), [1.5, 1.0], (-12.0, 12.0)),
        "van Laar": (lambda p: VanLaar(p), [1.5, 1.0], (1e-4, 30.0)),
        "Wilson": (lambda p: Wilson(p), [0.3, 0.8], (1e-8, 60.0)),
        "NRTL": (lambda p: NRTL(p), [0.0, 1.5], (-12.0, 20.0)),
        "UNIQUAC": (lambda p: UNIQUAC(p, r1=et.r, q1=et.q, r2=wa.r, q2=wa.q),
                    [0.5, 0.9], (1e-8, 25.0)),
    }


def pin(build, p0, lo, hi, target):
    """Solve the two parameters so that BOTH infinite-dilution ends match."""
    def resid(p):
        try:
            e = ends(build(p))
        except Exception:
            return [1e3, 1e3]
        return [e[0] - target[0], e[1] - target[1]]

    s = least_squares(resid, p0, bounds=(lo, hi), xtol=1e-15, ftol=1e-15,
                      gtol=1e-15)
    return build(s.x), s.x, float(np.max(np.abs(s.fun)))


def Q_of(m, x):
    return np.asarray(m.gE_RT(x), dtype=float) / (x * (1 - x))


def inflects(m, x):
    """True if d2Q/dx1^2 changes sign strictly inside (0, 1)."""
    Q = Q_of(m, x)
    d2 = np.diff(Q, 2)
    d2 = d2[np.isfinite(d2)]
    if d2.size == 0:
        return False
    s = np.sign(d2[np.abs(d2) > 1e-12])
    return bool(s.size and np.any(s[:-1] * s[1:] < 0))


# --------------------------------------------------------------------------
def analyse():
    t0 = time.time()
    et, wa = v.component("ethanol"), v.component("water")
    ref = UNIFACModel(et, wa)
    x = np.linspace(1e-4, 1 - 1e-4, 801)

    target = (float(ref.ln_gamma(np.array([EPS]), T_REF)[0][0]),
              float(ref.ln_gamma(np.array([1 - EPS]), T_REF)[1][0]))

    B = BUILDERS(et, wa)
    pinned, strong = {}, {}
    for k, (b, p0, bd) in B.items():
        m, p, r = pin(b, p0, bd[0], bd[1], target)
        pinned[k] = dict(model=m, params=p, resid=r, gE=m.gE_RT(x),
                         Q=Q_of(m, x))
        m2, p2, r2 = pin(b, p0, bd[0], bd[1], STRONG)
        gap = FL.miscibility_gap(m2)
        strong[k] = dict(model=m2, params=p2, resid=r2,
                         g=FL.g_mix(m2, x), gap=gap,
                         min_d2=float(np.min(FL.d2g_mix(m2, x))))

    gE_ref = np.asarray(ref.gE_RT(x, T_REF), dtype=float)
    Q_ref = gE_ref / (x * (1 - x))

    # ------------------------------------------------ the shape identities
    xs = np.linspace(0.02, 0.98, 241)
    gA = np.linspace(0.1, 5.0, NSWEEP)
    gV = np.geomspace(0.05, 12.0, NSWEEP)
    gW = np.geomspace(1e-3, 30.0, NSWEEP)
    gN = np.linspace(-3.0, 6.0, NSWEEP)
    gU = np.geomspace(1e-3, 8.0, NSWEEP)

    def sweep_inflect(build, grid):
        n = tot = 0
        for a in grid:
            for b in grid:
                try:
                    m = build([a, b])
                except Exception:
                    continue
                tot += 1
                if inflects(m, xs):
                    n += 1
        return n, tot

    shape = {}
    shape["Margules-2"] = sweep_inflect(lambda p: Margules(p), gA)
    shape["van Laar"] = sweep_inflect(lambda p: VanLaar(p), gV)
    shape["Wilson"] = sweep_inflect(lambda p: Wilson(p), gW)
    shape["NRTL"] = sweep_inflect(lambda p: NRTL(p), gN)
    shape["UNIQUAC"] = sweep_inflect(
        lambda p: UNIQUAC(p, r1=et.r, q1=et.q, r2=wa.r, q2=wa.q), gU)

    # Margules-2's Q is the chord, as an identity: measure the departure
    chord_err = 0.0
    for a in gA:
        for b in gA:
            Q = Q_of(Margules([a, b]), xs)
            line = Q[0] + (Q[-1] - Q[0]) * (xs - xs[0]) / (xs[-1] - xs[0])
            chord_err = max(chord_err, float(np.max(np.abs(Q - line))))

    # ------------------------------------------- the Wilson stability sweep
    xw = np.linspace(1e-4, 1 - 1e-4, 401)
    gWbig = np.geomspace(1e-3, 60.0, NWILSON)
    w_min, w_bad, w_tot = np.inf, 0, 0
    for a in gWbig:
        for b in gWbig:
            d2 = FL.d2g_mix(Wilson([a, b]), xw)
            mn = float(np.min(d2))
            w_min = min(w_min, mn)
            w_tot += 1
            if mn <= 0:
                w_bad += 1

    # ------------------------------------------------------- the real data
    dat = D.ethanol_water()
    g1, g2 = dat.gamma()
    mk = dat.interior() & np.isfinite(g1) & np.isfinite(g2)
    gE_dat = dat.x1[mk] * np.log(g1[mk]) + (1 - dat.x1[mk]) * np.log(g2[mk])

    return dict(x=x, target=target, pinned=pinned, strong=strong,
                gE_ref=gE_ref, Q_ref=Q_ref, shape=shape, chord_err=chord_err,
                w_min=w_min, w_bad=w_bad, w_tot=w_tot, dat=dat,
                x_dat=dat.x1[mk], gE_dat=gE_dat, elapsed=time.time() - t0)


# ==========================================================================
def spread(y, dy):
    y = np.asarray(y, dtype=float)
    o = np.argsort(y)
    out = y.copy()
    for k in range(1, len(o)):
        i, j = o[k - 1], o[k]
        if out[j] - out[i] < dy:
            out[j] = out[i] + dy
    return out


def build(d):
    use_style()
    fig, (axA, axB, axC) = plt.subplots(1, 3, figsize=(15.6, 6.9))
    x = d["x"]

    # ------------------------------------------------------------- panel (a)
    axA.grid(True, zorder=0)
    axA.set_axisbelow(True)
    axA.plot(x, d["gE_ref"], "-", color=GRAPHITE, lw=3.4, alpha=0.35, zorder=2)
    axA.plot(d["x_dat"], d["gE_dat"], "o", color=INK, mfc=PAPER, mew=1.5,
             ms=5.5, zorder=6)
    peaks = {}
    for k, r in d["pinned"].items():
        axA.plot(x, r["gE"], "-", color=COL[k], lw=2.0, zorder=4)
        peaks[k] = (float(x[np.argmax(r["gE"])]), float(np.max(r["gE"])))
    axA.set_xlim(0, 1)
    axA.set_xlabel("$x_1$   (ethanol)")
    axA.set_ylabel(r"$G^E/RT$")
    hi = max(v[1] for v in peaks.values())
    axA.set_ylim(-0.02 * hi, 1.42 * hi)
    axA.set_title("(a)  both ends pinned to the same\n"
                  r"$\gamma_i^{\infty}$ — the interior is the FORM",
                  fontsize=11.6, pad=6)
    lo_pk = min(v[1] for v in peaks.values())
    # the arrow goes where the curves are actually furthest apart, which is
    # computed, not chosen
    stack = np.vstack([r["gE"] for r in d["pinned"].values()])
    jp = int(np.argmax(np.ptp(stack, axis=0)))
    xp = float(x[jp])
    axA.annotate("", xy=(xp, float(np.min(stack[:, jp]))),
                 xytext=(xp, float(np.max(stack[:, jp]))),
                 arrowprops=dict(arrowstyle="<->", color=GRAPHITE, lw=1.8),
                 zorder=8)
    axA.text(0.575, 0.90 * hi,
             f"{100 * (hi - lo_pk) / lo_pk:.0f} % spread at the peak,\n"
             "with both ends pinned and\nnothing left to adjust",
             fontsize=9.4, color=GRAPHITE, ha="left", va="center",
             linespacing=1.45, zorder=8,
             bbox=dict(boxstyle="round,pad=0.24", fc=PAPER, ec=MIST, lw=0.9,
                       alpha=0.95))
    axA.text(0.03, 0.965,
             "thick grey: UNIFAC prediction\n"
             "circles: measured $G^E\\!/RT$,\ndoi:10.1021/je2008704",
             transform=axA.transAxes, ha="left", va="top", fontsize=9.0,
             color=GRAPHITE, linespacing=1.5, zorder=8,
             bbox=dict(boxstyle="round,pad=0.24", fc=PAPER, ec=MIST, lw=0.9,
                       alpha=0.95))

    # ------------------------------------------------------------- panel (b)
    axB.grid(True, zorder=0)
    axB.set_axisbelow(True)
    axB.plot(x, d["Q_ref"], "-", color=GRAPHITE, lw=3.4, alpha=0.35, zorder=2)
    for k, r in d["pinned"].items():
        axB.plot(x, r["Q"], "-", color=COL[k], lw=2.0, zorder=4)
    axB.plot([0, 1], [d["target"][0], d["target"][1]], "o", color=INK, ms=9,
             mfc=PAPER, mew=1.8, zorder=7, clip_on=False)
    axB.set_xlim(0, 1)
    axB.set_xlabel("$x_1$   (ethanol)")
    axB.set_ylabel(r"$Q = G^E/(R T x_1 x_2)$")
    axB.set_title("(b)  the same curves, reduced —\n"
                  "where the algebra becomes visible", fontsize=11.6, pad=6)

    # direct labels at the composition where the curves are most separated
    j = int(np.argmax(np.ptp(np.vstack([r["Q"] for r in d["pinned"].values()]),
                             axis=0)))
    j = int(np.clip(j, 30, len(x) - 60))
    names = list(d["pinned"].keys())
    yv = np.array([d["pinned"][k]["Q"][j] for k in names])
    lo, hi = axB.get_ylim()
    axB.set_ylim(lo, hi + 0.10 * (hi - lo))
    lo, hi = axB.get_ylim()
    yl = spread(yv, 0.088 * (hi - lo))
    for k, y0, y1 in zip(names, yv, yl):
        axB.annotate(k, xy=(x[j], y0), xytext=(x[j] + 0.075, y1),
                     ha="left", va="center", fontsize=9.6, color=COL[k],
                     zorder=9,
                     bbox=dict(boxstyle="round,pad=0.18", fc=PAPER, ec="none",
                               alpha=0.90),
                     arrowprops=dict(arrowstyle="-", color=COL[k], lw=0.9,
                                     shrinkA=1, shrinkB=3))
    sh = d["shape"]
    axB.text(0.03, 0.035,
             "checked, not asserted:\n"
             r"Margules-2  $Q$ is the chord to "
             f"{d['chord_err']:.0e}\n"
             f"van Laar  inflects in {sh['van Laar'][0]} of "
             f"{sh['van Laar'][1]} parameter pairs\n"
             f"NRTL  inflects in {sh['NRTL'][0]} of {sh['NRTL'][1]}",
             transform=axB.transAxes, ha="left", va="bottom", fontsize=8.8,
             color=GRAPHITE, linespacing=1.55, zorder=8,
             bbox=dict(boxstyle="round,pad=0.26", fc=PAPER, ec=MIST, lw=0.9,
                       alpha=0.95))

    # ------------------------------------------------------------- panel (c)
    axC.grid(True, zorder=0)
    axC.set_axisbelow(True)
    axC.axhline(0.0, color=GRAPHITE, lw=1.0, zorder=2)
    for k, r in d["strong"].items():
        tag = (f"{k} — splits {r['gap']['x1_phase_a']:.2f} / "
               f"{r['gap']['x1_phase_b']:.2f}" if r["gap"]
               else f"{k} — NO SPLIT, whatever the parameters")
        if k == "van Laar":
            tag += "  (= Margules-2 when $A = B$)"
        axC.plot(x, r["g"], "-", color=COL[k], lw=2.0, zorder=4, label=tag)
        if r["gap"]:
            xa, xb = r["gap"]["x1_phase_a"], r["gap"]["x1_phase_b"]
            ga = float(FL.g_mix(r["model"], np.array([xa]))[0])
            gb = float(FL.g_mix(r["model"], np.array([xb]))[0])
            axC.plot([xa, xb], [ga, gb], "--", color=COL[k], lw=1.2, zorder=3)
            axC.plot([xa, xb], [ga, gb], "o", color=COL[k], ms=6, zorder=5)
    axC.set_xlim(0, 1)
    axC.set_xlabel("$x_1$")
    axC.set_ylabel(r"$\Delta g_{\rm mix}/RT$")
    axC.set_title("(c)  the shape Wilson cannot make —\n"
                  r"all five pinned at $\ln\gamma_i^{\infty}$ = "
                  f"{STRONG[0]:g}", fontsize=11.6, pad=6)

    glo = min(float(np.min(r["g"])) for r in d["strong"].values())
    axC.set_ylim(1.75 * glo, -0.30 * glo)
    axC.legend(loc="upper right", fontsize=8.6, handlelength=1.6,
               labelspacing=0.45)
    axC.text(0.025, 0.030,
             "Wilson cannot represent a liquid-liquid split AT ALL —\n"
             "a property of its algebra, not of its parameters.\n"
             f"Sweep of {NWILSON}$\\times${NWILSON} = {d['w_tot']} "
             r"$\Lambda$ pairs over $[10^{-3},\,60]$:" "\n"
             f"{d['w_bad']} unstable, and the smallest "
             r"$\mathrm{d}^2\Delta g_{\rm mix}/\mathrm{d}x_1^2$"
             f"\nfound anywhere on that grid is {d['w_min']:+.2e}",
             transform=axC.transAxes, ha="left", va="bottom", fontsize=8.8,
             color=RUST, linespacing=1.55, zorder=8,
             bbox=dict(boxstyle="round,pad=0.26", fc=PAPER, ec=RUST, lw=1.0,
                       alpha=0.96))

    fig.suptitle("What shape of $G^E$ each model can draw — every model here "
                 "is a TWO-parameter model with both parameters already spent "
                 "on the two ends", fontsize=14.0, y=0.985)
    fig.text(0.5, 0.018, wrapped(
        "Nothing on this figure is fitted to data. Each model's two "
        "parameters are solved so that both infinite-dilution activity "
        "coefficients match a common target exactly; the largest endpoint "
        "residual over all five models and both targets is "
        f"{max(max(r['resid'] for r in d['pinned'].values()), max(r['resid'] for r in d['strong'].values())):.1e} "
        "in $\\ln\\gamma^\\infty$. Target for (a) and (b): original UNIFAC "
        "for ethanol + water at 323.15 K from the published group table in "
        "vlekit.unifac — a PREDICTION, not a measurement, plotted with the "
        "measured $G^E\\!/RT$ of doi:10.1021/je2008704 for scale. UNIQUAC "
        "$r$, $q$ are UNIFAC group sums, not fitted. NRTL $\\alpha$ = 0.3, "
        "not fitted.\n"
        "The reduced function $Q = G^E/(RTx_1x_2)$ has $Q(0) = "
        "\\ln\\gamma_1^\\infty$ and $Q(1) = \\ln\\gamma_2^\\infty$, so in "
        "panel (b) every curve is forced through the same two open circles "
        "and only the form is left. Margules-2 is then the chord and has no "
        "freedom at all; van Laar is a monotone hyperbola with "
        "$\\mathrm{d}^2Q/\\mathrm{d}x_1^2$ of fixed sign. Both statements are "
        "identities, and both are checked by sweep rather than asserted.",
        168), ha="center", va="bottom", fontsize=9.5, color=SLATE,
        linespacing=1.6)
    fig.tight_layout(rect=(0.005, 0.275, 0.995, 0.930))
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = analyse()
    t = d["target"]
    print(f"target ends from original UNIFAC, ethanol + water at {T_REF} K: "
          f"ln g1_inf = {t[0]:.5f} (g1_inf = {np.exp(t[0]):.4f}), "
          f"ln g2_inf = {t[1]:.5f} (g2_inf = {np.exp(t[1]):.4f})")
    print()
    print(f"  {'model':11s} {'parameters':26s} {'end resid':>10s} "
          f"{'max G^E/RT':>11s} {'at x1':>7s} {'Q(0.5)':>8s}")
    x = d["x"]
    for k, r in d["pinned"].items():
        ps = ", ".join(f"{q:+.5f}" for q in r["params"])
        i = int(np.argmax(r["gE"]))
        print(f"  {k:11s} [{ps:24s}] {r['resid']:10.1e} "
              f"{float(np.max(r['gE'])):11.5f} {float(x[i]):7.3f} "
              f"{float(r['Q'][len(x) // 2]):8.4f}")
    i = int(np.argmax(d["gE_ref"]))
    print(f"  {'UNIFAC':11s} {'(no parameters)':26s} {'—':>10s} "
          f"{float(np.max(d['gE_ref'])):11.5f} {float(x[i]):7.3f} "
          f"{float(d['Q_ref'][len(x) // 2]):8.4f}")
    pk = [float(np.max(r["gE"])) for r in d["pinned"].values()]
    print(f"  spread of the peak height across the five forms: "
          f"{min(pk):.4f} to {max(pk):.4f}, i.e. "
          f"{100 * (max(pk) - min(pk)) / min(pk):.1f} % — with both ends "
          f"pinned and nothing left to adjust")
    print(f"  the UNIFAC target's Q(0.5) = {float(d['Q_ref'][len(x)//2]):.4f} "
          f"lies OUTSIDE the range the five forms span "
          f"({min(float(r['Q'][len(x)//2]) for r in d['pinned'].values()):.4f}"
          f" to "
          f"{max(float(r['Q'][len(x)//2]) for r in d['pinned'].values()):.4f})")
    print()
    print("shape identities, checked by parameter sweep "
          f"({NSWEEP}x{NSWEEP} grids):")
    print(f"  Margules-2: max |Q - chord| over the grid = {d['chord_err']:.3e} "
          "(it IS the chord)")
    for k, (n, tot) in d["shape"].items():
        print(f"  {k:11s} d2Q/dx1^2 changes sign inside (0,1) in "
              f"{n:5d} of {tot:5d} parameter pairs")
    print()
    print(f"panel (c): all five pinned at ln gamma_i^inf = {STRONG[0]:g} "
          f"both ways")
    for k, r in d["strong"].items():
        ps = ", ".join(f"{q:+.5f}" for q in r["params"])
        g = (f"splits {r['gap']['x1_phase_a']:.4f} / "
             f"{r['gap']['x1_phase_b']:.4f}" if r["gap"] else "NO SPLIT")
        print(f"  {k:11s} [{ps:24s}] end resid {r['resid']:.1e}  "
              f"min d2g/dx1^2 = {r['min_d2']:+.5f}   {g}")
    print(f"  Wilson sweep: {d['w_bad']} unstable of {d['w_tot']} pairs; "
          f"min d2(dg_mix)/dx1^2 anywhere on the grid = {d['w_min']:+.4e}")
    print(f"  [analyse() took {d['elapsed']:.1f} s]")
    for p in write(build(d), SLUG):
        print("wrote", p)
