#!/usr/bin/env python3
"""F4.5  Three teaching datasets — consistent, borderline, inconsistent —
        with every test statistic tabulated underneath.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

All three sets are isobaric 2-propanol (1) / 2-butanone (2) at 101.325 kPa,
generated from NRTL(0.35, 0.62) with the same scatter and the same seed. They
differ only in the size b of a systematic bias  delta y1 = b x1 x2  added to
the vapour compositions. Isobaric data are used so that all five tests in
`vlekit.consistency` apply — Herington's D-J test is defined only when the
temperature varies across the set.

'Borderline' is the value of b at which the set still passes every test and
should nevertheless worry the reader: b = 0.06 gives an area D of 9.7 against a
threshold of 10 and a mean |dy1| of 0.0095 against a threshold of 0.01, while
the point test already calls it index 4 — marginal on the Van Ness scale. A set
that passes on the strength of the third decimal place is a more useful
teaching object than one four tests reject.

The cliff is worth recording too: between b = 0.06 and b = 0.08 four of the
five verdicts flip together. The tests are therefore not independent detectors.
They are largely responding to the same residual with different thresholds,
which is why a dataset must be reported with all of them rather than with the
one that happens to pass.

Everything printed on the figure is the value returned by
`consistency.run_all`.

Run:  python3 f4_05.py
"""
import os
import sys

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, "/home/claude/vlekit")
import vlekit as v                                              # noqa: E402
from vlekit import consistency as C                             # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,     # noqa: E402
                          PAPER, RUST, SLATE, TEAL, use_style)

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_05_three_datasets_tests"

TRUE = [0.35, 0.62]
P_SET = 101.325
BIASES = [(0.00, "consistent", TEAL),
          (0.06, "borderline", AMBER),
          (0.30, "inconsistent", RUST)]
THRESH_DY = 0.01

ROWS = [("area (Redlich-Kister),  $D$", "10", "{:.2f}"),
        ("Herington,  $|D-J|$", "10", "{:.2f}"),
        ("point (VNBG),  mean $|\\delta y_1|$", "0.01", "{:.4f}"),
        ("direct (Van Ness),  rms $\\delta$", "0.05", "{:.4f}"),
        ("infinite dilution (Kojima)", "30", "{:.1f}")]


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def make():
    c1, c2 = v.component("2-propanol"), v.component("mek")
    truth = v.NRTL(TRUE)
    x = np.linspace(0.02, 0.98, 21)
    sets = []
    for b, name, col in BIASES:
        noise = {"y": 0.002, "T": 0.05}
        if b:
            noise["y_bias"] = b
        d = v.generate(truth, x, P=P_SET, c1=c1, c2=c2, kind="isobaric",
                       label=name, noise=noise, seed=3)
        f = v.barker_fit(d, "nrtl")
        sets.append({"b": b, "name": name, "colour": col, "data": d,
                     "fit": f, "tests": C.run_all(d, "nrtl")})
    return sets


def build(sets):
    use_style()
    fig = plt.figure(figsize=(13.0, 8.6))
    gs = fig.add_gridspec(2, 3, height_ratios=[1.0, 0.80], hspace=0.34,
                          wspace=0.16)

    allr = np.concatenate([s["fit"].y1_calc - s["data"].y1 for s in sets])
    dlo, dhi = float(np.min(allr)), float(np.max(allr))
    dlo, dhi = min(dlo, -THRESH_DY), max(dhi, THRESH_DY)
    pad = 0.14 * (dhi - dlo)

    axes = []
    for i, s in enumerate(sets):
        ax = fig.add_subplot(gs[0, i])
        ax.grid(True, zorder=0)
        ax.set_axisbelow(True)
        ax.axhspan(-THRESH_DY, THRESH_DY, color=MIST, alpha=0.45, zorder=1)
        ax.axhline(0.0, color=GRAPHITE, lw=1.1, zorder=2)
        dy = s["fit"].y1_calc - s["data"].y1
        ax.plot(s["data"].x1, dy, "o-", color=s["colour"], mfc=PAPER,
                mew=1.7, lw=1.8, ms=6.5, zorder=4)
        ax.set_xlim(0, 1)
        ax.set_ylim(dlo - pad, dhi + pad)
        ax.set_xlabel("$x_1$")
        if i == 0:
            ax.set_ylabel(r"$\delta y_1 = y_1^{\rm calc} - y_1^{\rm exp}$")
        else:
            ax.set_yticklabels([])
        ax.set_title(f"({'abc'[i]})  {s['name']}\n"
                     f"bias $b$ = {s['b']:.2f}",
                     fontsize=13, color=s["colour"], linespacing=1.4)
        axes.append(ax)
    axes[0].text(0.04, 0.05, f"shaded: $\\pm${THRESH_DY:g} band",
                 transform=axes[0].transAxes, fontsize=10, color=SLATE,
                 ha="left", va="bottom")

    # ------------------------------------------------------------- the table
    tab = fig.add_subplot(gs[1, :])
    tab.axis("off")
    tab.set_xlim(0, 1)
    tab.set_ylim(0, 1)

    xcol = [0.005, 0.315, 0.500, 0.700, 0.900]
    ytop, dyr = 0.90, 0.148

    tab.text(xcol[0], ytop, "consistency test", fontsize=12,
             fontweight="bold", color=INK, ha="left", va="center")
    tab.text(xcol[1], ytop, "threshold", fontsize=12, fontweight="bold",
             color=INK, ha="center", va="center")
    for j, s in enumerate(sets):
        tab.text(xcol[2 + j], ytop, s["name"], fontsize=12,
                 fontweight="bold", color=s["colour"], ha="center",
                 va="center")
    tab.plot([0.0, 1.0], [ytop - 0.075] * 2, "-", color=GRAPHITE, lw=1.2,
             clip_on=False)

    for r, (label, thr, fmt) in enumerate(ROWS):
        y = ytop - 0.115 - r * dyr
        if r % 2 == 1:
            tab.add_patch(plt.Rectangle((0.0, y - 0.062), 1.0, 0.124,
                                        facecolor=MIST, alpha=0.22, lw=0,
                                        zorder=0))
        tab.text(xcol[0], y, label, fontsize=11.5, color=INK, ha="left",
                 va="center", zorder=3)
        tab.text(xcol[1], y, thr, fontsize=11.5, color=SLATE, ha="center",
                 va="center", zorder=3)
        for j, s in enumerate(sets):
            t = s["tests"][r]
            txt = fmt.format(t.statistic)
            if t.index:
                txt += f"   (index {t.index})"
            tab.text(xcol[2 + j], y, txt, fontsize=11.5, ha="center",
                     va="center", zorder=3,
                     color=TEAL if t.passed else RUST,
                     fontweight="normal" if t.passed else "bold")
    tab.plot([0.0, 1.0], [ytop - 0.115 - 4.5 * dyr] * 2, "-", color=GRAPHITE,
             lw=1.0, clip_on=False)
    tab.text(0.0, ytop - 0.115 - 5.35 * dyr,
             "Green = pass, red = fail.  Every value is what "
             "vlekit.consistency.run_all returned for the set plotted "
             "above it.\n"
             "At $b$ = 0.06 every test passes — the area test by 0.3 of its "
             "threshold, the point test by 0.0005 — yet the point index is "
             "already 4, which is marginal.\n"
             "Between $b$ = 0.06 and $b$ = 0.08 four of the five verdicts "
             "flip together: these are not independent detectors, but one "
             "residual read at different thresholds.\n"
             "Report a dataset with all five, never with the one that "
             "happens to pass.",
             fontsize=10.5, color=SLATE, ha="left", va="top",
             linespacing=1.5)

    fig.suptitle("2-propanol (1) / 2-butanone (2), isobaric at "
                 f"{P_SET:g} kPa — the same experiment at three bias levels "
                 r"$\delta y_1 = b\,x_1x_2$", fontsize=14, y=0.985)
    return fig


if __name__ == "__main__":
    sets = make()
    for s in sets:
        print(f"\n--- {s['name']}  (b = {s['b']:.2f}, "
              f"T = {s['data'].T.min():.2f}-{s['data'].T.max():.2f} K, "
              f"n = {s['data'].n}) ---")
        print(C.report(s["tests"]))
    for p in write(build(sets), SLUG):
        print("wrote", p)
