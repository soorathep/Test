#!/usr/bin/env python3
"""F4.8  Two fits the data cannot tell apart: one predicts a liquid-liquid
        split, the other does not.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

n-hexane (1) / methanol (2) at 318.15 K, measured only over x1 = 0.60 to 0.98
(the arrangement used in examples/module4_pipeline.py step 7). A two-parameter
Margules model is fitted by Barker's method, and two parameter sets are then
taken from the *same* fit: the two points one joint standard error away from
the optimum along the least-determined direction of the covariance matrix.

Neither is a different model and neither is a worse fit — their residuals in P
agree to three decimal places, well inside the 0.5 kPa scatter of the data.
They disagree about whether the liquid separates into two phases at all. The
bootstrap puts a number on that disagreement: a fraction of the replicates
predict a split and the rest do not, and that fraction is printed on the
figure.

Run:  python3 f4_08.py
"""
import os
import sys

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, "/home/claude/vlekit")
import vlekit as v                                              # noqa: E402
from vlekit import plots as pl                                  # noqa: E402
from vlekit.flash import miscibility_gap                        # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,     # noqa: E402
                          PAPER, RUST, SLATE, TEAL, use_style)
from vlekit.regress import bubble_P                             # noqa: E402

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_08_indistinguishable_fits_lle"

T_SET = 318.15
X_LO, X_HI, NPT = 0.60, 0.98, 9
TRUTH = [2.05, 1.98]
NOISE = {"y": 0.006, "P": 0.5}          # sigma_P = 0.5 kPa on 50-78 kPa
SEED = 5
N_BOOT = 300


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def make():
    c1, c2 = v.component("n-hexane"), v.component("methanol")
    dat = v.generate(v.Margules(TRUTH), np.linspace(X_LO, X_HI, NPT),
                     T=T_SET, c1=c1, c2=c2, noise=NOISE, seed=SEED,
                     label="measured only for $x_1 > 0.60$")
    best = v.fit(dat, "margules")

    # the least-determined direction of the fit: the eigenvector of the
    # covariance matrix with the largest eigenvalue. One joint standard error
    # either way along it gives two parameter sets the data do not separate.
    w, V = np.linalg.eigh(best.cov)
    j = int(np.argmax(w))
    step = np.sqrt(w[j]) * V[:, j]

    cand = []
    for sgn in (+1, -1):
        p = best.params + sgn * step
        m = v.Margules(p)
        P, y = bubble_P(m, dat.x1, dat.T, c1, c2)
        cand.append({"params": p, "model": m,
                     "rms_P": float(np.sqrt(np.mean((P - dat.P) ** 2))),
                     "rms_y": float(np.sqrt(np.mean((y - dat.y1) ** 2))),
                     "gap": miscibility_gap(m, T_SET)})
    # order them so the one without a split is drawn first
    cand.sort(key=lambda c: c["gap"] is not None)

    boot = v.bootstrap(dat, "margules", n_boot=N_BOOT, seed=1)
    gaps = [miscibility_gap(v.Margules(p), T_SET) for p in boot["samples"]]
    frac_split = float(np.mean([g is not None for g in gaps]))
    return c1, c2, dat, best, cand, frac_split


def build(c1, c2, dat, best, cand, frac_split):
    cols = [NAVY, AMBER]
    names = ["fit A", "fit B"]
    use_style()
    fig, (axL, axR) = plt.subplots(1, 2, figsize=(12.8, 5.4))

    # ------------------------------------------ (a) the fit the data can see
    axL.grid(True, zorder=0)
    axL.set_axisbelow(True)
    axL.axvspan(X_LO, X_HI, color=MIST, alpha=0.40, zorder=0)
    xs = np.linspace(1e-5, 1 - 1e-5, 500)
    for cd, col, nm in zip(cand, cols, names):
        P, _ = bubble_P(cd["model"], xs, np.full_like(xs, T_SET), c1, c2)
        axL.plot(xs, P, "-", color=col, lw=2.4, zorder=4,
                 label=f"{nm}:  $A_{{12}}$ = {cd['params'][0]:.3f},  "
                       f"$A_{{21}}$ = {cd['params'][1]:.3f}")
    axL.plot(dat.x1, dat.P, "o", color=INK, mfc=PAPER, mew=1.8, ms=8,
             zorder=6, label=f"data ({dat.n} points, "
                             f"$\\sigma_P$ = {NOISE['P']:g} kPa)")
    axL.set_xlabel("$x_1$   (n-hexane)")
    axL.set_ylabel("bubble pressure $P$ / kPa")
    axL.set_xlim(0, 1)
    plo, phi = axL.get_ylim()
    axL.set_ylim(plo, phi + 0.28 * (phi - plo))
    axL.legend(loc="lower left", bbox_to_anchor=(0.13, 0.02),
               fontsize=10.5)
    axL.set_title("(a)  where the data are, the two fits are the same curve",
                  fontsize=13)
    axL.text(0.5 * (X_LO + X_HI), 0.965,
             f"data cover $x_1$ = {X_LO:g}–{X_HI:g}",
             transform=axL.get_xaxis_transform(which="grid"), ha="center",
             va="top", fontsize=10.5, color=SLATE)
    axL.text(0.025, 0.965,
             f"rms $\\delta P$:  fit A {cand[0]['rms_P']:.3f} kPa,  "
             f"fit B {cand[1]['rms_P']:.3f} kPa",
             transform=axL.transAxes, ha="left", va="top", fontsize=10.5,
             color=INK)

    # ----------------------------------- (b) the question the data never asked
    pl.gmix_plot([cd["model"] for cd in cand], T=T_SET,
                 labels=[f"{nm}: {'no split' if cd['gap'] is None else 'splits'}"
                         for nm, cd in zip(names, cand)], ax=axR)
    axR.set_title("(b)  the same two fits, asked about stability", fontsize=13)
    axR.set_xlabel("$x_1$   (n-hexane)")

    lo, hi = axR.get_ylim()
    axR.set_ylim(lo - 0.28 * (hi - lo), hi + 0.42 * (hi - lo))
    axR.text(0.985, 0.965,
             f"{100 * frac_split:.0f} % of {N_BOOT} bootstrap refits\n"
             f"predict a split, {100 * (1 - frac_split):.0f} % do not.\n"
             "The data do not settle the question.",
             transform=axR.transAxes, ha="right", va="top", fontsize=10.5,
             color=INK, linespacing=1.5,
             bbox=dict(boxstyle="round,pad=0.36", fc=PAPER, ec=MIST, lw=1.0,
                       alpha=0.95))

    fig.suptitle("n-hexane (1) / methanol (2) at 318.15 K — two Margules "
                 "parameter sets one standard error apart",
                 fontsize=14, y=1.005)
    fig.text(0.5, -0.035,
             f"Both sets lie one joint standard error from the same Barker "
             f"fit along its least-determined direction; their residuals in "
             f"$P$ differ by {abs(cand[0]['rms_P'] - cand[1]['rms_P']):.4f} "
             f"kPa, against a scatter of {NOISE['P']:g} kPa.",
             ha="center", va="center", fontsize=10.5, color=SLATE)
    fig.tight_layout()
    return fig


if __name__ == "__main__":
    c1, c2, dat, best, cand, frac_split = make()
    print(f"data: n = {dat.n}, x1 = {dat.x1.min():.2f}-{dat.x1.max():.2f}, "
          f"P = {dat.P.min():.2f}-{dat.P.max():.2f} kPa, T = {T_SET} K")
    print(f"best fit  A12 = {best.params[0]:.4f} +/- {best.stderr[0]:.4f}, "
          f"A21 = {best.params[1]:.4f} +/- {best.stderr[1]:.4f}, "
          f"rms dP = {best.rms_P:.4f} kPa")
    for nm, cd in zip(["fit A", "fit B"], cand):
        g = cd["gap"]
        print(f"{nm}: A12 = {cd['params'][0]:.4f}, A21 = {cd['params'][1]:.4f}"
              f"   rms dP = {cd['rms_P']:.4f} kPa, rms dy = {cd['rms_y']:.5f}"
              f"   split = "
              + ("none" if g is None
                 else f"{g['x1_phase_a']:.3f}-{g['x1_phase_b']:.3f}"))
    print(f"bootstrap ({N_BOOT} refits): {100 * frac_split:.1f} % predict a "
          f"liquid-liquid split")
    for p in write(build(c1, c2, dat, best, cand, frac_split), SLUG):
        print("wrote", p)
