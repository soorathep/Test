#!/usr/bin/env python3
"""F4.12  Why a binary azeotropes: the criterion drawn as a map.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

An azeotrope is a root of y1 = x1, i.e. of

    gamma_1 / gamma_2 = Psat_2 / Psat_1        equivalently   alpha_12 = 1

with alpha_12 = gamma_1 Psat_1 / (gamma_2 Psat_2) the relative volatility. The
left-hand side is continuous on (0, 1) and, for every two-parameter G^E model
in `vlekit.models`, monotonic, so the root exists if and only if alpha_12
straddles one between the two ends. At the ends the activity coefficients take
their infinite-dilution values, so the whole question collapses to two numbers
per binary:

    alpha_12(x1 -> 0) = gamma_1^inf  Psat_1 / Psat_2
    alpha_12(x1 -> 1) = (1/gamma_2^inf) Psat_1 / Psat_2

Plot one against the other and the plane splits into four regions. WHAT THOSE
REGIONS ARE IS THE POINT OF THIS FIGURE, AND IT IS NARROWER THAN IT LOOKS.

    both ends above 1      no azeotrope, (1) more volatile throughout
    both ends below 1      no azeotrope, (2) more volatile throughout
    straddling, a0 > 1 > a1   a MINIMUM-boiling azeotrope, G^E > 0
    straddling, a0 < 1 < a1   a MAXIMUM-boiling azeotrope, G^E < 0

Those are four regions of a map about AZEOTROPY. They are not the course's four
solution types, and the difference matters in two directions.

  - Type 1, the ideal solution, is not a region: it is a point near where the
    two ends coincide, and it lands in a no-azeotrope quadrant along with
    every non-ideal mixture whose deviation is too small to turn the curve
    over. Methanol + water is on this figure to make that concrete. It
    deviates positively, gamma_1^inf = 2.41, and it has no azeotrope. It sits
    in the same quadrant as benzene + toluene. "Positive deviation" and
    "azeotrope" are different statements and this is the panel that proves it.

  - Type 4, VLLE, is not a region either. 1-butanol + water lands in the
    minimum-boiling quadrant, on top of the Type 2 system, because it does
    have a minimum-boiling azeotrope. What the map cannot say is that the
    azeotrope is HETEROGENEOUS — that the liquid it is in equilibrium with is
    not one phase but two. Partial miscibility is a question about the
    STABILITY of the liquid, not about the root of alpha_12 = 1, and nothing
    plotted here answers it. Module 5 answers it, with the tangent-plane
    criterion. Read this map as deciding azeotropy and nothing else.

The right panel is the same statement in composition space: alpha_12(x1) along
the bubble curve, with the alpha = 1 line. A curve that crosses it has an
azeotrope at the crossing; a curve that does not, does not. For the VLLE system
the part of that curve lying inside the measured two-liquid region is drawn
broken, because a single-liquid alpha_12 there is a property of the fitted
model and not of anything that exists.

WHAT IS COMPUTED, AND WITH WHAT
    gamma_i^inf   NRTL, fitted to each published dataset by Barker's method
                  (P or T and x1 only; y is not used in the fit). Fit quality
                  is printed to stdout for every system.
    Psat_i        the Antoine correlations in `vlekit.data.LIBRARY`, plus the
                  two components `vlekit.datasets` adds.
    the ends      for the isobaric sets the two ends are at DIFFERENT
                  temperatures — the boiling points of the two pure components
                  at the operating pressure — so Psat_1/Psat_2 is evaluated at
                  each end's own temperature. For the isothermal set both ends
                  are at 303.15 K.

The right panel also marks, as an open symbol, the azeotropic composition read
directly out of the published table by interpolating y1 - x1 through zero. It
does not coincide with the model root, and the gap is printed on the figure:
that gap is what a two-parameter model fitted to P-x costs at the azeotrope.
For 1-butanol + water that reading is suppressed, because interpolating across
a miscibility gap is meaningless; the measured heteroazeotropic vapour
composition is marked instead.

CAVEAT stated on the figure: straddling ends guarantee a root, but non-
straddling ends do not forbid one. A G^E model with three or more parameters
can make gamma_1/gamma_2 non-monotonic and produce two azeotropes with both
ends on the same side. Nothing in `vlekit.models` with two parameters can.

Run:  python3 f4_12.py
"""
from __future__ import annotations

import os
import sys

import numpy as np

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib                                                  # noqa: E402
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                    # noqa: E402
from matplotlib.patches import Rectangle                           # noqa: E402

import vlekit as v                                                 # noqa: E402
from vlekit import datasets as D                                   # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY, PAPER,  # noqa: E402
                          RUST, SAND, SKYBLUE, SLATE, TEAL, use_style)
from vlekit.regress import bubble_T                                # noqa: E402

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_12_azeotrope_criterion"

# key, short label for the figure, colour, tag shown in front of the name
SYSTEMS = [
    ("benzene-toluene", "benzene + toluene", TEAL, "Type 1"),
    ("ethanol-water", "ethanol + water", AMBER, "Type 2"),
    ("chloroform-butanone", "chloroform + 2-butanone", RUST, "Type 3"),
    ("acetone-chloroform", "acetone + chloroform", SAND, "Type 3"),
    ("butanol-water", "1-butanol + water", NAVY, "Type 4 (VLLE)"),
    ("methanol-water", "methanol + water", SKYBLUE, "COUNTEREXAMPLE"),
]

NX = 161


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


# --------------------------------------------------------------------------
def data_azeotrope(dat, gap=None):
    """x1 where the measured y1 - x1 changes sign. No model is involved.

    A crossing inside `gap` is discarded: for a partially miscible binary the
    liquid composition is not single-valued there, so the interpolation is
    across a range in which no liquid exists.
    """
    d = dat.sorted_by_x()
    f = d.y1 - d.x1
    out, fake = [], []
    for i in np.where(np.sign(f[:-1]) * np.sign(f[1:]) < 0)[0]:
        t = -f[i] / (f[i + 1] - f[i])
        x = float(d.x1[i] + t * (d.x1[i + 1] - d.x1[i]))
        (fake if gap is not None and gap[0] < x < gap[1] else out).append(x)
    return out, fake


def analyse():
    res = []
    for key, label, col, tag in SYSTEMS:
        dat = D.load(key)
        fit = v.fit(dat, "nrtl")
        m = fit.model

        g1inf = float(np.exp(m.ln_gamma(np.array([1e-9]))[0][0]))
        g2inf = float(np.exp(m.ln_gamma(np.array([1 - 1e-9]))[1][0]))

        if dat.kind == "isobaric":
            P = float(np.mean(dat.P))
            T_end0 = float(dat.c2.Tsat(P))       # x1 -> 0: pure 2 boils
            T_end1 = float(dat.c1.Tsat(P))       # x1 -> 1: pure 1 boils
        else:
            T_end0 = T_end1 = float(np.mean(dat.T))

        r0 = float(dat.c1.Psat(T_end0) / dat.c2.Psat(T_end0))
        r1 = float(dat.c1.Psat(T_end1) / dat.c2.Psat(T_end1))
        a0, a1 = g1inf * r0, r1 / g2inf

        # alpha_12 along the bubble curve
        x = np.linspace(1e-4, 1 - 1e-4, NX)
        if dat.kind == "isobaric":
            T, _ = bubble_T(m, x, np.full_like(x, float(np.mean(dat.P))),
                            dat.c1, dat.c2)
        else:
            T = np.full_like(x, float(np.mean(dat.T)))
        g1, g2 = m.gamma(x, T)
        alpha = g1 * dat.c1.Psat(T) / (g2 * dat.c2.Psat(T))

        roots = []
        s = np.sign(alpha - 1.0)
        for i in np.where(s[:-1] * s[1:] < 0)[0]:
            t = (1.0 - alpha[i]) / (alpha[i + 1] - alpha[i])
            roots.append(float(x[i] + t * (x[i + 1] - x[i])))

        if a0 > 1 and a1 > 1:
            verdict, short = "no azeotrope", "none"
        elif a0 < 1 and a1 < 1:
            verdict, short = "no azeotrope", "none"
        elif a0 > 1 > a1:
            verdict, short = "minimum-boiling azeotrope", "min-boiling"
        else:
            verdict, short = "maximum-boiling azeotrope", "max-boiling"

        vlle = D.butanol_water_vlle() if key == "butanol-water" else None
        gap = None if vlle is None else (vlle["x1_aq"], vlle["x1_org"])
        az, fake = data_azeotrope(dat, vlle["gap"] if vlle else None)

        res.append(dict(key=key, label=label, col=col, tag=tag, dat=dat,
                        fit=fit, g1inf=g1inf, g2inf=g2inf, r0=r0, r1=r1,
                        a0=a0, a1=a1, x=x, alpha=alpha, roots=roots,
                        verdict=verdict, short=short, type=D.TYPES[key],
                        doi=D.DOIS[key], T_end0=T_end0, T_end1=T_end1,
                        data_az=az, fake_az=fake, vlle=vlle, twophase=gap,
                        counter=key in D.COUNTEREXAMPLES))
    return res


# --------------------------------------------------------------------------
class Placer:
    """A coarse occupancy grid over one axes, used to place labels.

    Everything already drawn is marked on the grid; each label then takes the
    emptiest rectangle of the size it needs and marks that rectangle occupied,
    so no two labels can land on one another. Positions are therefore a
    function of the data, not of the author's eye.
    """

    def __init__(self, ax, nx=64, ny=52):
        self.ax, self.nx, self.ny = ax, nx, ny
        self.g = np.zeros((ny, nx))

    def _frac(self, x, y):
        tx, ty = self.ax.transData, self.ax.transAxes
        pts = tx.transform(np.column_stack([np.asarray(x, dtype=float),
                                            np.asarray(y, dtype=float)]))
        return ty.inverted().transform(pts).T

    def occupy(self, x, y, pad=1):
        fx, fy = self._frac(x, y)
        i = np.clip((fy * self.ny).astype(int), 0, self.ny - 1)
        j = np.clip((fx * self.nx).astype(int), 0, self.nx - 1)
        for a, b in zip(i, j):
            self.g[max(0, a - pad):a + pad + 1,
                   max(0, b - pad):b + pad + 1] += 1.0

    def occupy_box(self, fx, fy, w, h):
        i0 = int(np.clip(fy * self.ny, 0, self.ny - 1))
        j0 = int(np.clip(fx * self.nx, 0, self.nx - 1))
        i1 = int(np.clip((fy + h) * self.ny, 0, self.ny))
        j1 = int(np.clip((fx + w) * self.nx, 0, self.nx))
        self.g[i0:i1, j0:j1] += 20.0

    def place(self, w, h, margin=0.015, anchor=None, pull=6.0, allow=None):
        """Lower-left corner, in axes fraction, of the emptiest w-by-h box.

        `anchor` is a point in axes fraction the label belongs to; boxes far
        from it are penalised so that the leader line stays short and the
        label stays next to the thing it names. `allow(fx, fy, w, h)` may veto
        a position outright — on this figure it keeps every label inside the
        same quadrant as the point it names, since a label that strayed across
        a boundary would say the opposite of what the panel means.
        """
        cw = max(1, int(round(w * self.nx)))
        ch = max(1, int(round(h * self.ny)))
        m = max(1, int(round(margin * self.nx)))
        best, score, cells = (margin, 1 - h - margin), None, None
        for i in range(m, self.ny - ch - m + 1):
            for j in range(m, self.nx - cw - m + 1):
                s = float(self.g[i:i + ch, j:j + cw].sum())
                cx = (j + 0.5 * cw) / self.nx
                cy = (i + 0.5 * ch) / self.ny
                if anchor is not None:
                    s += pull * float(np.hypot(cx - anchor[0], cy - anchor[1]))
                if allow is not None and not allow(j / self.nx, i / self.ny,
                                                   w, h):
                    s += 1e4
                if score is None or s < score:
                    score, best, cells = s, (j / self.nx, i / self.ny), (i, j)
        i, j = cells
        self.g[max(0, i - 1):i + ch + 1, max(0, j - 1):j + cw + 1] += 50.0
        return best


def spread_labels(y, dy):
    """Push a set of label ordinates apart so that none is within dy of another.

    A simple one-pass relaxation on the sorted values. Label positions on this
    figure are derived from the data; nothing is nudged by hand.
    """
    y = np.asarray(y, dtype=float)
    order = np.argsort(y)
    out = y.copy()
    for k in range(1, len(order)):
        i, j = order[k - 1], order[k]
        if out[j] - out[i] < dy:
            out[j] = out[i] + dy
    return out


def build(res):
    use_style()
    fig, (axL, axR) = plt.subplots(1, 2, figsize=(14.6, 6.4),
                                   gridspec_kw={"width_ratios": [1.06, 1.0]})

    # ================================================================ left
    a0 = np.array([r["a0"] for r in res])
    a1 = np.array([r["a1"] for r in res])
    lo = 0.045 * min(a0.min(), a1.min())
    hi = 9.0 * max(a0.max(), a1.max())
    axL.set_xscale("log")
    axL.set_yscale("log")
    axL.set_xlim(lo, hi)
    axL.set_ylim(lo, hi)

    axL.add_patch(Rectangle((1, 1), hi, hi, facecolor=MIST, alpha=0.30,
                            edgecolor="none", zorder=0))
    axL.add_patch(Rectangle((lo, lo), 1 - lo, 1 - lo, facecolor=MIST,
                            alpha=0.30, edgecolor="none", zorder=0))
    axL.add_patch(Rectangle((1, lo), hi, 1 - lo, facecolor=AMBER, alpha=0.20,
                            edgecolor="none", zorder=0))
    axL.add_patch(Rectangle((lo, 1), 1 - lo, hi, facecolor=RUST, alpha=0.17,
                            edgecolor="none", zorder=0))
    axL.axvline(1.0, color=GRAPHITE, lw=1.4, zorder=2)
    axL.axhline(1.0, color=GRAPHITE, lw=1.4, zorder=2)
    axL.grid(True, which="major", zorder=1)
    axL.set_axisbelow(True)

    # Region titles live in the outer corners of their quadrants, which are the
    # parts of the plane no real binary occupies. They name what the MAP
    # decides — azeotropy — not the course's solution types, which is why the
    # type numbers appear only in parentheses.
    corners = [(0.985, 0.985, "right", "top",
                "NO AZEOTROPE\n(1) more volatile at both ends",
                GRAPHITE, 10.4),
               (0.015, 0.015, "left", "bottom",
                "NO AZEOTROPE\n(2) more volatile at both ends",
                GRAPHITE, 10.4),
               (0.985, 0.015, "right", "bottom",
                "MINIMUM-BOILING AZEOTROPE\n$G^E > 0$",
                "#9A6412", 10.8),
               (0.015, 0.985, "left", "top",
                "MAXIMUM-BOILING\nAZEOTROPE   $G^E < 0$",
                "#8A3F28", 10.8)]
    pl = Placer(axL)
    for fx, fy, ha, va, txt, col, fs in corners:
        axL.text(fx, fy, txt, transform=axL.transAxes, ha=ha, va=va,
                 fontsize=fs, color=col, linespacing=1.45, zorder=3)
        n = txt.count("\n") + 1
        w, h = 0.46, 0.075 * n
        pl.occupy_box(fx - (w if ha == "right" else 0.0),
                      fy - (h if va == "top" else 0.0), w, h)

    # the markers are weighted heavily: a label that sits on top of the point
    # it names is the one collision the eye notices immediately
    for _ in range(8):
        pl.occupy(a0, a1, pad=4)
    # the two quadrant boundaries carry the meaning of the panel, so no label
    # is allowed to sit across them
    tline = np.geomspace(lo, hi, 200)
    pl.occupy(np.full_like(tline, 1.0), tline, pad=2)
    pl.occupy(tline, np.full_like(tline, 1.0), pad=2)

    # Every label is two lines, "tag" over "system". The box the placer
    # reserves is sized from the longest line rather than fixed, because a box
    # declared smaller than it renders is exactly how two labels end up on top
    # of one another.
    def box_size(r):
        lines = [r["tag"], r["label"]]
        per = 0.0138 if r["counter"] else 0.0126
        return min(0.44, 0.055 + per * max(len(t) for t in lines)), 0.135

    for r in res:
        axL.plot([r["a0"]], [r["a1"]],
                 "s" if r["counter"] else ("^" if r["vlle"] else "o"),
                 color=r["col"], ms=13 if r["counter"] else 12,
                 mec=GRAPHITE, mew=1.3, zorder=6)
    qx, qy = pl._frac([1.0], [1.0])
    qx, qy = float(qx[0]), float(qy[0])
    for r in res:
        ax_, ay_ = pl._frac([r["a0"]], [r["a1"]])
        ax_, ay_ = float(ax_[0]), float(ay_[0])

        def same_quadrant(fx, fy, w, h, ax_=ax_, ay_=ay_):
            for cx in (fx, fx + w):
                for cy in (fy, fy + h):
                    if (cx > qx) != (ax_ > qx) or (cy > qy) != (ay_ > qy):
                        return False
            return True

        bw, bh = box_size(r)
        fx, fy = pl.place(bw, bh, anchor=(ax_, ay_), allow=same_quadrant)
        axL.annotate(f"{r['tag']}\n{r['label']}",
                     xy=(r["a0"], r["a1"]), xycoords="data",
                     xytext=(fx + 0.5 * bw, fy + 0.5 * bh),
                     textcoords="axes fraction", ha="center", va="center",
                     fontsize=9.4, color=r["col"], linespacing=1.3, zorder=7,
                     fontweight="bold" if r["counter"] else "normal",
                     bbox=dict(boxstyle="round,pad=0.22", fc=PAPER,
                               ec=r["col"], lw=1.4 if r["counter"] else 0.9,
                               alpha=0.95),
                     arrowprops=dict(arrowstyle="-", color=r["col"], lw=1.0,
                                     shrinkA=2, shrinkB=6))

    axL.set_xlabel(r"$\alpha_{12}$ at $x_1 \to 0$   "
                   r"$= \gamma_1^{\infty}\, P_1^{\rm sat}/P_2^{\rm sat}$")
    axL.set_ylabel(r"$\alpha_{12}$ at $x_1 \to 1$   "
                   r"$= (1/\gamma_2^{\infty})\, P_1^{\rm sat}/P_2^{\rm sat}$")
    axL.set_title("(a)  the criterion as a map: an azeotrope exists iff "
                  r"$\alpha_{12}$ straddles 1", fontsize=12.4, pad=8)

    # ================================================================ right
    axR.grid(True, zorder=0)
    axR.set_axisbelow(True)
    axR.set_yscale("log")
    axR.axhline(1.0, color=GRAPHITE, lw=1.6, zorder=2)
    axR.text(0.012, 1.0, r"$\alpha_{12} = 1$", fontsize=11, color=GRAPHITE,
             ha="left", va="bottom", zorder=5,
             bbox=dict(boxstyle="round,pad=0.15", fc=PAPER, ec="none",
                       alpha=0.85))

    # the measured two-liquid region of the VLLE system, shaded once
    for r in res:
        if r["twophase"] is not None:
            axR.axvspan(r["twophase"][0], r["twophase"][1], color=MIST,
                        alpha=0.45, zorder=1)

    ends = np.array([np.log10(r["alpha"][-1]) for r in res])
    ley = spread_labels(ends, 0.175)
    for r, yl in zip(res, ley):
        if r["twophase"] is None:
            axR.plot(r["x"], r["alpha"], "-", color=r["col"], lw=2.3, zorder=4)
        else:
            lo2, hi2 = r["twophase"]
            inside = (r["x"] > lo2) & (r["x"] < hi2)
            a = np.where(inside, np.nan, r["alpha"])
            b = np.where(inside, r["alpha"], np.nan)
            axR.plot(r["x"], a, "-", color=r["col"], lw=2.3, zorder=4)
            axR.plot(r["x"], b, ":", color=r["col"], lw=2.0, zorder=4)
        tag = f"{r['tag']} — " if r["counter"] else f"{r['tag']}  "
        axR.annotate(f"{tag}{r['label'].replace(chr(10), ' ')}",
                     xy=(1.0, r["alpha"][-1]), xytext=(1.045, 10 ** yl),
                     ha="left", va="center", fontsize=9.2, color=r["col"],
                     fontweight="bold" if r["counter"] else "normal",
                     zorder=6,
                     arrowprops=dict(arrowstyle="-", color=r["col"], lw=0.9,
                                     shrinkA=1, shrinkB=1))
        for xr in r["roots"]:
            inside = (r["twophase"] is not None
                      and r["twophase"][0] < xr < r["twophase"][1])
            axR.plot([xr], [1.0], "D", color=PAPER if inside else r["col"],
                     ms=9, mec=r["col"] if inside else GRAPHITE,
                     mew=1.8 if inside else 1.1, zorder=7)
        for xd in r["data_az"]:
            axR.plot([xd], [1.0], "o", color=PAPER, ms=9, mec=r["col"],
                     mew=1.8, zorder=6)
        if r["vlle"] is not None:
            axR.plot([r["vlle"]["y1"]], [1.0], "*", color=AMBER, ms=17,
                     mec=GRAPHITE, mew=1.0, zorder=8)

    axR.set_xlim(0, 1.0)
    axR.set_xlabel("$x_1$")
    axR.set_ylabel(r"relative volatility  $\alpha_{12} = "
                   r"\gamma_1 P_1^{\rm sat} / (\gamma_2 P_2^{\rm sat})$")
    axR.set_title(r"(b)  the same statement in composition space",
                  fontsize=12.4, pad=8)

    vs = [r for r in res if r["vlle"] is not None][0]
    az = [r for r in res if r["roots"] and r["data_az"]]
    gaps = ";  ".join(
        f"{r['label'].replace(chr(10), ' ')}: model {r['roots'][0]:.3f} vs "
        f"data {r['data_az'][0]:.3f}" for r in az)
    axR.text(0.5, -0.20,
             "filled diamond = azeotrope of the fitted NRTL;  open circle = "
             "crossing of $y_1 = x_1$ read from the published table\n" + gaps
             + "\nshaded strip = the MEASURED two-liquid region of 1-butanol + "
               "water; the dotted curve inside it is model, not measurement.\n"
               "Open diamond = the model's root, which falls inside that "
               "region;  star = the measured heteroazeotropic vapour, "
               f"$y_1$ = {vs['vlle']['y1']:.3f}.",
             transform=axR.transAxes, ha="center", va="top", fontsize=9.0,
             color=SLATE, linespacing=1.5)

    fig.suptitle("An azeotrope is a consequence, not a category:  "
                 r"$\gamma_1/\gamma_2 = P_2^{\rm sat}/P_1^{\rm sat}$ either "
                 "has a root in (0, 1) or it does not",
                 fontsize=14.4, y=1.005)
    fig.text(0.5, -0.115,
             r"$\gamma_i^{\infty}$ from NRTL ($\alpha$ = 0.3) fitted to each "
             "published set by Barker's method; $P_i^{\\rm sat}$ from the "
             "Antoine constants in vlekit.data.LIBRARY, evaluated at each "
             "end's own boiling temperature for the isobaric sets.\n"
             "Straddling ends guarantee a root; non-straddling ends do not "
             r"forbid one — a $G^E$ with three or more parameters can make "
             r"$\gamma_1/\gamma_2$ non-monotonic and place two azeotropes with "
             "both ends on the same side.\n"
             "WHAT THIS MAP DOES NOT DECIDE. It decides azeotropy. It does not "
             "decide how many liquid phases there are. 1-butanol + water lands "
             "in the same quadrant as ethanol + water\nbecause both have a "
             "minimum-boiling azeotrope; that its azeotrope is HETEROGENEOUS, "
             "and that its liquid splits in two, is a stability question this "
             "figure cannot answer. Module 5 answers it.",
             ha="center", va="center", fontsize=10.0, color=SLATE,
             linespacing=1.6)
    fig.tight_layout(rect=(0, 0.0, 1, 0.94))
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    res = analyse()
    print("NRTL fitted to each published set by Barker's method "
          "(objective = T for isobaric, P for isothermal)\n")
    hdr = (f"{'system':24s} {'tag':<15s} {'g1inf':>8s} {'g2inf':>7s} "
           f"{'a(x1->0)':>9s} {'a(x1->1)':>9s}  {'verdict':<12s} "
           f"{'x_az model':>10s} {'x_az data':>10s}")
    print(hdr)
    print("-" * len(hdr))
    for r in res:
        rm = f"{r['roots'][0]:.4f}" if r["roots"] else "     —"
        rd = f"{r['data_az'][0]:.4f}" if r["data_az"] else "     —"
        print(f"{r['key']:24s} {r['tag']:<15s} {r['g1inf']:8.3f} "
              f"{r['g2inf']:7.3f} {r['a0']:9.3f} {r['a1']:9.4f}  "
              f"{r['short']:<12s} {rm:>10s} {rd:>10s}")
    print()
    for r in res:
        f = r["fit"]
        print(f"  {r['key']:24s} doi:{r['doi']}  tau12 = {f.params[0]:+.4f}, "
              f"tau21 = {f.params[1]:+.4f};  rms dP = {f.rms_P:.4g} kPa, "
              f"rms dT = {f.rms_T:.4g} K, rms dy1 = {f.rms_y:.5f}")
        print(f"    ends evaluated at T = {r['T_end0']:.2f} K (x1->0) and "
              f"{r['T_end1']:.2f} K (x1->1); "
              f"Psat1/Psat2 = {r['r0']:.4f} and {r['r1']:.4f}")
    print()
    print("classification check: every system lands in the quadrant its "
          "dataset shows —")
    for r in res:
        obs = ("azeotrope in the table" if r["data_az"]
               else ("heteroazeotrope in the table" if r["vlle"]
                     else "no crossing in the table"))
        note = "  <- COUNTEREXAMPLE, deliberately not a type" if r["counter"] else ""
        print(f"    {r['key']:24s} map says {r['short']:<12s} | data says "
              f"{obs}{note}")
    print()
    for r in res:
        if r["vlle"] is None:
            continue
        v_ = r["vlle"]
        print("what the map cannot say, spelled out:")
        print(f"    {r['key']} lands at a0 = {r['a0']:.3f}, a1 = {r['a1']:.4f}: "
              f"the same quadrant as ethanol + water, verdict "
              f"'{r['short']}'.")
        print(f"    That verdict is correct and incomplete. The measured "
              f"two-liquid region runs x1 = {v_['x1_aq']:.4f} to "
              f"{v_['x1_org']:.4f} at {v_['T']:.2f} K,")
        print(f"    and the model's alpha = 1 root, x1 = {r['roots'][0]:.4f}, "
              f"lies INSIDE it: there is no single liquid of that composition.")
        print(f"    The real object is the heteroazeotrope, whose vapour is "
              f"y1 = {v_['y1']:.4f} — {abs(r['roots'][0] - v_['y1']):.4f} away "
              f"from the model root.")
        for x in r["fake_az"]:
            print(f"    (The naive y1 - x1 crossing at x1 = {x:.4f} is "
                  f"discarded: it is inside the miscibility gap.)")
        print("    Deciding that the liquid splits at all is the tangent-plane "
              "criterion, i.e. Module 5.")
    for p in write(build(res), SLUG):
        print("wrote", p)
