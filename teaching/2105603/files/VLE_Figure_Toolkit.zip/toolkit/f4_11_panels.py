#!/usr/bin/env python3
"""F4.11a-e  One slide per solution type, with the gamma curves the overview
had no room for.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

`f4_11.py` puts all four types plus the counterexample on one six-panel
overview. This script draws the same five systems one per figure, at the size
of a whole slide, and adds beside each phase diagram the thing the
classification is actually a statement about: gamma_1(x_1) and gamma_2(x_1).

    f4_11a_type1_ideal          benzene + toluene
    f4_11b_type2_positive       ethanol + water
    f4_11c_type3_negative       chloroform + 2-butanone
    f4_11d_type4_vlle           1-butanol + water
    f4_11e_counterexample       methanol + water

WHY THIS IS A SIBLING AND NOT A SECOND COPY OF THE ANALYSIS. Every number on
these five figures — the Raoult reference, the gamma arrays, the gamma ranges,
the largest signed departure, the interpolated azeotrope, the discarded
crossing inside the miscibility gap, the three-phase state — comes from
`f4_11.analyse()`, imported below and called once. There is exactly one place
in the repository where a benzene + toluene gamma is computed, so the overview
and the per-type slides cannot drift apart. What is local to this file is
layout only: figure size, axis limits, and where labels go.

WHAT EACH FIGURE CARRIES THAT THE OVERVIEW COULD NOT
  (a) the T-x-y or P-x-y panel, unchanged in content from the overview:
      measured bubble and dew points, the Raoult reference computed with the
      same Antoine correlations, the azeotrope read out of the table.
  (b) gamma_1 and gamma_2 against x_1 on a logarithmic axis with the
      gamma = 1 line, because the four types are four statements about where
      those two curves sit relative to that line, and the sixth of a slide the
      overview gave each system had no space to say so.

THE TYPE 4 SLIDE, and the number on it that looks like a mistake. gamma_1
reaches 57.12 at x_1 = 0.006. That is not a typo and not a failure of the
gamma-phi route: it is 1-butanol at a mole fraction of half a per cent in
water, whose escaping tendency is 57 times what an ideal solution of the same
composition would have. A liquid that unhappy lowers its Gibbs energy by
splitting in two, which is precisely what this system does, and the figure
says so on its face. Whether a liquid splits is a stability question and
Module 4 does not own the tool for it; Module 5 does, and every Type 4 figure
carries that sentence.

THE COUNTEREXAMPLE SLIDE. Positive deviation does not imply an azeotrope. The
condition for one is alpha_12 = gamma_1 Psat_1 / (gamma_2 Psat_2) = 1, so at
each measured composition there is a value gamma_2 would have to reach,
gamma_1 Psat_1 / Psat_2, and the figure draws it. For methanol + water that
curve stays a factor of 3.17 above the measured gamma_2 at its closest, so
there is no crossing and no azeotrope. The deviation is real and it is simply
not large enough to overcome the ratio of the pure vapour pressures.

SIZE, AND WHAT THAT MEANS FOR TEXT. Each figure is drawn at 11.0 x 6.3 in, and
the rendered PNG comes out near 1.7:1 — the shape of a figure filling about
60 % of the height of a 1280 x 720 slide, i.e. roughly 740 x 432 px. That is
about a quarter of the drawn size, so every word on these figures is set at
four times the size it will be read at, and anything below about 8.8 pt here
is decoration on the slide. The footnote is therefore two lines (see `footer`)
and the in-axes boxes are at most three; what the slide's own cards say is left
to them. Nothing is hard-coded into position: the caption's type size, the
legend and the panel titles are all measured down until they fit, and every
annotation is placed by the occupancy grid below, from the data actually
drawn, at the largest type size for which a clear rectangle exists.

Run:  python3 f4_11_panels.py
"""
from __future__ import annotations

import os
import sys

import numpy as np

sys.path.insert(0, "/home/claude/vlekit")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import matplotlib                                                  # noqa: E402
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                    # noqa: E402
from matplotlib.ticker import FixedLocator, FuncFormatter          # noqa: E402

from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY, PAPER,  # noqa: E402
                          RUST, SLATE, TEAL, use_style)

# the single source of the data and of every computed number on these figures
from f4_11 import analyse, write                                   # noqa: E402

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")

#: dataset key -> output slug, in the order the slides are shown
SLUGS = {
    "benzene-toluene": "f4_11a_type1_ideal",
    "ethanol-water": "f4_11b_type2_positive",
    "chloroform-butanone": "f4_11c_type3_negative",
    "butanol-water": "f4_11d_type4_vlle",
    "methanol-water": "f4_11e_counterexample",
}

FIGSIZE = (11.0, 6.3)          # ~1.75:1, the shape of a 60vh slide figure
G1COL, G2COL = TEAL, RUST


# --------------------------------------------------------------------------
class Placer:
    """A coarse occupancy grid over one axes, used to place labels.

    Same idea as the one in `f4_11.py`, with two differences that the extra
    panel needs: the mapping from data to grid goes through `transData`, so it
    is correct on the logarithmic gamma axis as well as the linear one, and a
    label can be pulled towards the point it names. No label position on these
    figures is typed in — everything already drawn is marked on the grid, and
    each label then takes the emptiest rectangle of the size it needs and
    marks that rectangle occupied, so no two of them can collide.
    """

    def __init__(self, ax, nx=56, ny=44):
        self.ax, self.nx, self.ny = ax, nx, ny
        self.g = np.zeros((ny, nx))
        self.pending = []
        self.inside = []

    def frac(self, x, y):
        pts = self.ax.transData.transform(
            np.column_stack([np.asarray(x, dtype=float),
                             np.asarray(y, dtype=float)]))
        return self.ax.transAxes.inverted().transform(pts).T

    def occupy(self, x, y, pad=1):
        fx, fy = self.frac(x, y)
        ok = np.isfinite(fx) & np.isfinite(fy)
        i = np.clip((fy[ok] * self.ny).astype(int), 0, self.ny - 1)
        j = np.clip((fx[ok] * self.nx).astype(int), 0, self.nx - 1)
        for a, b in zip(i, j):
            self.g[max(0, a - pad):a + pad + 1,
                   max(0, b - pad):b + pad + 1] += 1.0

    def occupy_box(self, bb, pad=1):
        """Mark a text's rendered rectangle, in display coordinates, occupied.

        `occupy` marks the anchor point of a text and a cell or two around it,
        which is right for a curve and wrong for a sentence: a 24-character
        line drawn from a data point reaches a third of the way across the
        panel, and a boxed label will settle on top of it. Measuring the drawn
        text is the only way to know how much room it actually takes.
        """
        (x0, y0), (x1, y1) = self.ax.transAxes.inverted().transform(
            [[bb.x0, bb.y0], [bb.x1, bb.y1]])
        i0 = max(0, int(np.floor(y0 * self.ny)) - pad)
        j0 = max(0, int(np.floor(x0 * self.nx)) - pad)
        i1 = int(np.ceil(y1 * self.ny)) + pad
        j1 = int(np.ceil(x1 * self.nx)) + pad
        self.g[i0:i1 + 1, j0:j1 + 1] += 80.0

    def search(self, w, h, anchor=None, pull=4.0, margin=0.012):
        """Best (i, j, cw, ch) for a w-by-h box, and how much it overlaps.

        The overlap is returned separately from the score so that a caller can
        tell "this box fits in clear space" from "this box is the least bad of
        a set of bad options" and do something about the second case.
        """
        cw = max(1, int(round(w * self.nx)))
        ch = max(1, int(round(h * self.ny)))
        m = max(1, int(round(margin * self.nx)))
        best, score, ov = None, None, None
        for i in range(m, self.ny - ch - m + 1):
            for j in range(m, self.nx - cw - m + 1):
                o = float(self.g[i:i + ch, j:j + cw].sum())
                cx, cy = (j + 0.5 * cw) / self.nx, (i + 0.5 * ch) / self.ny
                s = o
                if anchor is not None:
                    s += pull * float(np.hypot(cx - anchor[0], cy - anchor[1]))
                else:
                    s += 1e-3 * (1.0 - cy)      # ties break towards the top
                if score is None or s < score:
                    score, best, ov = s, (i, j, ch, cw), o
        if best is None:                        # box too big for the axes
            return None, np.inf
        return best, ov

    def commit(self, cell):
        i, j, ch, cw = cell
        self.g[max(0, i - 1):i + ch + 1, max(0, j - 1):j + cw + 1] += 80.0
        return (j / self.nx) + 0.5 * cw / self.nx, \
               (i / self.ny) + 0.5 * ch / self.ny

    def curve(self, x, y, n=240, pad=1):
        """Mark a polyline as occupied, resampled so no cell is missed.

        Marking only the measured points leaves holes between them that a
        label will happily settle into and then sit on top of the curve.
        """
        x = np.asarray(x, dtype=float)
        y = np.asarray(y, dtype=float)
        ok = np.isfinite(x) & np.isfinite(y)
        x, y = x[ok], y[ok]
        if len(x) < 2:
            return self.occupy(x, y, pad)
        s = np.concatenate([[0.0], np.cumsum(np.hypot(np.diff(x), np.diff(y)))])
        if s[-1] <= 0:
            return self.occupy(x, y, pad)
        t = np.linspace(0.0, s[-1], n)
        self.occupy(np.interp(t, s, x), np.interp(t, s, y), pad)

    def autosize(self, text, fs, boxpad=0.26):
        """Measure `text` and return its box size as a fraction of the axes.

        The alternative is to guess a width and a height for every annotation,
        and a guess that is one line short is exactly how a box ends up
        hanging over the title of its own panel.
        """
        fig = self.ax.figure
        tmp = fig.text(0.0, 0.0, text, fontsize=fs, linespacing=1.35)
        rend = fig.canvas.get_renderer()
        bb = tmp.get_window_extent(rend)
        tmp.remove()
        ab = self.ax.get_window_extent(rend)
        pad = 2.0 * (boxpad + 0.25) * fs * fig.dpi / 72.0
        return ((bb.width + pad) / ab.width, (bb.height + pad) / ab.height)

    def label(self, text, xy, col, fs=10.4, arrow=True, pull=4.0):
        """Queue a label. Nothing is placed until `flush()`.

        A box is measured against the axes it will live in, so it cannot be
        placed until the axes has its final size — and `tight_layout` resizes
        every axes on the figure. So the drawing pass records what has to be
        said and `flush()`, called after the layout is settled, decides where.
        """
        self.pending.append((text, xy, col, fs, arrow, pull))

    def keep_inside(self, artist):
        """Register a text drawn at a data position that must not run off the
        panel. A label centred on the middle of a miscibility gap can be wider
        than the gap; sliding it sideways is better than shrinking it, and it
        still means what it says."""
        self.inside.append(artist)

    def flush(self):
        rend = self.ax.figure.canvas.get_renderer()
        ab = self.ax.get_window_extent(rend)
        for t in self.inside:
            bb = t.get_window_extent(rend)
            dx = 0.0
            if bb.x0 < ab.x0 + 4:
                dx = ab.x0 + 4 - bb.x0
            elif bb.x1 > ab.x1 - 4:
                dx = ab.x1 - 4 - bb.x1
            if dx:
                x, y = t.get_position()
                px, py = self.ax.transData.transform((x, y))
                nx_, _ = self.ax.transData.inverted().transform((px + dx, py))
                t.set_position((nx_, y))
        # Only now, with those texts in their final positions and the axes at
        # its final size, is it possible to say how much of the panel they
        # cover — so that is done here, before any boxed label is placed.
        for t in self.inside:
            self.occupy_box(t.get_window_extent(rend))
        for args in self.pending:
            self._label(*args)
        self.pending = []

    def _label(self, text, xy, col, fs=10.4, arrow=True, pull=4.0, fs_min=8.8):
        """Place one label, shrinking the type until the box lands in clear
        space. A slide is not improved by a legible sentence written across a
        curve; if the panel has no clear rectangle big enough, the honest fix
        is a smaller box, and the search below finds the largest type size for
        which one exists.

        The floor is the point at which a box stops being readable on a slide:
        at 60vh these figures render about a quarter of their drawn size, so
        anything below roughly 8.8 pt is decoration. A label that will not fit
        above the floor is a label whose wording is too long, and the fix
        belongs in the caller.
        """
        anchor = None
        if xy is not None:
            fx, fy = self.frac([xy[0]], [xy[1]])
            anchor = (float(fx[0]), float(fy[0]))
        best = None
        while True:
            w, h = self.autosize(text, fs)
            if w <= 0.96 and h <= 0.96:
                cell, ov = self.search(w, h, anchor, pull)
                if cell is not None and (best is None or ov < best[1]):
                    best = (cell, ov, fs)
                if cell is not None and ov <= 0.0:
                    break
            if fs <= fs_min:
                break
            fs = max(fs_min, fs * 0.92)
        if best is None:                        # nothing fits at all: give up
            return
        cell, _ov, fs = best
        cx, cy = self.commit(cell)
        box = dict(boxstyle="round,pad=0.26", fc=PAPER, ec=col, lw=1.0,
                   alpha=0.95)
        if xy is None:
            self.ax.text(cx, cy, text, transform=self.ax.transAxes,
                         ha="center", va="center", fontsize=fs, color=col,
                         linespacing=1.35, zorder=10, bbox=box)
            return
        self.ax.annotate(
            text, xy=xy, xycoords="data", xytext=(cx, cy),
            textcoords="axes fraction", ha="center", va="center",
            fontsize=fs, color=col, linespacing=1.35, zorder=10, bbox=box,
            arrowprops=(dict(arrowstyle="-", color=col, lw=1.1, shrinkA=3,
                             shrinkB=6) if arrow else None))


# --------------------------------------------------------------------------
def log_ticks(lo, hi):
    """Readable ticks for a log axis spanning [lo, hi], chosen from the range.

    A narrow span (Type 1 gammas run 0.93 to 1.01) gets fine ticks; a span of
    nearly two decades (Type 4 runs 1 to 57) gets coarse ones. Nothing here is
    tied to a particular dataset.
    """
    cand = np.array([0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8,
                     0.9, 0.95, 1.0, 1.05, 1.1, 1.2, 1.3, 1.5, 1.7, 2.0, 2.5,
                     3.0, 4.0, 5.0, 7.0, 10.0, 15.0, 20.0, 30.0, 50.0, 70.0,
                     100.0])
    t = cand[(cand >= lo) & (cand <= hi)]
    while len(t) > 9:                      # thin out, keeping 1.0
        keep = np.ones(len(t), dtype=bool)
        keep[1::2] = np.isclose(t[1::2], 1.0)
        t = t[keep]
    return t


def fmt_tick(v, _pos=None):
    return f"{v:g}"


def cond_line(d):
    return (f"isobaric, $P$ = {float(np.mean(d.P)):g} kPa"
            if d.kind == "isobaric"
            else f"isothermal, $T$ = {float(np.mean(d.T)):g} K")


# --------------------------------------------------------------------------
def draw_phase(ax, r):
    """Panel (a): the T-x-y or P-x-y diagram, with the Raoult reference."""
    d = r["dat"]
    ax.grid(True, zorder=0)
    ax.set_axisbelow(True)
    ax.plot(r["xs"], r["ref"], "--", color=SLATE, lw=2.0, zorder=2,
            label="Raoult's law ($\\gamma_i = 1$)")

    if r["gap"] is not None:
        for (bx, bT, _by) in r["br"]:
            ax.plot(bx, bT, "-", color=r["col"], lw=1.9, zorder=3, alpha=0.85)

    ax.plot(d.x1, r["meas"], "o", color=r["col"], mfc=PAPER, mew=1.8, ms=7.0,
            zorder=5, label="measured, bubble ($x_1$)")
    ax.plot(d.y1, r["meas"], "s", color=GRAPHITE, mfc=PAPER, mew=1.4, ms=5.6,
            zorder=4, label="measured, dew ($y_1$)")

    ax.set_xlim(-0.02, 1.02)
    ally = np.concatenate([r["meas"], r["ref"]])
    lo, hi = float(np.min(ally)), float(np.max(ally))
    pad = 0.09 * (hi - lo)
    # The VLLE panel needs a clear strip BELOW the three-phase line, wide
    # enough for the two-liquid label to sit in without touching either the
    # line above it or the axis below it. Rather than guess a padding, put the
    # three-phase temperature at a known fraction of the axis height and let
    # the bottom limit follow from that.
    top = hi + 1.5 * pad
    if r["vlle"] is not None:
        frac = 0.30
        ax.set_ylim((r["vlle"]["T"] - frac * top) / (1.0 - frac), top)
    else:
        ax.set_ylim(lo - pad, top)

    pl = Placer(ax)
    pl.curve(r["xs"], r["ref"])
    pl.occupy(np.concatenate([d.x1, d.y1]),
              np.concatenate([r["meas"], r["meas"]]))
    if r["gap"] is not None:
        for (bx, bT, _by) in r["br"]:
            pl.curve(bx, bT)

    # ------------------------------------------------------- the VLLE extras
    v = r["vlle"]
    if v is not None:
        xa, xo, T3 = v["x1_aq"], v["x1_org"], v["T"]
        ylo, yhi = ax.get_ylim()
        ax.axvspan(xa, xo, ymin=0.0, ymax=(T3 - ylo) / (yhi - ylo),
                   color=MIST, alpha=0.45, zorder=1)
        ax.plot([xa, xo], [T3, T3], "-", color=INK, lw=3.4, zorder=6,
                solid_capstyle="butt", label="three-phase line (VLLE)")
        ax.plot([xa, xo], [T3, T3], "|", color=INK, ms=13, mew=2.2, zorder=6)
        ax.plot([v["y1"]], [T3], "D", color=AMBER, ms=10.5, mec=GRAPHITE,
                mew=1.2, zorder=8)
        pl.occupy(np.linspace(xa, xo, 40), np.full(40, T3), pad=1)

        # the two conjugate liquid compositions, marked where they are
        for xv in (xa, xo):
            ax.plot([xv], [T3], "o", color=INK, ms=6.5, zorder=7)
        ytwo = ylo + 0.105 * (yhi - ylo)
        pl.keep_inside(ax.text(
            0.5 * (xa + xo), ytwo,
            "TWO LIQUID PHASES\n"
            f"$x_1'$ = {xa:.4f}  to  $x_1''$ = {xo:.4f},  $T_3$ = {T3:.2f} K",
            ha="center", va="center", fontsize=10.0, color=GRAPHITE,
            linespacing=1.35, zorder=7))
        pl.occupy(np.linspace(xa - 0.14, xo + 0.14, 60), np.full(60, ytwo),
                  pad=2)

        pl.label(f"heteroazeotrope: ONE vapour, $y_1$ = {v['y1']:.3f},\n"
                 "in equilibrium with BOTH liquids at once",
                 (v["y1"], T3), AMBER, fs=10.4)

    # --------------------------------------------------------- the azeotrope
    for a in r["az"]:
        yv = a["T"] if d.kind == "isobaric" else a["P"]
        ax.plot([a["x1"]], [yv], "D", color=AMBER, ms=10, mec=GRAPHITE,
                mew=1.2, zorder=7)
        if d.kind == "isobaric":
            kind = ("maximum-boiling azeotrope"
                    if yv > float(np.max(r["ref"])) else
                    "minimum-boiling azeotrope")
            val = f"$x_1 = y_1$ = {a['x1']:.4f},  $T$ = {a['T']:.2f} K"
        else:
            # an isothermal set shows the same object as a pressure extremum
            kind = ("minimum-pressure azeotrope\n"
                    "(maximum-boiling at constant $T$)")
            val = f"$x_1 = y_1$ = {a['x1']:.4f},  $P$ = {a['P']:.2f} kPa"
        pl.label(f"{kind}\n{val}", (a["x1"], yv), AMBER, fs=10.4)

    if not r["az"] and r["vlle"] is None:
        pl.label("$y_1 > x_1$ at every measured point:\n"
                 "the curves never meet, so no azeotrope",
                 None, r["col"], fs=10.4)

    ax.set_xlabel(f"$x_1$,  $y_1$   ({d.c1.name})", labelpad=2)
    ax.set_ylabel(r["ylabel"])
    ax.set_title("(a)  " + ("$T$-$x$-$y$" if d.kind == "isobaric"
                            else "$P$-$x$-$y$")
                 + f",  {cond_line(d)}", fontsize=11.8, pad=7)
    return pl


# --------------------------------------------------------------------------
def draw_gamma(ax, r):
    """Panel (b): gamma_1 and gamma_2 against liquid composition."""
    d = r["dat"]
    g1, g2, m = r["g1"], r["g2"], r["gmask"]
    ax.grid(True, zorder=0)
    ax.set_axisbelow(True)
    ax.set_yscale("log")
    ax.set_xlim(-0.02, 1.02)

    show_req = r["key"] == "methanol-water"

    stack = [g1[m], g2[m]]
    if show_req:
        stack.append(r["g2_req"][m])
    allg = np.concatenate(stack)
    lo, hi = float(np.min(allg)), float(np.max(allg))
    lo, hi = min(lo, 1.0), max(hi, 1.0)
    # Headroom above the curves for the annotations. The VLLE panel carries
    # the long "gamma_1 = 57 is real" note, so it is given more.
    f = (hi / lo) ** 0.10
    ax.set_ylim(lo / f, hi * f ** (3.4 if r["vlle"] is not None else 2.2))

    ax.axhline(1.0, color=GRAPHITE, lw=1.3, ls=":", zorder=2)

    # curves, split at the miscibility gap where there is no liquid to join
    def segments(mask):
        x = d.x1[mask]
        o = np.argsort(x)
        if r["gap"] is None:
            return [(x[o], o)]
        lo_, hi_ = r["gap"]
        a = x[o] <= lo_ + 1e-9
        b = x[o] >= hi_ - 1e-9
        return [(x[o][a], o[a]), (x[o][b], o[b])]

    for g, col, lab in ((g1, G1COL, f"$\\gamma_1$   {d.c1.name}"),
                        (g2, G2COL, f"$\\gamma_2$   {d.c2.name}")):
        for xs_, o in segments(m):
            gg = g[m][o]
            ax.plot(xs_, gg, "-", color=col, lw=2.0, zorder=4, alpha=0.9)
            ax.plot(xs_, gg, "o", color=col, mfc=PAPER, mew=1.7, ms=6.0,
                    zorder=5, label=lab)
            lab = "_nolegend_"

    if r["gap"] is not None:
        ax.axvspan(r["gap"][0], r["gap"][1], color=MIST, alpha=0.45, zorder=1)

    pl = Placer(ax)
    for g in (g1, g2):
        for xs_, o in segments(m):
            pl.curve(xs_, g[m][o])
    pl.occupy(np.linspace(-0.02, 1.02, 60), np.full(60, 1.0), pad=0)

    # the azeotrope, on this panel too: it is the composition at which
    # gamma_1/gamma_2 has come all the way to Psat_2/Psat_1
    ylo_, yhi_ = ax.get_ylim()
    for a in r["az"]:
        ax.axvline(a["x1"], color=AMBER, ls=(0, (4, 3)), lw=1.6, zorder=3)
        pl.occupy(np.full(40, a["x1"]),
                  np.geomspace(ylo_, yhi_, 40), pad=0)
        side = "right" if a["x1"] > 0.5 else "left"      # write into the room
        pad = "  " if side == "left" else ""
        pl.keep_inside(ax.text(
            a["x1"], ylo_ * (yhi_ / ylo_) ** 0.02,
            f"{pad}azeotrope, $x_1$ = {a['x1']:.4f}{'' if pad else '  '}",
            ha=side, va="bottom", fontsize=9.6, color="#9A6412", zorder=6))

    # --------------------------------------------- the counterexample's point
    if show_req:
        o = np.argsort(d.x1[m])
        ax.plot(d.x1[m][o], r["g2_req"][m][o], "-.", color=NAVY, lw=2.2,
                zorder=4)
        pl.curve(d.x1[m][o], r["g2_req"][m][o], pad=2)
        xk = r["amin_x"]
        ax.annotate("", xy=(xk, r["amin_g2req"]), xytext=(xk, r["amin_g2"]),
                    arrowprops=dict(arrowstyle="<->", color=AMBER, lw=2.4,
                                    shrinkA=0, shrinkB=0), zorder=7)
        pl.occupy(np.full(40, xk),
                  np.geomspace(r["amin_g2"], r["amin_g2req"], 40), pad=1)
        pl.label(r"$\gamma_2$ WOULD HAVE TO REACH THIS LINE"
                 "\n"
                 r"($\gamma_2 = \gamma_1 P_1^{\rm sat}/P_2^{\rm sat}$, "
                 r"i.e. $\alpha_{12} = 1$)",
                 (float(d.x1[m][o][len(o) // 2]),
                  float(r["g2_req"][m][o][len(o) // 2])), NAVY, fs=10.2)
        pl.label(f"closest approach, at $x_1$ = {xk:.3f}:\n"
                 f"$\\gamma_2$ = {r['amin_g2']:.3f}, not the "
                 f"{r['amin_g2req']:.3f} needed\n"
                 f"— short by a factor {r['amin']:.2f}",
                 (xk, float(np.sqrt(r["amin_g2"] * r["amin_g2req"]))),
                 "#9A6412", fs=10.2)

    # ------------------------------------------------ the Type 4 explanation
    if r["vlle"] is not None:
        k = int(np.nanargmax(np.where(m, g1, np.nan)))
        ax.plot([d.x1[k]], [g1[k]], "o", color=G1COL, ms=11, mfc=PAPER,
                mew=2.4, zorder=6)
        ylo_, yhi_ = ax.get_ylim()
        ytxt = ylo_ * (yhi_ / ylo_) ** 0.17
        pl.keep_inside(ax.text(
            0.5 * (r["gap"][0] + r["gap"][1]), ytxt,
            "no single liquid\nphase exists here",
            ha="center", va="center", fontsize=9.6, color=SLATE,
            linespacing=1.35, zorder=6))
        pl.occupy(np.linspace(r["gap"][0], r["gap"][1], 30),
                  np.full(30, ytxt), pad=2)
        pl.label(f"$\\gamma_1$ = {g1[k]:.1f} at $x_1$ = {d.x1[k]:.3f} "
                 "— NOT AN ERROR:\n"
                 f"{g1[k]:.0f}$\\times$ the escaping tendency an ideal\n"
                 "solution would give it, so the liquid SPLITS.",
                 (d.x1[k], g1[k]), G1COL, fs=10.2)

    # ---------------------------------------------- direct labels on the two
    for g, col, name, sub in (
            (g1, G1COL, r"$\gamma_1$", d.c1.name),
            (g2, G2COL, r"$\gamma_2$", d.c2.name)):
        gg, xx = g[m], d.x1[m]
        j = int(np.argmax(np.abs(np.log(gg))))
        pl.label(f"{name}  ({sub})\n"
                 + (f"{r['g1lo']:.3f} – {r['g1hi']:.3f}" if col is G1COL
                    else f"{r['g2lo']:.3f} – {r['g2hi']:.3f}"),
                 (float(xx[j]), float(gg[j])), col, fs=10.4)

    ticks = log_ticks(*ax.get_ylim())
    ax.yaxis.set_major_locator(FixedLocator(ticks))
    ax.yaxis.set_minor_locator(FixedLocator([]))
    ax.yaxis.set_major_formatter(FuncFormatter(fmt_tick))
    ax.set_xlabel(f"$x_1$   ({d.c1.name}, liquid)", labelpad=2)
    ax.set_ylabel(r"activity coefficient  $\gamma_i$   (log scale)")
    ax.set_title(r"(b)  $\gamma_1$ and $\gamma_2$ from the same "
                 r"measurements", fontsize=11.8, pad=7)
    return pl


# --------------------------------------------------------------------------
def footer(r):
    """At most two lines, at a size that survives a 60vh slide.

    These five figures each have a slide of their own, and that slide carries
    the gamma ranges, the departure from Raoult, the three-phase state, the
    discarded spurious crossing and the Module 5 pointer in full-size type. A
    block of eight grey lines under the panels renders at about 5 px of cap
    height there — not small but legible, unreadable — and it says nothing the
    slide has not already said larger.

    So only what the PNG must carry on its own, because the PNG travels into
    the handout and into the printed notes where the slide's cards do not
    follow it:

      line 1  what the data is, and where it came from;
      line 2  the one assumption a reader could otherwise get wrong.

    Everything else stays on the slide, or is already annotated inside the
    axes where it is drawn at the size of the thing it names.
    """
    d = r["dat"]
    lines = [
        f"{d.c1.name} (1) + {d.c2.name} (2)  ·  {len(d)} points, "
        f"{cond_line(d)}  ·  doi:{r['doi']}",
    ]
    if r["vlle"] is not None:
        # The one number on this figure that is not read straight off a table.
        lines.append(
            "$T_3$ and $y_1$ are measured; the two conjugate liquid "
            "compositions are extrapolated 3.2 K from the paper's own LLE "
            "table.")
    else:
        lines.append(
            "$\\gamma_i = y_i P/(x_i P_i^{\\rm sat})$: modified Raoult, ideal "
            "vapour, Antoine $P_i^{\\rm sat}$. Nothing here is fitted.")
    return "\n".join(lines)


def build(r):
    use_style()
    fig, (axL, axR) = plt.subplots(1, 2, figsize=FIGSIZE,
                                   gridspec_kw={"width_ratios": [1.0, 1.16]})
    plL = draw_phase(axL, r)
    plR = draw_gamma(axR, r)

    h, lab = axL.get_legend_handles_labels()
    h2, lab2 = axR.get_legend_handles_labels()
    seen, hh, ll = set(), [], []
    for a, b in list(zip(h, lab)) + list(zip(h2, lab2)):
        if b not in seen and not b.startswith("_"):
            seen.add(b)
            hh.append(a)
            ll.append(b)
    # One legend row across the top. The VLLE figure has one more entry than
    # the others, so the type size is measured down until the row fits rather
    # than being fixed at a value that happens to work for four of the five.
    fs = 10.4
    for _ in range(6):
        leg = fig.legend(hh, ll, loc="upper center",
                         bbox_to_anchor=(0.5, 0.915), ncol=len(ll),
                         fontsize=fs, frameon=False)
        fig.canvas.draw()
        frac = (leg.get_window_extent().width
                / (fig.get_figwidth() * fig.dpi))
        if frac <= 0.98:
            break
        leg.remove()
        fs = fs / frac * 0.97

    fig.suptitle(r["head"] + " — " + r["sub"], fontsize=15.0,
                 color=r["col"] if r["is_type"] else "#1F6F78",
                 fontweight="normal" if r["is_type"] else "bold", y=0.988)
    # THE CAPTION IS SIZED BY MEASUREMENT, not by a typed-in point size. It is
    # two lines (see `footer`) and it stays two lines: what is measured down
    # here is the type size, not the column width, because re-wrapping a
    # footnote narrower is how it grew to eight unreadable lines in the first
    # place. A caption one character too wide makes bbox_inches='tight' grow
    # the canvas, which changes the aspect ratio of the slide and rescales both
    # panels, so each figure's footnote finds the largest size that fits the
    # figure width — with a floor, below which the line stops being readable at
    # slide scale and the honest answer is to write less, not smaller.
    cap, fs, t = footer(r), 13.0, None
    for _ in range(8):
        if t is not None:
            t.remove()
        t = fig.text(0.5, 0.014, cap, ha="center", va="bottom", fontsize=fs,
                     color=SLATE, linespacing=1.45)
        fig.canvas.draw()
        frac = (t.get_window_extent().width
                / (fig.get_figwidth() * fig.dpi))
        if frac <= 0.965 or fs <= 10.5:
            break
        fs = max(10.5, fs / frac * 0.955)
    # The caption's height is measured too, so the panels are given exactly
    # the room that is left rather than a per-line allowance that is right for
    # one figure and wrong for the VLLE one, whose footnote is longer.
    fig.canvas.draw()
    ch = t.get_window_extent().height / (fig.get_figheight() * fig.dpi)
    fig.tight_layout(rect=(0.006, 0.030 + ch, 0.994, 0.905))

    # A panel title wider than its panel makes bbox_inches='tight' widen the
    # canvas, exactly as an overflowing caption does. Measure and shrink.
    fig.canvas.draw()
    for ax in (axL, axR):
        for _ in range(5):
            ti = ax.title
            room = ax.get_window_extent().width + 0.05 * (
                fig.get_figwidth() * fig.dpi)
            wpx = ti.get_window_extent().width
            if wpx <= room:
                break
            ti.set_fontsize(ti.get_fontsize() * room / wpx * 0.98)
            fig.canvas.draw()

    # Only now, with both axes at their final size, are the annotations placed.
    plL.flush()
    plR.flush()
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    res = {r["key"]: r for r in analyse()}
    for key, slug in SLUGS.items():
        r = res[key]
        d = r["dat"]
        print(f"{slug}: {r['head']} — {d.label}   doi:{r['doi']}")
        print(f"    n = {len(d):2d}   {cond_line(d).replace('$', '')}")
        print(f"    gamma1 {r['g1lo']:.4f}-{r['g1hi']:.4f}   "
              f"gamma2 {r['g2lo']:.4f}-{r['g2hi']:.4f}   "
              f"(modified Raoult, ideal vapour)")
        print(f"    largest signed departure from the Raoult reference: "
              f"{r['worst']:+.3f} {r['unit']} at x1 = {r['worst_x']:.4f}")
        g1, g2, m = r["g1"], r["g2"], r["gmask"]
        k1 = int(np.nanargmax(np.where(m, g1, np.nan)))
        k2 = int(np.nanargmax(np.where(m, g2, np.nan)))
        print(f"    largest gamma1 {g1[k1]:.4f} at x1 = {d.x1[k1]:.4f};   "
              f"largest gamma2 {g2[k2]:.4f} at x1 = {d.x1[k2]:.4f}")
        for a in r["az"]:
            print(f"    azeotrope from the table (linear interpolation of "
                  f"y1 - x1 through zero): x1 = {a['x1']:.4f}, "
                  f"T = {a['T']:.2f} K, P = {a['P']:.2f} kPa")
        for a in r["fake"]:
            print(f"    DISCARDED spurious crossing at x1 = {a['x1']:.4f}: it "
                  f"lies inside the miscibility gap {r['gap']}")
        if not r["az"] and r["vlle"] is None:
            print(f"    no interior crossing of y1 = x1: no azeotrope.  "
                  f"alpha_12 = {r['amin']:.4f} at its smallest, at "
                  f"x1 = {r['amin_x']:.4f}, where gamma2 = {r['amin_g2']:.4f} "
                  f"against the {r['amin_g2req']:.4f} an azeotrope needs")
        v = r["vlle"]
        if v is not None:
            print(f"    three-phase (VLLE) state at {v['P']:g} kPa: "
                  f"T = {v['T']:.2f} K, heteroazeotropic vapour y1 = "
                  f"{v['y1']:.4f}")
            print(f"      conjugate liquids x1 = {v['x1_aq']:.4f} (water-rich) "
                  f"and {v['x1_org']:.4f} (1-butanol-rich); tie line spans "
                  f"{v['x1_org'] - v['x1_aq']:.4f} in x1")
            print("      the figure states that VLLE is treated properly in "
                  "Module 5")
        for p in write(build(r), slug, OUT):
            print("    wrote", p)
        print()
