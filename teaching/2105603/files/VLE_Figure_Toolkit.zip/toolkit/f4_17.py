#!/usr/bin/env python3
"""F4.17  gamma-phi and phi-phi on one system, and where gamma-phi stops.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

The two routes to the same equilibrium:

    gamma-phi     y_i phi_hat_i P = x_i gamma_i f_i^0,
                  f_i^0 = phi_i^sat Psat_i exp[v_i^L (P - Psat_i)/RT]
    phi-phi       y_i phi_hat_i^V(T,P,y) = x_i phi_hat_i^L(T,P,x)

The first needs a REFERENCE FUGACITY for pure liquid i at the temperature of
the mixture. The second does not: it evaluates both phases from one equation of
state and never mentions a pure liquid at all. That difference is invisible for
an ethanol/water mixture at 1 bar and fatal for a natural-gas mixture, and this
figure is the fatal case.

THE SYSTEM. methane (1) + n-butane (2) at 310.93 K (100 F), the classical
retrograde pair, using the Peng-Robinson equation with the 1976 alpha function
and k_12 = 0. Methane's critical temperature is 190.56 K, so at 310.93 K it
sits at T/Tc = 1.63. There is no pure liquid methane at this temperature, at
any pressure, and therefore no Psat_1 and no f_1^0. Raoult's law is written
here anyway — with Psat_1 taken from the Antoine correlation evaluated 120 K
above the end of its own stated range, 91-190 K — because that is exactly what
a spreadsheet does when it is asked, and the figure shows what comes out.

NO EXPERIMENTAL DATA IS CLAIMED ON THIS FIGURE. Both curves are calculations.
The phi-phi envelope comes from `vlekit.cubic` with Tc, Pc and omega from
Poling, Prausnitz & O'Connell as stored in `vlekit.data.LIBRARY`; the
gamma-phi line comes from the Antoine constants in the same table. The point
being made is about the structure of the two methods, not about the accuracy of
either, and no measurement is needed to make it.

WHAT PANEL (b) ADDS. Relative volatility is not the issue; the K-values are.
A mixture critical point is the state where K_i = 1 for EVERY component at
once. The phi-phi route produces that, because both K's are ratios of fugacity
coefficients evaluated from the same equation at the same T and P, and they
approach one together. The gamma-phi route has K_i = gamma_i Psat_i / P, a
product of a composition function and a pure-component function; there is no
mechanism in it that drives every K to one simultaneously, and near the
mixture critical point the equations it does have become ill-conditioned
because x and y are converging on each other while the route insists on
computing them from separate expressions.

Run:  python3 f4_17.py
"""
from __future__ import annotations

import os
import sys

import numpy as np

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib                                                  # noqa: E402
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                    # noqa: E402

import vlekit as v                                                 # noqa: E402
from vlekit import cubic as C                                      # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY, PAPER,  # noqa: E402
                          RUST, SKYBLUE, SLATE, TEAL, use_style)

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_17_gamma_phi_vs_phi_phi"

T_OP = 310.93            # K, 100 F
NX = 320
TRIVIAL = 0.004          # stop the bubble trace when y1 - x1 falls below this


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def wrapped(text, width):
    """Wrap a caption on spaces, never inside a $...$ span."""
    out = []
    for para in text.split("\n"):
        cur, n, inmath = [], 0, False
        for w in para.split(" "):
            if cur and not inmath and n + 1 + len(w) > width:
                out.append(" ".join(cur))
                cur, n = [], 0
            cur.append(w)
            n += len(w) + (1 if n else 0)
            if w.count("$") % 2 == 1:
                inmath = not inmath
        out.append(" ".join(cur))
    return "\n".join(out)


# --------------------------------------------------------------------------
def trace_bubble(mix, T, xs):
    """Walk the bubble branch with each point warm-starting the next.

    `cubic.bubble_P` selects the Z root by Gibbs energy, which is what lets it
    run into the critical region at all, and which is also why it must be
    marched rather than called cold at each composition. The trace stops when
    y1 - x1 collapses: that is the trivial solution, and it is the numerical
    signature of the mixture critical point.
    """
    P, K0, out = None, None, []
    for x1 in xs:
        r = C.bubble_P(mix, [x1, 1 - x1], T, guess=P, K0=K0)
        if not r["converged"] or r["P"] <= 0:
            break
        y = np.asarray(r["y"], dtype=float)
        if y[0] - x1 < TRIVIAL:
            break
        P = r["P"]
        K0 = y / np.array([x1, 1 - x1])
        out.append((x1, r["P"], y[0]))
    return np.array(out)


def analyse():
    me, nb = v.component("methane"), v.component("n-butane")
    pr = C.PengRobinson([me, nb])

    br = trace_bubble(pr, T_OP, np.linspace(5e-4, 0.95, NX))
    x1, Pb, y1 = br[:, 0], br[:, 1], br[:, 2]

    # the pure-component numbers the gamma-phi route would have to use
    Ps1 = float(me.Psat(T_OP))          # an extrapolation, and a fiction
    Ps2 = float(nb.Psat(T_OP))
    Ps2_eos = C.psat(pr, 1, T_OP)       # n-butane really does have one

    xr = np.linspace(0.0, 1.0, 201)
    P_raoult = xr * Ps1 + (1 - xr) * Ps2

    # per-cent departure of Raoult from the equation of state, at the
    # compositions where the equation of state has an answer
    P_raoult_at = x1 * Ps1 + (1 - x1) * Ps2
    dev = 100.0 * (P_raoult_at - Pb) / Pb

    # K values along the phi-phi bubble curve, and what gamma-phi would say at
    # the same pressure with gamma = 1 (no binary data exists, and none could
    # be regressed: there is no reference state to regress against)
    K1_pp = y1 / x1
    K2_pp = (1 - y1) / (1 - x1)
    K1_gp = Ps1 / Pb
    K2_gp = Ps2 / Pb

    crit = dict(x1=float(x1[-1]), P=float(Pb[-1]), y1=float(y1[-1]),
                K1=float(K1_pp[-1]), K2=float(K2_pp[-1]),
                K1_gp=float(K1_gp[-1]), K2_gp=float(K2_gp[-1]))

    return dict(me=me, nb=nb, pr=pr, x1=x1, Pb=Pb, y1=y1, xr=xr,
                P_raoult=P_raoult, dev=dev, Ps1=Ps1, Ps2=Ps2,
                Ps2_eos=Ps2_eos, K1_pp=K1_pp, K2_pp=K2_pp, K1_gp=K1_gp,
                K2_gp=K2_gp, crit=crit)


# --------------------------------------------------------------------------
def build(d):
    use_style()
    fig, (axA, axB) = plt.subplots(1, 2, figsize=(14.4, 6.9))
    MPa = 1e-3

    # ------------------------------------------------------------- panel (a)
    axA.grid(True, zorder=0)
    axA.set_axisbelow(True)
    axA.plot(d["x1"], d["Pb"] * MPa, "-", color=NAVY, lw=2.6, zorder=5)
    axA.plot(d["y1"], d["Pb"] * MPa, "-", color=TEAL, lw=2.6, zorder=5)
    axA.plot(d["xr"], d["P_raoult"] * MPa, "--", color=RUST, lw=2.2, zorder=4)
    axA.plot([d["crit"]["x1"]], [d["crit"]["P"] * MPa], "*", color=AMBER,
             ms=20, mec=GRAPHITE, mew=1.2, zorder=7)
    axA.plot([1.0], [d["Ps1"] * MPa], "o", color=RUST, ms=10, mfc=PAPER,
             mew=2.0, zorder=7)

    axA.set_xlim(0, 1.02)
    axA.set_ylim(0, 1.10 * d["Ps1"] * MPa)
    axA.set_xlabel("$x_1$,  $y_1$   (methane)")
    axA.set_ylabel("$P$ / MPa")
    axA.set_title(f"(a)  $P$-$x$-$y$ at {T_OP:g} K:  one route has an "
                  "envelope,\nthe other has a straight line to nowhere",
                  fontsize=11.8, pad=6)

    axA.annotate(r"$\phi$–$\phi$ bubble" "\n(Peng-Robinson, $k_{12}$ = 0)",
                 xy=(d["x1"][NX // 6], d["Pb"][NX // 6] * MPa),
                 xytext=(0.545, 0.170), textcoords="axes fraction",
                 ha="center", va="center", fontsize=10.0, color=NAVY,
                 linespacing=1.4, zorder=9,
                 bbox=dict(boxstyle="round,pad=0.24", fc=PAPER, ec=NAVY,
                           lw=1.0, alpha=0.95),
                 arrowprops=dict(arrowstyle="-", color=NAVY, lw=1.0,
                                 shrinkA=3, shrinkB=5))
    j = int(0.55 * len(d["y1"]))
    axA.annotate(r"$\phi$–$\phi$ dew", xy=(d["y1"][j], d["Pb"][j] * MPa),
                 xytext=(0.93, 0.36), textcoords="axes fraction",
                 ha="right", va="center", fontsize=10.0, color=TEAL,
                 zorder=9,
                 bbox=dict(boxstyle="round,pad=0.24", fc=PAPER, ec=TEAL,
                           lw=1.0, alpha=0.95),
                 arrowprops=dict(arrowstyle="-", color=TEAL, lw=1.0,
                                 shrinkA=3, shrinkB=5))
    axA.annotate("mixture critical point\n"
                 f"$x_1 = y_1$ = {d['crit']['x1']:.3f},  "
                 f"$P$ = {d['crit']['P'] * MPa:.2f} MPa\n"
                 r"$K_1 = K_2 \to 1$ together",
                 xy=(d["crit"]["x1"], d["crit"]["P"] * MPa),
                 xytext=(0.265, 0.470), textcoords="axes fraction",
                 ha="center", va="center", fontsize=9.8, color="#9A6412",
                 linespacing=1.45, zorder=9,
                 bbox=dict(boxstyle="round,pad=0.26", fc=PAPER, ec=AMBER,
                           lw=1.1, alpha=0.95),
                 arrowprops=dict(arrowstyle="-", color=AMBER, lw=1.2,
                                 shrinkA=3, shrinkB=8))
    axA.annotate(r"Raoult / $\gamma$–$\phi$ needs "
                 f"$P_1^{{\\rm sat}}$({T_OP:g} K) = {d['Ps1'] * MPa:.1f} MPa."
                 "\nMethane's $T_c$ is 190.56 K, so "
                 r"$T/T_c$ = " f"{T_OP / d['me'].Tc:.2f}:\n"
                 "THERE IS NO PURE LIQUID METHANE HERE.\n"
                 "The number comes from an Antoine fit\n"
                 "evaluated 120 K past its own range.",
                 xy=(1.0, d["Ps1"] * MPa), xytext=(0.035, 0.965),
                 textcoords="axes fraction", ha="left", va="top",
                 fontsize=9.6, color=RUST, linespacing=1.5, zorder=9,
                 bbox=dict(boxstyle="round,pad=0.28", fc=PAPER, ec=RUST,
                           lw=1.2, alpha=0.96),
                 arrowprops=dict(arrowstyle="-", color=RUST, lw=1.2,
                                 shrinkA=6, shrinkB=6))

    # ------------------------------------------------------------- panel (b)
    axB.grid(True, which="both", zorder=0)
    axB.set_axisbelow(True)
    axB.set_xscale("log")
    axB.set_yscale("log")
    axB.axhline(1.0, color=GRAPHITE, lw=1.4, zorder=3)
    axB.plot(d["Pb"] * MPa, d["K1_pp"], "-", color=NAVY, lw=2.6, zorder=5)
    axB.plot(d["Pb"] * MPa, d["K2_pp"], "-", color=TEAL, lw=2.6, zorder=5)
    axB.plot(d["Pb"] * MPa, d["K1_gp"], "--", color=RUST, lw=2.2, zorder=4)
    axB.plot(d["Pb"] * MPa, d["K2_gp"], "--", color=AMBER, lw=2.2, zorder=4)
    axB.plot([d["crit"]["P"] * MPa] * 2, [d["crit"]["K1"], d["crit"]["K2"]],
             "*", color=AMBER, ms=17, mec=GRAPHITE, mew=1.1, zorder=7)

    lab = [(d["K1_pp"][-1], r"$K_1$  $\phi$–$\phi$", NAVY),
           (d["K2_pp"][-1], r"$K_2$  $\phi$–$\phi$", TEAL),
           (d["K1_gp"][-1], r"$K_1$  $\gamma$–$\phi$", RUST),
           (d["K2_gp"][-1], r"$K_2$  $\gamma$–$\phi$", AMBER)]
    yv = np.log10([a for a, _, _ in lab])
    o = np.argsort(yv)
    out = yv.copy()
    for k in range(1, len(o)):
        i, jj = o[k - 1], o[k]
        if out[jj] - out[i] < 0.28:
            out[jj] = out[i] + 0.28
    for (y0, txt, col), yl in zip(lab, out):
        axB.annotate(txt, xy=(d["Pb"][-1] * MPa, y0),
                     xytext=(1.30 * d["Pb"][-1] * MPa, 10 ** yl),
                     ha="left", va="center", fontsize=10.2, color=col,
                     zorder=9,
                     arrowprops=dict(arrowstyle="-", color=col, lw=0.9,
                                     shrinkA=1, shrinkB=1))
    axB.set_xlim(0.85 * d["Pb"][0] * MPa, 3.6 * d["Pb"][-1] * MPa)
    axB.set_xlabel("$P$ / MPa   (logarithmic)")
    axB.set_ylabel("$K_i = y_i / x_i$")
    axB.set_title("(b)  the same two routes against pressure:\n"
                  "only one of them can reach a critical point",
                  fontsize=11.8, pad=6)
    axB.text(0.025, 0.030,
             "A critical point IS $K_i = 1$ for every $i$ at once.\n"
             r"$\phi$–$\phi$ gets there: both $K$ come from one equation at "
             "one $T$, $P$,\nand they meet at "
             f"{d['crit']['P'] * MPa:.2f} MPa.  "
             r"$\gamma$–$\phi$ has $K_i = \gamma_i P_i^{\rm sat}/P$, a "
             "composition\nfunction times a pure-component one, with nothing "
             "in it that drives\nevery $K$ to 1 together: there it still says "
             f"$K_1$ = {d['crit']['K1_gp']:.2f}, $K_2$ = "
             f"{d['crit']['K2_gp']:.3f}.",
             transform=axB.transAxes, ha="left", va="bottom", fontsize=8.8,
             color=GRAPHITE, linespacing=1.55, zorder=9,
             bbox=dict(boxstyle="round,pad=0.28", fc=PAPER, ec=MIST, lw=1.0,
                       alpha=0.96))

    fig.suptitle(r"Where the activity-coefficient route stops working:  "
                 r"$\gamma$–$\phi$ needs a pure-liquid reference fugacity, "
                 "and sometimes there is not one",
                 fontsize=14.0, y=0.985)
    fig.text(0.5, 0.018, wrapped(
        f"methane (1) + n-butane (2) at {T_OP:g} K. BOTH CURVES ARE "
        "CALCULATIONS; no measurement is claimed and none is needed for the "
        "point. Peng-Robinson, 1976 alpha function, $k_{12}$ = 0, with $T_c$, "
        "$P_c$ and $\\omega$ from Poling, Prausnitz & O'Connell as stored in "
        "vlekit.data.LIBRARY; the Raoult line uses the Antoine constants from "
        "the same table.\n"
        "The bubble branch is marched with each point warm-starting the next "
        "and stops where $y_1 - x_1$ collapses, which is the numerical "
        f"signature of the mixture critical point: {len(d['x1'])} converged "
        f"points, last at $x_1$ = {d['crit']['x1']:.4f}, $P$ = "
        f"{d['crit']['P'] * 1e-3:.3f} MPa. Raoult's law overstates the bubble "
        f"pressure by {d['dev'].min():.0f} to {d['dev'].max():.0f} per cent "
        "across the range where the equation of state has an answer at all.\n"
        "n-butane is subcritical here and does have a reference state: "
        f"$P_2^{{\\rm sat}}$ = {d['Ps2']:.1f} kPa from Antoine, "
        f"{d['Ps2_eos']:.1f} kPa from the same Peng-Robinson equation "
        f"({100 * (d['Ps2'] - d['Ps2_eos']) / d['Ps2_eos']:+.1f} per cent) — "
        "the disagreement between the two descriptions of the ONE component "
        "that has a liquid, for scale.", 176),
        ha="center", va="bottom", fontsize=9.5, color=SLATE, linespacing=1.6)
    fig.tight_layout(rect=(0.005, 0.275, 0.995, 0.930))
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = analyse()
    c = d["crit"]
    print(f"methane (1) + n-butane (2), Peng-Robinson (1976 alpha), "
          f"k12 = 0, T = {T_OP:g} K")
    print(f"  methane  Tc = {d['me'].Tc:.2f} K, Pc = {d['me'].Pc:.0f} kPa, "
          f"omega = {d['me'].omega:.4f}   ->  T/Tc = "
          f"{T_OP / d['me'].Tc:.3f}: SUPERCRITICAL, no pure liquid, no Psat")
    print(f"  n-butane Tc = {d['nb'].Tc:.2f} K, Pc = {d['nb'].Pc:.0f} kPa, "
          f"omega = {d['nb'].omega:.4f}   ->  T/Tc = "
          f"{T_OP / d['nb'].Tc:.3f}: subcritical")
    print()
    print(f"  Antoine Psat(methane, {T_OP:g} K)  = {d['Ps1']:10.1f} kPa "
          f"-- an extrapolation 120 K past the stated range "
          f"{d['me'].Trange[0]:.0f}-{d['me'].Trange[1]:.0f} K, and a fiction")
    print(f"  Antoine Psat(n-butane, {T_OP:g} K) = {d['Ps2']:10.1f} kPa;  "
          f"the same Peng-Robinson gives {d['Ps2_eos']:.1f} kPa "
          f"({100 * (d['Ps2'] - d['Ps2_eos']) / d['Ps2_eos']:+.2f} %)")
    print()
    print(f"  bubble branch: {len(d['x1'])} converged points, "
          f"x1 = {d['x1'][0]:.4f} to {d['x1'][-1]:.4f}")
    print(f"  mixture critical point (where y1 - x1 collapses): "
          f"x1 = y1 = {c['x1']:.4f}, P = {c['P'] * 1e-3:.3f} MPa")
    print(f"    phi-phi there: K1 = {c['K1']:.4f}, K2 = {c['K2']:.4f}  "
          f"(both -> 1, which is what a critical point is)")
    print(f"    gamma-phi there: K1 = {c['K1_gp']:.4f}, "
          f"K2 = {c['K2_gp']:.4f}  (neither is 1, and nothing makes them so)")
    print()
    print("  Raoult vs the equation of state, bubble pressure:")
    print(f"    {'x1':>8s} {'phi-phi / kPa':>14s} {'Raoult / kPa':>13s} "
          f"{'dev %':>8s}")
    for f in (0.0, 0.1, 0.25, 0.5, 0.75, 0.9, 1.0):
        i = int(np.clip(round(f * (len(d["x1"]) - 1)), 0, len(d["x1"]) - 1))
        pr_ = d["x1"][i] * d["Ps1"] + (1 - d["x1"][i]) * d["Ps2"]
        print(f"    {d['x1'][i]:8.4f} {d['Pb'][i]:14.1f} {pr_:13.1f} "
              f"{d['dev'][i]:8.1f}")
    print(f"    Raoult overstates the bubble pressure by "
          f"{d['dev'].min():.1f} to {d['dev'].max():.1f} % over the branch")
    for p in write(build(d), SLUG):
        print("wrote", p)
