#!/usr/bin/env python3
"""F4.10  The Rachford-Rice function: monotonic, and therefore safe.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

`vlekit.plots.rachford_rice_plot` draws one curve. This figure draws three, for
the same feed at three pressures, so that "monotonic and therefore safe" is
demonstrated rather than asserted:

    below the dew pressure   F(1) > 0, no root in [0,1] — the feed is all
                             vapour, and a solver told to find a root would be
                             looking for something that is not there
    between them             one root, which bisection cannot miss
    above the bubble         F(0) < 0, no root in [0,1] — all liquid

The slope dF/dV is differenced numerically for every curve and its maximum is
printed on the figure: it is negative everywhere, which is the property that
makes the two end values F(0) and F(1) a complete phase test before any
iteration starts.

K values come from `vlekit.flash.K_values` on the ethanol/water Margules model
of F4.2 (illustrative parameters, stated on the figure), evaluated at the feed
composition — the first K estimate a flash actually makes — rather than round
numbers chosen to make the picture work. The bubble and dew pressures that
bracket the two-phase case are computed with vlekit.regress.bubble_P and
vlekit.flash.dew_P.

Run:  python3 f4_10.py
"""
import os
import sys

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, "/home/claude/vlekit")
import vlekit as v                                              # noqa: E402
from vlekit import flash as FL                                  # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,     # noqa: E402
                          PAPER, RUST, SLATE, TEAL, newfig)

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_10_rachford_rice"

A = [1.6, 0.9]            # Margules-2, illustrative (the model of F4.2)
T_SET = 360.0
Z1 = 0.20


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def make():
    c1, c2 = v.component("ethanol"), v.component("water")
    model = v.Margules(A)

    Pb, _ = v.bubble_P(model, np.array([Z1]), np.array([T_SET]), c1, c2)
    Pd, _ = FL.dew_P(model, np.array([Z1]), np.array([T_SET]), c1, c2)
    Pb, Pd = float(Pb[0]), float(Pd[0])

    cases = []
    for P, tag, col in ((0.90 * Pd, "below the dew pressure", AMBER),
                        (0.5 * (Pb + Pd), "between dew and bubble", NAVY),
                        (1.10 * Pb, "above the bubble pressure", RUST)):
        # K values at the feed composition — the first guess a flash makes
        K1, K2 = FL.K_values(model, np.array([Z1]), np.array([T_SET]), P,
                             c1, c2)
        K1, K2 = float(K1[0]), float(K2[0])
        V, F = FL.rachford_rice_curve(Z1, K1, K2, n=601)
        root, status = FL.rachford_rice(Z1, K1, K2)
        dF = np.gradient(F, V)
        cases.append({"P": P, "tag": tag, "colour": col, "K1": K1, "K2": K2,
                      "V": V, "F": F, "root": root, "status": status,
                      "F0": float(F[0]), "F1": float(F[-1]),
                      "max_slope": float(np.max(dF))})
    return c1, c2, model, Pb, Pd, cases


def build(Pb, Pd, cases):
    fig, ax = newfig(9.6, 5.8)
    ax.axhline(0.0, color=GRAPHITE, lw=1.3, zorder=3)

    for cs in cases:
        # The root value goes in the legend entry rather than in a callout on
        # the plot. A leader from the marker down to a label crossed the
        # 'all liquid' curve from whichever side it was drawn, and a guide
        # line that cuts through data is worse than no guide line at all.
        tail = (f"  $\\rightarrow$  {cs['status']}"
                if cs["status"] != "two phase"
                else f"  $\\rightarrow$  two phase, root at "
                     f"$V$ = {cs['root']:.4f}")
        ax.plot(cs["V"], cs["F"], "-", color=cs["colour"], lw=2.6, zorder=4,
                label=f"$P$ = {cs['P']:.1f} kPa  ($K_1$ = {cs['K1']:.3f}, "
                      f"$K_2$ = {cs['K2']:.3f}){tail}")
        if cs["status"] == "two phase":
            ax.plot([cs["root"]], [0.0], "o", color=cs["colour"], ms=12,
                    mec=GRAPHITE, mew=1.2, zorder=7)

    ax.set_xlabel("vapour fraction $V$")
    ax.set_ylabel(r"$F(V) = \sum_i z_i (K_i-1)\,/\,[\,1+V(K_i-1)\,]$")
    ax.set_xlim(0, 1)
    lo = min(c["F"].min() for c in cases)
    hi = max(c["F"].max() for c in cases)
    # headroom only for the legend; the callout that needed the deep footwell
    # below the curves has been moved into the legend text
    ax.set_ylim(lo - 0.10 * (hi - lo), hi + 0.30 * (hi - lo))

    ax.legend(loc="upper right", fontsize=10.5, labelspacing=0.7,
              bbox_to_anchor=(1.0, 1.005))

    worst = max(c["max_slope"] for c in cases)
    fig.text(0.5, -0.055,
             f"Ethanol (1) / water (2), Margules-2 with $A_{{12}}$ = {A[0]:g}, "
             f"$A_{{21}}$ = {A[1]:g} (illustrative, as in F4.2).  Feed "
             f"$z_1$ = {Z1:g} at $T$ = {T_SET:.2f} K; bubble {Pb:.2f} kPa, "
             f"dew {Pd:.2f} kPa.\n"
             f"Largest $\\mathrm{{d}}F/\\mathrm{{d}}V$ over all three curves "
             f"= {worst:+.3f}: $F$ is strictly decreasing, so there is at most "
             "one root and the signs of $F(0)$ and $F(1)$ settle the phase "
             "state before any iteration begins.",
             ha="center", va="center", fontsize=10.5, color=SLATE,
             linespacing=1.5)

    # F(0) and F(1) tell the whole story, so they are marked on the axes
    for cs in cases:
        for xv, key, ha in ((0.0, "F0", "left"), (1.0, "F1", "right")):
            ax.plot([xv], [cs[key]], "s", color=cs["colour"], ms=6.5,
                    mec=PAPER, mew=1.0, zorder=6)

    ax.set_title("The Rachford-Rice function for one feed at three "
                 "pressures", fontsize=13.5)
    fig.tight_layout()
    return fig


if __name__ == "__main__":
    c1, c2, model, Pb, Pd, cases = make()
    print(f"feed z1 = {Z1:g} at T = {T_SET} K: bubble {Pb:.3f} kPa, "
          f"dew {Pd:.3f} kPa")
    for cs in cases:
        print(f"P = {cs['P']:7.3f} kPa  K1 = {cs['K1']:.4f}  "
              f"K2 = {cs['K2']:.4f}  F(0) = {cs['F0']:+.4f}  "
              f"F(1) = {cs['F1']:+.4f}  max dF/dV = {cs['max_slope']:+.4f}  "
              f"-> {cs['status']}"
              + (f", V = {cs['root']:.4f}" if cs["status"] == "two phase"
                 else ""))
    for p in write(build(Pb, Pd, cases), SLUG):
        print("wrote", p)
