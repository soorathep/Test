# Module 4 lecture figures — 2105603 Advanced Chemical Engineering Thermodynamics

Soorathep Kheawhom, Chulalongkorn University.

Twenty-two standalone scripts, one per figure. Each writes a PNG and a PDF of the
same render into `/home/claude/vle/qmd/figures/` at 300 dpi and prints the paths
and the numbers it computed.

```
cd /home/claude/vle/toolkit
python3 f4_01.py          # ... through f4_22.py
for f in f4_*.py; do python3 "$f"; done
```

Every script adds `/home/claude/vlekit` to `sys.path` and does its physics with
`vlekit` (`regress`, `consistency`, `flash`, `validate`, `plots`). Colours and
rcParams come from `vlekit.plots` — the Teal-Amber Lab Palette. The output
directory can be overridden with the `F4_OUT` environment variable.

**F4.1 to F4.10 use datasets synthesised with `vlekit.regress.generate` from a
known model.** None of them is an experimental measurement, and none of the
numbers on the figures is copied from the literature: each is the value a run of
the code returned. Where a *model parameter* is illustrative rather than fitted
(the ethanol/water Margules pair, the assumed excess enthalpy in F4.9) the
figure says so on its face.

**F4.11 to F4.18 use the published, DOI-cited sets in `vlekit.datasets`**, and
every figure carries the system name and the DOI on its face. The two
exceptions are stated on the figures themselves: F4.16's reference curve is a
UNIFAC *prediction*, not a measurement, and F4.17 is entirely a calculation
because the point it makes is about the structure of the two methods and no
measurement is needed for it. Where a curve comes from a model rather than a
measurement, the figure says which model, fitted to what, and at what
condition.

**F4.19 to F4.22 close the module.** F4.19 and F4.21 use the published sets;
F4.20 is about what happens when there are none; F4.22 is a diagram and carries
no measured quantity at all. F4.19 is the one figure in the module that shows a
*prediction with no measurement behind it* — a ternary assembled from binary
parameters — and it says so on its face rather than dressing it as a
validation.

| file | figure | the claim it supports | assumed inputs |
|---|---|---|---|
| `f4_01.py` | F4.1 `f4_01_vle_ladder` | Raoult → modified Raoult → gamma-phi → phi-phi is a ladder: each rung buys more physics with more parameters, more data and more computation. | Nothing computed — a concept map drawn with `FancyBboxPatch`/`FancyArrowPatch` in unit coordinates. |
| `f4_02.py` | F4.2 `f4_02_pxy_txy_azeotrope` | P-x-y and T-x-y are two sections through one surface; the azeotrope appears in both, and it is a root of gamma1 Psat1 = gamma2 Psat2, not a bump on a curve. | Margules-2 `A12 = 1.6, A21 = 0.9` for ethanol/water — illustrative teaching parameters from the course blueprint, labelled as such on the figure. |
| `f4_03.py` | F4.3 `f4_03_area_test` | The area test compares two lobe areas, so any error that grows both of them equally is invisible to it. | None beyond the generating model NRTL(0.35, 0.62). |
| `f4_04.py` | F4.4 `f4_04_point_test_residuals` | A consistent and an inconsistent set look similar apart; on one axis the bias is unmissable. | None. The inconsistent set is the consistent set plus `delta y1 = 0.30 x1 x2`. |
| `f4_05.py` | F4.5 `f4_05_three_datasets_tests` | Consistent, borderline and inconsistent are not one verdict but five, and the five scales are not calibrated against each other. | None. "Borderline" is `b = 0.10`, the bias that puts the direct-test index in the marginal band. |
| `f4_06.py` | F4.6 `f4_06_objective_functions` | Choosing the objective function moves the parameters further than the statistical uncertainty does, and moves the extrapolated predictions with them. | None beyond the generating model Margules-2 `[2.4, 2.0]`. |
| `f4_07.py` | F4.7 `f4_07_bootstrap_confidence_region` | Two parameters quoted with separate error bars describe a rectangle six times larger than the region the fit ever occupied. | None. 600 residual-resampling bootstraps, seed 2. |
| `f4_08.py` | F4.8 `f4_08_indistinguishable_fits_lle` | Two parameter sets one standard error apart fit the data identically and disagree about whether the liquid splits into two phases. | None beyond the generating model Margules-2 `[2.05, 1.98]`. |
| `f4_09.py` | F4.9 `f4_09_excess_enthalpy_term` | The `-(H^E/RT^2) dT/dx1` term an isobaric consistency test usually drops is negligible in mid-range and comparable to the tested residual at the dilute alcohol end. | **`H^E` is ASSUMED**: `H^E = 4 H^E_max x1 x2` with `H^E_max = 500 J/mol` (band 250–1000 J/mol). A plausible order of magnitude for an alcohol/water mixture near its boiling range, not a measurement; stated in full on the figure. The Margules pair is the illustrative one from F4.2. |
| `f4_10.py` | F4.10 `f4_10_rachford_rice` | The Rachford-Rice function is strictly decreasing, so it has at most one root and the signs of F(0) and F(1) decide the phase state before any iteration. | Margules-2 `A12 = 1.6, A21 = 0.9` (illustrative, as in F4.2), labelled on the figure. |
| `f4_11.py` | F4.11 `f4_11_four_solution_types` | Types 1 to 4 are one statement about the sign and size of G^E, shown on four measured mixtures against a common Raoult reference. | Nothing fitted. Antoine from `vlekit.data.LIBRARY`; azeotropes interpolated from the published tables. |
| `f4_12.py` | F4.12 `f4_12_azeotrope_criterion` | An azeotrope exists iff the relative volatility straddles one between the two ends, so the classification is a quadrant of a map rather than a list. | NRTL (alpha = 0.3) fitted by Barker to each set for gamma^inf. Assumes gamma1/gamma2 monotonic — stated on the figure. |
| `f4_13.py` | F4.13 `f4_13_azeotrope_pressure_shift` | The ethanol/water azeotrope moves 0.117 in mole fraction between 15 and 1000 kPa, and vanishes below 6.85 kPa. That gap is pressure-swing distillation. | NRTL fitted at 101.3 kPa and held FIXED as P varies; tau carries no T dependence, so the shift is all Psat1/Psat2(T). Extrapolation band marked. |
| `f4_14.py` | F4.14 `f4_14_bubble_dew_four_calculations` | The four calculations differ only in which two of P, T, x, y are given; two of them need an inner loop, and the iteration counts are counted by running them. | Ideal vapour. Both sections inside the data's 327-362 K range. Answers cross-checked against `vlekit.regress` / `vlekit.flash`. |
| `f4_15.py` | F4.15 `f4_15_gamma_corrections_ladder` | phi-hat and phi^sat are each worth a few per cent and push opposite ways; Poynting is worth 0.17 %. Applying one without the other is worse than applying neither. | Pitzer-Curl / Tsonopoulos B with k12 = 0, applied to associating species — stated on the figure as the limitation it is. |
| `f4_16.py` | F4.16 `f4_16_model_shape_capability` | With both parameters spent on the two infinite-dilution ends, what is left is the functional form: 20 % spread at the peak, and Wilson cannot make a liquid-liquid split at all. | Nothing fitted; ends pinned to a UNIFAC *prediction*. UNIQUAC r, q from groups; NRTL alpha = 0.3. |
| `f4_17.py` | F4.17 `f4_17_gamma_phi_vs_phi_phi` | gamma-phi needs a pure-liquid reference fugacity. At T/Tc = 1.63 there is none, and only phi-phi can reach a mixture critical point where every K goes to one. | Peng-Robinson, 1976 alpha, k12 = 0. No measurement claimed; both curves are calculations, and the figure says so. |
| `f4_18.py` | F4.18 `f4_18_mixing_rules_on_real_data` | Huron-Vidal and Wong-Sandler beat the classical rule by a factor of ten on a real Type 4 binary; Wong-Sandler keeps the quadratic second virial exactly and Huron-Vidal does not. | NRTL fitted by Barker, used only as the G^E input. Peng-Robinson, 1976 alpha. Antoine not used in panel (a) at all. |

| `f4_19.py` | F4.19 `f4_19_ternary_from_binaries` | NRTL and UNIQUAC displaced Margules and van Laar because they give N components from binary parameters alone: acetone + chloroform + 2-butanone at 101.3 kPa, two edges fitted to measurement, one predicted by UNIFAC, no ternary parameter — and an interior no measurement here tests. | tau taken temperature-independent, so the chloroform/2-butanone edge is used 50 K above its data; ideal vapour; alpha = 0.3 assumed. The acetone/2-butanone edge is a UNIFAC **prediction**. No measured ternary datum appears. |
| `f4_20.py` | F4.20 `f4_20_unifac_when_there_is_no_data` | A group prediction costs a factor of two to five against a good fit — and on two of the three systems it is inside the uncertainty the source paper reports. The fit only wins on the variable it was fitted to. | Original VLE UNIFAC (Fredenslund-Jones-Prausnitz, Hansen et al. table), **not** modified UNIFAC (Dortmund). Ideal vapour. End points dropped. |
| `f4_21.py` | F4.21 `f4_21_kvalues_and_relative_volatility` | K_i = gamma_i Psat_i / P and alpha = K1/K2 are the engineering output; taking alpha constant costs 0.09 of a stage on benzene/toluene and 4.1 stages on ethanol/water at x_D = 0.84, and the error grows without bound at the azeotrope. | Phi_i = 1. Psat at the bubble temperature of each composition. Fenske's four assumptions are printed on the figure. |
| `f4_22.py` | F4.22 `f4_22_module_map` | One page from question to number: gamma-phi or phi-phi, data or UNIFAC, consistent or diagnosed, which form against which objective, two components or N. | Nothing computed and nothing measured — a decision map. Every section number is checked against `vle.qmd` and every figure reference against the rendered PNGs before it is drawn. |

## What is computed rather than asserted

- F4.2 — the azeotrope from `vlekit.flash.azeotrope`; the isobaric azeotropic
  temperature by Brent on `azeotrope(T)["P"] - 101.325`.
- F4.3 — the two lobe areas from the same Redlich-Kister fit that `area_test`
  uses internally, so the printed `D` and the printed `A+`, `A-` are consistent.
- F4.5 — every cell of the table is a `TestResult` from
  `consistency.run_all`.
- F4.7 — the fraction of bootstrap replicates inside the linearised 95 %
  ellipse (94.7 %) and the ellipse-to-rectangle area ratio (0.169).
- F4.8 — the fraction of 300 bootstrap refits that predict a liquid-liquid
  split (71 %), each checked with `flash.miscibility_gap`.
- F4.9 — `dT/dx1` from `regress.bubble_T`; the left-hand side from
  `consistency.gibbs_duhem_residual`. Only `H^E` is assumed.
- F4.10 — `max dF/dV` differenced numerically over all three curves
  (-0.126, i.e. negative everywhere).
- F4.11 — the azeotropes (ethanol/water 0.8946, chloroform/2-butanone 0.1907)
  by interpolating `y1 - x1` through zero in the published table, and the
  largest signed departure from the Raoult reference in each panel.
- F4.12 — gamma_1^inf and gamma_2^inf from the fitted NRTL, and the two
  end-point relative volatilities that decide the quadrant. All five systems
  land in the quadrant their own data show.
- F4.13 — the pressure at which the azeotrope disappears, as the root of
  `Psat1/Psat2 = gamma_2^inf` (6.851 kPa, 295.72 K), and the composition
  ceiling at each of the two marked pressures.
- F4.14 — the iteration counts (0, 15, 9, 13 outer x 75 inner), counted by
  the solvers written out in the script, each answer checked against
  `vlekit` to better than 1e-10.
- F4.15 — each rung of Phi_i evaluated from the measured x, y, P, T; nothing
  fitted anywhere in the figure.
- F4.16 — the endpoint match (residual 4e-16 in ln gamma^inf), the chord
  identity for Margules-2 (3e-15), and the Wilson sweep: 0 unstable of 19600
  Lambda pairs, min d2(dg_mix)/dx1^2 = +1.08e-05.
- F4.17 — the mixture critical point located as the collapse of `y1 - x1`
  along a marched bubble trace (x1 = 0.7387, 13.551 MPa).
- F4.18 — the four AADs (21.94, 2.08, 3.97, 1.47 %) and the second-virial
  violation (2.20 % for chloroform/2-butanone, 22.85 % for ethanol/water,
  4e-11 % for Wong-Sandler).
- F4.19 — the two fitted edges (AAD 0.087 K in T on acetone/chloroform, 1.27 %
  in P on chloroform/2-butanone), the UNIFAC infinite-dilution gammas for the
  unmeasured edge (1.0070, 1.0085), the two predicted azeotropes and their node
  types (read off the integrated residue curves, not asserted), and the spread
  between two independent predictions of the interior (mean 0.72 K, max 2.57 K
  in bubble temperature over 55 points).
- F4.20 — every error in the figure, each divided by the uncertainty its own
  source paper reports: UNIFAC 0.93 sigma in P on chloroform/2-butanone, 2.03
  sigma in T on ethanol/water, and the azeotrope at 0.8971 against 0.8946
  measured while the fitted NRTL gives 0.9172.
- F4.21 — K and alpha both from the measured x, y (no model) and from the
  fitted NRTL; the stage counts stepped off one at a time at total reflux
  (7.81 against Fenske's 7.83 for benzene/toluene at x_D = 0.985; 8.58 against
  4.43 for ethanol/water at x_D = 0.844).
- F4.22 — nothing physical. The script checks its own cross-references: seven
  section numbers against `vle.qmd` and sixteen figure references against the
  PNGs on disk, and prints the result.

---

## `verify_worked_examples.py` — the checker for the worked-examples PDF

Not a figure script. It is the verifier for `out/VLE_Worked_Examples.pdf`, the
eight-problem worked-examples document for this module.

```bash
python3 verify_worked_examples.py            # the comparison table
python3 verify_worked_examples.py -v         # plus every intermediate
```

Every numerical answer printed in that PDF is produced twice and the two are
compared: once along the **rounded chain the document actually prints** —
carrying the same intermediates, rounded to the same number of figures a
student would keep on a calculator — and once by `vlekit` at double precision
with no rounding anywhere. The script prints a row per quantity and reports how
many fall outside tolerance.

Current run: **102 comparisons, none outside tolerance.** The largest
disagreements are all in Problem 5, the area test, and for a reason worth
knowing: `D` is a difference between two nearly equal areas, so it loses about
two significant figures to cancellation before it is even formed. The document
says so in the text rather than quietly adjusting the printed digit.

The point of running both chains is that "the hand arithmetic agrees with the
library" is a claim, and a claim about arithmetic should be settled by
arithmetic.
