#!/usr/bin/env python3
"""F4.6  One dataset, three objective functions: the parameters move, and so
        do the predictions.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

n-hexane (1) / methanol (2) at 318.15 K, measured only over x1 = 0.65 to 0.98,
fitted with NRTL (alpha = 0.3) three times: against P (Barker's method),
against y, and against ln gamma. Nothing else changes — same points, same
model, same optimiser.

Panel (a) puts the three parameter pairs next to the 95 % joint confidence
region of the Barker fit, so the size of the *modelling* decision can be read
against the size of the *statistical* uncertainty. Panel (b) evaluates the
three fitted models where there are no data at all, which is where the
disagreement becomes something a designer would act on.

Run:  python3 f4_06.py
"""
import os
import sys

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Ellipse

sys.path.insert(0, "/home/claude/vlekit")
import vlekit as v                                              # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,     # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, use_style)

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_06_objective_functions"

T_SET = 318.15
X_LO, X_HI, NPT = 0.65, 0.98, 9
NOISE = {"y": 0.012, "P": 0.10}
SEED = 5
TRUTH = [2.4, 2.0]                     # Margules-2 used to make the data
OBJ = [("P", NAVY, "o", "Barker: minimise $\\delta P$"),
       ("y", AMBER, "s", "minimise $\\delta y_1$"),
       ("gamma", TEAL, "^", "minimise $\\delta\\ln\\gamma_i$")]
CHI2_95_2DOF = 5.991


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def make():
    c1, c2 = v.component("n-hexane"), v.component("methanol")
    dat = v.generate(v.Margules(TRUTH), np.linspace(X_LO, X_HI, NPT),
                     T=T_SET, c1=c1, c2=c2, noise=NOISE, seed=SEED,
                     label=f"measured only for $x_1$ = {X_LO:g}–{X_HI:g}")
    fits = [v.fit(dat, "nrtl", objective=o) for o, _, _, _ in OBJ]
    return c1, c2, dat, fits


def build(c1, c2, dat, fits):
    use_style()
    fig, (axL, axR) = plt.subplots(1, 2, figsize=(12.6, 5.2))

    # ------------------------------------------------ (a) parameter positions
    axL.grid(True, zorder=0)
    axL.set_axisbelow(True)
    base = fits[0]
    w, V = np.linalg.eigh(base.cov)
    order = np.argsort(w)[::-1]
    w, V = w[order], V[:, order]
    ang = np.degrees(np.arctan2(V[1, 0], V[0, 0]))
    ell = Ellipse(tuple(base.params), 2 * np.sqrt(CHI2_95_2DOF * w[0]),
                  2 * np.sqrt(CHI2_95_2DOF * w[1]), angle=ang,
                  facecolor=SKYBLUE, alpha=0.20, edgecolor=NAVY, lw=1.6,
                  ls="--", zorder=2,
                  label="95 % joint confidence region\nof the Barker fit")
    axL.add_patch(ell)

    for f, (o, col, mk, lab) in zip(fits, OBJ):
        axL.plot(f.params[0], f.params[1], mk, color=col, ms=13, mec=GRAPHITE,
                 mew=1.1, zorder=5, label=f"objective '{o}' — {lab}")
    axL.set_xlabel(base.model.param_labels[0])
    axL.set_ylabel(base.model.param_labels[1])
    P = np.array([f.params for f in fits])
    spread = P.max(axis=0) - P.min(axis=0)
    mx, my = P.mean(axis=0)
    rx = max(1.9 * spread[0], 4.0 * np.sqrt(base.cov[0, 0]))
    ry = max(1.9 * spread[1], 4.0 * np.sqrt(base.cov[1, 1]))
    axL.set_xlim(mx - rx, mx + rx)
    axL.set_ylim(my - 1.05 * ry, my + 1.55 * ry)
    axL.legend(loc="upper left", fontsize=10.5, labelspacing=0.75)
    axL.set_title("(a)  where the three objectives put the parameters",
                  fontsize=13)
    axL.text(0.985, 0.03,
             f"spread across objectives: "
             f"$\\Delta\\tau_{{12}}$ = {spread[0]:.3f}, "
             f"$\\Delta\\tau_{{21}}$ = {spread[1]:.3f}\n"
             f"standard error of the Barker fit alone: "
             f"{base.stderr[0]:.3f}, {base.stderr[1]:.3f}",
             transform=axL.transAxes, ha="right", va="bottom", fontsize=10.5,
             color=INK, linespacing=1.5,
             bbox=dict(boxstyle="round,pad=0.36", fc=PAPER, ec=MIST, lw=1.0,
                       alpha=0.95))

    # -------------------------------------------- (b) predictions off the data
    axR.grid(True, zorder=0)
    axR.set_axisbelow(True)
    xs = np.linspace(1e-6, 1 - 1e-6, 600)
    axR.axvspan(X_LO, X_HI, color=MIST, alpha=0.40, zorder=0)
    ginf = []
    for f, (o, col, mk, lab), ls in zip(fits, OBJ, ("-", "-", "--")):
        lg1, _ = f.model.ln_gamma(xs, T_SET)
        axR.plot(xs, np.exp(lg1), ls, color=col, lw=2.4, zorder=4,
                 label=f"objective '{o}'")
        ginf.append(float(np.exp(f.model.ln_gamma(np.array([1e-9]),
                                                  T_SET)[0][0])))
    g1d, _ = dat.gamma()
    m = dat.interior() & np.isfinite(g1d)
    axR.plot(dat.x1[m], g1d[m], "o", color=INK, mfc=PAPER, mew=1.7, ms=7,
             zorder=6, label="data")
    axR.set_xlabel("$x_1$   (n-hexane)")
    axR.set_ylabel(r"$\gamma_1$")
    axR.set_xlim(0, 1)
    axR.set_ylim(0, 1.30 * max(ginf))
    axR.set_title("(b)  the same three models where nothing was measured",
                  fontsize=13)

    axR.text(0.5 * (X_LO + X_HI), 0.20, f"data cover\n$x_1$ = {X_LO:g}–{X_HI:g}",
             transform=axR.get_xaxis_transform(which="grid"), ha="center",
             va="center", fontsize=10.5, color=SLATE, linespacing=1.45)

    rows = "\n".join(f"'{o}':  $\\gamma_1^\\infty$ = {g:.2f}"
                     for (o, _, _, _), g in zip(OBJ, ginf))
    axR.text(0.985, 0.965,
             "extrapolated to infinite dilution\n" + rows +
             f"\nspread = {100 * (max(ginf) - min(ginf)) / min(ginf):.0f} % "
             "on a quantity\nno measurement here constrains",
             transform=axR.transAxes, ha="right", va="top", fontsize=10.5,
             color=INK, linespacing=1.5,
             bbox=dict(boxstyle="round,pad=0.36", fc=PAPER, ec=MIST, lw=1.0,
                       alpha=0.95))
    axR.legend(loc="upper right", fontsize=11, bbox_to_anchor=(1.0, 0.63))

    fig.suptitle("n-hexane (1) / methanol (2) at 318.15 K, NRTL "
                 r"($\alpha$ = 0.3) — one dataset, three objective functions",
                 fontsize=14, y=1.005)
    fig.tight_layout()
    return fig, ginf


if __name__ == "__main__":
    c1, c2, dat, fits = make()
    print(f"data: n = {dat.n}, x1 = {dat.x1.min():.3f}-{dat.x1.max():.3f}, "
          f"P = {dat.P.min():.2f}-{dat.P.max():.2f} kPa, T = {T_SET} K")
    print(v.objective_table(fits))
    fig, ginf = build(c1, c2, dat, fits)
    for f, g in zip(fits, ginf):
        print(f"objective {f.objective:<6} tau12 = {f.params[0]:+.4f} "
              f"+/- {f.stderr[0]:.4f}   tau21 = {f.params[1]:+.4f} "
              f"+/- {f.stderr[1]:.4f}   gamma1_inf = {g:.3f}")
    P = np.array([f.params for f in fits])
    print("spread across objectives:", np.round(P.max(0) - P.min(0), 4))
    print(f"gamma1_inf spread: {100 * (max(ginf) - min(ginf)) / min(ginf):.1f} %")
    for p in write(fig, SLUG):
        print("wrote", p)
