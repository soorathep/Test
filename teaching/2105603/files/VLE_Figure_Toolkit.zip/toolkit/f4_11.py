#!/usr/bin/env python3
"""F4.11  The four solution types, on four published datasets.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

The classification the course uses is a statement about the sign and the size
of G^E, so it has to be shown on measured mixtures rather than on drawn curves.
Each panel is one of the DOI-cited sets in `vlekit.datasets`:

    Type 1  benzene + toluene          near-ideal, no azeotrope
    Type 2  methanol + water           positive deviation, no azeotrope
    Type 3  ethanol + water            positive deviation, minimum boiling
    Type 4  chloroform + 2-butanone    negative deviation, maximum boiling

The reference line on every panel is Raoult's law with the SAME Antoine
correlations used everywhere else in `vlekit.data.LIBRARY`, so the gap between
the measured points and the line is the whole of the non-ideality and nothing
else. For the three isobaric sets the reference is the bubble temperature that
solves x1 Psat1(T) + x2 Psat2(T) = P; for the one isothermal set it is the
straight line P = x1 Psat1 + x2 Psat2.

Nothing on this figure is fitted. The azeotropic compositions are read out of
the tables by linear interpolation of y1 - x1 through zero — the crossing is a
property of the measurements, not of a model — and the deviation quoted in each
panel is the largest signed departure of the measurement from the Raoult line,
evaluated at the measured compositions.

Run:  python3 f4_11.py
"""
from __future__ import annotations

import os
import sys

import numpy as np
from scipy.optimize import brentq

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib                                                  # noqa: E402
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                    # noqa: E402

from vlekit import datasets as D                                   # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY, PAPER,  # noqa: E402
                          RUST, SKYBLUE, SLATE, TEAL, use_style)

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_11_four_solution_types"

PANELS = [
    ("benzene-toluene", 1, "near-ideal", "no azeotrope", TEAL),
    ("methanol-water", 2, "positive deviation", "no azeotrope", NAVY),
    ("ethanol-water", 3, "positive deviation", "minimum-boiling azeotrope",
     AMBER),
    ("chloroform-butanone", 4, "negative deviation",
     "maximum-boiling azeotrope", RUST),
]


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


# --------------------------------------------------------------------------
def raoult_T(x1, P, c1, c2):
    """Bubble temperature with gamma = 1: the ideal reference for isobaric data."""
    out = np.empty_like(np.atleast_1d(np.asarray(x1, dtype=float)))
    lo = min(c1.Tsat(P), c2.Tsat(P)) - 60.0
    hi = max(c1.Tsat(P), c2.Tsat(P)) + 60.0
    for i, x in enumerate(np.atleast_1d(x1)):
        out[i] = brentq(lambda T: x * c1.Psat(T) + (1 - x) * c2.Psat(T) - P,
                        lo, hi, xtol=1e-10)
    return out


def raoult_P(x1, T, c1, c2):
    """The straight line P = x1 Psat1 + x2 Psat2."""
    x1 = np.asarray(x1, dtype=float)
    return x1 * c1.Psat(T) + (1 - x1) * c2.Psat(T)


def azeotrope_from_data(dat):
    """Every interior sign change of y1 - x1, located by linear interpolation.

    This is a measurement, not a model: no activity coefficient is evaluated.
    Returns a list of dicts, empty when the data never cross y1 = x1.
    """
    d = dat.sorted_by_x()
    f = d.y1 - d.x1
    out = []
    for i in np.where(np.sign(f[:-1]) * np.sign(f[1:]) < 0)[0]:
        t = -f[i] / (f[i + 1] - f[i])
        out.append({"x1": float(d.x1[i] + t * (d.x1[i + 1] - d.x1[i])),
                    "T": float(d.T[i] + t * (d.T[i + 1] - d.T[i])),
                    "P": float(d.P[i] + t * (d.P[i + 1] - d.P[i]))})
    return out


def analyse():
    out = []
    for key, typ, dev, azo, col in PANELS:
        dat = D.load(key)
        xs = np.linspace(0.0, 1.0, 401)
        if dat.kind == "isobaric":
            P = float(np.mean(dat.P))
            ref = raoult_T(xs, P, dat.c1, dat.c2)
            ref_at = raoult_T(dat.x1, P, dat.c1, dat.c2)
            resid = dat.T - ref_at                    # K, signed
            unit, sym = "K", r"$T$ / K"
            meas = dat.T
        else:
            T = float(np.mean(dat.T))
            ref = raoult_P(xs, T, dat.c1, dat.c2)
            ref_at = raoult_P(dat.x1, T, dat.c1, dat.c2)
            resid = 100.0 * (dat.P - ref_at) / ref_at  # per cent, signed
            unit, sym = "%", r"$P$ / kPa"
            meas = dat.P
        j = int(np.nanargmax(np.abs(resid)))
        g1, g2 = dat.gamma()
        m = dat.interior() & np.isfinite(g1) & np.isfinite(g2)
        out.append(dict(key=key, typ=typ, dev=dev, azo=azo, col=col, dat=dat,
                        xs=xs, ref=ref, meas=meas, ylabel=sym, unit=unit,
                        worst=float(resid[j]), worst_x=float(dat.x1[j]),
                        az=azeotrope_from_data(dat),
                        g1lo=float(np.min(g1[m])), g1hi=float(np.max(g1[m])),
                        g2lo=float(np.min(g2[m])), g2hi=float(np.max(g2[m])),
                        doi=D.DOIS[key]))
    return out


# --------------------------------------------------------------------------
class Placer:
    """A coarse occupancy grid over one axes, used to place labels.

    A previous figure in this course had to be redone because two annotations
    collided, so no label position on this figure is typed in. Everything that
    is drawn is marked on a grid first; each label then takes the emptiest
    rectangle of the size it needs and marks that rectangle occupied, so the
    second label cannot land on the first.
    """

    def __init__(self, ax, nx=48, ny=32):
        self.ax, self.nx, self.ny = ax, nx, ny
        self.g = np.zeros((ny, nx))

    def _cells(self, x, y):
        x0, x1 = self.ax.get_xlim()
        y0, y1 = self.ax.get_ylim()
        fx = (np.asarray(x, dtype=float) - x0) / (x1 - x0)
        fy = (np.asarray(y, dtype=float) - y0) / (y1 - y0)
        i = np.clip((fy * self.ny).astype(int), 0, self.ny - 1)
        j = np.clip((fx * self.nx).astype(int), 0, self.nx - 1)
        return i, j

    def occupy(self, x, y, pad=1):
        i, j = self._cells(x, y)
        for a, b in zip(i, j):
            self.g[max(0, a - pad):a + pad + 1,
                   max(0, b - pad):b + pad + 1] += 1.0

    def place(self, w, h, margin=0.015):
        """Lower-left corner, in axes fraction, of the emptiest w-by-h box."""
        cw, ch = max(1, int(round(w * self.nx))), max(1, int(round(h * self.ny)))
        m = max(1, int(round(margin * self.nx)))
        best, score = (margin, 1.0 - h - margin), None
        for i in range(m, self.ny - ch - m + 1):
            for j in range(m, self.nx - cw - m + 1):
                s = float(self.g[i:i + ch, j:j + cw].sum())
                # break ties towards the top of the panel, which reads better
                s += 1e-4 * (self.ny - i)   # gentle tie-break towards the top
                if score is None or s < score:
                    score, best = s, (j / self.nx, i / self.ny)
                    self._best_cells = (i, j, ch, cw)
        i, j, ch, cw = self._best_cells
        # mark one cell wider than the box so the next label cannot abut it
        self.g[max(0, i - 1):i + ch + 1, max(0, j - 1):j + cw + 1] += 50.0
        return best


def build(res):
    use_style()
    fig, axes = plt.subplots(2, 2, figsize=(13.6, 8.0))

    for ax, r in zip(axes.ravel(), res):
        d = r["dat"]
        ax.grid(True, zorder=0)
        ax.set_axisbelow(True)
        ax.plot(r["xs"], r["ref"], "--", color=SLATE, lw=1.8, zorder=2,
                label="Raoult's law ($\\gamma_i = 1$)")
        ax.plot(d.x1, r["meas"], "o", color=r["col"], mfc=PAPER, mew=1.7,
                ms=6.5, zorder=4, label="measured, bubble ($x_1$)")
        ax.plot(d.y1, r["meas"], "s", color=GRAPHITE, mfc=PAPER, mew=1.3,
                ms=5.2, zorder=3, label="measured, dew ($y_1$)")

        ax.set_xlim(-0.02, 1.02)
        ally = np.concatenate([r["meas"], r["ref"]])
        lo, hi = float(np.min(ally)), float(np.max(ally))
        pad = 0.09 * (hi - lo)
        ax.set_ylim(lo - pad, hi + 2.4 * pad)

        pl = Placer(ax)
        pl.occupy(np.concatenate([d.x1, d.y1, r["xs"]]),
                  np.concatenate([r["meas"], r["meas"], r["ref"]]))

        sgn = "+" if r["worst"] > 0 else "−"
        bw, bh = 0.64, 0.19
        fx, fy = pl.place(bw, bh)
        ax.text(fx + 0.012, fy + 0.5 * bh,
                f"$\\gamma_1$ = {r['g1lo']:.3f}–{r['g1hi']:.3f},   "
                f"$\\gamma_2$ = {r['g2lo']:.3f}–{r['g2hi']:.3f}\n"
                f"largest departure from Raoult: {sgn}"
                f"{abs(r['worst']):.2f} {r['unit']} at $x_1$ = "
                f"{r['worst_x']:.3f}",
                transform=ax.transAxes, ha="left", va="center", fontsize=9.6,
                color=GRAPHITE, linespacing=1.5, zorder=8,
                bbox=dict(boxstyle="round,pad=0.28", fc=PAPER, ec=MIST,
                          lw=0.9, alpha=0.93))

        for a in r["az"]:
            yv = a["T"] if d.kind == "isobaric" else a["P"]
            ax.plot([a["x1"]], [yv], "D", color=AMBER, ms=9, mec=GRAPHITE,
                    mew=1.1, zorder=6)
            aw, ah = 0.35, 0.19
            fx, fy = pl.place(aw, ah)
            ax.annotate(f"azeotrope\n$x_1 = y_1 = {a['x1']:.4f}$",
                        xy=(a["x1"], yv), xycoords="data",
                        xytext=(fx + 0.5 * aw, fy + 0.5 * ah),
                        textcoords="axes fraction", ha="center", va="center",
                        fontsize=9.8, color=INK, linespacing=1.35, zorder=7,
                        bbox=dict(boxstyle="round,pad=0.26", fc=PAPER,
                                  ec=AMBER, lw=1.0, alpha=0.93),
                        arrowprops=dict(arrowstyle="-", color=AMBER, lw=1.1,
                                        shrinkA=3, shrinkB=6))

        cond = (f"isobaric, $P$ = {float(np.mean(d.P)):g} kPa"
                if d.kind == "isobaric"
                else f"isothermal, $T$ = {float(np.mean(d.T)):g} K")
        ax.set_title(f"Type {r['typ']} — {r['dev']}, {r['azo']}",
                     fontsize=12.6, color=r["col"], pad=7)
        ax.set_xlabel(f"$x_1$,  $y_1$   ({d.c1.name})", labelpad=2)
        ax.set_ylabel(r["ylabel"])
        ax.text(0.5, -0.245,
                f"{d.c1.name} (1) + {d.c2.name} (2), {cond}, {len(d)} points\n"
                f"doi:{r['doi']}",
                transform=ax.transAxes, ha="center", va="top", fontsize=9.4,
                color=SLATE, linespacing=1.45)

    h, lab = axes[0, 0].get_legend_handles_labels()
    fig.legend(h, lab, loc="upper center", bbox_to_anchor=(0.5, 0.945),
               ncol=3, fontsize=11.5, frameon=False)
    fig.suptitle("The four solution types, on four published datasets — "
                 "the dashed line is Raoult's law with the same Antoine "
                 "constants throughout",
                 fontsize=14.6, y=0.995)
    fig.tight_layout(rect=(0, 0.0, 1, 0.905))
    fig.subplots_adjust(hspace=0.55)
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    res = analyse()
    for r in res:
        d = r["dat"]
        print(f"Type {r['typ']}  {d.label}   doi:{r['doi']}")
        print(f"    n = {len(d):2d}   gamma1 {r['g1lo']:.4f}-{r['g1hi']:.4f}   "
              f"gamma2 {r['g2lo']:.4f}-{r['g2hi']:.4f}   (modified Raoult, "
              f"ideal vapour)")
        print(f"    largest signed departure from the Raoult reference: "
              f"{r['worst']:+.3f} {r['unit']} at x1 = {r['worst_x']:.4f}")
        if r["az"]:
            for a in r["az"]:
                print(f"    azeotrope from the table (linear interpolation of "
                      f"y1 - x1 through zero): x1 = {a['x1']:.4f}, "
                      f"T = {a['T']:.2f} K, P = {a['P']:.2f} kPa")
        else:
            print("    no interior crossing of y1 = x1: no azeotrope")
    for p in write(build(res), SLUG):
        print("wrote", p)
