#!/usr/bin/env python3
"""F4.11  The four solution types, on five published datasets.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

The classification the course uses is a statement about the sign and the size
of G^E, so it has to be shown on measured mixtures rather than on drawn curves.
Each panel is one of the DOI-cited sets in `vlekit.datasets`:

    Type 1  ideal solution          benzene + toluene
    Type 2  positive deviation      ethanol + water, minimum-boiling azeotrope
    Type 3  negative deviation      chloroform + 2-butanone, maximum-boiling
    Type 4  VLLE                    1-butanol + water, heteroazeotrope

and the fifth panel is not a type at all. Methanol + water deviates positively
and has NO azeotrope. It is on the figure because "positive deviation implies
an azeotrope" is the commonest error students make here, and because a
criterion with nothing to reject is not a criterion.

The reference line on every panel is Raoult's law with the SAME Antoine
correlations used everywhere else in `vlekit.data.LIBRARY`, so the gap between
the measured points and the line is the whole of the non-ideality and nothing
else. For the four isobaric sets the reference is the bubble temperature that
solves x1 Psat1(T) + x2 Psat2(T) = P; for the one isothermal set it is the
straight line P = x1 Psat1 + x2 Psat2.

Nothing on this figure is fitted. The azeotropic compositions are read out of
the tables by linear interpolation of y1 - x1 through zero — the crossing is a
property of the measurements, not of a model — and the deviation quoted in each
panel is the largest signed departure of the measurement from the Raoult line,
evaluated at the measured compositions.

THE TYPE 4 PANEL NEEDS ONE EXTRA RULE. 1-butanol + water has a liquid-liquid
miscibility gap: its table jumps from x1 = 0.009 to x1 = 0.558 because no
single liquid phase exists in between. Interpolating y1 - x1 across that hole
returns a "crossing" at x1 = 0.2121 that is pure fiction — there is no liquid
there to be in equilibrium with anything. So on that panel the interpolated
crossing is DISCARDED if it falls inside the gap, the two liquid branches are
drawn as two separate curves, and what is marked instead is the
heteroazeotrope: the three-phase state in which one vapour is in equilibrium
with two liquids at once, whose composition equals the OVERALL liquid
composition and not either phase's. The flat three-phase tie line is drawn at
the measured three-phase temperature between the two conjugate liquids.

Deciding how many liquid phases there are is a stability question, and this
module does not have the tool for it. Module 5 does.

Run:  python3 f4_11.py
"""
from __future__ import annotations

import os
import sys

import numpy as np
from scipy.optimize import brentq

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib                                                  # noqa: E402
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                    # noqa: E402

from vlekit import datasets as D                                   # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY, PAPER,  # noqa: E402
                          RUST, SKYBLUE, SLATE, TEAL, use_style)

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_11_four_solution_types"

# key, heading, subheading, colour, is-a-type-or-a-counterexample
PANELS = [
    ("benzene-toluene", "Type 1 — ideal solution",
     "$\\gamma_i \\approx 1$, no azeotrope", TEAL, True),
    ("ethanol-water", "Type 2 — positive deviation",
     "minimum-boiling azeotrope", AMBER, True),
    ("chloroform-butanone", "Type 3 — negative deviation",
     "maximum-boiling azeotrope", RUST, True),
    ("butanol-water", "Type 4 — VLLE",
     "partial miscibility, heteroazeotrope", NAVY, True),
    ("methanol-water", "NOT A TYPE — counterexample",
     "positive deviation, NO azeotrope", SKYBLUE, False),
]


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


# --------------------------------------------------------------------------
def raoult_T(x1, P, c1, c2):
    """Bubble temperature with gamma = 1: the ideal reference for isobaric data."""
    out = np.empty_like(np.atleast_1d(np.asarray(x1, dtype=float)))
    lo = min(c1.Tsat(P), c2.Tsat(P)) - 60.0
    hi = max(c1.Tsat(P), c2.Tsat(P)) + 60.0
    for i, x in enumerate(np.atleast_1d(x1)):
        out[i] = brentq(lambda T: x * c1.Psat(T) + (1 - x) * c2.Psat(T) - P,
                        lo, hi, xtol=1e-10)
    return out


def raoult_P(x1, T, c1, c2):
    """The straight line P = x1 Psat1 + x2 Psat2."""
    x1 = np.asarray(x1, dtype=float)
    return x1 * c1.Psat(T) + (1 - x1) * c2.Psat(T)


def azeotrope_from_data(dat, gap=None):
    """Every interior sign change of y1 - x1, located by linear interpolation.

    This is a measurement, not a model: no activity coefficient is evaluated.
    `gap` is the (lo, hi) miscibility gap of a partially miscible set; a
    crossing inside it is an artefact of interpolating across a composition
    range in which no liquid exists, and is returned separately so that the
    figure can say so rather than draw it.
    """
    d = dat.sorted_by_x()
    f = d.y1 - d.x1
    real, fake = [], []
    for i in np.where(np.sign(f[:-1]) * np.sign(f[1:]) < 0)[0]:
        t = -f[i] / (f[i + 1] - f[i])
        a = {"x1": float(d.x1[i] + t * (d.x1[i + 1] - d.x1[i])),
             "T": float(d.T[i] + t * (d.T[i + 1] - d.T[i])),
             "P": float(d.P[i] + t * (d.P[i + 1] - d.P[i]))}
        if gap is not None and gap[0] < a["x1"] < gap[1]:
            fake.append(a)
        else:
            real.append(a)
    return real, fake


def branches(dat, gap):
    """Split a partially miscible table into its two homogeneous branches."""
    d = dat.sorted_by_x()
    lo = d.x1 <= gap[0] + 1e-9
    hi = d.x1 >= gap[1] - 1e-9
    return (d.x1[lo], d.T[lo], d.y1[lo]), (d.x1[hi], d.T[hi], d.y1[hi])


def analyse():
    out = []
    for key, head, sub, col, is_type in PANELS:
        dat = D.load(key)
        vlle = D.butanol_water_vlle() if key == "butanol-water" else None
        gap = vlle["gap"] if vlle else None
        xs = np.linspace(0.0, 1.0, 401)
        if dat.kind == "isobaric":
            P = float(np.mean(dat.P))
            ref = raoult_T(xs, P, dat.c1, dat.c2)
            ref_at = raoult_T(dat.x1, P, dat.c1, dat.c2)
            resid = dat.T - ref_at                     # K, signed
            unit, sym = "K", r"$T$ / K"
            meas = dat.T
        else:
            T = float(np.mean(dat.T))
            ref = raoult_P(xs, T, dat.c1, dat.c2)
            ref_at = raoult_P(dat.x1, T, dat.c1, dat.c2)
            resid = 100.0 * (dat.P - ref_at) / ref_at  # per cent, signed
            unit, sym = "%", r"$P$ / kPa"
            meas = dat.P
        j = int(np.nanargmax(np.abs(resid)))
        g1, g2 = dat.gamma()
        m = dat.interior() & np.isfinite(g1) & np.isfinite(g2)
        az, fake = azeotrope_from_data(dat, gap)

        # The azeotrope criterion, point by point, from the same measurements:
        #   alpha_12 = gamma_1 Psat_1 / (gamma_2 Psat_2),  an azeotrope is
        #   alpha_12 = 1, so the gamma_2 that WOULD be needed at each measured
        #   composition is gamma_1 Psat_1 / Psat_2 and the shortfall factor is
        #   exactly alpha_12 itself. Computed here, beside gamma, so that the
        #   overview figure and the per-type slides cannot disagree about it.
        Ps1, Ps2 = dat.c1.Psat(dat.T), dat.c2.Psat(dat.T)
        with np.errstate(divide="ignore", invalid="ignore"):
            alpha12 = g1 * Ps1 / (g2 * Ps2)
            g2_req = g1 * Ps1 / Ps2
        k = int(np.nanargmin(np.where(m, alpha12, np.nan)))

        out.append(dict(key=key, head=head, sub=sub, col=col, dat=dat,
                        is_type=is_type, xs=xs, ref=ref, meas=meas,
                        ylabel=sym, unit=unit,
                        worst=float(resid[j]), worst_x=float(dat.x1[j]),
                        az=az, fake=fake, vlle=vlle, gap=gap,
                        br=branches(dat, gap) if gap else None,
                        g1=g1, g2=g2, gmask=m, Ps1=Ps1, Ps2=Ps2,
                        alpha12=alpha12, g2_req=g2_req,
                        amin=float(alpha12[k]), amin_x=float(dat.x1[k]),
                        amin_g2=float(g2[k]), amin_g2req=float(g2_req[k]),
                        g1lo=float(np.min(g1[m])), g1hi=float(np.max(g1[m])),
                        g2lo=float(np.min(g2[m])), g2hi=float(np.max(g2[m])),
                        doi=D.DOIS[key]))
    return out


# --------------------------------------------------------------------------
class Placer:
    """A coarse occupancy grid over one axes, used to place labels.

    A previous figure in this course had to be redone because two annotations
    collided, so no label position on this figure is typed in. Everything that
    is drawn is marked on a grid first; each label then takes the emptiest
    rectangle of the size it needs and marks that rectangle occupied, so the
    second label cannot land on the first.
    """

    def __init__(self, ax, nx=48, ny=32):
        self.ax, self.nx, self.ny = ax, nx, ny
        self.g = np.zeros((ny, nx))

    def _cells(self, x, y):
        x0, x1 = self.ax.get_xlim()
        y0, y1 = self.ax.get_ylim()
        fx = (np.asarray(x, dtype=float) - x0) / (x1 - x0)
        fy = (np.asarray(y, dtype=float) - y0) / (y1 - y0)
        i = np.clip((fy * self.ny).astype(int), 0, self.ny - 1)
        j = np.clip((fx * self.nx).astype(int), 0, self.nx - 1)
        return i, j

    def occupy(self, x, y, pad=1):
        i, j = self._cells(x, y)
        for a, b in zip(i, j):
            self.g[max(0, a - pad):a + pad + 1,
                   max(0, b - pad):b + pad + 1] += 1.0

    def place(self, w, h, margin=0.015):
        """Lower-left corner, in axes fraction, of the emptiest w-by-h box."""
        cw, ch = max(1, int(round(w * self.nx))), max(1, int(round(h * self.ny)))
        m = max(1, int(round(margin * self.nx)))
        best, score = (margin, 1.0 - h - margin), None
        for i in range(m, self.ny - ch - m + 1):
            for j in range(m, self.nx - cw - m + 1):
                s = float(self.g[i:i + ch, j:j + cw].sum())
                # break ties towards the top of the panel, which reads better
                s += 1e-4 * (self.ny - i)
                if score is None or s < score:
                    score, best = s, (j / self.nx, i / self.ny)
                    self._best_cells = (i, j, ch, cw)
        i, j, ch, cw = self._best_cells
        # mark one cell wider than the box so the next label cannot abut it
        self.g[max(0, i - 1):i + ch + 1, max(0, j - 1):j + cw + 1] += 50.0
        return best


def build(res):
    use_style()
    fig, axes = plt.subplots(2, 3, figsize=(16.4, 9.4))
    flat = list(axes.ravel())

    for ax, r in zip(flat, res):
        d = r["dat"]
        ax.grid(True, zorder=0)
        ax.set_axisbelow(True)
        ax.plot(r["xs"], r["ref"], "--", color=SLATE, lw=1.8, zorder=2,
                label="Raoult's law ($\\gamma_i = 1$)")

        if r["gap"] is not None:
            # two homogeneous liquid branches, drawn as two curves so that the
            # hole between them is impossible to mistake for missing data
            for (bx, bT, _by) in r["br"]:
                ax.plot(bx, bT, "-", color=r["col"], lw=1.7, zorder=3,
                        alpha=0.85)

        ax.plot(d.x1, r["meas"], "o", color=r["col"], mfc=PAPER, mew=1.7,
                ms=6.0, zorder=5, label="measured, bubble ($x_1$)")
        ax.plot(d.y1, r["meas"], "s", color=GRAPHITE, mfc=PAPER, mew=1.3,
                ms=4.8, zorder=4, label="measured, dew ($y_1$)")

        ax.set_xlim(-0.02, 1.02)
        ally = np.concatenate([r["meas"], r["ref"]])
        lo, hi = float(np.min(ally)), float(np.max(ally))
        pad = 0.09 * (hi - lo)
        # the VLLE panel needs a strip of clear space below the three-phase
        # line to label the two-liquid region without touching the axis
        ax.set_ylim(lo - (1.8 if r["vlle"] is not None else 1.0) * pad,
                    hi + 1.9 * pad)

        pl = Placer(ax)
        pl.occupy(np.concatenate([d.x1, d.y1, r["xs"]]),
                  np.concatenate([r["meas"], r["meas"], r["ref"]]))

        # ---------------------------------------------------- the VLLE extras
        v = r["vlle"]
        if v is not None:
            xa, xo, T3 = v["x1_aq"], v["x1_org"], v["T"]
            ylo, yhi = ax.get_ylim()
            # the two-liquid region lies BELOW the three-phase line, so the
            # shading must stop exactly at it
            ax.axvspan(xa, xo, ymin=0.0, ymax=(T3 - ylo) / (yhi - ylo),
                       color=MIST, alpha=0.45, zorder=1)
            ax.plot([xa, xo], [T3, T3], "-", color=INK, lw=3.0, zorder=6,
                    solid_capstyle="butt",
                    label="three-phase line (VLLE)")
            ax.plot([xa, xo], [T3, T3], "|", color=INK, ms=11, mew=2.0,
                    zorder=6)
            ax.plot([v["y1"]], [T3], "D", color=AMBER, ms=9.5, mec=GRAPHITE,
                    mew=1.1, zorder=8)
            pl.occupy(np.linspace(xa, xo, 40), np.full(40, T3), pad=1)

            aw, ah = 0.50, 0.115
            fx, fy = pl.place(aw, ah)
            ax.annotate(
                f"heteroazeotrope\n$y_1$ = {v['y1']:.3f},  $T$ = {T3:.2f} K",
                xy=(v["y1"], T3), xycoords="data",
                xytext=(fx + 0.5 * aw, fy + 0.5 * ah),
                textcoords="axes fraction", ha="center", va="center",
                fontsize=9.0, color=INK, linespacing=1.3, zorder=9,
                bbox=dict(boxstyle="round,pad=0.24", fc=PAPER, ec=AMBER,
                          lw=1.0, alpha=0.94),
                arrowprops=dict(arrowstyle="-", color=AMBER, lw=1.1,
                                shrinkA=3, shrinkB=6))
            ax.text(0.5 * (xa + xo), T3 - 0.075 * (yhi - ylo),
                    "two liquid phases", ha="center", va="center",
                    fontsize=9.0, color=SLATE, zorder=7)
            pl.occupy(np.linspace(xa, xo, 40),
                      np.full(40, T3 - 0.075 * (yhi - ylo)), pad=1)

        # ------------------------------------------------- the azeotrope
        for a in r["az"]:
            yv = a["T"] if d.kind == "isobaric" else a["P"]
            ax.plot([a["x1"]], [yv], "D", color=AMBER, ms=9, mec=GRAPHITE,
                    mew=1.1, zorder=7)
            aw, ah = 0.42, 0.115
            fx, fy = pl.place(aw, ah)
            ax.annotate(f"azeotrope\n$x_1 = y_1 = {a['x1']:.4f}$",
                        xy=(a["x1"], yv), xycoords="data",
                        xytext=(fx + 0.5 * aw, fy + 0.5 * ah),
                        textcoords="axes fraction", ha="center", va="center",
                        fontsize=9.2, color=INK, linespacing=1.3, zorder=9,
                        bbox=dict(boxstyle="round,pad=0.24", fc=PAPER,
                                  ec=AMBER, lw=1.0, alpha=0.93),
                        arrowprops=dict(arrowstyle="-", color=AMBER, lw=1.1,
                                        shrinkA=3, shrinkB=6))

        if not r["az"] and r["vlle"] is None:
            nw, nh = 0.50, 0.115
            fx, fy = pl.place(nw, nh)
            ax.text(fx + 0.5 * nw, fy + 0.5 * nh,
                    "$y_1 > x_1$ everywhere:\nno crossing, no azeotrope",
                    transform=ax.transAxes, ha="center", va="center",
                    fontsize=9.0, color=r["col"], linespacing=1.3, zorder=9,
                    bbox=dict(boxstyle="round,pad=0.22", fc=PAPER,
                              ec=r["col"], lw=1.0, alpha=0.93))

        cond = (f"isobaric, $P$ = {float(np.mean(d.P)):g} kPa"
                if d.kind == "isobaric"
                else f"isothermal, $T$ = {float(np.mean(d.T)):g} K")
        ax.set_title(r["head"] + "\n" + r["sub"], fontsize=11.4,
                     color=r["col"] if r["is_type"] else "#1F6F78", pad=6,
                     linespacing=1.35,
                     fontweight="bold" if not r["is_type"] else "normal")
        ax.set_xlabel(f"$x_1$,  $y_1$   ({d.c1.name})", labelpad=2)
        ax.set_ylabel(r["ylabel"])

        # The numbers live UNDER the axes, where there is guaranteed room. On a
        # three-column figure there is not enough clear space inside a panel for
        # a four-line box as well as an annotation, and a box that has to be
        # squeezed in is a box that will one day collide.
        sgn = "+" if r["worst"] > 0 else "−"
        extra = ""
        if r["vlle"] is not None:
            extra = (f"\nconjugate liquids $x_1$ = {r['vlle']['x1_aq']:.4f} "
                     f"and {r['vlle']['x1_org']:.4f}; gap "
                     f"{r['gap'][0]:g}–{r['gap'][1]:g}")
        ax.text(0.5, -0.30,
                f"{d.c1.name} (1) + {d.c2.name} (2), {cond}, {len(d)} points\n"
                f"$\\gamma_1$ = {r['g1lo']:.3f}–{r['g1hi']:.3f},   "
                f"$\\gamma_2$ = {r['g2lo']:.3f}–{r['g2hi']:.3f}\n"
                f"largest departure from Raoult: {sgn}"
                f"{abs(r['worst']):.2f} {r['unit']} at $x_1$ = "
                f"{r['worst_x']:.3f}{extra}\n"
                f"doi:{r['doi']}",
                transform=ax.transAxes, ha="center", va="top", fontsize=9.3,
                color=SLATE, linespacing=1.42)

    # ------------------------------------------------------- the sixth panel
    ax = flat[5]
    ax.set_axis_off()
    v = D.butanol_water_vlle()
    ax.text(0.02, 0.98,
            "How to read these five panels",
            transform=ax.transAxes, ha="left", va="top", fontsize=12.6,
            color=INK)
    ax.text(0.02, 0.885,
            "The dashed line on every panel is Raoult's law, evaluated with the\n"
            "same Antoine constants as the data. Everything between the points\n"
            "and that line is $G^E$, and nothing else.\n\n"
            "$\\bullet$  Type 1 sits on the line.\n"
            "$\\bullet$  Types 2 and 4 sit below it (isobaric) — $\\gamma_i > 1$.\n"
            "$\\bullet$  Type 3 sits above the line in $T$, below it in $P$ — "
            "$\\gamma_i < 1$.\n"
            "$\\bullet$  An azeotrope is where $y_1 - x_1$ changes sign. It is a\n"
            "     consequence of the size of $G^E$, not a fifth category.\n\n"
            "The counterexample is the point of the fifth panel: methanol +\n"
            "water deviates positively, $\\gamma_1$ reaches 2.17, and it still has\n"
            "no azeotrope. Positive deviation does NOT imply an azeotrope.\n\n"
            "TYPE 4 IS A DIFFERENT QUESTION. Whether one liquid phase or two\n"
            f"is a matter of stability, not of azeotropy. The flat line at "
            f"{v['T']:.2f} K\n"
            "on the Type 4 panel is a three-phase invariant: two liquids and\n"
            "one vapour, all fixed in composition. Reading an azeotrope off it\n"
            "by interpolating across the gap gives $x_1$ = 0.2121, which is\n"
            "fiction — there is no liquid at that composition.\n\n"
            "VLLE IS TREATED PROPERLY IN MODULE 5, where the tangent-plane\n"
            "criterion decides how many phases there are before any of this is\n"
            "attempted. Module 4 can only show that the split is there.",
            transform=ax.transAxes, ha="left", va="top", fontsize=9.5,
            color=GRAPHITE, linespacing=1.40)

    h, lab = flat[3].get_legend_handles_labels()
    h0, lab0 = flat[0].get_legend_handles_labels()
    seen, hh, ll = set(), [], []
    for a, b in list(zip(h0, lab0)) + list(zip(h, lab)):
        if b not in seen:
            seen.add(b)
            hh.append(a)
            ll.append(b)
    fig.legend(hh, ll, loc="upper center", bbox_to_anchor=(0.5, 0.952),
               ncol=4, fontsize=11.0, frameon=False)
    fig.suptitle("The four solution types, on five published datasets — "
                 "the dashed line is Raoult's law with the same Antoine "
                 "constants throughout",
                 fontsize=14.4, y=0.996)
    fig.tight_layout(rect=(0, 0.0, 1, 0.905))
    fig.subplots_adjust(hspace=1.02, wspace=0.30)
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    res = analyse()
    for r in res:
        d = r["dat"]
        kind = "TYPE" if r["is_type"] else "COUNTEREXAMPLE"
        print(f"{kind}: {r['head']} — {d.label}   doi:{r['doi']}")
        print(f"    n = {len(d):2d}   gamma1 {r['g1lo']:.4f}-{r['g1hi']:.4f}   "
              f"gamma2 {r['g2lo']:.4f}-{r['g2hi']:.4f}   (modified Raoult, "
              f"ideal vapour)")
        print(f"    largest signed departure from the Raoult reference: "
              f"{r['worst']:+.3f} {r['unit']} at x1 = {r['worst_x']:.4f}")
        if r["az"]:
            for a in r["az"]:
                print(f"    azeotrope from the table (linear interpolation of "
                      f"y1 - x1 through zero): x1 = {a['x1']:.4f}, "
                      f"T = {a['T']:.2f} K, P = {a['P']:.2f} kPa")
        elif r["vlle"] is None:
            print("    no interior crossing of y1 = x1: no azeotrope")
            print(f"      closest approach to the criterion: alpha_12 = "
                  f"{r['amin']:.4f} at x1 = {r['amin_x']:.4f} — gamma_2 would "
                  f"have to reach {r['amin_g2req']:.4f} there and it is "
                  f"{r['amin_g2']:.4f}")
        for a in r["fake"]:
            print(f"    DISCARDED spurious crossing at x1 = {a['x1']:.4f}: it "
                  f"lies inside the miscibility gap {r['gap']}, where no "
                  f"liquid phase exists")
        v = r["vlle"]
        if v is not None:
            print(f"    three-phase (VLLE) state at {v['P']:g} kPa: "
                  f"T = {v['T']:.2f} K, heteroazeotropic vapour y1 = "
                  f"{v['y1']:.4f}")
            print(f"      conjugate liquids x1 = {v['x1_aq']:.4f} (water-rich) "
                  f"and {v['x1_org']:.4f} (1-butanol-rich); tie line spans "
                  f"{v['x1_org'] - v['x1_aq']:.4f} in x1")
            print(f"      measured hole in the table: x1 from {v['gap'][0]:g} "
                  f"to {v['gap'][1]:g}")
            for doi, T3, y1, xa, xo in v["independent"]:
                yy = "   —  " if y1 is None else f"{y1:.4f}"
                print(f"      independent check doi:{doi:28s} T3 = {T3:.2f} K, "
                      f"y1 = {yy}, x1 = {xa:.4f} / {xo:.4f}")
    print()
    print("Module 5 note printed on the figure: VLLE is treated properly in "
          "Module 5; Module 4 can only show that the split is there.")
    for p in write(build(res), SLUG):
        print("wrote", p)
