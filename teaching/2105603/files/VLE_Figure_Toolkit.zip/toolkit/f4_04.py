#!/usr/bin/env python3
"""F4.4  Point-test residuals for a consistent and an inconsistent set,
        on one pair of axes.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

Both datasets are made with `vlekit.regress.generate` from the *same* NRTL
model at the same conditions. The only difference is that one of them has a
systematic bias added to y1 of the form  b x1 x2  with b = 0.30; everything
else — scatter, seed, composition grid — is identical. Putting the two residual
series on one axis is the whole point: separately they both look like "some
scatter about zero", and only the common scale shows that one is twenty times
the other.

The residual is delta y1 = y1(Barker fit to P-x only) - y1(measured). The fit
never saw y, so this is a prediction, not a fit residual.

Run:  python3 f4_04.py
"""
import os
import sys

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, "/home/claude/vlekit")
import vlekit as v                                              # noqa: E402
from vlekit.consistency import point_test                       # noqa: E402
from vlekit.plots import (GRAPHITE, INK, MIST, NAVY, PAPER,     # noqa: E402
                          RUST, SLATE, TEAL, newfig)

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_04_point_test_residuals"

TRUE = [0.35, 0.62]
T_SET = 328.15
BIAS = 0.30
THRESH = 0.01           # Van Ness-Byer-Gibbs acceptance band on mean |dy1|


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def build():
    c1, c2 = v.component("2-propanol"), v.component("mek")
    truth = v.NRTL(TRUE)
    x = np.linspace(0.02, 0.98, 21)
    base = {"y": 0.002, "P": 0.05}

    good = v.generate(truth, x, T=T_SET, c1=c1, c2=c2, label="no bias",
                      noise=base, seed=3)
    bad = v.generate(truth, x, T=T_SET, c1=c1, c2=c2,
                     label=f"bias $\\delta y_1 = {BIAS:g}\\,x_1x_2$",
                     noise={**base, "y_bias": BIAS}, seed=3)

    out = []
    for d in (good, bad):
        f = v.barker_fit(d, "nrtl")
        out.append((d, f, point_test(d, fit=f)))

    fig, ax = newfig(8.0, 5.2)
    ax.axhspan(-THRESH, THRESH, color=MIST, alpha=0.45, zorder=0,
               label=f"$\\pm${THRESH:g} acceptance band on $|\\delta y_1|$")
    ax.axhline(0.0, color=GRAPHITE, lw=1.2, zorder=2)

    styles = [(TEAL, "o", "-"), (RUST, "s", "--")]
    for (d, f, t), (col, mk, ls) in zip(out, styles):
        dy = f.y1_calc - d.y1
        ax.plot(d.x1, dy, mk, ls=ls, color=col, mfc=PAPER, mew=1.8, lw=1.8,
                ms=7, zorder=4,
                label=f"{d.label}: mean $|\\delta y_1|$ = {t.statistic:.4f}, "
                      f"index {t.index}")

    ax.set_xlabel("$x_1$")
    ax.set_ylabel(r"$\delta y_1 = y_1^{\rm calc} - y_1^{\rm exp}$")
    ax.set_xlim(0, 1)

    allr = np.concatenate([f.y1_calc - d.y1 for d, f, _ in out])
    dlo = min(float(np.min(allr)), -THRESH)
    dhi = max(float(np.max(allr)), THRESH)
    span = dhi - dlo
    ax.set_ylim(dlo - 0.10 * span, dhi + 0.62 * span)

    ax.legend(loc="upper center", fontsize=11.5, ncol=1,
              bbox_to_anchor=(0.52, 1.010))
    ax.set_title("Point test (Van Ness-Byer-Gibbs): one experiment, with and "
                 "without a bias in $y_1$", fontsize=13.5)
    fig.text(0.5, -0.035,
             "2-propanol (1) / 2-butanone (2) at 328.15 K, generated from "
             "NRTL(0.35, 0.62); Barker fit to $P$-$x$ only, $y_1$ predicted.",
             ha="center", va="center", fontsize=10.5, color=SLATE)
    fig.tight_layout()
    return fig, out


if __name__ == "__main__":
    fig, out = build()
    for d, f, t in out:
        dy = f.y1_calc - d.y1
        print(f"{d.label:<14} mean|dy1| = {t.statistic:.5f}  "
              f"max|dy1| = {np.max(np.abs(dy)):.5f}  index {t.index}  "
              f"{'pass' if t.passed else 'FAIL'}   rms dP = {f.rms_P:.4f} kPa")
    for p in write(fig, SLUG):
        print("wrote", p)
