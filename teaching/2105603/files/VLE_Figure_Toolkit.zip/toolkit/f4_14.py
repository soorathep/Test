#!/usr/bin/env python3
"""F4.14  BUBL P, DEW P, BUBL T, DEW T — what is fixed, what is solved for.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

Four calculations, one equation. In every one of them the working statement is
modified Raoult's law

    y_i P = x_i gamma_i(x, T) Psat_i(T)

and the four names differ only in which two of {P, T, x, y} are given. What
changes with them is the ARITHMETIC: two of the four need an inner loop, and
the reason is worth being precise about, because "it is iterative" is not a
reason.

    BUBL P   given T, x     P = sum_i x_i gamma_i Psat_i is explicit. Both
                            gamma and Psat can be evaluated before anything is
                            unknown. NO iteration.
    DEW P    given T, y     1/P = sum_i y_i / (gamma_i Psat_i) needs gamma_i,
                            which needs x, which is the answer. Iterate on
                            COMPOSITION. Psat is known throughout, because T is.
    BUBL T   given P, x     Psat_i(T) cannot be evaluated until T is known.
                            Iterate on TEMPERATURE.
    DEW T    given P, y     both of the above at once: an outer loop on T with
                            the composition loop inside it.

The numbers in the table are not a description of the algorithms — they are
counted by running them. Each solver below is written out in full rather than
called from `vlekit`, so that the iteration counter is visible next to the
line it counts. The converged answers are then checked against
`vlekit.regress.bubble_P` / `bubble_T` and `vlekit.flash.dew_P` / `dew_T`, and
the agreement is printed.

SYSTEM. methanol (1) + water (2), the COUNTEREXAMPLE in `vlekit.datasets` —
positive deviation (class 2) and no azeotrope, which is why it is filed in
COUNTEREXAMPLES rather than as a type of its own:
Yang et al., J. Chem. Eng. Data 2012, 57, 2696-2701,
https://doi.org/10.1021/je300613v, 16 points at 66.52 kPa. Chosen because it
has no azeotrope, so the bubble and dew curves are monotonic and the four
constructions do not cross one another. NRTL fitted to that set by Barker's
method; the isothermal panel is drawn at 340 K, inside the 327-362 K range the
data cover, so nothing on this figure is an extrapolation.

Vapour phase ideal throughout (Phi_i = 1). That is the assumption under which
"BUBL P is explicit" is true; F4.15 measures what it costs.

Run:  python3 f4_14.py
"""
from __future__ import annotations

import os
import sys

import numpy as np

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib                                                  # noqa: E402
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                    # noqa: E402
from matplotlib.patches import FancyBboxPatch, Rectangle           # noqa: E402

import vlekit as v                                                 # noqa: E402
from vlekit import datasets as D                                   # noqa: E402
from vlekit import flash as FL                                     # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY, PAPER,  # noqa: E402
                          RUST, SKYBLUE, SLATE, TEAL, use_style)
from vlekit.regress import bubble_P as vk_bubble_P                 # noqa: E402
from vlekit.regress import bubble_T as vk_bubble_T                 # noqa: E402

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_14_bubble_dew_four_calculations"

T_ISO = 340.0            # K, inside the range the dataset covers
P_ISO = 66.52            # kPa, the pressure the dataset was measured at
Z = 0.40                 # the specified composition, used as x1 and as y1
TOL = 1e-10


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


# ==========================================================================
# The four calculations, written out so that the iteration counts are real
# ==========================================================================
def gam(m, x1, T):
    g1, g2 = m.gamma(np.array([x1]), np.array([T]))
    return float(g1[0]), float(g2[0])


def bubl_P(m, x1, T, c1, c2):
    """Given T and x: one evaluation, no loop."""
    g1, g2 = gam(m, x1, T)
    P = x1 * g1 * c1.Psat(T) + (1 - x1) * g2 * c2.Psat(T)
    y1 = x1 * g1 * c1.Psat(T) / P
    return dict(P=float(P), y1=float(y1), T=T, x1=x1, outer=0, inner=0)


def dew_P(m, y1, T, c1, c2, itmax=200):
    """Given T and y: iterate on the liquid composition; T never moves."""
    Ps1, Ps2 = float(c1.Psat(T)), float(c2.Psat(T))
    x1, it = y1, 0
    for it in range(1, itmax + 1):
        g1, g2 = gam(m, x1, T)
        P = 1.0 / (y1 / (g1 * Ps1) + (1 - y1) / (g2 * Ps2))
        x_new = y1 * P / (g1 * Ps1)
        if abs(x_new - x1) < TOL:
            x1 = x_new
            break
        x1 = x_new
    g1, g2 = gam(m, x1, T)
    P = 1.0 / (y1 / (g1 * Ps1) + (1 - y1) / (g2 * Ps2))
    return dict(P=float(P), x1=float(x1), T=T, y1=y1, outer=0, inner=it)


def bubl_T(m, x1, P, c1, c2, itmax=200):
    """Given P and x: iterate on T, because Psat_i(T) is not yet computable."""
    T = float(x1 * c1.Tsat(P) + (1 - x1) * c2.Tsat(P))     # a linear guess
    it = 0
    for it in range(1, itmax + 1):
        g1, g2 = gam(m, x1, T)
        # invert the Antoine equation of component 1 for the T that makes the
        # bubble pressure equal P, holding the ratio Psat2/Psat1 at its
        # current value: the standard successive substitution for BUBL T
        ratio = float(c2.Psat(T) / c1.Psat(T))
        Ps1_new = P / (x1 * g1 + (1 - x1) * g2 * ratio)
        T_new = float(c1.Tsat(Ps1_new))
        if abs(T_new - T) < 1e-10:
            T = T_new
            break
        T = T_new
    g1, g2 = gam(m, x1, T)
    Pb = x1 * g1 * c1.Psat(T) + (1 - x1) * g2 * c2.Psat(T)
    y1 = x1 * g1 * c1.Psat(T) / Pb
    return dict(T=float(T), y1=float(y1), P=P, x1=x1, outer=it, inner=0)


def dew_T(m, y1, P, c1, c2, itmax=200):
    """Given P and y: an outer loop on T with the composition loop inside it."""
    T = float(y1 * c1.Tsat(P) + (1 - y1) * c2.Tsat(P))
    x1, outer, inner = y1, 0, 0
    for outer in range(1, itmax + 1):
        Ps1, Ps2 = float(c1.Psat(T)), float(c2.Psat(T))
        for k in range(1, itmax + 1):                       # composition loop
            g1, g2 = gam(m, x1, T)
            x_new = y1 * P / (g1 * Ps1)
            x_new = x_new / (x_new + (1 - y1) * P / (g2 * Ps2))
            inner += 1
            if abs(x_new - x1) < TOL:
                x1 = x_new
                break
            x1 = x_new
        g1, g2 = gam(m, x1, T)
        S = y1 / (g1 * Ps1) + (1 - y1) / (g2 * Ps2)         # = 1/P at the root
        Ps1_new = Ps1 * S * P
        T_new = float(c1.Tsat(Ps1_new))
        if abs(T_new - T) < 1e-10:
            T = T_new
            break
        T = T_new
    return dict(T=float(T), x1=float(x1), P=P, y1=y1, outer=outer, inner=inner)


# --------------------------------------------------------------------------
def analyse():
    dat = D.methanol_water()
    fit = v.fit(dat, "nrtl")
    m, c1, c2 = fit.model, dat.c1, dat.c2

    r = {
        "BUBL P": bubl_P(m, Z, T_ISO, c1, c2),
        "DEW P": dew_P(m, Z, T_ISO, c1, c2),
        "BUBL T": bubl_T(m, Z, P_ISO, c1, c2),
        "DEW T": dew_T(m, Z, P_ISO, c1, c2),
    }

    # independent checks against vlekit's own routines
    chk = {}
    Pv, yv = vk_bubble_P(m, np.array([Z]), np.array([T_ISO]), c1, c2)
    chk["BUBL P"] = (float(Pv[0]), float(yv[0]),
                     abs(float(Pv[0]) - r["BUBL P"]["P"]))
    Pd, xd = FL.dew_P(m, np.array([Z]), np.array([T_ISO]), c1, c2)
    chk["DEW P"] = (float(Pd[0]), float(xd[0]),
                    abs(float(Pd[0]) - r["DEW P"]["P"]))
    Tv, yv2 = vk_bubble_T(m, np.array([Z]), np.array([P_ISO]), c1, c2)
    chk["BUBL T"] = (float(Tv[0]), float(yv2[0]),
                     abs(float(Tv[0]) - r["BUBL T"]["T"]))
    Td, xt = FL.dew_T(m, np.array([Z]), np.array([P_ISO]), c1, c2)
    chk["DEW T"] = (float(Td[0]), float(xt[0]),
                    abs(float(Td[0]) - r["DEW T"]["T"]))

    # the two diagrams
    x = np.linspace(1e-4, 1 - 1e-4, 401)
    Pb, yb = vk_bubble_P(m, x, np.full_like(x, T_ISO), c1, c2)
    Tb, yt = vk_bubble_T(m, x, np.full_like(x, P_ISO), c1, c2)

    return dict(dat=dat, fit=fit, m=m, r=r, chk=chk, x=x, Pb=Pb, yb=yb,
                Tb=Tb, yt=yt)



# --------------------------------------------------------------------------
class Placer:
    """A coarse occupancy grid over one axes, used to place annotations.

    Everything already drawn is marked on the grid; each label then takes the
    emptiest rectangle of the size it needs, biased towards the construction
    it names. No annotation position on this figure is typed in.
    """

    def __init__(self, ax, nx=44, ny=34):
        self.ax, self.nx, self.ny = ax, nx, ny
        self.g = np.zeros((ny, nx))

    def frac(self, x, y):
        pts = self.ax.transData.transform(
            np.column_stack([np.asarray(x, dtype=float),
                             np.asarray(y, dtype=float)]))
        return self.ax.transAxes.inverted().transform(pts).T

    def occupy(self, x, y, pad=1):
        fx, fy = self.frac(x, y)
        i = np.clip((fy * self.ny).astype(int), 0, self.ny - 1)
        j = np.clip((fx * self.nx).astype(int), 0, self.nx - 1)
        for a, b in zip(i, j):
            self.g[max(0, a - pad):a + pad + 1,
                   max(0, b - pad):b + pad + 1] += 1.0

    def place(self, w, h, anchor=None, pull=4.0, margin=0.012):
        cw = max(1, int(round(w * self.nx)))
        ch = max(1, int(round(h * self.ny)))
        m = max(1, int(round(margin * self.nx)))
        best, score, cells = (margin, 1 - h - margin), None, None
        for i in range(m, self.ny - ch - m + 1):
            for j in range(m, self.nx - cw - m + 1):
                sc = float(self.g[i:i + ch, j:j + cw].sum())
                if anchor is not None:
                    cx, cy = (j + 0.5 * cw) / self.nx, (i + 0.5 * ch) / self.ny
                    sc += pull * float(np.hypot(cx - anchor[0],
                                                cy - anchor[1]))
                if score is None or sc < score:
                    score, best, cells = sc, (j / self.nx, i / self.ny), (i, j)
        i, j = cells
        self.g[max(0, i - 1):i + ch + 1, max(0, j - 1):j + cw + 1] += 60.0
        return best[0] + 0.5 * w, best[1] + 0.5 * h


# ==========================================================================
ROWS = [
    ("BUBL P", "$T$,  $x_i$", "$P$,  $y_i$",
     r"$P = \sum_i x_i\,\gamma_i\,P_i^{\rm sat}$",
     "explicit — no loop", TEAL),
    ("DEW P", "$T$,  $y_i$", "$P$,  $x_i$",
     r"$1/P = \sum_i y_i/(\gamma_i P_i^{\rm sat})$",
     r"loop on $x$: $\gamma_i$ needs the answer", NAVY),
    ("BUBL T", "$P$,  $x_i$", "$T$,  $y_i$",
     r"$\sum_i x_i\,\gamma_i\,P_i^{\rm sat}(T) = P$",
     r"loop on $T$: $P_i^{\rm sat}$ not yet computable", AMBER),
    ("DEW T", "$P$,  $y_i$", "$T$,  $x_i$",
     r"$\sum_i y_i/(\gamma_i P_i^{\rm sat}(T)) = 1/P$",
     r"loop on $T$ with the $x$ loop inside it", RUST),
]

COLS = [("calculation", 0.000, 0.128),
        ("fixed", 0.128, 0.218),
        ("solved for", 0.218, 0.318),
        ("the equation that closes it", 0.318, 0.600),
        ("worked answer", 0.600, 0.745),
        ("what has to iterate, and why", 0.745, 1.000)]


def build(d):
    use_style()
    fig = plt.figure(figsize=(16.2, 7.1))
    gs = fig.add_gridspec(2, 2, width_ratios=[1.52, 1.0],
                          height_ratios=[1.0, 1.0],
                          left=0.030, right=0.988, top=0.885, bottom=0.150,
                          wspace=0.17, hspace=0.50)
    axT = fig.add_subplot(gs[:, 0])
    axP = fig.add_subplot(gs[0, 1])
    axTx = fig.add_subplot(gs[1, 1])

    # ------------------------------------------------------------ the table
    axT.set_xlim(0, 1)
    axT.set_ylim(0, 1)
    axT.axis("off")
    head_h = 0.105
    body_top = 1.0 - head_h
    row_h = body_top / len(ROWS)

    for name, a, b in COLS:
        axT.text(a + 0.010, 1.0 - 0.45 * head_h, name, fontsize=10.0,
                 color=INK, ha="left", va="center")
    axT.plot([0, 1], [body_top] * 2, "-", color=GRAPHITE, lw=1.5,
             clip_on=False)

    for i, (name, fixed, solve, eq, loop, col) in enumerate(ROWS):
        y1 = body_top - i * row_h
        y0 = y1 - row_h
        if i % 2 == 0:
            axT.add_patch(Rectangle((0, y0), 1, row_h, facecolor=MIST,
                                    alpha=0.20, edgecolor="none", zorder=0))
        axT.add_patch(Rectangle((0, y0 + 0.012), 0.008, row_h - 0.024,
                                facecolor=col, edgecolor="none", zorder=2))
        res = d["r"][name]
        yc = 0.5 * (y0 + y1)

        if name.endswith("P"):
            ans = (f"$P$ = {res['P']:.3f} kPa\n"
                   + (f"$y_1$ = {res['y1']:.4f}" if name == "BUBL P"
                      else f"$x_1$ = {res['x1']:.4f}"))
        else:
            ans = (f"$T$ = {res['T']:.3f} K\n"
                   + (f"$y_1$ = {res['y1']:.4f}" if name == "BUBL T"
                      else f"$x_1$ = {res['x1']:.4f}"))
        if res["outer"] == 0 and res["inner"] == 0:
            cnt = "0 iterations"
        elif res["outer"] == 0:
            cnt = f"{res['inner']} composition steps"
        elif res["inner"] == 0:
            cnt = f"{res['outer']} temperature steps"
        else:
            cnt = (f"{res['outer']} outer $\\times$ {res['inner']} inner "
                   "steps")

        cells = [(name, col, 12.2, 11.0),
                 (fixed, INK, 11.0, 11.0),
                 (solve, INK, 11.0, 11.0),
                 (eq, INK, 11.0, 11.0),
                 (ans, GRAPHITE, 10.2, 10.2),
                 (loop + f"\n{cnt}", col, 9.8, 9.8)]
        for (txt, cc, fs, _), (_, a, b) in zip(cells, COLS):
            axT.text(a + 0.014, yc, txt, fontsize=fs, color=cc, ha="left",
                     va="center", linespacing=1.55, zorder=4)
        axT.plot([0, 1], [y0] * 2, "-", color=MIST, lw=0.8, zorder=1)

    for _, a, b in COLS[1:]:
        axT.plot([a, a], [0, 1.0], "-", color=MIST, lw=0.8, zorder=1)

    axT.set_title("one equation, four questions — "
                  f"worked at $x_1$ or $y_1$ = {Z:g} (methanol)",
                  fontsize=12.8, pad=8, color=INK)

    # ------------------------------------------------------- the P-x-y panel
    axP.grid(True, zorder=0)
    axP.set_axisbelow(True)
    axP.plot(d["x"], d["Pb"], "-", color=GRAPHITE, lw=2.0, zorder=3)
    axP.plot(d["yb"], d["Pb"], "--", color=GRAPHITE, lw=2.0, zorder=3)
    b, w = d["r"]["BUBL P"], d["r"]["DEW P"]
    axP.set_xlim(0, 1)
    lo, hi = float(np.min(d["Pb"])), float(np.max(d["Pb"]))
    axP.set_ylim(lo - 0.10 * (hi - lo), hi + 0.16 * (hi - lo))

    for res, key, col, lab in ((b, "y1", TEAL, "BUBL P"),
                              (w, "x1", NAVY, "DEW P")):
        xin = res["x1"] if lab == "BUBL P" else res["y1"]
        xout = res[key]
        axP.plot([xin, xin], [axP.get_ylim()[0], res["P"]], ":", color=col,
                 lw=1.4, zorder=2)
        axP.plot([min(xin, xout), max(xin, xout)], [res["P"]] * 2, "-",
                 color=col, lw=1.6, zorder=4)
        axP.plot([xin], [res["P"]], "o", color=col, ms=9, mec=GRAPHITE,
                 mew=1.1, zorder=6)
        axP.plot([xout], [res["P"]], "s", color=PAPER, ms=8, mec=col, mew=1.8,
                 zorder=6)

    plP = Placer(axP)
    plP.occupy(d["x"], d["Pb"], pad=1)
    plP.occupy(d["yb"], d["Pb"], pad=1)
    plP.occupy(np.full(40, Z), np.linspace(axP.get_ylim()[0], b["P"], 40))
    for res, key in ((b, "y1"), (w, "x1")):
        plP.occupy(np.linspace(Z, res[key], 40), np.full(40, res["P"]))
    for res, col, lab, inp, out in (
            (b, TEAL, "BUBL P", f"$x_1$ = {Z:g}",
             f"$P$ = {b['P']:.2f} kPa,  $y_1$ = {b['y1']:.4f}"),
            (w, NAVY, "DEW P", f"$y_1$ = {Z:g}",
             f"$P$ = {w['P']:.2f} kPa,  $x_1$ = {w['x1']:.4f}")):
        an = plP.frac([Z], [res["P"]])
        cx, cy = plP.place(0.50, 0.17,
                           anchor=(float(an[0][0]), float(an[1][0])))
        axP.annotate(f"{lab}:  {inp}\n$\\rightarrow$ {out}",
                     xy=(Z, res["P"]), xycoords="data", xytext=(cx, cy),
                     textcoords="axes fraction", ha="center", va="center",
                     fontsize=9.4, color=col, linespacing=1.45, zorder=8,
                     bbox=dict(boxstyle="round,pad=0.24", fc=PAPER, ec=col,
                               lw=1.0, alpha=0.95),
                     arrowprops=dict(arrowstyle="-", color=col, lw=1.0,
                                     shrinkA=3, shrinkB=6))
    axP.set_xlabel("$x_1$,  $y_1$   (methanol)", labelpad=1)
    axP.set_ylabel("$P$ / kPa")
    axP.set_title(f"isothermal section, $T$ = {T_ISO:g} K  —  the two "
                  r"$P$ calculations", fontsize=11.4, pad=6)

    # ------------------------------------------------------- the T-x-y panel
    axTx.grid(True, zorder=0)
    axTx.set_axisbelow(True)
    axTx.plot(d["x"], d["Tb"], "-", color=GRAPHITE, lw=2.0, zorder=3)
    axTx.plot(d["yt"], d["Tb"], "--", color=GRAPHITE, lw=2.0, zorder=3)
    bt, wt = d["r"]["BUBL T"], d["r"]["DEW T"]
    axTx.set_xlim(0, 1)
    lo, hi = float(np.nanmin(d["Tb"])), float(np.nanmax(d["Tb"]))
    axTx.set_ylim(lo - 0.14 * (hi - lo), hi + 0.12 * (hi - lo))

    for res, key, col, lab in ((bt, "y1", AMBER, "BUBL T"),
                               (wt, "x1", RUST, "DEW T")):
        xin = res["x1"] if lab == "BUBL T" else res["y1"]
        xout = res[key]
        axTx.plot([xin, xin], [axTx.get_ylim()[0], res["T"]], ":", color=col,
                  lw=1.4, zorder=2)
        axTx.plot([min(xin, xout), max(xin, xout)], [res["T"]] * 2, "-",
                  color=col, lw=1.6, zorder=4)
        axTx.plot([xin], [res["T"]], "o", color=col, ms=9, mec=GRAPHITE,
                  mew=1.1, zorder=6)
        axTx.plot([xout], [res["T"]], "s", color=PAPER, ms=8, mec=col,
                  mew=1.8, zorder=6)

    plT = Placer(axTx)
    plT.occupy(d["x"], d["Tb"], pad=1)
    plT.occupy(d["yt"], d["Tb"], pad=1)
    plT.occupy(np.full(40, Z), np.linspace(axTx.get_ylim()[0], wt["T"], 40))
    for res, key in ((bt, "y1"), (wt, "x1")):
        plT.occupy(np.linspace(Z, res[key], 40), np.full(40, res["T"]))
    for res, col, lab, inp, out in (
            (bt, AMBER, "BUBL T", f"$x_1$ = {Z:g}",
             f"$T$ = {bt['T']:.2f} K,  $y_1$ = {bt['y1']:.4f}"),
            (wt, RUST, "DEW T", f"$y_1$ = {Z:g}",
             f"$T$ = {wt['T']:.2f} K,  $x_1$ = {wt['x1']:.4f}")):
        an = plT.frac([Z], [res["T"]])
        cx, cy = plT.place(0.50, 0.17,
                           anchor=(float(an[0][0]), float(an[1][0])))
        axTx.annotate(f"{lab}:  {inp}\n$\\rightarrow$ {out}",
                      xy=(Z, res["T"]), xycoords="data", xytext=(cx, cy),
                      textcoords="axes fraction", ha="center", va="center",
                      fontsize=9.4, color=col, linespacing=1.45, zorder=8,
                      bbox=dict(boxstyle="round,pad=0.24", fc=PAPER, ec=col,
                                lw=1.0, alpha=0.95),
                      arrowprops=dict(arrowstyle="-", color=col, lw=1.0,
                                      shrinkA=3, shrinkB=6))
    axTx.set_xlabel("$x_1$,  $y_1$   (methanol)", labelpad=1)
    axTx.set_ylabel("$T$ / K")
    axTx.set_title(f"isobaric section, $P$ = {P_ISO:g} kPa  —  the two "
                   r"$T$ calculations", fontsize=11.4, pad=6)

    fig.suptitle("BUBL P, DEW P, BUBL T, DEW T:  the same equation, "
                 "specified four ways", fontsize=14.6, y=0.972)
    fig.text(0.5, 0.038,
             "methanol (1) + water (2), doi:10.1021/je300613v — NRTL "
             f"($\\alpha$ = 0.3, $\\tau_{{12}}$ = {d['fit'].params[0]:+.4f}, "
             f"$\\tau_{{21}}$ = {d['fit'].params[1]:+.4f}) fitted to the "
             f"16 published points by Barker's method, rms $\\delta T$ = "
             f"{d['fit'].rms_T:.3f} K.  Ideal vapour ($\\Phi_i$ = 1) "
             "throughout; both sections lie inside the 327–362 K range the "
             "data cover.\n"
             "Iteration counts are counted by the solvers in this script, "
             "which are written out in full; every converged answer is "
             "checked against vlekit.regress / vlekit.flash and agrees to "
             "better than "
             f"{max(c[2] for c in d['chk'].values()):.0e} in $P$ or $T$.",
             ha="center", va="center", fontsize=9.8, color=SLATE,
             linespacing=1.6)
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = analyse()
    f = d["fit"]
    print(f"methanol + water, doi:{D.DOIS['methanol-water']}, "
          f"{len(d['dat'])} points at {P_ISO:g} kPa")
    print(f"  NRTL by Barker: tau12 = {f.params[0]:+.5f}, "
          f"tau21 = {f.params[1]:+.5f};  rms dT = {f.rms_T:.4f} K, "
          f"rms dy1 = {f.rms_y:.5f}")
    print(f"  specified composition: {Z:g} (as x1 for the BUBL cases, "
          f"as y1 for the DEW cases)")
    print(f"  isothermal section at {T_ISO:g} K, isobaric section at "
          f"{P_ISO:g} kPa\n")
    print(f"  {'calculation':11s} {'fixed':14s} {'result':38s} "
          f"{'outer':>6s} {'inner':>6s}   check against vlekit")
    for name in ("BUBL P", "DEW P", "BUBL T", "DEW T"):
        r = d["r"][name]
        c = d["chk"][name]
        if name.endswith("P"):
            fixed = f"T = {T_ISO:g} K"
            got = (f"P = {r['P']:9.4f} kPa,  "
                   + (f"y1 = {r['y1']:.5f}" if name == "BUBL P"
                      else f"x1 = {r['x1']:.5f}"))
        else:
            fixed = f"P = {P_ISO:g} kPa"
            got = (f"T = {r['T']:9.4f} K  ,  "
                   + (f"y1 = {r['y1']:.5f}" if name == "BUBL T"
                      else f"x1 = {r['x1']:.5f}"))
        print(f"  {name:11s} {fixed:14s} {got:38s} {r['outer']:6d} "
              f"{r['inner']:6d}   |diff| = {c[2]:.2e}")
    print()
    print("  the two DEW calculations return different compositions from the "
          "two BUBL ones at the same specified number, which is the whole "
          "point: 0.40 in the liquid and 0.40 in the vapour are different "
          "states.")
    print(f"  BUBL P at x1 = {Z:g}: P = {d['r']['BUBL P']['P']:.4f} kPa;  "
          f"DEW P at y1 = {Z:g}: P = {d['r']['DEW P']['P']:.4f} kPa;  "
          f"ratio {d['r']['BUBL P']['P'] / d['r']['DEW P']['P']:.4f}")
    print(f"  BUBL T at x1 = {Z:g}: T = {d['r']['BUBL T']['T']:.4f} K;   "
          f"DEW T at y1 = {Z:g}: T = {d['r']['DEW T']['T']:.4f} K;   "
          f"difference {d['r']['DEW T']['T'] - d['r']['BUBL T']['T']:+.4f} K")
    for p in write(build(d), SLUG):
        print("wrote", p)
