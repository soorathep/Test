#!/usr/bin/env python3
"""F4.9  The excess-enthalpy term in the isobaric Gibbs-Duhem test.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

For a binary at constant pressure the Gibbs-Duhem equation is

    x1 dln(g1)/dx1 + x2 dln(g2)/dx1  =  -(H^E / R T^2) dT/dx1

The right-hand side is identically zero for an isothermal set and is almost
always dropped for an isobaric one. This figure asks when dropping it is
defensible, for ethanol (1) / water (2) at 101.325 kPa.

    dT/dx1  comes from a bubble-temperature calculation
            (vlekit.regress.bubble_T) on the Margules model used throughout
            Module 4 — it is computed, not assumed.

    H^E     is ASSUMED. No excess enthalpy measurement is used anywhere in
            this course package, so three magnitudes are drawn as a family,
            H^E = 4 H^E_max x1 x2 with H^E_max = 250, 500 and 1000 J/mol.
            The middle value is the one quoted in the caption; it is a
            plausible order of magnitude for an alcohol/water mixture near its
            normal boiling range and nothing more. Every H^E curve on the
            figure is labelled 'assumed'.

The left-hand side is evaluated from a synthetic dataset with realistic
scatter, because that is the number a consistency test actually has in hand:
a smoothed derivative of ln gamma from noisy y, T and x.

Run:  python3 f4_09.py
"""
import os
import sys

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, "/home/claude/vlekit")
import vlekit as v                                              # noqa: E402
from vlekit.consistency import gibbs_duhem_residual             # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,     # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, use_style)
from vlekit.regress import bubble_T                             # noqa: E402

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_09_excess_enthalpy_term"

R = 8.314462618
P_SET = 101.325
A = [1.6, 0.9]                       # Margules-2, illustrative (see F4.2)
HE_MAX = (250.0, 500.0, 1000.0)      # J/mol, ASSUMED — see the docstring
HE_REF = 500.0
NOISE = {"y": 0.003, "T": 0.05}
SEED = 4


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def make():
    c1, c2 = v.component("ethanol"), v.component("water")
    m = v.Margules(A)
    dat = v.generate(m, np.linspace(0.02, 0.98, 25), P=P_SET, c1=c1, c2=c2,
                     kind="isobaric", noise=NOISE, seed=SEED,
                     label="ethanol/water, isobaric")

    xs, res, rms = gibbs_duhem_residual(dat)          # the left-hand side

    xf = np.linspace(0.01, 0.99, 393)                 # smooth bubble curve
    Tf, _ = bubble_T(m, xf, np.full_like(xf, P_SET), c1, c2)
    dTdx = np.gradient(Tf, xf)

    terms = {}
    for hmax in HE_MAX:
        HE = 4.0 * hmax * xf * (1 - xf)               # J/mol, ASSUMED
        terms[hmax] = -(HE / (R * Tf ** 2)) * dTdx
    return c1, c2, dat, m, xs, res, rms, xf, Tf, dTdx, terms


def build(dat, xs, res, rms, xf, Tf, dTdx, terms):
    use_style()
    fig, (axL, axR) = plt.subplots(1, 2, figsize=(12.8, 5.2))

    # ------------------------------------------- (a) where dT/dx1 comes from
    axL.grid(True, zorder=0)
    axL.set_axisbelow(True)
    hT, = axL.plot(xf, Tf, "-", color=NAVY, lw=2.4, zorder=4,
                   label="bubble $T(x_1)$")
    axL.plot(dat.x1, dat.T, "o", color=NAVY, mfc=PAPER, mew=1.6, ms=6,
             zorder=5)
    axL.set_xlabel("$x_1$   (ethanol)")
    axL.set_ylabel("bubble temperature $T$ / K", color=NAVY)
    axL.tick_params(axis="y", colors=NAVY)
    axL.set_xlim(0, 1)

    ax2 = axL.twinx()
    hD, = ax2.plot(xf, dTdx, "--", color=RUST, lw=2.4, zorder=4,
                   label=r"$\mathrm{d}T/\mathrm{d}x_1$ (right axis)")
    ax2.set_ylabel(r"$\mathrm{d}T/\mathrm{d}x_1$ / K", color=RUST)
    ax2.tick_params(axis="y", colors=RUST)
    ax2.spines["right"].set_visible(True)
    ax2.spines["right"].set_color(RUST)
    ax2.grid(False)
    lo2, hi2 = ax2.get_ylim()
    ax2.set_ylim(lo2, hi2 + 0.30 * (hi2 - lo2))

    axL.legend([hT, hD], [hT.get_label(), hD.get_label()],
               loc="center right", fontsize=11, bbox_to_anchor=(1.0, 0.50))
    axL.set_title("(a)  the isobaric set changes temperature, "
                  "and that is the point", fontsize=12.5)

    # -------------------------------------------- (b) the two terms compared
    axR.grid(True, zorder=0)
    axR.set_axisbelow(True)
    axR.axhline(0.0, color=GRAPHITE, lw=1.1, zorder=2)
    axR.plot(xs, res, "-", color=RUST, lw=2.6, zorder=5,
             label="left side, from the data\n"
                   f"(rms {rms:.3f}, this is the scatter a\nconsistency test "
                   "already tolerates)")

    lows, highs = terms[HE_MAX[0]], terms[HE_MAX[-1]]
    axR.fill_between(xf, lows, highs, color=TEAL, alpha=0.20, zorder=3,
                     label=f"right side for assumed $H^E_{{\\max}}$ = "
                           f"{HE_MAX[0]:g}–{HE_MAX[-1]:g} J/mol")
    axR.plot(xf, terms[HE_REF], "-", color=TEAL, lw=2.6, zorder=4,
             label=f"right side, assumed $H^E_{{\\max}}$ = {HE_REF:g} J/mol")

    axR.set_xlabel("$x_1$   (ethanol)")
    axR.set_ylabel("term in the isobaric Gibbs-Duhem equation")
    axR.set_xlim(0, 1)
    top = max(float(np.max(np.abs(res))), float(np.max(np.abs(highs))))
    axR.set_ylim(-1.15 * top, 2.35 * top)
    axR.legend(loc="upper right", fontsize=10, labelspacing=0.7)
    axR.set_title("(b)  the term that is usually dropped, against the term "
                  "that is tested", fontsize=12.5)

    terms_ref = terms[HE_REF]
    xstar = float(xf[np.argmax(np.abs(terms[HE_REF]))])
    ystar = float(terms[HE_REF][np.argmax(np.abs(terms[HE_REF]))])
    axR.annotate(f"peak {ystar:+.3f} at $x_1$ = {xstar:.2f}",
                 xy=(xstar, ystar), xytext=(0.02, 0.53),
                 textcoords="axes fraction", ha="left", va="bottom",
                 fontsize=10.5, color=TEAL, zorder=8,
                 bbox=dict(boxstyle="round,pad=0.26", fc=PAPER, ec="none",
                           alpha=0.88),
                 arrowprops=dict(arrowstyle="-", color=TEAL, lw=1.1,
                                 shrinkA=2, shrinkB=3))

    ratio_peak = float(np.max(np.abs(terms_ref))) / rms
    ratio_half = abs(float(np.interp(0.5, xf, terms_ref))) / rms
    axR.text(0.985, 0.035,
             f"assumed term / rms of the left side:\n"
             f"{ratio_peak:.2f} at its peak ($x_1$ = {xstar:.2f}),  "
             f"{ratio_half:.2f} at $x_1$ = 0.5\n"
             "— droppable in the middle, not at the dilute ethanol end",
             transform=axR.transAxes, ha="right", va="bottom", fontsize=10.5,
             color=INK, linespacing=1.5,
             bbox=dict(boxstyle="round,pad=0.34", fc=PAPER, ec=MIST, lw=1.0,
                       alpha=0.95))

    fig.suptitle(r"Ethanol (1) / water (2) at 101.325 kPa:  "
                 r"$x_1\,\mathrm{d}\ln\gamma_1/\mathrm{d}x_1 + "
                 r"x_2\,\mathrm{d}\ln\gamma_2/\mathrm{d}x_1 = "
                 r"-\,(H^E/RT^2)\,\mathrm{d}T/\mathrm{d}x_1$",
                 fontsize=14, y=1.005)
    fig.text(0.5, -0.055,
             "ASSUMED VALUE: $H^E$ = $4H^E_{\\max}x_1x_2$ with "
             f"$H^E_{{\\max}}$ = {HE_REF:g} J/mol (band: "
             f"{HE_MAX[0]:g}–{HE_MAX[-1]:g} J/mol).  This is an assumed "
             "magnitude for an alcohol/water mixture near its boiling range, "
             "not a measurement;\nno calorimetric data are used anywhere in "
             "this package.  $\\mathrm{d}T/\\mathrm{d}x_1$ and the left-hand "
             "side are computed, from vlekit.regress.bubble_T and "
             "vlekit.consistency.gibbs_duhem_residual respectively.",
             ha="center", va="center", fontsize=10, color=SLATE,
             linespacing=1.5)
    fig.tight_layout()
    return fig


if __name__ == "__main__":
    c1, c2, dat, m, xs, res, rms, xf, Tf, dTdx, terms = make()
    print(f"isobaric ethanol/water at {P_SET:g} kPa, n = {dat.n}, "
          f"T = {dat.T.min():.2f}-{dat.T.max():.2f} K")
    print(f"dT/dx1 ranges {dTdx.min():.1f} to {dTdx.max():.1f} K")
    print(f"left-hand side from the data: rms {rms:.4f}, "
          f"max |.| {np.max(np.abs(res)):.4f}")
    for h in HE_MAX:
        t = terms[h]
        print(f"assumed H^E_max = {h:6.0f} J/mol -> right-hand side "
              f"max |.| {np.max(np.abs(t)):.4f} at x1 = "
              f"{xf[np.argmax(np.abs(t))]:.2f}, "
              f"value at x1 = 0.5 {np.interp(0.5, xf, t):+.4f}, "
              f"ratio to lhs rms {np.max(np.abs(t)) / rms:.2f}")
    for p in write(build(dat, xs, res, rms, xf, Tf, dTdx, terms), SLUG):
        print("wrote", p)
