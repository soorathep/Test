#!/usr/bin/env python3
"""F4.1  The ladder of the four VLE descriptions.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

A concept map, not a calculation. Four rungs: each one names the physics the
previous rung was missing, and the price that is paid for adding it. Nothing on
this figure is computed, which is why it is drawn entirely with matplotlib
primitives in unit coordinates.

Run:  python3 f4_01.py
"""
import os
import sys

import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

sys.path.insert(0, "/home/claude/vlekit")
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY, PAPER,  # noqa: E402
                          RUST, SLATE, TEAL, save, use_style)

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_01_vle_ladder"

# ---------------------------------------------------------------- content
# (title, working equation, what it costs)
RUNGS = [
    ("Raoult's law",
     r"$y_i P = x_i P_i^{\,\rm sat}$",
     "costs: nothing but $P_i^{\\rm sat}(T)$  —  no binary parameter, "
     "no data",
     NAVY),
    ("Modified Raoult's law",
     r"$y_i P = x_i \gamma_i P_i^{\,\rm sat}$",
     "costs: a $G^{E}$ model and 2 parameters fitted to binary VLE data",
     TEAL),
    (r"$\gamma$–$\phi$ formulation",
     r"$y_i \hat\phi_i P = x_i \gamma_i P_i^{\,\rm sat}\,"
     r"\phi_i^{\,\rm sat}\,\mathcal{F}_i$",
     "costs: a vapour EOS, virial coefficients, and an inner iteration",
     AMBER),
    (r"$\phi$–$\phi$ formulation",
     r"$y_i \hat\phi_i^{\,V} P = x_i \hat\phi_i^{\,L} P$",
     "costs: one EOS for both phases, $k_{ij}$, and a root/stability test",
     RUST),
]

# what each step adds, written on the arrow between the rungs
STEPS = [
    r"$+$ liquid non-ideality:  $\gamma_i(x,T)$ from an excess Gibbs energy",
    r"$+$ vapour non-ideality:  $\hat\phi_i$, $\phi_i^{\rm sat}$ and the "
    r"Poynting factor",
    r"$+$ one EOS for both phases:  no $P^{\rm sat}$, valid above $T_c$",
]


def build():
    use_style()
    fig, ax = plt.subplots(figsize=(11.0, 7.4))
    ax.set_xlim(0, 1)
    ax.set_ylim(-0.10, 1.0)
    ax.axis("off")

    x0, w, h, dy, dx = 0.075, 0.600, 0.170, 0.243, 0.055

    # the vertical "increasing physics, increasing cost" spine
    ax.add_patch(FancyArrowPatch((0.035, 0.035), (0.035, 0.965),
                                 arrowstyle="-|>", mutation_scale=18,
                                 lw=1.6, color=SLATE, zorder=1))
    ax.text(0.016, 0.50, "more physics   →   more parameters, "
                         "more data, more computation",
            rotation=90, ha="center", va="center", fontsize=11.5,
            color=SLATE)

    for i, (name, eq, cost, col) in enumerate(RUNGS):
        bx, by = x0 + i * dx, 0.030 + i * dy
        ax.add_patch(FancyBboxPatch((bx, by), w, h,
                                    boxstyle="round,pad=0.010,rounding_size=0.016",
                                    linewidth=1.8, edgecolor=col,
                                    facecolor=PAPER, zorder=3))
        # a coloured tab on the left edge carries the rung number
        ax.add_patch(FancyBboxPatch((bx, by), 0.036, h,
                                    boxstyle="round,pad=0.006,rounding_size=0.014",
                                    linewidth=0, facecolor=col, alpha=0.90,
                                    zorder=4))
        ax.text(bx + 0.018, by + h / 2, str(i + 1), ha="center", va="center",
                fontsize=15, color=PAPER, fontweight="bold", zorder=5)

        tx = bx + 0.055
        ax.text(tx, by + h - 0.036, name, ha="left", va="center",
                fontsize=14, color=INK, fontweight="bold", zorder=5)
        ax.text(tx, by + h - 0.088, eq, ha="left", va="center",
                fontsize=14.5, color=col, zorder=5)
        ax.text(tx, by + 0.033, cost, ha="left", va="center",
                fontsize=10.5, color=GRAPHITE, zorder=5)

        if i < len(STEPS):
            ax_ = bx + 0.105
            ax.add_patch(FancyArrowPatch((ax_, by + h + 0.008),
                                         (ax_, by + dy - 0.008),
                                         arrowstyle="-|>", mutation_scale=16,
                                         lw=2.0, color=RUNGS[i + 1][3],
                                         zorder=3))
            ax.text(ax_ + 0.030, by + h + (dy - h) / 2, STEPS[i],
                    ha="left", va="center", fontsize=11.5,
                    color=RUNGS[i + 1][3], zorder=5)

    # the two questions the ladder answers, parked in the empty upper-left
    ax.text(0.52, -0.075,
            "Every rung is exact given its own assumptions.  "
            "Choosing a rung is choosing which assumption to defend.",
            ha="center", va="center", fontsize=11.5, color=SLATE,
            bbox=dict(boxstyle="round,pad=0.45", fc=PAPER, ec=MIST, lw=0.9))

    ax.set_title("Four descriptions of vapour-liquid equilibrium, "
                 "and what each one costs",
                 fontsize=15, color=INK, pad=10)
    return fig


def write(fig, slug, out=OUT):
    """PNG for the slides, PDF for the printed notes. Same render, both files."""
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


if __name__ == "__main__":
    for p in write(build(), SLUG):
        print("wrote", p)
