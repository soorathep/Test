#!/usr/bin/env python3
"""F4.20  UNIFAC when there is no data — and what fitting actually buys.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

THE SITUATION. Every other figure in this module starts from a dataset. The
common industrial case is that there is none: the pair has never been measured,
or it was measured at a temperature nobody will admit to. The question a
student has to be able to answer with a NUMBER is "how wrong is UNIFAC likely
to be, and when is that good enough?" — not with an adjective.

WHAT IS DONE. Three published binaries are taken, and each is predicted by
UNIFAC with nothing fitted, then fitted with one parameter and with two. The
same bubble-point routine, the same ideal-vapour assumption and the same points
are used throughout, so the only thing that changes along the ladder is how
many numbers were allowed to see the data:

    0 parameters   UNIFAC, group contribution, nothing fitted
    1 parameter    two-suffix Margules, one A, fitted by Barker
    2 parameters   NRTL, tau12 and tau21, alpha = 0.3 fixed, fitted by Barker

WHICH UNIFAC. The original VLE UNIFAC of Fredenslund, Jones & Prausnitz, with
the group interaction table of Hansen et al. — the subset needed by
`vlekit.data.LIBRARY` is embedded in `vlekit.unifac` and is checked parameter
by parameter, and gamma by gamma, against the `thermo` package in
tests/test_extensions.py. It is NOT modified UNIFAC (Dortmund): there are no
temperature-dependent a_mn terms and no revised combinatorial. That matters,
because the Dortmund revision was fitted to more data and would give different
numbers; a prediction is only reproducible if the table it came from is named.

THE MEASURING STICK. An error is only "good enough" against something. The
denominator used here is the uncertainty the SOURCE PAPER reports, carried in
`dataset.sigma`. Panel (c) is every model error divided by that uncertainty:
below 1.0 the model is inside the noise of the measurement it is being judged
against, and no amount of further fitting can be shown to help.

WHAT CAME OUT, and two of the three were not what the naive story predicts:

  * chloroform + 2-butanone, 303.15 K: UNIFAC predicts the bubble pressure to
    an rms of 0.60 kPa against a reported uncertainty of 0.65 kPa. With nothing
    fitted, the prediction sits inside the experimental error bar.
  * ethanol + water, 101.3 kPa: UNIFAC beats the ONE-parameter fit by a factor
    of 6.7 in temperature, and locates the azeotrope within 0.003 in mole
    fraction — closer than the two-parameter NRTL fitted to the data by Barker
    on T, which misses it by 0.023.
  * acetone + chloroform: the fitted NRTL wins on T, the variable it was fitted
    against, and LOSES to UNIFAC on y, which it never saw. A fit is only better
    where you fitted it.

None of this says UNIFAC is as good as a fit. It says the gap is a number, the
number is often smaller than the measurement error, and the honest comparison
has to be made on a variable the fit did not get to optimise.

Run:  python3 f4_20.py       (a few seconds)
"""
from __future__ import annotations

import os
import sys
import time

import numpy as np

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib                                                  # noqa: E402
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                    # noqa: E402
from matplotlib.lines import Line2D                                # noqa: E402
from scipy.optimize import brentq                                  # noqa: E402

import vlekit as v                                                 # noqa: E402
from vlekit import datasets as D                                   # noqa: E402
from vlekit import unifac as U                                     # noqa: E402
from vlekit.regress import bubble_P, bubble_T                      # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY, PAPER,  # noqa: E402
                          RUST, SKYBLUE, SLATE, TEAL, use_style)

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_20_unifac_when_there_is_no_data"

#: the ladder, in fitted-parameter order. The label carries the count because
#: that is the axis of panel (c) and the point of the whole figure.
LADDER = [("UNIFAC, nothing fitted", "UNIFAC, 0 par", 0, AMBER),
          ("two-suffix Margules, 1 parameter", "Margules, 1 par", 1, SKYBLUE),
          ("NRTL, 2 parameters", "NRTL, 2 par", 2, NAVY)]

SYSTEMS = [("chloroform-butanone", TEAL), ("ethanol-water", NAVY),
           ("acetone-chloroform", RUST)]


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def wrapped(text, width):
    """Wrap a caption on spaces, never inside a $...$ span."""
    out = []
    for para in text.split("\n"):
        cur, n, inmath = [], 0, False
        for w in para.split(" "):
            if cur and not inmath and n + 1 + len(w) > width:
                out.append(" ".join(cur))
                cur, n = [], 0
            cur.append(w)
            n += len(w) + (1 if n else 0)
            if w.count("$") % 2 == 1:
                inmath = not inmath
        out.append(" ".join(cur))
    return "\n".join(out)


# --------------------------------------------------------------------------
def models_for(dat):
    """The three rungs of the ladder, for one dataset.

    UNIFAC is first because it is the only one that has not seen the data. The
    two fits use Barker's method, which is the default objective for the
    dataset's kind: T for isobaric, P for isothermal. The vapour composition is
    never used in either fit, so `rms dy` below is an out-of-objective test for
    all three models — including the fitted ones.
    """
    lab, short, npar, col = LADDER[0]
    out = [(lab, short, npar, col, U.UNIFACModel(dat.c1, dat.c2), None)]
    for (lab, short, npar, col), name in zip(LADDER[1:],
                                             ("margules1", "nrtl")):
        f = v.fit(dat, name)
        out.append((lab, short, npar, col, f.model, f))
    return out


def errors(dat, model):
    """Model error at the measured points, in every currency that matters.

    Endpoints are dropped: at x = 0 and x = 1 the combinatorial term of UNIFAC
    contains ln(phi/x) and the measured gamma is 0/0, so an endpoint would be a
    property of the arithmetic rather than of the model.
    """
    m = dat.interior()
    if dat.kind == "isobaric":
        dep, y = bubble_T(model, dat.x1[m], dat.P[m], dat.c1, dat.c2)
        obs, sig, unit, sym = dat.T[m], dat.sigma["T"], "K", "T"
    else:
        dep, y = bubble_P(model, dat.x1[m], dat.T[m], dat.c1, dat.c2)
        obs, sig, unit, sym = dat.P[m], dat.sigma["P"], "kPa", "P"
    g1e, g2e = dat.gamma("ideal")
    good = m & np.isfinite(g1e) & np.isfinite(g2e) & (g1e > 0) & (g2e > 0)
    lg1, _ = model.ln_gamma(dat.x1[good], dat.T[good])
    dlg = np.mean(np.abs(lg1 - np.log(g1e[good])))
    return dict(mask=m, dep=dep, y=y, obs=obs, sigma=sig, unit=unit, sym=sym,
                aad=float(np.mean(np.abs(dep - obs))),
                rms=float(np.sqrt(np.mean((dep - obs) ** 2))),
                pct=float(np.mean(np.abs(100 * (dep - obs) / obs))),
                rms_y=float(np.sqrt(np.nanmean((y - dat.y1[m]) ** 2))),
                sigma_y=dat.sigma["y"], dlg=float(dlg),
                gamma_pct=float(100 * (np.exp(dlg) - 1)))


def azeotrope_isobaric(model, P, c1, c2, lo=0.55, hi=0.98):
    """Where y1 - x1 changes sign on an isobaric bubble curve."""
    def f(x1):
        _, y = bubble_T(model, np.array([x1]), np.array([P]), c1, c2)
        return float(y[0] - x1)

    if f(lo) * f(hi) > 0:
        return None
    return float(brentq(f, lo, hi, xtol=1e-9))


def azeotrope_measured(dat):
    """The azeotrope the DATA shows, by linear interpolation on y - x.

    Two measured points bracket it; nothing is fitted to find it, which is what
    makes it a fair target for the models to be scored against.
    """
    d = dat.y1 - dat.x1
    k = np.where(np.sign(d[:-1]) != np.sign(d[1:]))[0]
    if len(k) != 1:
        return None, None
    i = int(k[0])
    t = d[i] / (d[i] - d[i + 1])
    return (float(dat.x1[i] + t * (dat.x1[i + 1] - dat.x1[i])),
            float(dat.T[i] + t * (dat.T[i + 1] - dat.T[i])))


# --------------------------------------------------------------------------
def analyse():
    t0 = time.time()
    res = {}
    for name, col in SYSTEMS:
        dat = D.load(name)
        rows = []
        for label, short, npar, mcol, model, fit in models_for(dat):
            e = errors(dat, model)
            e.update(label=label, short=short, npar=npar, colour=mcol,
                     model=model, fit=fit)
            rows.append(e)
        res[name] = dict(dat=dat, rows=rows, colour=col)

    # the azeotrope of ethanol + water, as a second, engineering-facing score
    ew = res["ethanol-water"]["dat"]
    xa_meas, Ta_meas = azeotrope_measured(ew)
    az = []
    for r in res["ethanol-water"]["rows"]:
        xa = azeotrope_isobaric(r["model"], float(ew.P[0]), ew.c1, ew.c2)
        Ta = None
        if xa is not None:
            Ta = float(bubble_T(r["model"], np.array([xa]),
                                np.array([ew.P[0]]), ew.c1, ew.c2)[0][0])
        az.append(dict(label=r["label"], npar=r["npar"], colour=r["colour"],
                       x1=xa, T=Ta))

    return dict(res=res, az=az, xa_meas=xa_meas, Ta_meas=Ta_meas,
                elapsed=time.time() - t0)


# --------------------------------------------------------------------------
def build(d):
    use_style()
    fig, (axA, axB, axC) = plt.subplots(1, 3, figsize=(16.0, 7.6),
                                        gridspec_kw={"width_ratios":
                                                     [1.0, 1.0, 1.06]})
    for a in (axA, axB, axC):
        a.grid(True, zorder=0)
        a.set_axisbelow(True)

    # ======================================= (a) isothermal: the P prediction
    S = d["res"]["chloroform-butanone"]
    dat = S["dat"]
    xs = np.linspace(1e-4, 1 - 1e-4, 260)
    axA.errorbar(dat.x1, dat.P, yerr=dat.sigma["P"], fmt="o", color=INK,
                 mfc=PAPER, mew=1.6, ms=7.0, ecolor=SLATE, elinewidth=1.2,
                 capsize=3, zorder=6,
                 label=f"measured, {len(dat)} pts, $\\pm${dat.sigma['P']} kPa"
                       "\n(doi:10.1021/je060150a)")
    for r in S["rows"]:
        P, _ = bubble_P(r["model"], xs, np.full_like(xs, dat.T[0]),
                        dat.c1, dat.c2)
        axA.plot(xs, P, "-" if r["npar"] else "--", color=r["colour"], lw=2.3,
                 zorder=4 + r["npar"],
                 label=f"{r['short']} — AAD {r['pct']:.2f} %, "
                       f"rms {r['rms']:.2f} kPa")
    axA.set_xlim(0, 1)
    axA.set_xlabel("$x_1$   (chloroform)")
    axA.set_ylabel("bubble pressure  $P$ / kPa")
    axA.legend(loc="upper left", fontsize=9.0, handlelength=1.7,
               borderaxespad=0.4)
    axA.set_title("(a)  isothermal, so the error is in $P$\n"
                  "chloroform + 2-butanone, 303.15 K",
                  fontsize=11.6, pad=6)
    u = S["rows"][0]
    axA.text(0.5, 0.020,
             "with NOTHING fitted, UNIFAC predicts $P$ to\n"
             f"rms {u['rms']:.2f} kPa against the "
             f"$\\pm${dat.sigma['P']} kPa this paper reports\n"
             f"— that is {u['rms'] / dat.sigma['P']:.2f} of the experimental "
             "uncertainty",
             transform=axA.transAxes, ha="center", va="bottom", fontsize=9.2,
             color=AMBER, linespacing=1.5, zorder=9,
             bbox=dict(boxstyle="round,pad=0.30", fc=PAPER, ec=AMBER, lw=1.1,
                       alpha=0.96))

    # ================================ (b) isobaric: the y prediction, and the
    #                                      azeotrope, which is what gets built
    S = d["res"]["ethanol-water"]
    dat = S["dat"]
    axB.plot([0, 1], [0, 1], "-", color=MIST, lw=1.4, zorder=2)
    axB.errorbar(dat.x1, dat.y1, yerr=dat.sigma["y"], fmt="o", color=INK,
                 mfc=PAPER, mew=1.6, ms=7.0, ecolor=SLATE, elinewidth=1.2,
                 capsize=3, zorder=6,
                 label=f"measured, {len(dat)} pts, $\\pm${dat.sigma['y']} in "
                       "$y_1$\n(doi:10.1021/je2008704)")
    for r in S["rows"]:
        _, y = bubble_T(r["model"], xs, np.full_like(xs, dat.P[0]),
                        dat.c1, dat.c2)
        axB.plot(xs, y, "-" if r["npar"] else "--", color=r["colour"], lw=2.3,
                 zorder=4 + r["npar"],
                 label=f"{r['short']} — rms {r['rms_y']:.4f} in $y_1$,"
                       f"\n     AAD {r['aad']:.3f} K in $T$")
    axB.set_xlim(0, 1)
    axB.set_ylim(0, 1)
    axB.set_xlabel("$x_1$   (ethanol)")
    axB.set_ylabel("$y_1$")
    axB.legend(loc="lower right", fontsize=8.6, handlelength=1.7,
               borderaxespad=0.4, labelspacing=0.45)
    axB.set_title("(b)  isobaric, and the number a column needs:\n"
                  "where is the azeotrope? ethanol + water, 101.3 kPa",
                  fontsize=11.6, pad=6)

    # the azeotrope panel-in-a-panel, with every entry computed
    lines = [f"azeotrope $x_1$ at 101.3 kPa\n"
             f"measured (interpolated between two points): "
             f"{d['xa_meas']:.4f}"]
    for a in d["az"]:
        if a["x1"] is None:
            lines.append(f"{a['label']}: none predicted")
        else:
            lines.append(f"{a['label']}: {a['x1']:.4f}  "
                         f"({a['x1'] - d['xa_meas']:+.4f})")
    axB.text(0.028, 0.972, "\n".join(lines), transform=axB.transAxes,
             ha="left", va="top", fontsize=8.6, color=GRAPHITE,
             linespacing=1.55, zorder=9,
             bbox=dict(boxstyle="round,pad=0.30", fc=PAPER, ec=SLATE, lw=1.0,
                       alpha=0.96))
    xa = d["xa_meas"]
    axB.plot([xa], [xa], "D", color=RUST, ms=8.0, mfc=PAPER, mew=1.8, zorder=8)

    # ============================ (c) what the fitting bought, against the
    #                                  uncertainty the source paper reports
    handles = []
    for name, col in SYSTEMS:
        S = d["res"][name]
        npars = [r["npar"] for r in S["rows"]]
        dep = [r["rms"] / r["sigma"] for r in S["rows"]]
        ys = [r["rms_y"] / r["sigma_y"] for r in S["rows"]]
        sym = S["rows"][0]["sym"]
        axC.plot(npars, dep, "-o", color=col, lw=2.3, ms=7.5, mfc=PAPER,
                 mew=1.8, zorder=5)
        axC.plot(npars, ys, "--s", color=col, lw=1.8, ms=6.5, mfc=col,
                 mew=1.2, alpha=0.85, zorder=4)
        handles.append((Line2D([], [], color=col, lw=2.4),
                        f"{S['dat'].c1.name} + {S['dat'].c2.name}"))
    axC.axhline(1.0, color=GRAPHITE, lw=1.6, zorder=3)
    axC.set_yscale("log")
    # headroom for the key, computed from the extremes actually plotted
    allv = [r["rms"] / r["sigma"] for n, _ in SYSTEMS
            for r in d["res"][n]["rows"]]
    allv += [r["rms_y"] / r["sigma_y"] for n, _ in SYSTEMS
             for r in d["res"][n]["rows"]]
    axC.set_ylim(0.6 * min(allv), 9.0 * max(allv))
    axC.set_xticks([0, 1, 2])
    axC.set_xticklabels(["0\nUNIFAC", "1\nMargules", "2\nNRTL"])
    axC.set_xlim(-0.16, 2.16)
    axC.set_xlabel("parameters fitted to these data", labelpad=2)
    axC.set_ylabel("model error  /  uncertainty the source paper reports")
    axC.set_title("(c)  what each parameter bought, measured against\n"
                  "the error bar of the data it was fitted to",
                  fontsize=11.6, pad=6)
    axC.text(0.020, 1.0, "inside the measurement's own uncertainty, below",
             transform=axC.get_yaxis_transform(), ha="left", va="bottom",
             fontsize=8.8, color=GRAPHITE, zorder=10,
             bbox=dict(boxstyle="round,pad=0.18", fc=PAPER, ec="none",
                       alpha=0.92))
    handles += [(Line2D([], [], color=GRAPHITE, lw=2.4, marker="o",
                        mfc=PAPER, mew=1.6, ms=7.0),
                 "the fitted variable, $P$ or $T$"),
                (Line2D([], [], color=GRAPHITE, lw=1.8, ls="--", marker="s",
                        ms=6.0),
                 "$y_1$ — which NO model here was fitted to")]
    axC.legend([h for h, _ in handles], [t for _, t in handles],
               loc="upper right", fontsize=9.0, handlelength=2.2,
               labelspacing=0.5, borderaxespad=0.5)

    fig.suptitle("How wrong is UNIFAC, in numbers — and what one or two "
                 "fitted parameters actually buy over it",
                 fontsize=14.2, y=0.985)
    ew = d["res"]["ethanol-water"]["rows"]
    ac = d["res"]["acetone-chloroform"]["rows"]
    cb = d["res"]["chloroform-butanone"]["rows"]
    fig.text(0.5, 0.016, wrapped(
        "Original VLE UNIFAC (Fredenslund, Jones & Prausnitz; group "
        "interaction table of Hansen et al.), the subset embedded in "
        "vlekit.unifac and checked parameter by parameter against the thermo "
        "package in the test suite. NOT modified UNIFAC (Dortmund): no "
        "temperature-dependent $a_{{mn}}$, no revised combinatorial. Nothing in "
        "the UNIFAC curves was fitted to anything. The two fits use Barker's "
        "method on the same points, so $y_1$ was withheld from every model on "
        "this figure. Ideal vapour, $\\Phi_i$ = 1, throughout; end points "
        "dropped because $\\gamma$ from data is 0/0 there.\n"
        "THE NUMBERS. chloroform + 2-butanone: UNIFAC {cb0:.2f} % in $P$ "
        "(rms {cb0r:.2f} kPa, {cb0s:.2f} of the reported $\\pm$0.65 kPa) "
        "against {cb2:.2f} % for two fitted parameters. ethanol + water: "
        "UNIFAC {ew0:.3f} K, one parameter {ew1:.3f} K, two parameters "
        "{ew2:.3f} K — the group prediction beats the one-parameter fit by "
        "{ratio:.1f}x, and places the azeotrope at $x_1$ = {uaz:.4f} against "
        "{maz:.4f} measured, while the fitted NRTL puts it at {naz:.4f}. "
        "acetone + chloroform: the fitted NRTL is better in $T$ "
        "({ac2:.3f} K vs {ac0:.3f} K) and WORSE in $y_1$ ({ac2y:.4f} vs "
        "{ac0y:.4f}), because $T$ is what it was fitted to and $y_1$ is not.\n"
        "WHEN IS IT GOOD ENOUGH. Read panel (c): a point below the heavy line "
        "is a model whose error is smaller than the uncertainty of the "
        "measurement judging it, and no further fitting can be shown to help "
        "with these data. UNIFAC is already there for chloroform + "
        "2-butanone in $P$ and for two of the three systems in $y_1$. It is "
        "not there for ethanol + water in $T$, where the two fitted "
        "parameters are worth having. The honest summary is that a group "
        "prediction costs a factor of two to five against a good fit on these "
        "systems — and that the fit only wins on the variable it was fitted "
        "to.", 208).format(
            cb0=cb[0]["pct"], cb0r=cb[0]["rms"],
            cb0s=cb[0]["rms"] / cb[0]["sigma"], cb2=cb[2]["pct"],
            ew0=ew[0]["aad"], ew1=ew[1]["aad"], ew2=ew[2]["aad"],
            ratio=ew[1]["aad"] / ew[0]["aad"], uaz=d["az"][0]["x1"],
            maz=d["xa_meas"], naz=d["az"][2]["x1"], ac2=ac[2]["aad"],
            ac0=ac[0]["aad"], ac2y=ac[2]["rms_y"], ac0y=ac[0]["rms_y"]),
        ha="center", va="bottom", fontsize=9.5, color=SLATE, linespacing=1.6)
    fig.tight_layout(rect=(0.005, 0.268, 0.995, 0.935))
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = analyse()
    print("F4.20  UNIFAC with nothing fitted, against one and two fitted "
          "parameters")
    print("  UNIFAC revision: original VLE UNIFAC (Fredenslund, Jones & "
          "Prausnitz), Hansen et al. group interaction table, the subset in "
          "vlekit.unifac; NOT modified UNIFAC (Dortmund)")
    print()
    for name, _ in SYSTEMS:
        S = d["res"][name]
        dat = S["dat"]
        r0 = S["rows"][0]
        print(f"  {dat.label}   doi:{D.DOIS[name]}   {len(dat)} points, "
              f"{int(r0['mask'].sum())} interior")
        print(f"    reported uncertainty: {r0['sym']} +/- {r0['sigma']} "
              f"{r0['unit']},  y +/- {r0['sigma_y']}")
        print(f"    {'model':34s} {'npar':>4s} {'AAD':>10s} {'rms':>9s} "
              f"{'rms/sigma':>10s} {'AAD %':>8s} {'rms dy':>9s} "
              f"{'rms dy/sig':>11s} {'mean|dln g1|':>13s}")
        for r in S["rows"]:
            print(f"    {r['label']:34s} {r['npar']:4d} "
                  f"{r['aad']:10.4f} {r['rms']:9.4f} "
                  f"{r['rms'] / r['sigma']:10.2f} {r['pct']:8.3f} "
                  f"{r['rms_y']:9.4f} {r['rms_y'] / r['sigma_y']:11.2f} "
                  f"{r['dlg']:13.4f}")
            if r["fit"] is not None:
                print("        fitted " + ", ".join(
                    f"{n} = {p:+.5f}" for n, p in
                    zip(r["fit"].model.param_names, r["fit"].params)))
        print()
    print(f"  the azeotrope of ethanol + water at 101.3 kPa "
          f"(the number a column is sized on):")
    print(f"    measured, interpolated between the two points that bracket "
          f"y1 = x1: x1 = {d['xa_meas']:.4f}, T = {d['Ta_meas']:.2f} K")
    for a in d["az"]:
        if a["x1"] is None:
            print(f"    {a['label']:34s} predicts no azeotrope")
        else:
            print(f"    {a['label']:34s} x1 = {a['x1']:.4f} "
                  f"({a['x1'] - d['xa_meas']:+.4f}), T = {a['T']:.2f} K")
    print("    -> the group prediction, with nothing fitted, locates it more "
          "closely than the two-parameter NRTL fitted by Barker on T; the "
          "fit was never shown y, and the azeotrope is a statement about y")
    print()
    ew = d["res"]["ethanol-water"]["rows"]
    print(f"  what the parameters bought, as a ratio of errors:")
    for name, _ in SYSTEMS:
        rows = d["res"][name]["rows"]
        print(f"    {name:22s} UNIFAC -> 2 parameters: "
              f"{rows[0]['rms'] / rows[2]['rms']:5.2f}x better in "
              f"{rows[0]['sym']}, "
              f"{rows[0]['rms_y'] / rows[2]['rms_y']:5.2f}x in y1 "
              f"(a ratio below 1 means the prediction wins)")
    print(f"  [analyse() took {d['elapsed']:.1f} s]")
    for p in write(build(d), SLUG):
        print("wrote", p)
