#!/usr/bin/env python3
"""F4.22  The module on one page: a decision map from question to number.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

WHAT THIS IS. The opening and closing slide of Module 4. Everything else in the
module answers one question; this answers the question of which question you
are in. It is a diagram, not a plot: there is no measured quantity on it, and
that is deliberate — a number here would be a number without a citation.

Every box carries the section of the deck it belongs to and, where one exists,
the figure that does the work:

    4.1  Four descriptions of one equilibrium      Raoult -> gamma-phi -> phi-phi
    4.2  Solution types and azeotropes             what the descriptions produce
    4.3  From measurement to activity coefficient  what gamma actually is
    4.4  Thermodynamic consistency                 can the data be believed
    4.5  Building a model from data                form, objective, uncertainty
    4.6  Using the model                           bubble, dew, flash, K, alpha
    4.7  The link to equations of state            where gamma-phi runs out

THE ONE CHECK THIS SCRIPT DOES RUN. A navigation aid that points at a figure
which does not exist, or a section that is not in the deck, is worse than no
navigation aid. So before drawing anything, the script reads
/home/claude/vle/qmd/vle.qmd and lists /home/claude/vle/qmd/figures, and
verifies that every section number and every figure reference printed on the
map is real. The result of that check is printed, and a failure is reported
rather than silently drawn.

THE SHAPE OF THE MAP. One spine, left to right, which is the ordinary path:

    what do you need  ->  is this a gamma-phi problem at all  ->  is there data
    ->  is the data consistent  ->  which form, fitted against which objective
    ->  the engineering output

with three branches hanging below it — no data, failed consistency,
more than two components — and the equation-of-state route running along the
top, because it is a different route and not a later step of the same one.

Run:  python3 f4_22.py       (under a second: it draws, it does not compute)
"""
from __future__ import annotations

import os
import re
import sys

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib                                                  # noqa: E402
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                    # noqa: E402
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch     # noqa: E402

from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY, PAPER,  # noqa: E402
                          RUST, SKYBLUE, SLATE, TEAL, use_style)

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_22_module_map"
QMD = os.environ.get("F4_QMD", "/home/claude/vle/qmd/vle.qmd")

W, H = 16.0, 9.0                      # the canvas, in the slide's own 16:9

# --------------------------------------------------------------------------
# The map, as data. Every box is (x, y) of its lower-left corner, its width and
# height, and the text that goes in it. Keeping the layout in one table is the
# only way a diagram this dense stays editable — and it is why the arrows below
# can be written as node pairs rather than as coordinates.
# --------------------------------------------------------------------------
NODES = {
    # ---------------------------------------------------------- the spine
    "start": dict(x=0.22, y=4.05, w=1.98, h=1.62, colour=INK, kind="start",
                  head="YOU NEED A NUMBER",
                  body="$K_i$, $y_i$, a bubble point,\n"
                       r"$\alpha_{12}$, a stage count",
                  tag="4.1"),
    "route": dict(x=2.46, y=4.05, w=2.14, h=1.62, colour=AMBER,
                  kind="decision",
                  head="IS THIS A $\\gamma$-$\\phi$ PROBLEM?",
                  body="low $P$, every component\nsub-critical, "
                       "$P_i^{sat}$ exists",
                  tag="4.1", fig="F4.1"),
    "gphi": dict(x=4.86, y=4.05, w=2.14, h=1.62, colour=TEAL, kind="action",
                 head="YES  ·  $\\gamma$-$\\phi$",
                 body="$y_i\\Phi_i P = x_i\\gamma_i P_i^{sat}$\n"
                      "decide $\\Phi_i$ against the noise",
                 tag="4.1, 4.3", fig="F4.1, F4.15"),
    "data": dict(x=7.26, y=4.05, w=2.14, h=1.62, colour=AMBER,
                 kind="decision",
                 head="IS THERE DATA?",
                 body="for EVERY binary in the\nmixture, with a DOI",
                 tag="4.3", fig="F4.11"),
    "consist": dict(x=9.66, y=4.05, w=2.14, h=1.62, colour=AMBER,
                    kind="decision",
                    head="CAN IT BE BELIEVED?",
                    body="area, point, direct,\nGibbs-Duhem, Herington",
                    tag="4.4", fig="F4.3, F4.4, F4.5"),
    "model": dict(x=12.06, y=4.05, w=2.14, h=1.62, colour=TEAL, kind="action",
                  head="FORM, AND OBJECTIVE",
                  body="shape first, then AIC;\nBarker on $P$ or $T$; state\n"
                       "the parameter uncertainty",
                  tag="4.5", fig="F4.6, F4.7, F4.16"),
    "out": dict(x=14.30, y=4.05, w=1.48, h=1.62, colour=NAVY, kind="output",
                head="THE OUTPUT",
                body="$K_i$, $\\alpha_{12}$,\nazeotrope,\n$N_{min}$",
                tag="4.2, 4.6", fig="F4.21"),
    # ------------------------------------------------- the top: the EoS route
    "eos": dict(x=2.46, y=6.62, w=2.14, h=1.62, colour=NAVY, kind="action",
                head="NO  ·  $\\phi$-$\\phi$",
                body="one cubic equation for\nBOTH phases; no $P_i^{sat}$\n"
                     "is needed anywhere",
                tag="4.1, 4.7", fig="F4.17"),
    "polar": dict(x=4.86, y=6.62, w=2.14, h=1.62, colour=AMBER,
                  kind="decision",
                  head="POLAR OR H-BONDING?",
                  body="i.e. is $G^E$ large enough\nto break a one-fluid rule",
                  tag="4.7", fig="F4.18"),
    "vdw": dict(x=7.26, y=6.62, w=2.94, h=1.62, colour=SKYBLUE, kind="action",
                head="NO  ·  CLASSICAL vdW ONE-FLUID",
                body="$a$, $b$ quadratic in $x$, one $k_{ij}$.\n"
                     "$k_{ij}$ is an ASSUMPTION — state it,\n"
                     "and state what it was fitted to",
                tag="4.7", fig="F4.18"),
    "gemix": dict(x=10.42, y=6.62, w=3.36, h=1.62, colour=NAVY, kind="action",
                  head="YES  ·  $G^E$ MIXING RULE",
                  body="Huron-Vidal, or Wong-Sandler if the\n"
                       "second virial must stay quadratic.\n"
                       "The activity model goes INSIDE the EoS",
                  tag="4.7", fig="F4.18"),
    # ----------------------------------------------------- the three branches
    "unifac": dict(x=7.26, y=1.72, w=2.14, h=1.72, colour=AMBER,
                   kind="action",
                   head="NO  ·  PREDICT IT",
                   body="UNIFAC. Name the revision\nand the parameter table.\n"
                        "Expect 1 to 3 times the\nexperimental uncertainty",
                   tag="4.5", fig="F4.20"),
    "failed": dict(x=9.66, y=1.72, w=2.14, h=1.72, colour=RUST, kind="action",
                   head="FAILED  ·  DIAGNOSE",
                   body="WHICH test failed is the\ninformation: end points,\n"
                        "a $y$ bias, or the isobaric\n$H^E$ term that "
                        "does not vanish",
                   tag="4.4", fig="F4.5"),
    "multi": dict(x=12.06, y=1.72, w=2.14, h=1.72, colour=TEAL, kind="action",
                  head="MORE THAN TWO?",
                  body="then NRTL or UNIQUAC —\nthey give N components\n"
                       "from BINARY parameters\nand no ternary parameter",
                  tag="4.5", fig="F4.19"),
    # ------------------------------------------------------- the closing box
    "close": dict(x=0.22, y=0.72, w=6.62, h=2.72, colour=GRAPHITE,
                  kind="closing",
                  head="A PARAMETER SET IS NOT A RESULT",
                  body="A result is a parameter set plus a statement of where "
                       "it may be used:\n"
                       "   ·  the data, with its DOI, and the uncertainty the "
                       "source reports\n"
                       "   ·  which consistency tests it passed, and which it "
                       "did not\n"
                       "   ·  the model form AND the objective it was fitted "
                       "against\n"
                       "   ·  the parameter uncertainty as a region, not two "
                       "numbers\n"
                       "   ·  the range of $T$, $P$ and $x$ in which the "
                       "answer may be quoted",
                  tag="4.5, 4.6", fig="F4.7, F4.8, F4.22"),
}

#: (from, to, label, side) — 'side' says which face of the boxes to leave from.
EDGES = [
    ("start", "route", "", "right"),
    ("route", "gphi", "yes", "right"),
    ("route", "eos", "no", "up"),
    ("eos", "polar", "", "right"),
    ("polar", "vdw", "no", "right"),
    ("polar", "gemix", "yes", "under"),
    ("gphi", "data", "", "right"),
    ("data", "consist", "yes", "right"),
    ("data", "unifac", "no", "down"),
    ("consist", "model", "passes", "right"),
    ("consist", "failed", "no", "down"),
    ("model", "out", "", "right"),
    ("model", "multi", "", "down-r"),
    ("unifac", "model", "", "join"),
    ("failed", "model", "", "join"),
    ("multi", "out", "", "rise"),
]


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


# --------------------------------------------------------------------------
def check_references(qmd=QMD, figdir=OUT):
    """Every section and figure named on the map must actually exist.

    A map is a navigation aid, and a navigation aid that points somewhere empty
    is worse than none. Sections are checked against the deck source, figures
    against the rendered PNGs on disk. F4.22 is this figure, so it is expected
    to be missing on the first run and present afterwards; that case is
    reported separately rather than treated as an error.
    """
    sections, figures = set(), set()
    for n in NODES.values():
        sections.update(s.strip() for s in n.get("tag", "").split(","))
        figures.update(s.strip() for s in n.get("fig", "").split(",") if s)

    try:
        src = open(qmd, encoding="utf-8").read()
    except OSError as exc:
        return dict(ok=False, note=f"could not read {qmd}: {exc}",
                    sections={}, figures={})

    sec_ok = {s: bool(re.search(rf"\b{re.escape(s)}\b", src))
              for s in sorted(sections) if s}
    have = os.listdir(figdir) if os.path.isdir(figdir) else []
    fig_ok = {}
    for f in sorted(figures):
        stem = "f4_" + f.split(".")[1].zfill(2) + "_"
        fig_ok[f] = any(h.startswith(stem) and h.endswith(".png")
                        for h in have)
    missing = ([s for s, v in sec_ok.items() if not v]
               + [f for f, v in fig_ok.items() if not v and f != "F4.22"])
    return dict(ok=not missing, sections=sec_ok, figures=fig_ok,
                missing=missing, note="")


# --------------------------------------------------------------------------
def box(ax, n):
    """One node: a rounded box, a head, a body, and its section tag."""
    kind = n["kind"]
    fc = PAPER
    lw = 2.0 if kind in ("decision", "start", "output") else 1.5
    ls = "--" if kind == "decision" else "-"
    ax.add_patch(FancyBboxPatch(
        (n["x"], n["y"]), n["w"], n["h"],
        boxstyle="round,pad=0.06,rounding_size=0.14",
        linewidth=lw, linestyle=ls, edgecolor=n["colour"], facecolor=fc,
        zorder=4))
    cx = n["x"] + n["w"] / 2
    top = n["y"] + n["h"]
    ax.text(cx, top - 0.26, n["head"], ha="center", va="center",
            fontsize=11.0 if kind != "closing" else 12.4, color=n["colour"],
            zorder=6)
    ax.text(cx if kind != "closing" else n["x"] + 0.16,
            top - 0.56 if kind != "closing" else top - 0.62,
            n["body"], ha="center" if kind != "closing" else "left",
            va="top", fontsize=9.6 if kind != "closing" else 10.4,
            color=GRAPHITE, linespacing=1.55, zorder=6)
    tag = "§ " + n["tag"] + (("   ·   " + n["fig"]) if n.get("fig") else "")
    ax.text(n["x"] + n["w"] - 0.10, n["y"] + 0.10, tag, ha="right",
            va="bottom", fontsize=8.2, color=SLATE, zorder=6)


def anchor(n, side):
    """A point on one face of a node, in data coordinates."""
    x, y, w, h = n["x"], n["y"], n["w"], n["h"]
    return {"right": (x + w, y + h / 2), "left": (x, y + h / 2),
            "up": (x + w / 2, y + h), "down": (x + w / 2, y),
            "up-left": (x + 0.25 * w, y + h),
            "up-right": (x + 0.75 * w, y + h),
            "down-left": (x + 0.25 * w, y),
            "down-right": (x + 0.75 * w, y)}[side]


def arrow(ax, a, b, label="", how="right"):
    """One edge. The routing is chosen by the edge's own 'side' entry."""
    style = dict(arrowstyle="-|>,head_width=0.20,head_length=0.36",
                 linewidth=1.6, color=SLATE, zorder=3,
                 shrinkA=1.0, shrinkB=1.0)
    if how == "right":
        p, q, cs = anchor(a, "right"), anchor(b, "left"), "arc3,rad=0"
    elif how == "up":
        p, q, cs = anchor(a, "up"), anchor(b, "down"), "arc3,rad=0"
    elif how == "down":
        p, q, cs = anchor(a, "down"), anchor(b, "up"), "arc3,rad=0"
    elif how == "down-r":
        p, q, cs = anchor(a, "down-right"), anchor(b, "up-right"), "arc3,rad=0"
    elif how == "under":                     # past a sibling box, underneath
        p, q, cs = anchor(a, "down"), anchor(b, "down"), "arc3,rad=-0.12"
    elif how == "rise":                      # out of a side, up into a bottom
        p, q, cs = anchor(a, "right"), anchor(b, "down"), "arc3,rad=-0.30"
    else:                                    # 'join': a branch rejoining
        p, q, cs = anchor(a, "up-right"), anchor(b, "down-left"), \
            "arc3,rad=-0.22"
    ax.add_patch(FancyArrowPatch(p, q, connectionstyle=cs, **style))
    if label:
        mx, my = 0.5 * (p[0] + q[0]), 0.5 * (p[1] + q[1])
        off = {"right": (0.0, 0.20), "under": (0.0, -0.46),
               "up": (0.30, 0.0), "down": (0.30, 0.0)}.get(how, (0.30, 0.0))
        ax.text(mx + off[0], my + off[1], label, ha="center", va="center",
                fontsize=9.0, color=SLATE, zorder=7,
                bbox=dict(boxstyle="round,pad=0.16", fc=PAPER, ec="none",
                          alpha=0.95))


def build(chk):
    use_style()
    fig, ax = plt.subplots(figsize=(W, H))
    ax.set_xlim(0, W)
    ax.set_ylim(0, H)
    ax.set_aspect("equal")
    ax.axis("off")

    # lane labels first, so every box sits on top of them
    ax.text(0.22, 8.62, "THE EQUATION-OF-STATE ROUTE — a different route, "
                        "not a later step of the same one",
            ha="left", va="center", fontsize=10.6, color=NAVY, zorder=2)
    ax.text(0.22, 5.94, "THE ORDINARY PATH", ha="left", va="center",
            fontsize=10.6, color=TEAL, zorder=2)
    ax.text(W - 0.22, 1.32, "WHEN THE ORDINARY PATH DOES NOT APPLY",
            ha="right", va="center", fontsize=10.6, color=RUST, zorder=2)
    ax.plot([0.22, W - 0.22], [8.42, 8.42], "-", color=MIST, lw=1.0, zorder=1)
    ax.plot([0.22, W - 0.22], [5.80, 5.80], "-", color=MIST, lw=1.0, zorder=1)

    for a, b, lab, how in EDGES:
        arrow(ax, NODES[a], NODES[b], lab, how)
    for n in NODES.values():
        box(ax, n)

    ax.set_title("Module 4 on one page: which question are you in, and which "
                 "section answers it",
                 fontsize=15.0, pad=10, color=INK)
    note = ("every box carries its deck section (§) and the figure that does "
            "the work.  Sections checked against vle.qmd and figures against "
            "the rendered PNGs: "
            + ("all resolve." if chk["ok"] else
               "MISSING — " + ", ".join(chk["missing"]) + "."))
    ax.text(W / 2, 0.16, note, ha="center", va="bottom", fontsize=9.4,
            color=SLATE if chk["ok"] else RUST, zorder=7)
    fig.tight_layout(rect=(0.004, 0.004, 0.996, 0.985))
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    chk = check_references()
    print("F4.22  the module map — a diagram, with no measured quantity on it")
    print(f"  deck source: {QMD}")
    print(f"  figure directory: {OUT}")
    print("  section references printed on the map, checked against the deck:")
    for s, ok in chk["sections"].items():
        print(f"    section {s:9s} {'found in vle.qmd' if ok else 'NOT FOUND'}")
    print("  figure references printed on the map, checked against the PNGs:")
    for f, ok in chk["figures"].items():
        state = ("rendered" if ok else
                 "not yet rendered (this figure)" if f == "F4.22"
                 else "MISSING")
        print(f"    {f:8s} {state}")
    if chk["missing"]:
        print(f"  -> {len(chk['missing'])} reference(s) do not resolve: "
              + ", ".join(chk["missing"]))
    else:
        print("  -> every section and every figure named on the map resolves")
    print(f"  {len(NODES)} boxes, {len(EDGES)} arrows, laid out on a "
          f"{W:g} x {H:g} canvas (the slide's own 16:9)")
    for p in write(build(chk), SLUG):
        print("wrote", p)
