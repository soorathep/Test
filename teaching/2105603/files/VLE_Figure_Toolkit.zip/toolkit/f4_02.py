#!/usr/bin/env python3
"""F4.2  The same system, drawn two ways: P-x-y and T-x-y.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

Ethanol (1) / water (2) with a two-parameter Margules model. The azeotrope is
located with `vlekit.flash.azeotrope`, which solves
gamma1 Psat1 = gamma2 Psat2 rather than reading a maximum off a curve — the
number printed on the figure is the root, not an eyeball estimate.

The isobaric azeotrope temperature is obtained by driving the azeotropic
pressure to 101.325 kPa with Brent, so both panels mark the *same* physical
state of the same model, one at fixed T and one at fixed P.

The Margules parameters are illustrative teaching values supplied with the
course blueprint, not a regression of experimental ethanol/water data; the
figure says so.

Run:  python3 f4_02.py
"""
import os
import sys

import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import brentq

sys.path.insert(0, "/home/claude/vlekit")
import vlekit as v                                              # noqa: E402
from vlekit.flash import azeotrope                              # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,     # noqa: E402
                          PAPER, RUST, SLATE, TEAL, use_style)
from vlekit.regress import bubble_P, bubble_T                   # noqa: E402

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_02_pxy_txy_azeotrope"

T_ISO = 323.15          # K, 50 C — well inside the Antoine range of both
P_ISO = 101.325         # kPa
A = [1.6, 0.9]          # Margules-2, illustrative


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


def build():
    c1, c2 = v.component("ethanol"), v.component("water")
    m = v.Margules(A)

    # ---------------------------------------------------------- isothermal
    x = np.linspace(1e-5, 1 - 1e-5, 601)
    P, y = bubble_P(m, x, np.full_like(x, T_ISO), c1, c2)
    az_P = azeotrope(m, T_ISO, c1, c2)

    # ------------------------------------------------------------ isobaric
    # the azeotropic temperature is the T at which the azeotropic pressure
    # equals the operating pressure
    T_az = brentq(lambda T: azeotrope(m, T, c1, c2)["P"] - P_ISO,
                  330.0, 375.0, xtol=1e-10)
    az_T = azeotrope(m, T_az, c1, c2)

    xb = np.linspace(1e-4, 1 - 1e-4, 241)
    Tb, yb = bubble_T(m, xb, np.full_like(xb, P_ISO), c1, c2)

    use_style()
    fig, (axL, axR) = plt.subplots(1, 2, figsize=(12.4, 5.0))

    # ------------------------------------------------------------- panel a
    axL.grid(True, zorder=0)
    axL.set_axisbelow(True)
    axL.plot(x, P, "-", color=NAVY, lw=2.4, label="bubble  $P$–$x_1$")
    axL.plot(y, P, "--", color=RUST, lw=2.4, label="dew  $P$–$y_1$")
    axL.plot([az_P["x1"]], [az_P["P"]], "o", color=AMBER, ms=11,
             mec=GRAPHITE, mew=1.2, zorder=6)
    axL.plot([0, az_P["x1"]], [az_P["P"]] * 2, ":", color=AMBER, lw=1.2,
             zorder=1)
    axL.annotate(f"azeotrope\n$x_1 = y_1 = {az_P['x1']:.4f}$\n"
                 f"$P = {az_P['P']:.2f}$ kPa",
                 xy=(az_P["x1"], az_P["P"]), xytext=(0.47, 0.985),
                 textcoords="axes fraction", ha="center", va="top",
                 fontsize=11, color=INK, linespacing=1.45, zorder=7,
                 bbox=dict(boxstyle="round,pad=0.34", fc=PAPER, ec=AMBER,
                           lw=1.1, alpha=0.90),
                 arrowprops=dict(arrowstyle="-", color=AMBER, lw=1.2,
                                 shrinkA=4, shrinkB=6))
    axL.set_xlabel("$x_1$,  $y_1$   (ethanol)")
    axL.set_ylabel("$P$ / kPa")
    axL.set_xlim(0, 1)
    axL.set_ylim(0.90 * float(np.min(P)), 1.28 * float(np.max(P)))
    axL.legend(loc="lower right", fontsize=11.5)
    axL.set_title(f"(a)  isothermal, $T$ = {T_ISO:.2f} K", fontsize=13.5)
    axL.text(0.07, 0.93, "liquid", transform=axL.transAxes, fontsize=11.5,
             color=NAVY, ha="left", va="center")
    axL.text(0.30, 0.055, "vapour", transform=axL.transAxes, fontsize=11.5,
             color=RUST, ha="center", va="center")

    # ------------------------------------------------------------- panel b
    axR.grid(True, zorder=0)
    axR.set_axisbelow(True)
    axR.plot(xb, Tb, "-", color=NAVY, lw=2.4, label="bubble  $T$–$x_1$")
    axR.plot(yb, Tb, "--", color=RUST, lw=2.4, label="dew  $T$–$y_1$")
    axR.plot([az_T["x1"]], [T_az], "o", color=AMBER, ms=11,
             mec=GRAPHITE, mew=1.2, zorder=6)
    axR.plot([0, az_T["x1"]], [T_az] * 2, ":", color=AMBER, lw=1.2, zorder=1)
    axR.annotate(f"azeotrope\n$x_1 = y_1 = {az_T['x1']:.4f}$\n"
                 f"$T = {T_az:.2f}$ K",
                 xy=(az_T["x1"], T_az), xytext=(0.30, 0.020),
                 textcoords="axes fraction", ha="center", va="bottom",
                 fontsize=11, color=INK, linespacing=1.45, zorder=7,
                 bbox=dict(boxstyle="round,pad=0.34", fc=PAPER, ec=AMBER,
                           lw=1.1, alpha=0.90),
                 arrowprops=dict(arrowstyle="-", color=AMBER, lw=1.2,
                                 shrinkA=4, shrinkB=6))
    axR.set_xlabel("$x_1$,  $y_1$   (ethanol)")
    axR.set_ylabel("$T$ / K")
    axR.set_xlim(0, 1)
    lo, hi = float(np.nanmin(Tb)), float(np.nanmax(Tb))
    axR.set_ylim(lo - 0.50 * (hi - lo), hi + 0.09 * (hi - lo))
    axR.legend(loc="upper right", fontsize=11.5)
    axR.set_title(f"(b)  isobaric, $P$ = {P_ISO:g} kPa", fontsize=13.5)
    axR.text(0.46, 0.93, "vapour", transform=axR.transAxes, fontsize=11.5,
             color=RUST, ha="center", va="center")
    axR.text(0.72, 0.10, "liquid", transform=axR.transAxes, fontsize=11.5,
             color=NAVY, ha="center", va="center")

    fig.suptitle("Ethanol (1) / water (2), Margules-2 with "
                 f"$A_{{12}}$ = {A[0]:g}, $A_{{21}}$ = {A[1]:g}",
                 fontsize=14.5, y=1.005)
    fig.text(0.5, -0.045,
             "Illustrative Margules parameters from the course blueprint, not "
             "a regression of measured ethanol/water data.  Azeotrope located "
             "with vlekit.flash.azeotrope.",
             ha="center", va="center", fontsize=10.5, color=SLATE)
    fig.tight_layout()
    return fig, az_P, az_T, T_az


if __name__ == "__main__":
    fig, az_P, az_T, T_az = build()
    print(f"isothermal azeotrope at {T_ISO:.2f} K : "
          f"x1 = {az_P['x1']:.5f}, P = {az_P['P']:.3f} kPa ({az_P['kind']})")
    print(f"isobaric   azeotrope at {P_ISO:g} kPa: "
          f"x1 = {az_T['x1']:.5f}, T = {T_az:.3f} K")
    for p in write(fig, SLUG):
        print("wrote", p)
