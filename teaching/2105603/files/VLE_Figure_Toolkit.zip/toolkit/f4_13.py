#!/usr/bin/env python3
"""F4.13  The azeotrope moves with pressure — which is why it can be beaten.

2105603 Advanced Chemical Engineering Thermodynamics — Module 4
Soorathep Kheawhom, Chulalongkorn University

Ethanol (1) + water (2), the Type 3 set in `vlekit.datasets`:
Kamihama et al., J. Chem. Eng. Data 2012, 57, 339-344,
https://doi.org/10.1021/je2008704, 21 points at 101.3 kPa.

NRTL (alpha = 0.3) is fitted to that set by Barker's method — only T and x1
enter the objective — and the fitted parameters are then held FIXED while the
pressure is varied. The azeotropic composition at each pressure is a root of

    gamma_1(x) Psat_1(T) = gamma_2(x) Psat_2(T)

found by `vlekit.flash.azeotrope`, with T driven by Brent until the azeotropic
pressure equals the target. Two columns operating at the two marked pressures
have different composition ceilings, and the gap between them is the whole of
pressure-swing distillation.

THE EXTRAPOLATION, STATED PLAINLY AND ALSO ON THE FIGURE
The tau values are fitted at one condition: 101.3 kPa, over 351-368 K. They
carry no temperature dependence of their own — tau_ij is a number, not
exp(-du_ij/RT) — so in this calculation gamma(x) is the same function at every
pressure and the entire movement of the azeotrope comes from Psat_1/Psat_2,
which is a strong function of T. That is a real effect and it is the dominant
one, but it is not the whole effect: the true G^E of ethanol + water does
change with temperature, and a parameter set fitted at 101 kPa has no way to
know about it. Everything outside the shaded band on the figure is
extrapolation, and the figure says so.

WHAT THE MODEL PREDICTS THAT IS WORTH CHECKING AGAINST THE LITERATURE
The azeotrope vanishes below a pressure this script computes rather than
quotes: the condition is alpha_12(x1 -> 1) = 1, i.e.
Psat_1(T)/Psat_2(T) = gamma_2^inf, and its root is printed. The commonly cited
experimental value is near 9 kPa; the number here is what THIS model and THESE
Antoine constants give, and the difference is reported rather than hidden.

Run:  python3 f4_13.py
"""
from __future__ import annotations

import os
import sys

import numpy as np
from scipy.optimize import brentq

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib                                                  # noqa: E402
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                    # noqa: E402

import vlekit as v                                                 # noqa: E402
from vlekit import datasets as D                                   # noqa: E402
from vlekit.flash import azeotrope                                 # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY, PAPER,  # noqa: E402
                          RUST, SKYBLUE, SLATE, TEAL, use_style)
from vlekit.regress import bubble_T                                # noqa: E402

OUT = os.environ.get("F4_OUT", "/home/claude/vle/qmd/figures")
SLUG = "f4_13_azeotrope_pressure_shift"

P_LO, P_HI = 15.0, 1000.0          # the two marked column pressures, kPa
P_RANGE = (8.0, 1600.0)


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


# --------------------------------------------------------------------------
def az_at_P(model, P, c1, c2, T_bracket=(280.0, 520.0)):
    """The azeotrope whose pressure is P. Brent on azeotrope(T)['P'] - P."""
    def f(T):
        a = azeotrope(model, T, c1, c2)
        return np.nan if a is None else a["P"] - P

    lo, hi = T_bracket
    flo, fhi = f(lo), f(hi)
    if not np.isfinite(flo) or not np.isfinite(fhi) or flo * fhi > 0:
        return None
    T = brentq(f, lo, hi, xtol=1e-10)
    a = azeotrope(model, T, c1, c2)
    a["T"] = T
    return a


def analyse():
    dat = D.ethanol_water()
    fit = v.fit(dat, "nrtl")
    m, c1, c2 = fit.model, dat.c1, dat.c2

    # the pressure at which the azeotrope disappears: alpha_12(x1 -> 1) = 1
    g2inf = float(np.exp(m.ln_gamma(np.array([1 - 1e-12]))[1][0]))
    T_van = brentq(lambda T: c1.Psat(T) / c2.Psat(T) / g2inf - 1.0,
                   250.0, 450.0, xtol=1e-10)
    P_van = float(c1.Psat(T_van))

    Ps = np.geomspace(max(P_RANGE[0], 1.02 * P_van), P_RANGE[1], 121)
    rows = []
    for P in Ps:
        a = az_at_P(m, P, c1, c2, (T_van + 0.05, 560.0))
        if a is not None:
            rows.append((P, a["x1"], a["T"]))
    Pa = np.array([r[0] for r in rows])
    xa = np.array([r[1] for r in rows])
    Ta = np.array([r[2] for r in rows])

    marks = {}
    for P in (P_LO, P_HI):
        a = az_at_P(m, P, c1, c2, (T_van + 0.05, 560.0))
        marks[P] = a

    # x-y curves at the two column pressures
    xy = {}
    for P in (P_LO, P_HI):
        x = np.linspace(1e-4, 1 - 1e-4, 241)
        T, y = bubble_T(m, x, np.full_like(x, P), c1, c2)
        xy[P] = (x, y, T)

    # the composition ceiling of each column, and the gap
    gap = marks[P_HI]["x1"] - marks[P_LO]["x1"]

    # the azeotrope of the same model at the pressure the data were taken at
    a101 = az_at_P(m, float(np.mean(dat.P)), c1, c2, (T_van + 0.05, 560.0))

    # the crossing read straight out of the published table, for comparison
    d = dat.sorted_by_x()
    f = d.y1 - d.x1
    i = int(np.where(np.sign(f[:-1]) * np.sign(f[1:]) < 0)[0][0])
    t = -f[i] / (f[i + 1] - f[i])
    x_data = float(d.x1[i] + t * (d.x1[i + 1] - d.x1[i]))

    return dict(dat=dat, fit=fit, m=m, Pa=Pa, xa=xa, Ta=Ta, marks=marks,
                xy=xy, gap=gap, P_van=P_van, T_van=T_van, g2inf=g2inf,
                a101=a101, x_data=x_data,
                Tdata=(float(dat.T.min()), float(dat.T.max())))



# --------------------------------------------------------------------------
class Placer:
    """A coarse occupancy grid over one axes, used to place labels.

    Everything already drawn is marked on the grid; each label then takes the
    emptiest rectangle of the size it needs, biased towards the point it
    names, and marks that rectangle occupied. No annotation position on this
    figure is typed in, so no two of them can collide.
    """

    def __init__(self, ax, nx=54, ny=42):
        self.ax, self.nx, self.ny = ax, nx, ny
        self.g = np.zeros((ny, nx))

    def frac(self, x, y):
        pts = self.ax.transData.transform(
            np.column_stack([np.asarray(x, dtype=float),
                             np.asarray(y, dtype=float)]))
        return self.ax.transAxes.inverted().transform(pts).T

    def occupy(self, x, y, pad=1):
        fx, fy = self.frac(x, y)
        i = np.clip((fy * self.ny).astype(int), 0, self.ny - 1)
        j = np.clip((fx * self.nx).astype(int), 0, self.nx - 1)
        for a, b in zip(i, j):
            self.g[max(0, a - pad):a + pad + 1,
                   max(0, b - pad):b + pad + 1] += 1.0

    def place(self, w, h, anchor=None, pull=5.0, margin=0.012):
        cw = max(1, int(round(w * self.nx)))
        ch = max(1, int(round(h * self.ny)))
        m = max(1, int(round(margin * self.nx)))
        best, score, cells = (margin, 1 - h - margin), None, None
        for i in range(m, self.ny - ch - m + 1):
            for j in range(m, self.nx - cw - m + 1):
                s = float(self.g[i:i + ch, j:j + cw].sum())
                if anchor is not None:
                    cx, cy = (j + 0.5 * cw) / self.nx, (i + 0.5 * ch) / self.ny
                    s += pull * float(np.hypot(cx - anchor[0], cy - anchor[1]))
                if score is None or s < score:
                    score, best, cells = s, (j / self.nx, i / self.ny), (i, j)
        i, j = cells
        self.g[max(0, i - 1):i + ch + 1, max(0, j - 1):j + cw + 1] += 60.0
        return best[0] + 0.5 * w, best[1] + 0.5 * h


# --------------------------------------------------------------------------
def build(d):
    use_style()
    fig, (axL, axR) = plt.subplots(1, 2, figsize=(14.0, 5.9),
                                   gridspec_kw={"width_ratios": [1.16, 1.0]})
    dat = d["dat"]

    # ================================================================= left
    axL.grid(True, zorder=0)
    axL.set_axisbelow(True)
    axL.set_xscale("log")
    axL.set_xlim(d["Pa"].min() * 0.78, d["Pa"].max() * 1.9)
    axL.set_ylim(0.800, 1.008)

    # the band of pressures the fitted temperature range actually covers
    Pband = np.array([d["Pa"][np.argmin(np.abs(d["Ta"] - d["Tdata"][0]))],
                      d["Pa"][np.argmin(np.abs(d["Ta"] - d["Tdata"][1]))]])
    axL.axvspan(Pband.min(), Pband.max(), color=MIST, alpha=0.50, zorder=0)

    aL, aH = d["marks"][P_LO], d["marks"][P_HI]
    P_arrow = d["Pa"].max() * 1.45
    for yv, col in ((aL["x1"], TEAL), (aH["x1"], RUST)):
        axL.plot(axL.get_xlim(), [yv, yv], ":", color=col, lw=1.2, zorder=2)
    axL.plot(d["Pa"], d["xa"], "-", color=NAVY, lw=2.6, zorder=4)
    axL.axvline(d["P_van"], color=RUST, lw=1.6, ls=":", zorder=3)
    for P, col in ((P_LO, TEAL), (P_HI, RUST)):
        axL.plot([P], [d["marks"][P]["x1"]], "o", color=col, ms=11,
                 mec=GRAPHITE, mew=1.2, zorder=6)
    axL.annotate("", xy=(P_arrow, aH["x1"]), xytext=(P_arrow, aL["x1"]),
                 arrowprops=dict(arrowstyle="<->", color=AMBER, lw=2.6,
                                 shrinkA=0, shrinkB=0), zorder=7)

    pl = Placer(axL)
    pl.occupy(d["Pa"], d["xa"], pad=1)
    pl.occupy(np.full(60, P_arrow), np.linspace(aH["x1"], aL["x1"], 60), pad=1)
    pl.occupy(np.full(60, d["P_van"]), np.linspace(0.80, 1.008, 60), pad=1)
    pl.occupy(np.geomspace(*axL.get_xlim(), 80), np.full(80, aL["x1"]), pad=0)
    pl.occupy(np.geomspace(*axL.get_xlim(), 80), np.full(80, aH["x1"]), pad=0)

    def annotate(ax, placer, text, xy, w, h, col, fs=10.2):
        ax_, ay_ = placer.frac([xy[0]], [xy[1]])
        cx, cy = placer.place(w, h, anchor=(float(ax_[0]), float(ay_[0])))
        ax.annotate(text, xy=xy, xycoords="data", xytext=(cx, cy),
                    textcoords="axes fraction", ha="center", va="center",
                    fontsize=fs, color=col, linespacing=1.45, zorder=9,
                    bbox=dict(boxstyle="round,pad=0.26", fc=PAPER, ec=col,
                              lw=1.05, alpha=0.96),
                    arrowprops=dict(arrowstyle="-", color=col, lw=1.1,
                                    shrinkA=3, shrinkB=6))

    annotate(axL, pl,
             f"$\\Delta x_{{\\rm az}}$ = {abs(d['gap']):.3f}\n"
             "mole fraction of ethanol\nbetween the two ceilings",
             (P_arrow, 0.5 * (aL["x1"] + aH["x1"])), 0.34, 0.155, "#9A6412",
             fs=10.6)
    annotate(axL, pl,
             f"{P_LO:g} kPa\n$x_{{\\rm az}}$ = {aL['x1']:.4f}\n"
             f"$T$ = {aL['T']:.1f} K", (P_LO, aL["x1"]), 0.23, 0.155, TEAL)
    annotate(axL, pl,
             f"{P_HI:g} kPa\n$x_{{\\rm az}}$ = {aH['x1']:.4f}\n"
             f"$T$ = {aH['T']:.1f} K", (P_HI, aH["x1"]), 0.23, 0.155, RUST)
    annotate(axL, pl,
             f"no azeotrope below {d['P_van']:.2f} kPa\n"
             f"({d['T_van']:.1f} K), where\n"
             r"$P_1^{\rm sat}/P_2^{\rm sat} = \gamma_2^{\infty}$ = "
             f"{d['g2inf']:.3f}", (d["P_van"], 0.965), 0.33, 0.155, RUST,
             fs=9.8)
    annotate(axL, pl,
             "the fit's own range,\n"
             f"{d['Tdata'][0]:.1f}–{d['Tdata'][1]:.1f} K.  Outside it\n"
             "this curve is EXTRAPOLATION",
             (float(np.sqrt(Pband.min() * Pband.max())), 0.83), 0.36, 0.155,
             SLATE, fs=9.8)

    axL.set_xlabel("$P$ / kPa   (logarithmic)")
    axL.set_ylabel(r"azeotropic composition  $x_{\rm az}$  (ethanol)")
    axL.set_title("(a)  where the azeotrope sits, as a function of pressure",
                  fontsize=12.6, pad=8)

    # ================================================================ right
    axR.grid(True, zorder=0)
    axR.set_axisbelow(True)
    axR.set_xlim(0, 1)
    axR.set_ylim(0, 1)
    axR.set_aspect("equal")
    axR.plot([0, 1], [0, 1], "-", color=GRAPHITE, lw=1.2, zorder=2)
    axR.axvspan(d["marks"][P_HI]["x1"], d["marks"][P_LO]["x1"],
                color=AMBER, alpha=0.22, zorder=1)
    for P, col in ((P_LO, TEAL), (P_HI, RUST)):
        x, y, T = d["xy"][P]
        axR.plot(x, y, "-", color=col, lw=2.5, zorder=4)
        a = d["marks"][P]
        axR.plot([a["x1"]], [a["x1"]], "o", color=col, ms=10, mec=GRAPHITE,
                 mew=1.2, zorder=6)

    pr = Placer(axR)
    pr.occupy(np.linspace(0, 1, 80), np.linspace(0, 1, 80), pad=1)
    for P in (P_LO, P_HI):
        x, y, _ = d["xy"][P]
        pr.occupy(x, y, pad=1)
    pr.occupy(np.full(40, 0.5 * (d["marks"][P_HI]["x1"]
                                 + d["marks"][P_LO]["x1"])),
              np.linspace(0.05, 0.55, 40), pad=1)
    axR.text(0.5 * (d["marks"][P_HI]["x1"] + d["marks"][P_LO]["x1"]), 0.30,
             "the swing\nwindow", ha="center", va="center", fontsize=10.4,
             color="#9A6412", linespacing=1.4, zorder=5, rotation=90)
    for P, col in ((P_LO, TEAL), (P_HI, RUST)):
        a = d["marks"][P]
        annotate(axR, pr,
                 f"{P:g} kPa,  $T_{{\\rm az}}$ = {a['T']:.1f} K\n"
                 f"$x_{{\\rm az}} = y_{{\\rm az}}$ = {a['x1']:.4f}",
                 (a["x1"], a["x1"]), 0.44, 0.115, col, fs=10.0)

    axR.set_xlabel("$x_1$   (ethanol, liquid)")
    axR.set_ylabel("$y_1$   (ethanol, vapour)")
    axR.set_title("(b)  the two columns of a pressure swing",
                  fontsize=12.6, pad=8)

    fig.suptitle("Pressure-swing distillation of ethanol + water:  the "
                 "azeotrope is a property of the pressure, not of the mixture",
                 fontsize=14.4, y=1.005)
    fig.text(0.5, -0.085,
             "MODEL: NRTL ($\\alpha$ = 0.3, "
             f"$\\tau_{{12}}$ = {d['fit'].params[0]:+.4f}, "
             f"$\\tau_{{21}}$ = {d['fit'].params[1]:+.4f}) fitted by Barker's "
             "method to Kamihama et al. 2012, doi:10.1021/je2008704 — 21 "
             f"points, 101.3 kPa, 351.3–368.2 K, rms $\\delta T$ = "
             f"{d['fit'].rms_T:.3f} K.  $P_i^{{\\rm sat}}$ from "
             "vlekit.data.LIBRARY.\n"
             "THE PARAMETERS ARE HELD FIXED AS $P$ IS VARIED. $\\tau_{ij}$ "
             "carries no temperature dependence of its own, so in this "
             r"calculation the whole shift comes from $P_1^{\rm sat}/"
             r"P_2^{\rm sat}(T)$; the real $G^E$ also changes with $T$, and a "
             "fit at one pressure cannot know how.\n"
             f"For scale: at 101.3 kPa this model puts the azeotrope at "
             f"$x_1$ = {d['a101']['x1']:.4f} where the published table gives "
             f"{d['x_data']:.4f}, a difference of "
             f"{abs(d['a101']['x1'] - d['x_data']):.4f} in mole fraction.",
             ha="center", va="center", fontsize=10.0, color=SLATE,
             linespacing=1.6)
    fig.tight_layout(rect=(0, 0.0, 1, 0.945))
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = analyse()
    f = d["fit"]
    print(f"ethanol + water, doi:{D.DOIS['ethanol-water']}, "
          f"{len(d['dat'])} points at {float(np.mean(d['dat'].P)):g} kPa")
    print(f"  NRTL by Barker: tau12 = {f.params[0]:+.5f}, "
          f"tau21 = {f.params[1]:+.5f}, alpha = 0.3;  rms dT = {f.rms_T:.4f} K,"
          f"  rms dy1 = {f.rms_y:.5f}")
    print(f"  gamma_2^inf = {d['g2inf']:.4f}")
    print(f"  azeotrope vanishes at T = {d['T_van']:.3f} K, "
          f"P = {d['P_van']:.3f} kPa "
          f"(condition Psat1/Psat2 = gamma_2^inf)")
    print(f"  model azeotrope at 101.3 kPa: x1 = {d['a101']['x1']:.4f}, "
          f"T = {d['a101']['T']:.2f} K;  published table gives "
          f"x1 = {d['x_data']:.4f} "
          f"(difference {d['a101']['x1'] - d['x_data']:+.4f})")
    print()
    print("  azeotropic composition against pressure (fixed NRTL parameters):")
    print(f"    {'P / kPa':>10s} {'T / K':>9s} {'x_az':>9s}")
    for P in (10.0, 15.0, 25.0, 50.0, 101.3, 200.0, 400.0, 700.0, 1000.0,
              1600.0):
        a = az_at_P(d["m"], P, d["dat"].c1, d["dat"].c2,
                    (d["T_van"] + 0.05, 560.0))
        if a is None:
            print(f"    {P:10.1f} {'—':>9s} {'no azeotrope':>9s}")
        else:
            print(f"    {P:10.1f} {a['T']:9.2f} {a['x1']:9.4f}")
    print()
    print(f"  pressure swing {P_LO:g} kPa -> {P_HI:g} kPa moves the ceiling "
          f"from x1 = {d['marks'][P_LO]['x1']:.4f} to "
          f"{d['marks'][P_HI]['x1']:.4f}, a window of "
          f"{abs(d['gap']):.4f} in mole fraction")
    print(f"  temperature range of the fitted data: "
          f"{d['Tdata'][0]:.2f}-{d['Tdata'][1]:.2f} K;  the {P_HI:g} kPa point "
          f"is at {d['marks'][P_HI]['T']:.2f} K, i.e. "
          f"{d['marks'][P_HI]['T'] - d['Tdata'][1]:+.1f} K outside it")
    for p in write(build(d), SLUG):
        print("wrote", p)
