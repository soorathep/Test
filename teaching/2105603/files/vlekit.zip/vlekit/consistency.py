"""Thermodynamic consistency tests for binary VLE data.

Every test in this file is one way of asking the same question: does the
reported dataset satisfy the Gibbs-Duhem equation? It cannot be answered by
looking at the scatter of the points, because a smooth dataset can be smoothly
wrong. It is answered by using the fact that x, y, T and P are not independent
— the Gibbs-Duhem equation ties them together, so one of the four is redundant
and can be predicted from the other three. The size of the prediction error is
the test.

The tests differ in what they discard and what they therefore detect:

    area / Redlich-Kister   integral over the whole composition range, so it
                            is insensitive to errors that change sign, and it
                            passes datasets it should not. Kept because it is
                            ubiquitous in the literature and students must be
                            able to say why it is weak.
    Herington              the area test with an empirical allowance for the
                            temperature variation of an isobaric set.
    point (VNBG)           fit G^E to P-x only, predict y, compare with the
                            measured y. Uses every point, so errors cannot
                            cancel.
    direct (Van Ness 1995) residuals in ln(gamma1/gamma2) against the same
                            Barker fit; reports the 1-10 index used by the
                            journals.
    infinite dilution      Kojima's endpoint check, which catches the region
                            where measurement is hardest and models are least
                            constrained.

A dataset that fails is not necessarily wrong. It may be that the vapour phase
was treated as ideal when it is not, or that the vapour pressure correlation is
being extrapolated. Distinguishing those is the point of running the tests with
different `vapour` settings and watching what moves.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


# --------------------------------------------------------------------------
@dataclass
class TestResult:
    """One test's verdict, kept together with the number that produced it."""

    name: str
    statistic: float
    threshold: float
    passed: bool
    index: int = 0                  # 1-10 Van Ness scale where defined
    detail: dict = None
    note: str = ""

    def __repr__(self):
        v = "pass" if self.passed else "FAIL"
        idx = f", index {self.index}" if self.index else ""
        return (f"<{self.name}: {self.statistic:.4g} "
                f"(threshold {self.threshold:g}) {v}{idx}>")


# --------------------------------------------------------------------------
# Redlich-Kister smoothing, shared by several tests
# --------------------------------------------------------------------------
def rk_fit(x1, f, order=4, w=None):
    """Least-squares fit of f(x1) by a polynomial in z = 2 x1 - 1.

    The Redlich-Kister expansion is exactly this: a polynomial in the
    composition variable centred on the equimolar point. Fitting the *ratio*
    ln(gamma1/gamma2) rather than each gamma separately is what lets the area
    test be evaluated to the pure end points, where the data usually stop
    short.
    """
    x1 = np.asarray(x1, dtype=float)
    f = np.asarray(f, dtype=float)
    good = np.isfinite(x1) & np.isfinite(f)
    x1, f = x1[good], f[good]
    if w is not None:
        w = np.asarray(w, dtype=float)[good]
    z = 2 * x1 - 1
    order = min(order, len(x1) - 1)
    V = np.vander(z, order + 1, increasing=True)
    if w is None:
        c, *_ = np.linalg.lstsq(V, f, rcond=None)
    else:
        sw = np.sqrt(w)
        c, *_ = np.linalg.lstsq(V * sw[:, None], f * sw, rcond=None)
    return c


def rk_eval(c, x1):
    z = 2 * np.asarray(x1, dtype=float) - 1
    return np.polyval(c[::-1], z)


def rk_integral_01(c):
    """int_0^1 f dx1 for f expanded in z = 2x1-1.

    dx1 = dz/2 and z runs -1 to 1, so odd powers integrate to zero and the
    even ones give 2/(k+1). The odd terms dropping out is not an accident: a
    symmetric excess Gibbs energy has an antisymmetric ln(gamma1/gamma2), whose
    area vanishes identically. Only the *even* Redlich-Kister coefficients of
    the ratio can make a dataset fail the area test.
    """
    tot = 0.0
    for k, ck in enumerate(c):
        if k % 2 == 0:
            tot += ck / (k + 1)
    return tot


# --------------------------------------------------------------------------
# 1. Area test / Redlich-Kister
# --------------------------------------------------------------------------
def area_test(dat, vapour="ideal", order=4, threshold=10.0, extrapolate=True):
    """The Redlich-Kister area test.

        D = 100 |int_0^1 ln(g1/g2) dx1| / int_0^1 |ln(g1/g2)| dx1

    For an isothermal set the integral is zero when the data obey Gibbs-Duhem
    and the excess volume is neglected. D is the imbalance expressed as a
    percentage of the total area, so it does not depend on how non-ideal the
    system is.

    extrapolate=True fits a Redlich-Kister polynomial and integrates it over
    the full range, which is the only defensible way to reach x1 = 0 and 1 when
    the data stop at 0.05 and 0.95. Setting it False integrates the data
    directly by the trapezoidal rule over whatever range they cover, and
    reports that range in `detail`.
    """
    d = dat.sorted_by_x()
    g1, g2 = d.gamma(vapour)
    m = d.interior() & np.isfinite(g1) & np.isfinite(g2) & (g1 > 0) & (g2 > 0)
    x, r = d.x1[m], np.log(g1[m] / g2[m])
    if len(x) < 4:
        raise ValueError("area test needs at least four interior points")

    if extrapolate:
        c = rk_fit(x, r, order)
        xs = np.linspace(0.0, 1.0, 2001)
        rs = rk_eval(c, xs)
        num = abs(rk_integral_01(c))
        den = np.trapezoid(np.abs(rs), xs)
        detail = {"mode": "RK extrapolated", "order": len(c) - 1,
                  "coeffs": c,
                  "ln_gamma1_inf": rk_eval(c, 0.0),
                  "ln_gamma2_inf": -rk_eval(c, 1.0),
                  "rms_fit": float(np.sqrt(np.mean((rk_eval(c, x) - r) ** 2)))}
    else:
        num = abs(np.trapezoid(r, x))
        den = np.trapezoid(np.abs(r), x)
        detail = {"mode": "trapezoid over data", "x_range": (x[0], x[-1])}

    D = 100.0 * num / den if den > 0 else np.inf
    return TestResult("area (Redlich-Kister)", D, threshold, D < threshold,
                      detail=detail,
                      note=("An area test can only fail on the even "
                            "Redlich-Kister coefficients of ln(g1/g2); a "
                            "symmetric error is invisible to it."))


# --------------------------------------------------------------------------
# 2. Herington, for isobaric data
# --------------------------------------------------------------------------
def herington_test(dat, vapour="ideal", order=4, threshold=10.0):
    """Herington's D-J test for isobaric data.

        J = 150 (Tmax - Tmin) / Tmin,   pass if |D - J| < 10

    The J term is an empirical allowance for the fact that an isobaric set
    changes temperature across the composition range, so the excess enthalpy
    term in the Gibbs-Duhem equation no longer vanishes. It is a correlation,
    not a derivation, and Wisniak has shown it can both pass bad data and fail
    good data. Reported here because reviewers still ask for it.
    """
    if dat.kind != "isobaric":
        raise ValueError("Herington's test is defined for isobaric data")
    a = area_test(dat, vapour, order)
    Tmin, Tmax = float(np.min(dat.T)), float(np.max(dat.T))
    J = 150.0 * (Tmax - Tmin) / Tmin
    stat = abs(a.statistic - J)
    return TestResult("Herington D-J", stat, threshold, stat < threshold,
                      detail={"D": a.statistic, "J": J, "Tmin": Tmin, "Tmax": Tmax},
                      note="Empirical; Wisniak's criticism is worth quoting alongside it.")


# --------------------------------------------------------------------------
# 3. Point test (Van Ness-Byer-Gibbs)
# --------------------------------------------------------------------------
_POINT_SCALE = [0.002, 0.005, 0.008, 0.010, 0.012, 0.015, 0.020, 0.025, 0.030]
_DIRECT_SCALE = [0.025, 0.050, 0.075, 0.100, 0.125, 0.150, 0.175, 0.200, 0.225]


def _index(value, scale):
    for i, s in enumerate(scale, start=1):
        if value < s:
            return i
    return 10


def point_test(dat, model="margules", vapour="ideal", threshold=0.01, fit=None):
    """Van Ness-Byer-Gibbs point test: fit P-x only, then predict y.

    The logic is worth stating plainly to students. Barker's method uses only
    the pressures and the liquid compositions; the vapour compositions never
    enter the objective. If the data satisfy Gibbs-Duhem, the y values are
    already implied by the P-x curve, and the fit must reproduce them. If they
    do not, the measured y and the implied y disagree, and the size of that
    disagreement is a property of the data, not of the model — provided the
    model is flexible enough to follow the P-x curve, which is why the residual
    in P is reported alongside.
    """
    from .regress import barker_fit               # local, avoids a cycle

    fit = fit or barker_fit(dat, model, vapour=vapour)
    dy = fit.y1_calc - dat.y1
    m = np.isfinite(dy) & dat.interior()
    mad = float(np.mean(np.abs(dy[m])))
    idx = _index(mad, _POINT_SCALE)
    return TestResult("point (Van Ness-Byer-Gibbs)", mad, threshold,
                      mad < threshold, index=idx,
                      detail={"dy": dy, "rms_P": fit.rms_P,
                              "max_dy": float(np.max(np.abs(dy[m]))),
                              "model": fit.model.name, "params": fit.params},
                      note=("A large residual in P means the model, not the "
                            "data, failed; check rms_P before blaming the "
                            "measurement."))


# --------------------------------------------------------------------------
# 4. Direct test (Van Ness 1995)
# --------------------------------------------------------------------------
def direct_test(dat, model="margules", vapour="ideal", threshold=0.05, fit=None):
    """Van Ness's direct test on residuals in ln(gamma1/gamma2).

        delta = ln(g1/g2)_exp - ln(g1/g2)_fitted

    The fitted values come from a Barker fit to P-x alone, so `delta` measures
    the same redundancy the point test measures, but in the variable in which
    Gibbs-Duhem is written. Van Ness's 1-10 index maps the RMS of delta onto a
    scale where 1 is excellent and anything above 5 should not be published
    without an explanation.
    """
    from .regress import barker_fit

    fit = fit or barker_fit(dat, model, vapour=vapour)
    g1, g2 = dat.gamma(vapour)
    lr_exp = np.log(g1 / g2)
    lg1, lg2 = fit.model.ln_gamma(dat.x1, dat.T)
    lr_cal = lg1 - lg2
    delta = lr_exp - lr_cal
    m = np.isfinite(delta) & dat.interior()
    rms = float(np.sqrt(np.mean(delta[m] ** 2)))
    idx = _index(rms, _DIRECT_SCALE)
    return TestResult("direct (Van Ness 1995)", rms, threshold, rms < threshold,
                      index=idx,
                      detail={"delta": delta, "model": fit.model.name},
                      note="Index 1-3 good, 4-5 marginal, 6+ reject.")


# --------------------------------------------------------------------------
# 5. Infinite dilution test (Kojima)
# --------------------------------------------------------------------------
def infinite_dilution_test(dat, vapour="ideal", order=4, threshold=30.0):
    """Kojima's endpoint test.

    Write q = (G^E/RT)/(x1 x2). As x1 -> 0, G^E/RT -> x1 ln g1_inf, so q tends
    to ln g1_inf; and ln(g1/g2) tends to the same limit, because ln g2 vanishes
    there. At the other end q tends to ln g2_inf while ln(g1/g2) tends to
    *minus* ln g2_inf, hence the sign change between the two expressions:

        I1 = 100 |[ q - ln(g1/g2) ] / q|  at x1 -> 0
        I2 = 100 |[ q + ln(g1/g2) ] / q|  at x1 -> 1

    The dilute region is where the vapour composition is hardest to measure and
    where a model has the least data holding it down, so a set that passes the
    area test and fails here is common and informative.
    """
    d = dat.sorted_by_x()
    g1, g2 = d.gamma(vapour)
    m = d.interior() & np.isfinite(g1) & np.isfinite(g2) & (g1 > 0) & (g2 > 0)
    x = d.x1[m]
    ratio = np.log(g1[m] / g2[m])
    gE = x * np.log(g1[m]) + (1 - x) * np.log(g2[m])
    q = gE / (x * (1 - x))

    cq = rk_fit(x, q, order)
    cr = rk_fit(x, ratio, order)
    out = {}
    for end, xe, sgn in (("x1->0", 0.0, -1.0), ("x1->1", 1.0, +1.0)):
        qe, re = rk_eval(cq, xe), rk_eval(cr, xe)
        out[end] = np.inf if qe == 0 else 100.0 * abs((qe + sgn * re) / qe)
    stat = max(out.values())
    return TestResult("infinite dilution (Kojima)", stat, threshold,
                      stat < threshold,
                      detail={**out,
                              "ln_gamma1_inf": rk_eval(cr, 0.0),
                              "ln_gamma2_inf": -rk_eval(cr, 1.0)},
                      note="Both ends extrapolated by a Redlich-Kister fit.")


# --------------------------------------------------------------------------
# 6. Gibbs-Duhem residual computed from the data themselves
# --------------------------------------------------------------------------
def gibbs_duhem_residual(dat, vapour="ideal", order=4):
    """x1 dln(g1)/dx1 + x2 dln(g2)/dx1 evaluated from smoothed data.

    A model satisfies this identically; data do not. The residual is returned
    on a fine grid together with its RMS, so it can be plotted next to the
    model's own residual — which is zero to machine precision — and the
    difference between "satisfied by construction" and "satisfied by
    measurement" becomes visible rather than asserted.
    """
    d = dat.sorted_by_x()
    g1, g2 = d.gamma(vapour)
    m = d.interior() & np.isfinite(g1) & np.isfinite(g2) & (g1 > 0) & (g2 > 0)
    x = d.x1[m]
    c1 = rk_fit(x, np.log(g1[m]), order)
    c2 = rk_fit(x, np.log(g2[m]), order)
    xs = np.linspace(max(0.01, x.min()), min(0.99, x.max()), 401)
    h = 1e-5
    d1 = (rk_eval(c1, xs + h) - rk_eval(c1, xs - h)) / (2 * h)
    d2 = (rk_eval(c2, xs + h) - rk_eval(c2, xs - h)) / (2 * h)
    res = xs * d1 + (1 - xs) * d2
    return xs, res, float(np.sqrt(np.mean(res ** 2)))


# --------------------------------------------------------------------------
def run_all(dat, model="margules", vapour="ideal", order=4):
    """Every applicable test, in the order a referee would want to read them."""
    from .regress import barker_fit

    fit = barker_fit(dat, model, vapour=vapour)
    out = [area_test(dat, vapour, order)]
    if dat.kind == "isobaric":
        out.append(herington_test(dat, vapour, order))
    out.append(point_test(dat, vapour=vapour, fit=fit))
    out.append(direct_test(dat, vapour=vapour, fit=fit))
    out.append(infinite_dilution_test(dat, vapour, order))
    return out


def report(results, width=78):
    """A plain-text table, because that is what goes into a report."""
    lines = ["-" * width,
             f"{'test':<30}{'statistic':>12}{'threshold':>12}{'index':>8}{'verdict':>10}",
             "-" * width]
    for r in results:
        lines.append(f"{r.name:<30}{r.statistic:>12.4g}{r.threshold:>12g}"
                     f"{(str(r.index) if r.index else '-'):>8}"
                     f"{('pass' if r.passed else 'FAIL'):>10}")
    lines.append("-" * width)
    return "\n".join(lines)
