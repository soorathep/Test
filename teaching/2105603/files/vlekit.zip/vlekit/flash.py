"""Bubble, dew, flash — and the stability question the flash does not ask.

Four routines that a process simulator runs thousands of times, written out so
that their differences are visible: they solve the same equilibrium condition
but with different variables specified, and they do not all converge equally
well.

The last section is the bridge to Module 5. A flash calculation assumes it
knows how many phases there are. Nothing in the Rachford-Rice equation checks
that assumption, and a fitted activity model can predict a liquid-liquid split
that the flash will happily ignore. Finding the split requires the Gibbs energy
of mixing, not the equilibrium equations.
"""
from __future__ import annotations

import numpy as np
from scipy.optimize import brentq

from .regress import bubble_P, bubble_T


# --------------------------------------------------------------------------
def K_values(model, x1, T, P, c1, c2):
    """K_i = y_i / x_i by modified Raoult: K_i = gamma_i Psat_i / P."""
    g1, g2 = model.gamma(x1, T)
    return g1 * c1.Psat(T) / P, g2 * c2.Psat(T) / P


# --------------------------------------------------------------------------
def rachford_rice(z1, K1, K2):
    """Solve sum_i z_i (K_i - 1) / (1 + V (K_i - 1)) = 0 for the vapour fraction.

    The function is monotonically decreasing in V wherever it is defined, which
    is why this formulation is used rather than the algebraically equivalent
    ones: a monotonic function has one root and bisection cannot fail. Show the
    plot before showing the algebra.
    """
    z = np.array([z1, 1 - z1], dtype=float)
    K = np.array([K1, K2], dtype=float)
    if not np.all(np.isfinite(K)):
        raise ValueError(
            f"non-finite K values {K}. This usually means the liquid "
            "composition that produced them is itself undefined — for example "
            "because the model predicts a liquid-liquid split at this "
            "composition, so there is no single liquid phase for the flash to "
            "find. Check flash.miscibility_gap before flashing.")

    def f(V):
        return float(np.sum(z * (K - 1) / (1 + V * (K - 1))))

    # no split if the feed is outside the two-phase region
    if f(0.0) < 0:
        return 0.0, "all liquid"
    if f(1.0) > 0:
        return 1.0, "all vapour"
    lo = 1.0 / (1.0 - K.max()) + 1e-12 if K.max() > 1 else 0.0
    hi = 1.0 / (1.0 - K.min()) - 1e-12 if K.min() < 1 else 1.0
    lo, hi = max(lo, 0.0), min(hi, 1.0)
    return brentq(f, lo, hi, xtol=1e-12), "two phase"


def rachford_rice_curve(z1, K1, K2, n=400):
    """The Rachford-Rice function against V, for the monotonicity figure."""
    z = np.array([z1, 1 - z1], dtype=float)
    K = np.array([K1, K2], dtype=float)
    V = np.linspace(0.0, 1.0, n)
    F = np.array([np.sum(z * (K - 1) / (1 + v * (K - 1))) for v in V])
    return V, F


def flash_TP(model, z1, T, P, c1, c2, tol=1e-10, itmax=200):
    """Isothermal flash at fixed T and P by successive substitution.

    Returns (V, x1, y1, status). The inner loop updates the K values from the
    activity model at the current liquid composition, which is what makes this
    slower and less robust than the ideal-solution version — and is also what
    makes it right for a non-ideal mixture.
    """
    x1 = y1 = float(z1)
    V = 0.5
    gap = miscibility_gap(model, float(np.mean(T)))
    if gap and gap["x1_phase_a"] < z1 < gap["x1_phase_b"]:
        # The vapour-liquid flash has no way to notice this. It will return a
        # single liquid composition inside a region where one liquid phase is
        # not the stable state, and the number will look perfectly reasonable.
        # Say so rather than returning it silently.
        return (np.nan, np.nan, np.nan,
                f"unstable liquid: the model predicts a split at "
                f"x1 = {gap['x1_phase_a']:.3f}-{gap['x1_phase_b']:.3f}, so a "
                f"two-phase VL flash is the wrong calculation here")
    for _ in range(itmax):
        K1, K2 = K_values(model, np.array([x1]), np.array([T]), P, c1, c2)
        V, status = rachford_rice(z1, float(K1[0]), float(K2[0]))
        if status != "two phase":
            return (0.0, z1, np.nan, status) if status == "all liquid" \
                else (1.0, np.nan, z1, status)
        xn = z1 / (1 + V * (float(K1[0]) - 1))
        yn = float(K1[0]) * xn
        if abs(xn - x1) < tol and abs(yn - y1) < tol:
            x1, y1 = xn, yn
            break
        x1, y1 = xn, yn
    return V, x1, y1, "two phase"


# --------------------------------------------------------------------------
def dew_P(model, y1, T, c1, c2, tol=1e-10, itmax=200):
    """Dew pressure: given the vapour composition, find P and the first liquid.

    Converges more slowly than the bubble calculation because the liquid
    composition it needs is the unknown, so the activity coefficients have to be
    updated every iteration. The asymmetry between bubble and dew is not
    incidental — it is why simulators do not treat them as the same routine.
    """
    y1 = np.atleast_1d(np.asarray(y1, dtype=float))
    T = np.broadcast_to(np.asarray(T, dtype=float), y1.shape)
    Pout, xout = np.empty_like(y1), np.empty_like(y1)
    for i, (ya, Ta) in enumerate(zip(y1, T)):
        Ps1, Ps2 = float(c1.Psat(Ta)), float(c2.Psat(Ta))
        x = ya
        P = 1.0 / (ya / Ps1 + (1 - ya) / Ps2)
        for _ in range(itmax):
            g1, g2 = model.gamma(np.array([x]), np.array([Ta]))
            Pn = 1.0 / (ya / (float(g1[0]) * Ps1) + (1 - ya) / (float(g2[0]) * Ps2))
            xn = ya * Pn / (float(g1[0]) * Ps1)
            if abs(xn - x) < tol and abs(Pn - P) < tol * P:
                x, P = xn, Pn
                break
            x, P = xn, Pn
        Pout[i], xout[i] = P, x
    return Pout, xout


def dew_T(model, y1, P, c1, c2, bracket=None, tol=1e-8):
    """Dew temperature: Brent on dew_P(T) - P."""
    y1 = np.atleast_1d(np.asarray(y1, dtype=float))
    P = np.broadcast_to(np.asarray(P, dtype=float), y1.shape)
    Tout, xout = np.empty_like(y1), np.empty_like(y1)
    for i, (ya, Pa) in enumerate(zip(y1, P)):
        lo, hi = bracket or (min(c1.Tsat(Pa), c2.Tsat(Pa)) - 60.0,
                             max(c1.Tsat(Pa), c2.Tsat(Pa)) + 60.0)

        def f(T, ya=ya, Pa=Pa):
            return dew_P(model, np.array([ya]), np.array([T]), c1, c2)[0][0] - Pa

        k = 0
        while f(lo) * f(hi) > 0 and k < 12:
            lo -= 20.0
            hi += 20.0
            k += 1
        Ti = brentq(f, lo, hi, xtol=tol)
        Tout[i] = Ti
        xout[i] = dew_P(model, np.array([ya]), np.array([Ti]), c1, c2)[1][0]
    return Tout, xout


# --------------------------------------------------------------------------
def azeotrope(model, T, c1, c2, tol=1e-12):
    """Composition where y1 = x1, found as a root rather than by eye.

    At the azeotrope gamma1 Psat1 = gamma2 Psat2, so the function whose root is
    wanted is ln(gamma1 Psat1) - ln(gamma2 Psat2). Returns None when there is no
    interior root, which is the honest answer for most systems.
    """
    Ps1, Ps2 = float(c1.Psat(T)), float(c2.Psat(T))

    def f(x):
        g1, g2 = model.gamma(np.array([x]), np.array([T]))
        return np.log(float(g1[0]) * Ps1) - np.log(float(g2[0]) * Ps2)

    a, b = 1e-6, 1 - 1e-6
    if f(a) * f(b) > 0:
        return None
    xa = brentq(f, a, b, xtol=tol)
    P, y = bubble_P(model, np.array([xa]), np.array([T]), c1, c2)
    return {"x1": xa, "P": float(P[0]), "T": T,
            "kind": "maximum-pressure" if f(a) > 0 else "minimum-pressure"}


# --------------------------------------------------------------------------
# Stability: the question the flash never asks
# --------------------------------------------------------------------------
def g_mix(model, x1, T=None):
    """Delta g_mix / RT = x1 ln x1 + x2 ln x2 + G^E/RT.

    The ideal part is always convex, so a liquid can only split when G^E is
    positive and large enough to defeat it. That is the whole stability story
    for a binary, and it is worth writing as one line of code.
    """
    x1 = np.asarray(x1, dtype=float)
    x2 = 1 - x1
    with np.errstate(divide="ignore", invalid="ignore"):
        ideal = np.where(x1 > 0, x1 * np.log(np.where(x1 > 0, x1, 1)), 0.0) \
            + np.where(x2 > 0, x2 * np.log(np.where(x2 > 0, x2, 1)), 0.0)
    return ideal + model.gE_RT(x1, T)


def d2g_mix(model, x1, T=None, h=1e-5):
    """Second derivative of Delta g_mix / RT.

    The ideal part is differentiated analytically — it is 1/x1 + 1/x2 — and
    only G^E is differenced. Doing the whole thing numerically produces
    spurious sign changes within one step of each pure end point, where the
    logarithm is being evaluated at a negative argument, and those show up as
    phantom spinodal roots at x1 = 0 and x1 = 1. Splitting the two parts costs
    one line and removes the failure mode entirely.
    """
    x1 = np.asarray(x1, dtype=float)
    ideal = 1.0 / x1 + 1.0 / (1.0 - x1)
    ge = (model.gE_RT(x1 + h, T) - 2 * model.gE_RT(x1, T)
          + model.gE_RT(x1 - h, T)) / h ** 2
    return ideal + ge


def spinodal(model, T=None, n=2001):
    """Compositions where d2(Delta g_mix)/dx1^2 = 0.

    Between them the mixture is unstable to any fluctuation. Outside them it may
    still be metastable, so the spinodal is a lower bound on the miscibility gap
    rather than the gap itself — the binodal requires the common tangent.
    """
    x = np.linspace(1e-4, 1 - 1e-4, n)
    d2 = d2g_mix(model, x, T)
    s = np.sign(d2)
    idx = np.where(np.diff(s) != 0)[0]
    roots = []
    for i in idx:
        try:
            roots.append(brentq(lambda z: float(d2g_mix(model, np.array([z]), T)[0]),
                                x[i], x[i + 1], xtol=1e-12))
        except ValueError:
            continue
    return roots


def miscibility_gap(model, T=None, n=1001):
    """Binodal by the common tangent, if there is one.

    Two compositions xa < xb are in equilibrium when the tangent to
    Delta g_mix at xa is also the tangent at xb, which is the same statement as
    equality of both components' activities. Solved here by a coarse scan
    followed by a two-variable Newton step, which is enough for a binary and
    keeps the geometry visible.

    Returns None when the curve is convex everywhere — the common case, and the
    one where a fitted model that predicts a split should be treated as a
    warning about extrapolation rather than a discovery.
    """
    sp = spinodal(model, T, n=2001)
    if len(sp) < 2:
        return None

    def mu(x):
        """The two 'chemical potentials' d g/d x and g - x dg/dx."""
        h = 1e-6
        g = float(g_mix(model, np.array([x]), T)[0])
        dg = float((g_mix(model, np.array([x + h]), T)[0]
                    - g_mix(model, np.array([x - h]), T)[0]) / (2 * h))
        return dg, g - x * dg

    xa, xb = 0.5 * sp[0], 1 - 0.5 * (1 - sp[-1])
    for _ in range(200):
        (d1, i1), (d2, i2) = mu(xa), mu(xb)
        F = np.array([d1 - d2, i1 - i2])
        if np.max(np.abs(F)) < 1e-12:
            break
        h = 1e-6
        J = np.empty((2, 2))
        for j, (xv, sgn) in enumerate(((xa, +1), (xb, -1))):
            dp, ip = mu(xv + h)
            dm, im = mu(xv - h)
            J[0, j] = sgn * (dp - dm) / (2 * h)
            J[1, j] = sgn * (ip - im) / (2 * h)
        try:
            step = np.linalg.solve(J, -F)
        except np.linalg.LinAlgError:
            return None
        step = np.clip(step, -0.05, 0.05)
        xa = float(np.clip(xa + step[0], 1e-9, 1 - 1e-9))
        xb = float(np.clip(xb + step[1], 1e-9, 1 - 1e-9))
    if abs(xb - xa) < 1e-4:
        return None
    return {"x1_phase_a": min(xa, xb), "x1_phase_b": max(xa, xb),
            "spinodal": sp}


def is_stable(model, T=None):
    """True when the liquid is stable at every composition."""
    x = np.linspace(1e-4, 1 - 1e-4, 1001)
    return bool(np.all(d2g_mix(model, x, T) > 0))
