"""The Peng-Robinson equation of state for mixtures, and the phase envelope.

Everything before this module takes the phi-gamma route: an activity model for
the liquid, something simple for the vapour. That route has a structural limit.
It needs a pure-component vapour pressure for every species, so it cannot
describe a mixture above the critical temperature of one of its components, and
it treats the two phases with two different kinds of model, so it can never
predict a mixture critical point. Natural gas, reservoir fluids and anything
near a critical point therefore need one equation of state used for both
phases — the phi-phi route:

    y_i phi_i^V(T, P, y) = x_i phi_i^L(T, P, x)

with both phi from the same equation. This module is that equation.

    P = RT/(v - b) - a(T) / [v(v + b) + b(v - b)]

with the van der Waals one-fluid quadratic mixing rule

    a = sum_i sum_j x_i x_j sqrt(a_i a_j) (1 - k_ij),   b = sum_i x_i b_i

Two things in here are worth more attention than the algebra.

The first is root selection. The cubic in Z has either one or three real roots,
and when it has three, the middle one is mechanically unstable and meaningless
while the outer two are both candidate physical states. Which of them is the
real phase is decided by the Gibbs energy, not by position in the list and not
by whatever the caller happened to ask for. `ln_phi(..., phase='stable')` picks
the root with the lower molar Gibbs energy and is the default; `'liquid'` and
`'vapour'` force the small and large root and exist because a two-phase
calculation sometimes needs a specific branch. Asking for the vapour root at a
condition where only the liquid root exists silently returns the liquid root,
because there is only one root: the equation has no way to signal a phase that
does not exist, which is precisely the hazard Module 4 warns about.

The second is the phase envelope. Solving each point of a P-T envelope from a
cold start fails near the critical point, where the bubble and dew branches
approach each other and a solver started on one lands on the other or on the
trivial solution K_i = 1. `envelope` instead uses Michelsen's continuation: the
unknowns are (ln K_1 .. ln K_N, ln T, ln P), one of them is specified and the
rest are solved by Newton, and each new point is predicted by extrapolating
along the tangent to the curve. The specified variable is re-chosen at every
step as the one changing fastest, which is what carries the trace around the
critical point — there ln K collapses to zero while T and P barely move, so
ln K becomes the natural parameter and the bubble branch continues smoothly
into the dew branch.

Pressures are in kPa throughout, to match `data.Component`.
"""
from __future__ import annotations

import numpy as np

R = 8.314462618              # J / mol / K
SQRT2 = np.sqrt(2.0)

# Peng-Robinson universal constants, from the critical-point conditions
OMEGA_A = 0.45723552892138218      # = 0.45724 to five figures
OMEGA_B = 0.07779607390388850      # = 0.07780 to four figures


# ==========================================================================
class PengRobinson:
    """Peng-Robinson EOS for an N-component mixture, quadratic mixing rule.

    Built from `data.Component` objects, which already carry Tc, Pc and omega.
    The binary interaction matrix k_ij defaults to zero: that is the honest
    default and it is almost never right, exactly as for the virial cross
    coefficient in `data.B_cross`.

    The 1976 alpha function is used by default. Its m(omega) polynomial was
    fitted for omega < 0.5 and it degrades badly for heavy or strongly
    hydrogen-bonding species; `alpha='1978'` switches to the cubic extension
    Peng and Robinson published for omega > 0.491. Which one is in use is
    recorded on the object rather than hidden, because the two give different
    vapour pressures for the same component and a parameter fitted with one
    cannot be used with the other.
    """

    def __init__(self, components, kij=None, alpha="1976"):
        self.components = list(components)
        self.n = len(self.components)
        if alpha not in ("1976", "1978"):
            raise ValueError("alpha must be '1976' or '1978'")
        self.alpha_rule = alpha

        self.Tc = np.array([c.Tc for c in self.components], dtype=float)
        self.Pc = np.array([c.Pc for c in self.components], dtype=float) * 1e3  # Pa
        self.omega = np.array([c.omega for c in self.components], dtype=float)
        if not np.all(np.isfinite(self.Tc) & np.isfinite(self.Pc)
                      & np.isfinite(self.omega)):
            bad = [c.name for c in self.components
                   if not (np.isfinite(c.Tc) and np.isfinite(c.Pc)
                           and np.isfinite(c.omega))]
            raise ValueError(f"Tc, Pc and omega are required for the cubic "
                             f"route; missing for {bad}")

        if kij is None:
            self.kij = np.zeros((self.n, self.n))
        else:
            self.kij = np.array(kij, dtype=float).reshape(self.n, self.n)
            if not np.allclose(self.kij, self.kij.T):
                raise ValueError("kij must be symmetric")

        w = self.omega
        if alpha == "1976":
            self.m = 0.37464 + 1.54226 * w - 0.26992 * w ** 2
        else:
            self.m = np.where(w <= 0.491,
                              0.37464 + 1.54226 * w - 0.26992 * w ** 2,
                              0.379642 + 1.48503 * w - 0.164423 * w ** 2
                              + 0.016666 * w ** 3)
        self.b = OMEGA_B * R * self.Tc / self.Pc          # m^3/mol
        self._ac = OMEGA_A * (R * self.Tc) ** 2 / self.Pc  # J m^3 / mol^2

    # ------------------------------------------------------------ pure terms
    def alpha(self, T):
        """The temperature function, 1 at Tc by construction."""
        Tr = float(T) / self.Tc
        return (1.0 + self.m * (1.0 - np.sqrt(Tr))) ** 2

    def a_pure(self, T):
        """a_i(T) for each component, J m^3 / mol^2."""
        return self._ac * self.alpha(T)

    def a_cross(self, T):
        """a_ij = sqrt(a_i a_j)(1 - k_ij), the whole content of the mixing rule."""
        ai = self.a_pure(T)
        return np.sqrt(np.outer(ai, ai)) * (1.0 - self.kij)

    # ------------------------------------------------------- mixture terms
    def a_mix(self, T, x):
        x = self._clean(x)
        return float(x @ self.a_cross(T) @ x)

    def b_mix(self, x):
        return float(self._clean(x) @ self.b)

    def AB(self, T, P, x):
        """The dimensionless groups A = aP/(RT)^2 and B = bP/RT."""
        T, Pa = float(T), float(P) * 1e3
        A = self.a_mix(T, x) * Pa / (R * T) ** 2
        B = self.b_mix(x) * Pa / (R * T)
        return A, B

    def _clean(self, x):
        x = np.asarray(x, dtype=float).ravel()
        if x.size != self.n:
            raise ValueError(f"composition of length {x.size}, expected {self.n}")
        s = x.sum()
        return x / s if s > 0 else x

    # -------------------------------------------------------------- roots
    def Z_roots(self, T, P, x):
        """All physically admissible compressibility factors, ascending.

        The cubic is  Z^3 - (1-B) Z^2 + (A - 3B^2 - 2B) Z - (AB - B^2 - B^3) = 0.
        Roots with Z <= B are discarded: they correspond to a molar volume
        smaller than the co-volume b, which is not a state of matter. Complex
        roots are discarded on a relative tolerance rather than an absolute one
        so that the test still works at the very small Z of a dense liquid.
        """
        A, B = self.AB(T, P, x)
        coef = [1.0, -(1.0 - B), A - 3 * B ** 2 - 2 * B,
                -(A * B - B ** 2 - B ** 3)]
        r = np.roots(coef)
        keep = [float(z.real) for z in r
                if abs(z.imag) < 1e-9 * max(1.0, abs(z.real))
                and z.real > B]
        return np.sort(np.array(keep))

    def gres_RT(self, T, P, x, Z):
        """Residual Gibbs energy G^res/RT at a given root.

        This is the quantity that decides which root is the real phase. The
        ideal-gas part of G is the same for both roots at the same T, P and
        composition, so comparing the residual parts compares the phases.
        """
        A, B = self.AB(T, P, x)
        return (Z - 1.0 - np.log(Z - B)
                - A / (2 * SQRT2 * B)
                * np.log((Z + (1 + SQRT2) * B) / (Z + (1 - SQRT2) * B)))

    def select_root(self, T, P, x, phase="stable"):
        """Pick one root. 'stable' compares Gibbs energies; the others force a branch.

        With three real roots, 'vapour' and 'liquid' return the largest and the
        smallest — the middle root has (dP/dv)_T > 0 and is mechanically
        unstable, so it is never returned. With one real root all three options
        return the same number, and no warning is possible: a single root is
        both the liquid and the vapour, which is the correct behaviour above the
        mixture critical point and a trap everywhere else.
        """
        Zs = self.Z_roots(T, P, x)
        if Zs.size == 0:
            raise ValueError(f"no admissible Z root at T={T:.4g} K, P={P:.4g} kPa")
        if Zs.size == 1 or phase == "vapour":
            return float(Zs[-1]) if phase != "liquid" else float(Zs[0])
        if phase == "liquid":
            return float(Zs[0])
        if phase != "stable":
            raise ValueError("phase must be 'stable', 'liquid' or 'vapour'")
        g = [self.gres_RT(T, P, x, z) for z in (Zs[0], Zs[-1])]
        return float(Zs[0]) if g[0] <= g[1] else float(Zs[-1])

    # ------------------------------------------------------ fugacity
    def ln_phi(self, T, P, x, phase="stable"):
        """ln phi_i for every component, and the Z it was evaluated at.

        ln phi_i = (b_i/b)(Z-1) - ln(Z-B)
                   - A/(2 sqrt2 B) [ 2 sum_j x_j a_ij / a - b_i/b ]
                     ln[ (Z + (1+sqrt2)B) / (Z + (1-sqrt2)B) ]

        which is the partial molar residual Gibbs energy,
        ln phi_i = d(n G^res/RT)/dn_i at fixed T, P and the other n_j. That
        identity is not decoration: it is checked numerically in the tests, and
        it is the only way to be sure the composition derivative of the mixing
        rule was differentiated correctly.
        """
        x = self._clean(x)
        Z = self.select_root(T, P, x, phase)
        A, B = self.AB(T, P, x)
        a = self.a_mix(T, x)
        b = self.b_mix(x)
        bi_b = self.b / b
        sum_j = self.a_cross(T) @ x
        L = np.log((Z + (1 + SQRT2) * B) / (Z + (1 - SQRT2) * B))
        lnphi = (bi_b * (Z - 1.0) - np.log(Z - B)
                 - A / (2 * SQRT2 * B) * (2 * sum_j / a - bi_b) * L)
        return lnphi, Z

    def phi(self, T, P, x, phase="stable"):
        lnphi, Z = self.ln_phi(T, P, x, phase)
        return np.exp(lnphi), Z

    # ------------------------------------------------------------ helpers
    def pure(self, i):
        """A one-component PengRobinson for component i, same alpha rule."""
        return PengRobinson([self.components[i]], alpha=self.alpha_rule)

    def unit(self, i):
        x = np.zeros(self.n)
        x[i] = 1.0
        return x

    def __repr__(self):
        names = "/".join(c.name for c in self.components)
        return f"<PengRobinson {names}, alpha={self.alpha_rule}>"


# ==========================================================================
# Pure-component vapour pressure from the mixture routine
# ==========================================================================
def psat(mix, i, T, tol=1e-10):
    """Vapour pressure of component i, from the mixture routine at x = pure.

    The saturation condition for a pure substance is that the two roots of the
    cubic have the same Gibbs energy: ln phi(vapour root) = ln phi(liquid root).
    Solving that is the same statement as the equal-area construction on the
    isotherm, and it is worth doing this way rather than with a separate
    correlation, because it exercises exactly the code path a mixture
    calculation uses.

    Returns nan at or above Tc, where there is nothing to solve.
    """
    from scipy.optimize import brentq

    x = np.zeros(mix.n)
    x[i] = 1.0
    Tc, Pc = mix.Tc[i], mix.Pc[i] / 1e3
    T = float(T)
    if T >= Tc:
        return np.nan

    def f(P):
        Zs = mix.Z_roots(T, P, x)
        if Zs.size < 2:                        # only one phase exists here
            return np.nan
        return (mix.gres_RT(T, P, x, Zs[-1]) - mix.gres_RT(T, P, x, Zs[0]))

    # bracket by scanning the pressures where three roots exist at all; below
    # the spinodal pressure the vapour root is alone, above it the liquid is
    lo, hi = None, None
    grid = Pc * np.logspace(-12, 0, 400)
    vals = np.array([f(P) for P in grid])
    ok = np.where(np.isfinite(vals))[0]
    if ok.size < 2:
        return np.nan
    v = vals[ok]
    s = np.where(np.sign(v[:-1]) != np.sign(v[1:]))[0]
    if s.size == 0:
        return np.nan
    lo, hi = grid[ok[s[0]]], grid[ok[s[0] + 1]]
    return float(brentq(f, lo, hi, xtol=tol * Pc, rtol=1e-14))


# ==========================================================================
# The phase boundary, written once and used for bubble, dew and the envelope
# ==========================================================================
def _wilson_K(mix, T, P):
    """Wilson's K estimate. Only ever a starting guess, never an answer."""
    return (mix.Pc / 1e3 / P) * np.exp(5.373 * (1.0 + mix.omega)
                                       * (1.0 - mix.Tc / T))


def _split(z, K, beta):
    """The two phase compositions on a boundary, from K and the phase fraction.

    beta = 0 puts the whole mixture in the x phase and makes y the incipient
    one; beta = 1 does the reverse. Both are the same equation.
    """
    x = z / (1.0 - beta + beta * K)
    return x, K * x


def _residual(mix, z, X, beta, spec, S):
    """The N+2 equations of a phase boundary point.

    X = [ln K_1 .. ln K_N, ln T, ln P]

        g_i   = ln K_i - ln phi_i(x) + ln phi_i(y) = 0     equifugacity
        g_N+1 = sum_i (y_i - x_i) = 0                      the phase closes
        g_N+2 = X[spec] - S = 0                            what is held fixed

    Note what the first N equations do NOT contain: any statement of which
    phase is liquid and which is vapour. They are symmetric. The only place the
    distinction enters is the root selection inside `ln_phi`, and that is why a
    single continuation can run up the bubble branch, through the critical
    point, and back down the dew branch without changing a single equation.
    """
    n = mix.n
    K = np.exp(X[:n])
    T, P = np.exp(X[n]), np.exp(X[n + 1])
    x, y = _split(z, K, beta)
    lx, _ = mix.ln_phi(T, P, x, "stable")
    ly, _ = mix.ln_phi(T, P, y, "stable")
    g = np.empty(n + 2)
    g[:n] = X[:n] - lx + ly
    g[n] = np.sum(y - x)
    g[n + 1] = X[spec] - S
    return g


def _jacobian(mix, z, X, beta, spec, S, h=1e-6):
    """Forward differences. N+2 extra residual evaluations, which for a binary
    is four — cheaper to write and to read than the analytical derivatives, and
    the analytical ones would be the thing most likely to be wrong."""
    n = mix.n
    f0 = _residual(mix, z, X, beta, spec, S)
    J = np.empty((n + 2, n + 2))
    for k in range(n + 2):
        Xp = X.copy()
        Xp[k] += h
        J[:, k] = (_residual(mix, z, Xp, beta, spec, S) - f0) / h
    return J, f0


def solve_point(mix, z, X0, beta=0.0, spec=None, S=None,
                tol=1e-9, itmax=40, damp_max=0.5):
    """Newton on the N+2 equations. Returns (X, converged, iterations).

    The step is limited to `damp_max` in each log variable. Without that limit
    Newton overshoots into a region where the cubic has no admissible root and
    the whole trace dies; with it, convergence is slower and never dies.
    """
    n = mix.n
    X = np.array(X0, dtype=float)
    if spec is None:
        spec = n + 1
    if S is None:
        S = X[spec]
    for it in range(1, itmax + 1):
        try:
            J, f = _jacobian(mix, z, X, beta, spec, S)
        except ValueError:
            return X, False, it
        if np.max(np.abs(f)) < tol:
            return X, True, it
        try:
            dX = np.linalg.solve(J, -f)
        except np.linalg.LinAlgError:
            return X, False, it
        big = np.max(np.abs(dX))
        if big > damp_max:
            dX *= damp_max / big
        X = X + dX
    return X, np.max(np.abs(_residual(mix, z, X, beta, spec, S))) < 1e-6, itmax


# --------------------------------------------------------------------------
def _boundary(mix, z, beta, T=None, P=None, K0=None, guess=None, **kw):
    """One bubble or dew point. Internal; the four public wrappers call it."""
    n = mix.n
    z = np.asarray(z, dtype=float) / np.sum(z)
    if (T is None) == (P is None):
        raise ValueError("specify exactly one of T and P")
    if T is None:
        T = float(guess) if guess else _ideal_boundary_T(mix, z, P, beta)
    if P is None:
        P = float(guess) if guess else _ideal_boundary_P(mix, z, T, beta)
    K = _wilson_K(mix, T, P) if K0 is None else np.asarray(K0, dtype=float)
    X0 = np.concatenate([np.log(K), [np.log(T), np.log(P)]])
    spec = n if (kw.pop("fix", "T") == "T") else n + 1
    X, ok, it = solve_point(mix, z, X0, beta=beta, spec=spec, **kw)
    K = np.exp(X[:n])
    x, y = _split(z, K, beta)
    return {"T": float(np.exp(X[n])), "P": float(np.exp(X[n + 1])),
            "x": x, "y": y, "K": K, "converged": bool(ok), "iterations": it}


def _ideal_boundary_P(mix, z, T, beta):
    """Raoult-with-Wilson-K starting pressure. A guess, and labelled as one."""
    Ps = np.array([psat(mix, i, T) for i in range(mix.n)])
    Ps = np.where(np.isfinite(Ps), Ps, mix.Pc / 1e3)   # supercritical: use Pc
    return float(np.sum(z * Ps)) if beta < 0.5 else float(1.0 / np.sum(z / Ps))


def _ideal_boundary_T(mix, z, P, beta):
    from scipy.optimize import brentq

    def f(T):
        K = _wilson_K(mix, T, P)
        return np.sum(z * K) - 1.0 if beta < 0.5 else 1.0 - np.sum(z / K)

    lo, hi = 0.35 * float(np.min(mix.Tc)), 1.3 * float(np.max(mix.Tc))
    flo, fhi = f(lo), f(hi)
    if flo * fhi > 0:
        return float(np.sum(z * mix.Tc))
    return float(brentq(f, lo, hi))


def bubble_P(mix, x, T, **kw):
    """Bubble pressure and incipient vapour composition at given liquid x and T.

    `guess` sets the starting pressure and `K0` the starting K values. Both
    default to a Raoult-plus-Wilson estimate, which is fine at low pressure and
    is not fine within twenty or thirty kelvin of the mixture critical point:
    there the estimate is out by a factor of two, Newton walks away from the
    bubble branch, and what comes back is converged and wrong. Near the
    critical region take the guess from `envelope`, which is what continuation
    is for. There is a test asserting exactly this failure, because a routine
    whose limits are only written in the docstring is a routine whose limits
    nobody knows.
    """
    return _boundary(mix, x, beta=0.0, T=T, fix="T", **kw)


def dew_P(mix, y, T, **kw):
    """Dew pressure and incipient liquid composition at given vapour y and T.

    Same warm-start caveat as `bubble_P`.
    """
    return _boundary(mix, y, beta=1.0, T=T, fix="T", **kw)


def bubble_T(mix, x, P, **kw):
    """Bubble temperature and incipient vapour composition at given x and P."""
    return _boundary(mix, x, beta=0.0, P=P, fix="P", **kw)


def dew_T(mix, y, P, **kw):
    """Dew temperature and incipient liquid composition at given y and P."""
    return _boundary(mix, y, beta=1.0, P=P, fix="P", **kw)


# ==========================================================================
# The P-T envelope
# ==========================================================================
class Envelope:
    """A traced P-T phase envelope at one fixed overall composition.

    Attributes: T, P (arrays, in trace order), K (n_points x N), beta_side
    ('bubble' before the critical point, 'dew' after it), critical, and the
    two extrema.
    """

    def __init__(self, z, T, P, K, i_crit):
        self.z = z
        self.T = np.asarray(T, dtype=float)
        self.P = np.asarray(P, dtype=float)
        self.K = np.asarray(K, dtype=float)
        self.i_crit = i_crit
        self.critical = None
        self.cricondentherm = None
        self.cricondenbar = None

    @property
    def bubble(self):
        """The branch traced before the critical point: (T, P)."""
        j = len(self.T) if self.i_crit is None else self.i_crit + 1
        return self.T[:j], self.P[:j]

    @property
    def dew(self):
        j = 0 if self.i_crit is None else self.i_crit
        return self.T[j:], self.P[j:]

    def warm_start(self, T, branch="bubble"):
        """(P, K) from the traced point nearest T on one branch.

        What to hand to `bubble_P` or `dew_P` as `guess` and `K0` when the
        condition is anywhere near the critical region. On the dew branch the
        traced K is the ratio of the incipient *liquid* to the bulk vapour, so
        it is inverted here to match the convention `dew_P` expects.
        """
        lo = 0 if branch == "bubble" else (self.i_crit or 0)
        hi = ((self.i_crit or len(self)) + 1) if branch == "bubble" else len(self)
        j = lo + int(np.argmin(np.abs(self.T[lo:hi] - T)))
        K = self.K[j] if branch == "bubble" else 1.0 / self.K[j]
        return float(self.P[j]), K

    def __len__(self):
        return len(self.T)

    def __repr__(self):
        c = ("" if self.critical is None
             else f", Tc={self.critical[0]:.2f} K Pc={self.critical[1]:.1f} kPa")
        return f"<Envelope {len(self)} points{c}>"


def envelope(mix, z, P_start=101.325, P_stop=None, n_max=600,
             dS_max=0.20, dS_min=1e-4, target_iter=4, tol=1e-9):
    """Trace the whole P-T envelope at fixed overall composition z.

    The algorithm is Michelsen's (Fluid Phase Equilibria 4 (1980) 1-10) in its
    simplest form. Start from a low-pressure bubble point, then repeat:

      1. from the converged Jacobian, get the tangent dX/dS by solving
         J dX/dS = e_{N+2};
      2. choose as the next specified variable the component of X with the
         largest |dX/dS| — near the critical point that is ln K, everywhere
         else it is ln T or ln P;
      3. predict the next point by a first-order extrapolation along the
         tangent and correct it by Newton;
      4. grow or shrink the step depending on how many Newton iterations that
         took.

    Step 2 is the whole trick. Parametrising by pressure fails at the
    cricondenbar where dP = 0 along the curve, parametrising by temperature
    fails at the cricondentherm, and both fail at the critical point where the
    two branches touch. Parametrising by whichever variable is currently moving
    fastest fails at none of them.

    The trivial solution K_i = 1 satisfies the equifugacity equations at every
    T and P, so it is an attractor for any solver that wanders near it. The
    trace is kept off it by refusing to place a point with max|ln K| below
    `K_floor`; when the predictor lands there, the step is pushed through to
    the far side instead. That is also what carries the trace from the bubble
    branch onto the dew branch.
    """
    n = mix.n
    z = np.asarray(z, dtype=float) / np.sum(z)
    K_floor = 0.05
    P_stop = P_start if P_stop is None else P_stop

    # --- first point: a bubble point at a pressure low enough to be easy
    b = bubble_T(mix, z, P_start, tol=tol)
    if not b["converged"]:
        raise RuntimeError(f"could not start the envelope at P = {P_start} kPa")
    X = np.concatenate([np.log(b["K"]), [np.log(b["T"]), np.log(P_start)]])
    spec = n + 1                       # start by marching in pressure
    S = X[spec]
    dS = 0.05

    Ts, Ps, Ks = [b["T"]], [P_start], [b["K"].copy()]
    i_crit = None
    # The critical point is where every K_i passes through 1 at once. Watching
    # one of them is enough, and the one to watch is the component most
    # enriched in the incipient phase at the start of the trace: its ln K is
    # the largest, so it crosses zero most cleanly.
    i_ref = int(np.argmax(np.log(b["K"])))
    sign_prev = np.sign(np.log(b["K"][i_ref]))

    for _ in range(n_max):
        J, _f = _jacobian(mix, z, X, 0.0, spec, S)
        try:
            e = np.zeros(n + 2)
            e[n + 1] = 1.0
            dXdS = np.linalg.solve(J, e)
        except np.linalg.LinAlgError:
            break

        # re-specify on the fastest-moving variable, and rescale the tangent so
        # that dS is a step in that variable
        new_spec = int(np.argmax(np.abs(dXdS)))
        dXdS = dXdS / dXdS[new_spec]
        if new_spec != spec:
            # dS measured a step in the old variable; convert it to the new one
            # so that the marching direction along the curve is preserved
            rate = dXdS[spec]
            dS = dS / rate if abs(rate) > 1e-12 else dS
            spec = new_spec
        S = X[spec]

        dS = float(np.clip(abs(dS), dS_min, dS_max)) * np.sign(dS)
        for _attempt in range(8):
            Snew = S + dS
            Xp = X + dXdS * dS
            # never place a point on the trivial solution
            if spec < n and abs(Snew) < K_floor and abs(S) > 1e-12:
                Snew = np.sign(dS) * K_floor
                Xp = X + dXdS * (Snew - S)
            Xn, ok, it = solve_point(mix, z, Xp, beta=0.0, spec=spec, S=Snew,
                                     tol=tol)
            if ok and np.max(np.abs(Xn[:n])) > 1e-3:
                break
            dS *= 0.4
        else:
            break

        X, S = Xn, Snew
        dS *= float(np.clip(target_iter / max(it, 1), 0.5, 1.8))

        T, P = float(np.exp(X[n])), float(np.exp(X[n + 1]))
        Ts.append(T)
        Ps.append(P)
        Ks.append(np.exp(X[:n]).copy())

        sign_now = np.sign(X[i_ref])
        if i_crit is None and sign_now != sign_prev:
            i_crit = len(Ts) - 2                  # last point on the bubble side
        sign_prev = sign_now

        if i_crit is not None and P < P_stop:
            break
        if T < 0.2 * float(np.min(mix.Tc)):
            break

    # The trace deliberately jumped over the critical point rather than
    # crawling into the trivial solution, which leaves a gap of several kelvin
    # between the end of the bubble branch and the start of the dew branch.
    # Fill it in afterwards, when both ends are known and each new point can be
    # warm-started from its neighbour: with ln K itself as the specified
    # variable the solve is well conditioned right up to the critical point.
    if i_crit is not None:
        lo = _creep_to_critical(mix, z, Ts, Ps, Ks, i_crit, i_ref, +1, K_floor)
        hi = _creep_to_critical(mix, z, Ts, Ps, Ks, i_crit + 1, i_ref, -1,
                                K_floor)
        j = i_crit + 1
        Ts = Ts[:j] + [p[0] for p in lo] + [p[0] for p in hi[::-1]] + Ts[j:]
        Ps = Ps[:j] + [p[1] for p in lo] + [p[1] for p in hi[::-1]] + Ps[j:]
        Ks = Ks[:j] + [p[2] for p in lo] + [p[2] for p in hi[::-1]] + Ks[j:]
        i_crit = i_crit + len(lo)

    env = Envelope(z, Ts, Ps, np.array(Ks), i_crit)
    env.i_ref = i_ref
    env.critical = _critical_from_trace(mix, env)
    env.cricondentherm = _extremum(mix, env, "T")
    env.cricondenbar = _extremum(mix, env, "P")
    return env


def _creep_to_critical(mix, z, Ts, Ps, Ks, j, i_ref, sign, K_floor, n=8,
                       eps=4e-3):
    """Points marching from trace index j in towards ln K_ref = 0.

    Specifying ln K_ref and solving for T, P and the other ln K stays well
    conditioned all the way in — the degeneracy at the critical point is in the
    equations' dependence on ln K, not on T and P. Returned in marching order,
    which is towards the critical point.
    """
    n_c = mix.n
    X = np.concatenate([np.log(Ks[j]), [np.log(Ts[j]), np.log(Ps[j])]])
    s0 = abs(X[i_ref])
    if s0 <= eps:
        return []
    out = []
    for s in np.geomspace(s0, eps, n + 1)[1:]:
        X, ok, _ = solve_point(mix, z, X, beta=0.0, spec=i_ref, S=sign * s)
        if not ok:
            break
        out.append((float(np.exp(X[n_c])), float(np.exp(X[n_c + 1])),
                    np.exp(X[:n_c]).copy()))
    return out


def _critical_from_trace(mix, env):
    """The mixture critical point, by interpolation across the K = 1 crossing.

    It cannot be solved for directly with these equations. At K_i = 1 the two
    phases are identical, the equifugacity residuals vanish for every T and P,
    and the Jacobian is singular — the critical point is a removable
    degeneracy of the phase-boundary system, not a solution of it. What the
    trace does give is points arbitrarily close on either side, so T and P are
    interpolated against sum_i z_i ln K_i, which passes through zero there.
    """
    if env.i_crit is None:
        return None
    n = mix.n
    i, r = env.i_crit, getattr(env, "i_ref", 0)
    X_of = lambda j: np.concatenate(
        [np.log(env.K[j]), [np.log(env.T[j]), np.log(env.P[j])]])
    Xs = (X_of(i), X_of(i + 1))

    def at(eps):
        """The boundary point with ln K_ref pinned to eps, on either side."""
        out = []
        for sgn, X0 in zip((+1, -1), Xs):
            X, ok, _ = solve_point(mix, env.z, X0, beta=0.0, spec=r, S=sgn * eps)
            if not ok:
                return None
            out.append((np.exp(X[n]), np.exp(X[n + 1])))
        return 0.5 * (np.array(out[0]) + np.array(out[1]))

    # The midpoint of the two branches at +/- eps approaches the critical point
    # like eps^2, so one Richardson step on two values of eps removes the
    # leading error. A direct solve at eps = 0 is impossible: there the two
    # phases are identical and the Jacobian is singular.
    hi, lo = at(0.06), at(0.03)
    if hi is None or lo is None:
        s = np.log(env.K[:, r])
        w = -s[i] / (s[i + 1] - s[i])
        return (float(env.T[i] + w * (env.T[i + 1] - env.T[i])),
                float(env.P[i] + w * (env.P[i + 1] - env.P[i])))
    c = (4.0 * lo - hi) / 3.0
    return float(c[0]), float(c[1])


def _extremum(mix, env, which, itmax=60):
    """The cricondentherm (which='T') or cricondenbar (which='P'), refined.

    Reporting max(T) over the traced points is not good enough: the trace does
    not land on the extremum, and the answer would then depend on where the
    steps happened to fall. The fix uses the local geometry. At the
    cricondentherm the curve has a vertical tangent in the P-T plane, so T is a
    smooth quadratic maximum as a function of P — pressure is a perfectly good
    parameter there even though temperature is not. So: fix P, solve the
    boundary point, and maximise the resulting T over P by golden section. The
    cricondenbar is the same argument with T and P exchanged.

    Each solve is warm-started from its neighbour on the trace, which is what
    keeps it on the correct branch: at these pressures the bubble branch also
    has a solution, and a cold start finds it about half the time.
    """
    n = mix.n
    u = env.T if which == "T" else env.P          # the quantity to maximise
    spec = n + 1 if which == "T" else n           # the one to march in
    i = int(np.argmax(u))
    if i == 0 or i == len(u) - 1:
        return float(env.T[i]), float(env.P[i])

    X_of = lambda j: np.concatenate(
        [np.log(env.K[j]), [np.log(env.T[j]), np.log(env.P[j])]])
    Xs = [X_of(i - 1), X_of(i), X_of(i + 1)]
    lo, hi = sorted((Xs[0][spec], Xs[2][spec]))

    def value(S):
        j = int(np.argmin([abs(X[spec] - S) for X in Xs]))
        X, ok, _ = solve_point(mix, env.z, Xs[j], beta=0.0, spec=spec, S=S)
        if not ok:
            return -np.inf, None
        return (X[n] if which == "T" else X[n + 1]), X

    g = 0.5 * (np.sqrt(5.0) - 1.0)
    a, b = lo, hi
    c, d = b - g * (b - a), a + g * (b - a)
    fc, fd = value(c)[0], value(d)[0]
    for _ in range(itmax):
        if abs(b - a) < 1e-10:
            break
        if fc > fd:
            b, d, fd = d, c, fc
            c = b - g * (b - a)
            fc = value(c)[0]
        else:
            a, c, fc = c, d, fd
            d = a + g * (b - a)
            fd = value(d)[0]
    _, X = value(0.5 * (a + b))
    if X is None:
        return float(env.T[i]), float(env.P[i])
    return float(np.exp(X[n])), float(np.exp(X[n + 1]))


# ==========================================================================
# A two-phase flash, so that liquid dropout is computed and not asserted
# ==========================================================================
def _rachford_rice(z, K):
    """Vapour fraction from sum_i z_i (K_i - 1)/(1 + V(K_i - 1)) = 0.

    The N-component form of the routine in `flash.py`, which carries the
    binary version and the figure showing why the function cannot trap a
    solver. Returns (V, status).
    """
    from scipy.optimize import brentq

    z = np.asarray(z, dtype=float)
    K = np.asarray(K, dtype=float)

    def f(V):
        return float(np.sum(z * (K - 1.0) / (1.0 + V * (K - 1.0))))

    if f(0.0) < 0:
        return 0.0, "all liquid"
    if f(1.0) > 0:
        return 1.0, "all vapour"
    lo = 1.0 / (1.0 - K.max()) + 1e-12 if K.max() > 1 else 0.0
    hi = 1.0 / (1.0 - K.min()) - 1e-12 if K.min() < 1 else 1.0
    return brentq(f, max(lo, 0.0), min(hi, 1.0), xtol=1e-13), "two phase"


def flash_TP(mix, z, T, P, K0=None, tol=1e-10, itmax=400):
    """Isothermal flash by successive substitution on K = phi^L / phi^V.

    Returns a dict with V (vapour mole fraction), x, y, K and status. Slow
    near a phase boundary, where successive substitution always is, and honest
    about not converging rather than returning the last iterate silently.

    This is what turns the retrograde region from an assertion into a
    measurement: fix T inside the window, walk P down from the upper dew point,
    and read the liquid fraction 1 - V.
    """
    z = np.asarray(z, dtype=float) / np.sum(z)
    K = _wilson_K(mix, T, P) if K0 is None else np.array(K0, dtype=float)
    V, status = 0.5, "two phase"
    x = y = z
    for it in range(itmax):
        V, status = _rachford_rice(z, K)
        if status != "two phase":
            return {"V": V, "x": z, "y": z, "K": K, "status": status,
                    "iterations": it}
        x = z / (1.0 + V * (K - 1.0))
        y = K * x
        lx, _ = mix.ln_phi(T, P, x, "stable")
        ly, _ = mix.ln_phi(T, P, y, "stable")
        Kn = np.exp(lx - ly)
        if np.max(np.abs(Kn - K)) < tol * np.max(K):
            K = Kn
            break
        K = Kn
    else:
        status = "not converged"
    # a converged flash that has collapsed onto K = 1 has found the trivial
    # solution, not an equilibrium; report it as single phase rather than as a
    # split into two identical phases
    if np.max(np.abs(np.log(K))) < 1e-6:
        status = "trivial solution"
    return {"V": V, "x": x, "y": y, "K": K, "status": status,
            "iterations": it + 1}


def liquid_dropout(mix, z, T, P_lo, P_hi, n=60, K0=None):
    """Liquid mole fraction along an isotherm, from P_hi down to P_lo.

    Each flash is started from the previous converged K values, for the same
    reason the envelope uses continuation: a cold start close to a phase
    boundary collapses onto the trivial solution and the flash then reports a
    single phase where there are two. Pass `K0` from the boundary calculation
    when the walk begins right at one.
    """
    Ps = np.linspace(P_hi, P_lo, n)
    L, K = [], K0
    for P in Ps:
        r = flash_TP(mix, z, T, P, K0=K)
        if r["status"] == "two phase":
            K = r["K"]
            L.append(1.0 - r["V"])
        elif r["status"] == "all liquid":
            L.append(1.0)
        elif r["status"] == "all vapour":
            L.append(0.0)
        else:
            # successive substitution slows to a crawl within a per cent or so
            # of a phase boundary, where the two phases are nearly identical.
            # A nan is the honest answer; a zero would draw a curve through a
            # point that was never computed.
            L.append(np.nan)
    return Ps, np.array(L)


# ==========================================================================
def retrograde_window(env):
    """The temperature band in which dropping P at constant T condenses liquid.

    It runs from the mixture critical temperature to the cricondentherm. Inside
    it the two-phase region is entered and left through the dew curve twice, so
    an isothermal expansion crosses the upper dew point, forms liquid, and then
    re-vaporises it at the lower dew point. Outside it — at any temperature
    below the critical — expansion does what intuition says.

    Returned as (T_critical, T_cricondentherm). Empty (None) if the trace never
    reached a critical point, which for a mixture of similar components is the
    normal outcome at the pressures traced.
    """
    if env.critical is None or env.cricondentherm is None:
        return None
    Tc = env.critical[0]
    Tct = env.cricondentherm[0]
    return (Tc, Tct) if Tct > Tc else None


def dew_branch_at_T(env, T):
    """The pressures at which the dew curve crosses a given temperature.

    Returns them sorted. Two values inside the retrograde window and one
    outside it — which is the retrograde phenomenon stated as a fact about the
    geometry of the curve rather than as an assertion about liquid dropout.
    """
    Td, Pd = env.dew
    out = []
    for i in range(len(Td) - 1):
        a, b = Td[i], Td[i + 1]
        if (a - T) * (b - T) <= 0 and a != b:
            w = (T - a) / (b - a)
            out.append(Pd[i] + w * (Pd[i + 1] - Pd[i]))
    return np.sort(np.array(out))
