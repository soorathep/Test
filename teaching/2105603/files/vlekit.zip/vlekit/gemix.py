"""EoS-G^E mixing rules: Huron-Vidal and Wong-Sandler.

`cubic.py` mixes with the van der Waals one-fluid rule, a quadratic in
composition with one adjustable number per pair. That rule is very good for
mixtures of hydrocarbons and very bad for anything that hydrogen bonds: a
single k_ij cannot bend the a(x) curve into the shape that an alcohol + water
mixture requires. Meanwhile `models.py` describes exactly those mixtures well,
but only as a liquid, only below the critical point of every component, and
with no equation for the vapour.

This module is the bridge. The idea, due to Huron and Vidal (Fluid Phase
Equilibria 3 (1979) 255-271), is to stop guessing a(x) and instead *require*
that the equation of state reproduce a chosen excess Gibbs energy. One
reference state makes that requirement solvable in closed form: infinite
pressure, where the liquid is packed against its own co-volume, v -> b, the
excess volume vanishes, and the excess Gibbs energy of the equation of state
collapses to an algebraic function of a and b. Setting that function equal to
the G^E of an activity model gives one equation, and the two mixing rules here
are two different ways of closing it:

    Huron-Vidal    keep b linear in composition, solve for a. Simple, exact at
                   infinite pressure, and it destroys the quadratic composition
                   dependence of the second virial coefficient.
    Wong-Sandler   impose that quadratic dependence as a second equation and
                   solve for a and b together. One extra binary parameter,
                   k_ij, appears inside the constraint.

Why the second virial coefficient matters is worth stating plainly, because it
is the whole argument for the extra complication. Every equation of state has a
low-density expansion, and for a cubic that expansion begins

    Z = 1 + B(T, x) / v + ...,        B(T, x) = b(x) - a(T, x) / RT

Statistical mechanics says B for a mixture is *exactly* quadratic in
composition -- it is a sum over pairs of molecules and there is nothing else it
could be. The classical rule satisfies that identity by accident of its own
form. Huron-Vidal does not, so its predictions have a built-in error at low
density which grows with the strength of the G^E model, and that error is why
Huron-Vidal parameters fitted at one temperature travel badly to another.
Wong-Sandler was constructed to keep both properties at once. `test_gemix.py`
measures the violation rather than describing it.

Why a separate module rather than more of `cubic.py`: `cubic.py` is already
long, and everything in it is one subject -- one equation of state, one mixing
rule, and the phase behaviour that follows. The G^E link is a different
subject, it needs `models.py` as well, and it is lectured separately. What the
classes here do *not* do is replace anything: `HuronVidal` and `WongSandler`
subclass `PengRobinson` and override only `a_mix`, `b_mix` and `ln_phi`, so
every module-level routine in `cubic.py` -- `psat`, `bubble_P`, `dew_T`,
`flash_TP`, `envelope` -- keeps working on them unchanged. That is the point of
writing them as a mixing rule rather than as a new equation of state.

Binary mixtures only, because `models.py` is binary only. The algebra below is
written in general N-component form anyway, since it costs nothing and shows
the student what generalises.
"""
from __future__ import annotations

import numpy as np

from .cubic import PengRobinson, R, SQRT2
from .models import ActivityModel

__all__ = ["C_PR", "GEMixingRule", "HuronVidal", "WongSandler", "ClassicalGE",
           "vanlaar_equivalent_of_classical", "ares_RT", "gE_from_eos",
           "aE_from_eos", "second_virial", "second_virial_quadratic",
           "ln_phi_numeric", "bubble_P", "gamma_phi_start"]


# ==========================================================================
# The constant C, derived rather than asserted
# ==========================================================================
# Start from the residual Helmholtz energy of the Peng-Robinson equation at
# constant T and V, which is the integral of (P - RT/v) dv and is the same
# expression `cubic.gres_RT` is built from:
#
#     A^res(T, v)/RT = -ln(Z - B) + ln Z - A/(2 sqrt2 B) * L
#     L = ln[ (Z + (1 + sqrt2) B) / (Z + (1 - sqrt2) B) ]
#
# and the residual Gibbs energy that follows from it,
#
#     G^res/RT = A^res/RT + (Z - 1) - ln Z
#              = (Z - 1) - ln(Z - B) - A/(2 sqrt2 B) * L
#
# Now let P -> infinity at fixed T. The equation of state says
# P = RT/(v - b) - a/[v(v+b) + b(v-b)], so v - b -> RT/P, i.e. the liquid is
# squeezed onto its own co-volume and
#
#     Z - B = P(v - b)/RT -> 1        so   ln(Z - B) -> 0
#     Z/B   = v/b         -> 1        so   Z -> B
#
# With Z -> B the logarithm L has a finite limit that contains no property of
# the fluid at all:
#
#     L -> ln[ (B + (1+sqrt2)B) / (B + (1-sqrt2)B) ] = ln[(2+sqrt2)/(2-sqrt2)]
#        = ln(3 + 2 sqrt2) = ln[(1 + sqrt2)^2] = 2 ln(1 + sqrt2)
#
# and A/(2 sqrt2 B) = a / (2 sqrt2 b RT) loses its pressure. So
#
#     G^res/RT -> B - (a / (b RT)) * ln(1 + sqrt2) / sqrt2
#              =  B + C a / (b RT),        C = -ln(1 + sqrt2)/sqrt2
#                                            =  ln(sqrt2 - 1)/sqrt2
#
# because ln(sqrt2 - 1) = -ln(sqrt2 + 1); the two forms are the same number,
# and it is negative.
#
# The excess Gibbs energy is the mixture value minus the mole-fraction average
# of the pure ones at the same T and P (the ideal-gas and ideal-mixing parts
# cancel identically), so
#
#     G^E_inf/RT = [B_mix - sum_i x_i B_i] + C [ a/(b RT) - sum_i x_i a_i/(b_i RT) ]
#
# The first bracket is P/RT times (b_mix - sum_i x_i b_i), which is P V^E in
# the infinite-pressure limit. It VANISHES if and only if b is linear in
# composition, which is exactly the assumption Huron-Vidal makes and exactly
# the assumption Wong-Sandler gives up. With it gone,
#
#     G^E_inf = C [ a/b - sum_i x_i a_i/b_i ]
#     =>  a/b = sum_i x_i a_i/b_i + G^E_inf / C
#
# Sign check, which is the part worth doing slowly. C < 0, so a positive G^E
# *lowers* a/b. That is the right direction: positive deviations from Raoult's
# law mean the unlike attraction is weaker than the mean of the like ones, and
# in the classical rule the same physics is produced by a positive k_ij, which
# also lowers a. Writing the rule as "minus G^E/C" with a *negative* C would
# reverse it and make every positive-deviation system look like a
# negative-deviation one. Some references define C with the opposite sign and
# then subtract; both conventions appear in print, only one can be used with
# the value below, and `test_huron_vidal_reproduces_its_gE_at_infinite_pressure`
# is the test that settles it, since it takes the limit numerically instead of
# trusting either the algebra or the reference.
#
# For Soave-Redlich-Kwong the same derivation gives C = -ln 2, which is the
# constant in Huron and Vidal's original paper; the value depends on the volume
# translation of the cubic and on nothing else.
C_PR = np.log(SQRT2 - 1.0) / SQRT2          # = -0.6232252401402305

# The activity models are singular exactly at a pure end point (Wilson and
# UNIQUAC contain x ln x), while every mixing rule below needs G^E and
# ln gamma there. The limit exists and is zero for G^E and finite for
# ln gamma, so composition is nudged inside the open interval by this much
# before the activity model sees it. It changes nothing at four significant
# figures anywhere else, and `test_ln_phi_goes_to_the_pure_limit` measures what
# it leaves behind.
_XEPS = 1e-12


# ==========================================================================
class GEMixingRule(PengRobinson):
    """Shared machinery for the two infinite-pressure G^E mixing rules.

    Both rules set the same dimensionless group

        D(T, x) = a_mix / (b_mix R T)
                = sum_i x_i a_i/(b_i R T) + G^E(T, x)/(R T C)

    and differ only in where b_mix comes from. Everything else -- the partial
    molar quantities, the fugacity coefficient, the numerical cross-checks --
    is written once, here.

    ASSUMPTION, and it is the one a reader should know about: G^E is supplied
    by an activity model fitted to low-pressure VLE data, whereas the quantity
    the derivation actually produces is the excess Helmholtz energy at infinite
    pressure. Those are two different functions of state. Equating them is not
    a theorem; it is the empirical observation that G^E is a weak function of
    pressure, and it is where the temperature extrapolation of these rules
    ultimately comes from and ultimately fails. `aE_from_eos` computes the
    excess Helmholtz energy that the equation of state really has, so the size
    of the assumption can be looked at instead of assumed away.
    """

    #: the infinite-pressure constant of the cubic, derived at the top of the file
    C = C_PR

    def __init__(self, components, gE, alpha="1976"):
        if len(components) != 2:
            raise ValueError("the G^E mixing rules here are binary only, "
                             "because vlekit.models is binary only")
        if not isinstance(gE, ActivityModel):
            raise TypeError("gE must be a vlekit.models.ActivityModel")
        # kij is deliberately not accepted by the base class: in Huron-Vidal
        # the whole binary information lives in the activity model, and in
        # Wong-Sandler the binary parameter belongs to a different term and is
        # stored separately. The inherited self.kij therefore stays zero, and
        # the inherited `a_cross` -- which is not used by either rule -- returns
        # the plain geometric mean.
        super().__init__(components, kij=None, alpha=alpha)
        self.gE = gE

    # ------------------------------------------------------- the G^E model
    def _x1(self, x):
        """Mole fraction of component 1, nudged off the singular end points."""
        return float(np.clip(self._clean(x)[0], _XEPS, 1.0 - _XEPS))

    def gE_RT(self, T, x):
        """G^E/RT of the activity model at this composition."""
        return float(self.gE.gE_RT(self._x1(x), T))

    def ln_gamma(self, T, x):
        """[ln gamma_1, ln gamma_2] of the activity model, as an array."""
        lg1, lg2 = self.gE.ln_gamma(self._x1(x), T)
        return np.array([float(lg1), float(lg2)])

    # ----------------------------------------------------- the group D
    def D(self, T, x):
        """D = a_mix/(b_mix R T), the infinite-pressure statement itself."""
        x = self._clean(x)
        return float(x @ (self.a_pure(T) / (self.b * R * float(T))
                          )) + self.gE_RT(T, x) / self.C

    def D_bar(self, T, x):
        """d(n D)/dn_i at n = 1, i.e. the partial molar D.

        n D = sum_i n_i a_i/(b_i R T) + n G^E/(R T C), and the partial molar
        quantity of n G^E/RT is ln gamma_i by definition -- which is the only
        place the activity model's derivative is needed, and the reason these
        rules can be differentiated in closed form at all.
        """
        return (self.a_pure(T) / (self.b * R * float(T))
                + self.ln_gamma(T, x) / self.C)

    # -------------------------------------------- what the subclasses supply
    def b_mix(self, x, T=None):
        raise NotImplementedError

    def b_bar(self, T, x):
        """d(n b_mix)/dn_i at n = 1."""
        raise NotImplementedError

    # ------------------------------------------------- what follows from them
    def a_mix(self, T, x):
        return self.b_mix(x, T) * R * float(T) * self.D(T, x)

    def a_bar(self, T, x):
        """d(n^2 a_mix)/dn_i at n = 1.

        n^2 a_mix = (n b_mix)(n D) R T is a product of two extensive
        quantities, so the derivative is the product rule and nothing else.
        """
        return R * float(T) * (self.b_bar(T, x) * self.D(T, x)
                               + self.b_mix(x, T) * self.D_bar(T, x))

    def AB(self, T, P, x):
        """A and B. Overridden only because b_mix may now depend on T."""
        T, Pa = float(T), float(P) * 1e3
        A = self.a_mix(T, x) * Pa / (R * T) ** 2
        B = self.b_mix(x, T) * Pa / (R * T)
        return A, B

    # ------------------------------------------------------------- fugacity
    def ln_phi(self, T, P, x, phase="stable"):
        """ln phi_i for every component, and the Z it was evaluated at.

        The general form for any Peng-Robinson mixing rule is

            ln phi_i = (bbar_i/b)(Z - 1) - ln(Z - B)
                       - A/(2 sqrt2 B) [ abar_i/a - bbar_i/b ] L

        with abar_i = d(n^2 a)/dn_i and bbar_i = d(n b)/dn_i, both at n = 1.
        The version in `cubic.py` is this expression with the classical
        derivatives already substituted: abar_i = 2 sum_j x_j a_ij and
        bbar_i = b_i. The second of those is true for Huron-Vidal and FALSE for
        Wong-Sandler, whose b_mix is not linear in composition, so using
        `cubic.ln_phi` on a Wong-Sandler object would give a smooth, plausible,
        wrong answer. That is why this method exists and why
        `test_analytic_and_numerical_derivatives_agree` exists next to it.
        """
        x = self._clean(x)
        Z = self.select_root(T, P, x, phase)
        A, B = self.AB(T, P, x)
        a, b = self.a_mix(T, x), self.b_mix(x, T)
        bi_b = self.b_bar(T, x) / b
        L = np.log((Z + (1 + SQRT2) * B) / (Z + (1 - SQRT2) * B))
        return (bi_b * (Z - 1.0) - np.log(Z - B)
                - A / (2 * SQRT2 * B) * (self.a_bar(T, x) / a - bi_b) * L), Z

    # ------------------------------------------- numerical cross-checks
    # Written out because the analytical derivatives above are the single most
    # error-prone lines in the module, and a student is better served by two
    # independent routes that must agree than by one clever one that is merely
    # asserted to be right.
    def _perturb(self, T, x, i, d, f):
        """f evaluated at mole numbers x with n_i shifted by d."""
        n = np.array(self._clean(x), dtype=float)
        n[i] += d
        ntot = n.sum()
        return f(ntot, n / ntot)

    def b_bar_numeric(self, T, x, h=1e-7):
        """d(n b_mix)/dn_i by central differences on the mole numbers."""
        return np.array([
            (self._perturb(T, x, i, +h, lambda nt, xx: nt * self.b_mix(xx, T))
             - self._perturb(T, x, i, -h, lambda nt, xx: nt * self.b_mix(xx, T)))
            / (2 * h) for i in range(self.n)])

    def a_bar_numeric(self, T, x, h=1e-7):
        """d(n^2 a_mix)/dn_i by central differences on the mole numbers."""
        g = lambda nt, xx: nt ** 2 * self.a_mix(T, xx)
        return np.array([
            (self._perturb(T, x, i, +h, g) - self._perturb(T, x, i, -h, g))
            / (2 * h) for i in range(self.n)])

    def __repr__(self):
        names = "/".join(c.name for c in self.components)
        return (f"<{type(self).__name__} {names}, "
                f"G^E={self.gE.name}, alpha={self.alpha_rule}>")


# ==========================================================================
class HuronVidal(GEMixingRule):
    """Huron-Vidal: b linear in composition, a from the G^E match.

        b_mix = sum_i x_i b_i
        a_mix / b_mix = sum_i x_i a_i/b_i + G^E(T, x) / C

    Two consequences follow immediately and both are tested.

    It reproduces the activity model exactly in the infinite-pressure limit,
    since that limit is the equation it was built from. It does *not* reproduce
    it at ordinary pressures, and it was never claimed to: what survives to
    1 bar is the shape of the G^E function, not its value.

    It gives up the quadratic composition dependence of the second virial
    coefficient. B = b - a/RT is now b_mix(1 - D), and D contains G^E, which
    for any real activity model is not a quadratic. `test_second_virial_...`
    reports how large the violation is for a fitted model.

    Since b stays linear, d(n b)/dn_i = b_i exactly as in the classical rule,
    and the only new term in ln phi_i comes through a.
    """

    def b_mix(self, x, T=None):
        # linear, and T is accepted only so that the signature matches
        # WongSandler and the shared AB() can call both the same way
        return float(self._clean(x) @ self.b)

    def b_bar(self, T, x):
        return self.b.copy()


# ==========================================================================
class WongSandler(GEMixingRule):
    """Wong-Sandler: the same G^E match, with the second virial constraint.

    Two equations for the two unknowns a_mix and b_mix:

        (1) b_mix - a_mix/RT = sum_i sum_j x_i x_j (b - a/RT)_ij     virial
        (2) a_mix / (b_mix R T) = D(T, x)                            G^E match

    with the cross term of (1) built by an arithmetic mean of the co-volumes,
    a geometric mean of the attractions, and one adjustable binary number:

        (b - a/RT)_ij = [ (b_i + b_j)/2 - sqrt(a_i a_j)/RT ] (1 - k_ij)

    Substituting (2) into (1) gives the rule in the form it is usually quoted:

        b_mix = Q / (1 - D),        a_mix = R T b_mix D,     Q = sum sum x x Q_ij

    Note what k_ij here is NOT: it is not the classical k_ij of `cubic.py`.
    That one multiplies sqrt(a_i a_j) alone; this one multiplies the whole
    second-virial cross coefficient, so the same numerical value means
    different things in the two rules and a value fitted for one must never be
    carried over to the other. It is stored as `kij_ws` for that reason, and
    the inherited `self.kij` is left at zero.

    The price of the constraint is that b_mix is no longer linear in
    composition. Every composition derivative therefore changes, which is the
    part of this rule that gets implemented wrongly in practice.
    """

    def __init__(self, components, gE, kij=0.0, alpha="1976"):
        super().__init__(components, gE, alpha=alpha)
        k = np.zeros((self.n, self.n)) if kij is None else np.asarray(
            kij, dtype=float)
        if k.ndim == 0:                     # a scalar means the one binary pair
            k = np.full((self.n, self.n), float(k))
            np.fill_diagonal(k, 0.0)
        self.kij_ws = k.reshape(self.n, self.n)
        if not np.allclose(self.kij_ws, self.kij_ws.T):
            raise ValueError("kij must be symmetric")
        if not np.allclose(np.diag(self.kij_ws), 0.0):
            raise ValueError("kij must have a zero diagonal: k_ii would change "
                             "the pure-component second virial coefficient")

    # ---------------------------------------------------------------- Q
    def Q_cross(self, T):
        """The matrix (b - a/RT)_ij, i.e. the second virial cross coefficients."""
        T = float(T)
        ai = self.a_pure(T)
        bij = 0.5 * (self.b[:, None] + self.b[None, :])
        aij = np.sqrt(np.outer(ai, ai))
        return (bij - aij / (R * T)) * (1.0 - self.kij_ws)

    def Q_mix(self, T, x):
        x = self._clean(x)
        return float(x @ self.Q_cross(T) @ x)

    def Q_bar(self, T, x):
        """d(n Q)/dn_i at n = 1. Q is a quadratic mean, so this is standard."""
        x = self._clean(x)
        return 2.0 * (self.Q_cross(T) @ x) - self.Q_mix(T, x)

    # ---------------------------------------------------------------- b, a
    def b_mix(self, x, T=None):
        if T is None:
            raise ValueError("Wong-Sandler b_mix depends on temperature "
                             "through the second virial constraint; pass T")
        D = self.D(T, x)
        if abs(1.0 - D) < 1e-10:
            # D = 1 means a_mix = b_mix R T exactly, and the constraint has no
            # solution. It happens far above the temperatures this is used at,
            # but a silent division by zero would be much worse than a message.
            raise ValueError(f"Wong-Sandler is singular at D = {D:.6g}: the "
                             f"second virial constraint has no solution")
        return self.Q_mix(T, x) / (1.0 - D)

    def b_bar(self, T, x):
        """d(n b_mix)/dn_i at n = 1.

        n b = (n Q)/(1 - D). D is intensive, so d D/dn_i = Dbar_i - D at n = 1
        (from n D being extensive), and the quotient rule gives

            bbar_i = [ Qbar_i + b (Dbar_i - D) ] / (1 - D)

        This is the derivative the classical `cubic.ln_phi` gets wrong, and it
        is checked against `b_bar_numeric` in the tests rather than trusted.
        """
        D = self.D(T, x)
        b = self.b_mix(x, T)
        return (self.Q_bar(T, x) + b * (self.D_bar(T, x) - D)) / (1.0 - D)


# ==========================================================================
# The degenerate G^E: what the classical rule is secretly assuming
# ==========================================================================
class ClassicalGE(ActivityModel):
    """The excess Gibbs energy the van der Waals one-fluid rule itself implies.

    Run the Huron-Vidal derivation backwards. If a_mix and b_mix are the
    classical quadratic and linear rules, then at infinite pressure the
    equation of state already has an excess Gibbs energy, namely

        G^E_cl/RT = (C/RT) [ a_cl(T, x)/b_cl(x) - sum_i x_i a_i/b_i ]

    Feed *that* back into Huron-Vidal or Wong-Sandler and the classical rule
    comes back exactly. So the classical rule is not an alternative to the G^E
    route -- it is the G^E route with one particular, and rather rigid, choice
    of activity model. That is the cleanest way to say what these rules buy,
    and it is a test as well as a slogan.

    Temperature is not optional here: a_i(T) is in the expression. The model
    therefore raises if called with T = None, unlike the fitted models in
    `models.py` whose parameters already absorbed the temperature.
    """

    name = "classical-G^E"
    param_names = ()
    param_labels = ()

    def __init__(self, pr):
        super().__init__([])
        self.pr = pr

    def _x(self, x1):
        x1 = np.asarray(x1, dtype=float)
        return np.stack([x1, 1.0 - x1], axis=-1)

    def _need_T(self, T):
        if T is None:
            raise ValueError("ClassicalGE depends on temperature through "
                             "a_i(T); pass T")
        return float(T)

    def gE_RT(self, x1, T=None):
        T = self._need_T(T)
        pr = self.pr
        X = self._x(x1)
        aij, ai, bi = pr.a_cross(T), pr.a_pure(T), pr.b
        a = np.einsum("...i,ij,...j->...", X, aij, X)
        b = X @ bi
        return (C_PR / (R * T)) * (a / b - X @ (ai / bi))

    def ln_gamma(self, x1, T=None):
        """The partial molar quantity of the above, in closed form.

        n G^E/RT = (C/RT)[ (n^2 a)/(n b) - sum_i n_i a_i/b_i ], so
            ln gamma_i = (C/RT)[ abar_i/b - a b_i/b^2 - a_i/b_i ]
        with the classical abar_i = 2 sum_j x_j a_ij and bbar_i = b_i.
        """
        T = self._need_T(T)
        pr = self.pr
        X = self._x(x1)
        aij, ai, bi = pr.a_cross(T), pr.a_pure(T), pr.b
        a = np.einsum("...i,ij,...j->...", X, aij, X)
        b = X @ bi
        abar = 2.0 * (X @ aij)
        lg = (C_PR / (R * T)) * (abar / b[..., None]
                                 - (a / b ** 2)[..., None] * bi
                                 - ai / bi)
        return lg[..., 0], lg[..., 1]


def vanlaar_equivalent_of_classical(pr, T):
    """The van Laar model that is exactly `ClassicalGE`, when every k_ij = 0.

    Worth writing down because it is a closed form and it is the historical
    statement of the result (Vidal, Chem. Eng. Sci. 33 (1978) 787). With
    a_12 = sqrt(a_1 a_2) the numerator of `ClassicalGE` factorises:

        a_cl/b_cl - sum x_i a_i/b_i
            = - x1 x2 [ sqrt(a1 b2/b1) - sqrt(a2 b1/b2) ]^2 / (x1 b1 + x2 b2)

    a perfect square, so G^E/RT = K x1 x2 / (x1 b1 + x2 b2) with
    K = -C [..]^2/RT > 0, and that is a van Laar function with
    A = K/b2, B = K/b1. Returns (A, B).

    The factorisation needs k_12 = 0; with k_12 != 0 the bracket is no longer a
    square and `ClassicalGE` is still right while van Laar is no longer enough.
    """
    from .models import VanLaar

    T = float(T)
    a, b = pr.a_pure(T), pr.b
    if not np.allclose(pr.kij, 0.0):
        raise ValueError("the van Laar equivalence holds only for k_ij = 0")
    delta = np.sqrt(a[0] * b[1] / b[0]) - np.sqrt(a[1] * b[0] / b[1])
    K = -C_PR * delta ** 2 / (R * T)
    return VanLaar([K / b[1], K / b[0]])


# ==========================================================================
# Diagnostics: the quantities the tests are about
# ==========================================================================
def ares_RT(mix, T, P, x, Z):
    """Residual Helmholtz energy at constant T and P, A^res/RT, at a given root.

        A(T,P) - A^ig(T,P) = A^res(T,V) - RT ln Z = RT [ G^res/RT - (Z - 1) ]

    This is the quantity whose excess has a finite infinite-pressure limit for
    *both* mixing rules, and it is also far better conditioned numerically than
    G^res: the divergent (Z - 1) term is subtracted off analytically instead of
    being left to cancel against an equally large number.
    """
    A, B = mix.AB(T, P, x)
    return (-np.log(Z - B) - A / (2 * SQRT2 * B)
            * np.log((Z + (1 + SQRT2) * B) / (Z + (1 - SQRT2) * B)))


def _excess(mix, T, P, x, fn, phase="liquid"):
    """Excess of a per-mole residual property: mixture minus the pure average."""
    x = mix._clean(x)
    Zm = mix.select_root(T, P, x, phase)
    out = fn(mix, T, P, x, Zm)
    for i in range(mix.n):
        e = mix.unit(i)
        Zi = mix.select_root(T, P, e, phase)
        out = out - x[i] * fn(mix, T, P, e, Zi)
    return float(out)


def gE_from_eos(mix, T, P, x, phase="liquid"):
    """G^E/RT of the equation of state itself, at a finite pressure.

    The ideal-gas and ideal-mixing contributions cancel between the mixture and
    the pure components, so the excess Gibbs energy is just the excess of the
    residual part. For Huron-Vidal this converges to the activity model's
    G^E/RT as P -> infinity. For Wong-Sandler it does not converge at all: it
    grows like P V^E, because Wong-Sandler's b_mix is not linear and so its
    excess volume at infinite pressure is not zero. `aE_from_eos` is the
    quantity to use there, and the difference between the two is exactly P V^E.
    """
    return _excess(mix, T, P, x,
                   lambda m, T, P, xx, Z: m.gres_RT(T, P, xx, Z), phase)


def aE_from_eos(mix, T, P, x, phase="liquid"):
    """A^E/RT of the equation of state itself, at a finite pressure.

    Converges to the input activity model for both rules, because the
    infinite-pressure match is really a Helmholtz-energy match. See the
    ASSUMPTION note on `GEMixingRule`.
    """
    return _excess(mix, T, P, x, ares_RT, phase)


def second_virial(mix, T, x):
    """B(T, x) = b_mix - a_mix/RT, the second virial coefficient of the cubic.

    Expand Z = Pv/RT for the Peng-Robinson equation in 1/v:
        Z = v/(v-b) - a v /[RT(v(v+b)+b(v-b))] = 1 + (b - a/RT)/v + O(1/v^2)
    so this really is the coefficient the virial equation would report, and it
    is the property statistical mechanics requires to be quadratic in x.
    """
    T = float(T)
    b = mix.b_mix(x, T) if isinstance(mix, GEMixingRule) else mix.b_mix(x)
    return b - mix.a_mix(T, x) / (R * T)


def second_virial_quadratic(mix, T, x, B12=None):
    """sum_i sum_j x_i x_j B_ij, the quadratic form B(T, x) is supposed to have.

    B_11 and B_22 are fixed by the pure components. B_12 is not a free
    parameter of the comparison but is *read off* the rule itself, at x1 = 1/2,
    so that the quadratic and the rule agree at three compositions by
    construction and any residual difference elsewhere is a genuine departure
    from quadratic behaviour rather than a bad choice of cross coefficient.
    """
    T = float(T)
    B11 = second_virial(mix, T, mix.unit(0))
    B22 = second_virial(mix, T, mix.unit(1))
    if B12 is None:
        Bh = second_virial(mix, T, np.array([0.5, 0.5]))
        B12 = 2.0 * Bh - 0.5 * (B11 + B22)      # invert the quadratic at x=1/2
    x = mix._clean(x)
    B = np.array([[B11, B12], [B12, B22]])
    return float(x @ B @ x)


def bubble_P(mix, x, T, P0=None, tol=1e-12, itmax=400):
    """Bubble pressure and incipient vapour composition, by successive substitution.

    `cubic.bubble_P` already does this by Newton on the full N+2 system, and it
    is the routine to use near a critical point. It is *not* the routine to use
    here, and the reason is worth a paragraph because it is a real limitation
    and not a bug.

    Newton in `cubic.py` selects each root by Gibbs energy (`phase='stable'`),
    which is what lets a single set of equations run through the critical point
    onto the dew branch. The price is that the choice can flip while the solver
    is still far from the answer: for a strongly non-ideal liquid at 20 kPa the
    starting pressure from Raoult's law is 30 per cent too high, at that
    pressure the trial vapour composition is liquid-stable, the residual it
    returns is meaningless, and Newton walks away to P -> 0. Warm-starting it
    from the activity model (`gamma_phi_start`) fixes most of the points and
    not all of them.

    So this routine does the opposite thing: it forces the liquid root for x
    and the vapour root for y, iterating

        K_i = phi_i^L(T, P, x) / phi_i^V(T, P, y),   y <- Kx/sum(Kx),
        P   <- P * sum_i K_i x_i

    until sum_i K_i x_i = 1. Forcing the branch is safe far below the critical
    point and unsafe near it, which is exactly the opposite trade-off, and
    together the two routines cover the range. Returns (P, y, iterations), with
    iterations = -1 if it did not converge.
    """
    x = mix._clean(x)
    P = float(P0) if P0 is not None else float(
        np.sum(x * np.array([_psat_cached(mix, i, T) for i in range(mix.n)])))
    y = x.copy()
    for it in range(itmax):
        lx, _ = mix.ln_phi(T, P, x, "liquid")
        ly, _ = mix.ln_phi(T, P, y, "vapour")
        K = np.exp(lx - ly)
        S = float(np.sum(K * x))
        y = K * x / S
        P = P * S
        if abs(S - 1.0) < tol:
            return P, y, it
    return P, y, -1


def _psat_cached(mix, i, T):
    """Pure vapour pressure from the equation of state, memoised.

    `cubic.psat` brackets by scanning 400 pressures, so calling it once per
    composition point turns a cheap calculation into a slow one. The cache is
    keyed on the component and T only, because that is all psat depends on.
    """
    key = (id(mix.components[i]), mix.alpha_rule, float(T))
    if key not in _PSAT_CACHE:
        from .cubic import psat
        _PSAT_CACHE[key] = psat(mix, i, T)
    return _PSAT_CACHE[key]


_PSAT_CACHE: dict = {}


def gamma_phi_start(mix, x, T):
    """A starting (P, K) for a bubble point, from the mixing rule's own G^E model.

    P = sum_i x_i gamma_i Psat_i and K_i = gamma_i Psat_i / P: modified
    Raoult's law, with the activity coefficients taken from the very model that
    was fed to the mixing rule and the vapour pressures taken from the equation
    of state itself, so that the guess is consistent with both halves of the
    calculation. It is only a guess -- the whole point of the G^E route is that
    the equation of state does not reproduce the activity model at 1 bar -- but
    it is a far better one than Raoult with gamma = 1.
    """
    x = mix._clean(x)
    Ps = np.array([_psat_cached(mix, i, T) for i in range(mix.n)])
    gam = np.exp(mix.ln_gamma(T, x))
    P = float(np.sum(x * gam * Ps))
    return P, gam * Ps / P


def ln_phi_numeric(mix, T, P, x, phase="stable", h=1e-6):
    """ln phi_i by differentiating n G^res/RT with respect to n_i.

    The definition, not a rearrangement of it:
        ln phi_i = [ d(n G^res/RT) / dn_i ]_{T, P, n_j}
    Note that T and P are held fixed, so Z is re-solved at every perturbed
    composition; that is what makes this an independent check of the analytic
    expression rather than a restatement of it.
    """
    x = mix._clean(x)

    def nG(n):
        ntot = n.sum()
        xx = n / ntot
        Z = mix.select_root(T, P, xx, phase)
        return ntot * mix.gres_RT(T, P, xx, Z)

    out = np.empty(mix.n)
    for i in range(mix.n):
        p, m = x.copy(), x.copy()
        p[i] += h
        m[i] -= h
        out[i] = (nG(p) - nG(m)) / (2 * h)
    return out
