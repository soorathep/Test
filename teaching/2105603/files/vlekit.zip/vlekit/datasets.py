"""Four published binary VLE datasets, one for each deviation class.

The course classifies a binary mixture by what its excess Gibbs energy does:

    Type 1   near-ideal, gamma ~ 1 across the whole range, no azeotrope
    Type 2   positive deviation, gamma > 1, but the deviation is never large
             enough to make the P-x curve turn over: no azeotrope
    Type 3   positive deviation strong enough to produce a pressure maximum,
             i.e. a minimum-boiling azeotrope
    Type 4   negative deviation with a pressure minimum, i.e. a
             maximum-boiling azeotrope

Every module before this one takes a dataset as given. This one is about where
the dataset comes from, because a number copied out of a textbook table with no
citation is not evidence, and a student who cannot say where a number came from
cannot defend a conclusion drawn from it.

Standard of evidence
--------------------
Nothing appears below unless all five of the following were done:

1.  The DOI resolves and the full bibliographic record (authors, title,
    journal, year, volume, issue, pages) was retrieved from the publisher's
    record, not copied from another paper's reference list.
2.  The record was checked for editorial notices. None of the papers cited
    here carries a retraction, correction, erratum or expression of concern.
3.  The numeric table was transcribed mechanically, not by eye. Four of the
    five tables were parsed out of the NIST TRC ThermoML digitisation of the
    paper (https://trc.nist.gov/ThermoML/<doi>.xml, the archive documented at
    https://doi.org/10.18434/mds2-2422); the fifth was read from the
    publisher's own HTML and PDF renderings and the two were required to
    agree digit for digit. The parser was itself validated by re-reading one
    dataset from NIST's own JSON rendering and confirming the first eight
    (x, P) pairs matched.
4.  The pure-component end points were checked against the Antoine
    correlations in `vlekit.data.LIBRARY`. The discrepancy is stated in per
    cent beside every table, including the ones that are not small.
5.  The qualitative shape was checked against what the paper itself claims
    (azeotropic composition, sign of the deviation) and the five consistency
    tests in `vlekit.consistency` were run. Their verdicts are recorded beside
    the data, failures included.

A failure is reported, not hidden. Three of these five sets fail at least one
consistency test, and the reasons are instructive rather than disqualifying:
the area test divides by the integral of |ln(gamma1/gamma2)|, which for a
near-ideal system is nearly zero, so Type 1 data fails it structurally; the
Kojima infinite-dilution test is evaluated where the data are sparsest. Knowing
which test to disbelieve is the skill the course is trying to teach.

Units throughout: T in K, P in kPa, x1 and y1 mole fractions of component 1.

Caveat that applies to all of them
----------------------------------
Isothermal P-x-y is what the gamma-phi route wants, because at constant T the
Gibbs-Duhem equation has no enthalpy term. Only one of the five sets below
(chloroform + 2-butanone) is isothermal; the others are isobaric T-x-y, where
Gibbs-Duhem carries an extra -(H^E/RT^2) dT term that the plain area test
ignores. That is exactly why `consistency.herington_test` exists, and every
isobaric set here is labelled `kind='isobaric'` so the tests take the right
form.
"""
from __future__ import annotations

import numpy as np

from .data import Component, VLEData, component

__all__ = [
    "TOLUENE", "DATASETS", "TYPES", "load",
    "benzene_toluene", "methanol_water", "ethanol_water",
    "chloroform_butanone", "acetone_chloroform",
    "BENZENE_TOLUENE_101KPA", "METHANOL_WATER_66KPA", "METHANOL_WATER_37KPA",
    "ETHANOL_WATER_101KPA", "CHLOROFORM_BUTANONE_303K", "ACETONE_CHLOROFORM_101KPA",
]


# --------------------------------------------------------------------------
# One component the main LIBRARY does not carry.
#
# Antoine from the NIST Chemistry WebBook entry for toluene, which reproduces
# Stull, D. R., Ind. Eng. Chem. 1947, 39, 517-540:
#     log10(Psat/bar) = 4.07827 - 1343.943 / (T/K - 53.773),  273-371 K
# Checked the same two ways every LIBRARY entry is checked:
#     Tsat(101.325 kPa) = 383.773 K   against a normal boiling point of 383.78 K
#     Psat(298.15 K)    = 3.7914 kPa  against a tabulated 3.79 kPa
# The correlation is used slightly above its stated upper limit (to 383.8 K) in
# the benzene + toluene set; the boiling-point check above is precisely that
# extrapolation, so the error it introduces is the 0.005 K seen there.
# --------------------------------------------------------------------------
TOLUENE = Component.from_antoine(
    "toluene", 4.07827, 1343.943, -53.773, punit="bar", tunit="K",
    Tc=591.75, Pc=4108.0, omega=0.264, vL=106.9e-6, Trange=(273.0, 384.0),
    source="NIST WebBook / Stull 1947, log10(bar), T in K")


# ==========================================================================
# TYPE 1 -- near-ideal, no azeotrope
# ==========================================================================
# benzene (1) + toluene (2), isobaric at 101.33 kPa, 13 points.
#
# Li, H.; Han, M.; Gao, X.; Li, X.
#   "Isobaric vapor-liquid equilibrium for binary system of cinnamaldehyde +
#    benzaldehyde at 10, 20 and 30 kPa"
#   Fluid Phase Equilibria 2014, 364, 62-66.
#   https://doi.org/10.1016/j.fluid.2013.12.002
#   Editorial notices: none (checked 2026).
#
# WHY TYPE 1: benzene and toluene are the same functional class differing by
# one methyl group, so the unlike interaction is very close to the mean of the
# like ones. From the table itself, with modified Raoult and the LIBRARY
# Antoine sets, gamma1 runs 0.990-1.003 and gamma2 runs 0.934-1.014. y1 > x1
# at every point, so there is no y = x crossing and no azeotrope.
#
# PROVENANCE CAVEAT, stated plainly: benzene + toluene is not the subject of
# this paper. It is the binary the authors measured to validate their still
# before measuring cinnamaldehyde + benzaldehyde. That is a normal and
# legitimate use, and NIST TRC digitised it as reported experimental data, but
# it does mean the set is small (13 points) and was not the focus of the work.
# It was cross-checked against an independent measurement of the same system at
# the same pressure -- Gupta & Lee, Fluid Phase Equilib. 2012, 313, 190-195,
# https://doi.org/10.1016/j.fluid.2011.10.009 -- which agrees to about 0.02 in
# y1 and 0.9 K in T. The two are genuinely independent: different composition
# grids, different reported precision.
#
# END-POINT CHECK (both pure points were measured, so no extrapolation needed):
#   x1 = 1 (benzene):  T = 353.26 K, Psat_Antoine = 101.67 kPa vs P = 101.33 -> +0.33 %
#   x1 = 0 (toluene):  T = 383.81 K, Psat_Antoine = 101.43 kPa vs P = 101.33 -> +0.10 %
#
# TYPO / SMOOTHNESS CHECK: residuals of T(x1) about a quartic are 0.023 K rms,
# largest 1.9 sigma. Nothing looks like a transposed digit. The paper prints the
# table in descending x1; it is stored ascending here.
#
# CONSISTENCY (consistency.run_all, margules, ideal vapour):
#   area (Redlich-Kister)        44.83   threshold 10    FAIL
#   Herington D-J                31.86   threshold 10    FAIL
#   point (Van Ness-Byer-Gibbs)  0.00107 threshold 0.01  pass, index 1
#   direct (Van Ness 1995)       0.0215  threshold 0.05  pass, index 1
#   infinite dilution (Kojima)   157     threshold 30    FAIL
# Read this the right way round. The two tests that use every point and have a
# physically meaningful scale -- the point test and the direct test -- return
# the best index on the 1-10 scale, meaning y is predicted from P-x to within
# 0.001 in mole fraction. The area and Kojima statistics are ratios whose
# denominator is an integral of |ln(gamma1/gamma2)|; for a near-ideal system
# that denominator is nearly zero, so the ratio explodes on data that are in
# fact excellent. This dataset is the standing counter-example to "it failed
# the area test, therefore it is bad data".
BENZENE_TOLUENE_101KPA = [
    # x1(benzene), y1(benzene), T/K      at P = 101.33 kPa
    (0.0000, 0.0000, 383.81),
    (0.1061, 0.2203, 379.14),
    (0.2219, 0.4062, 374.56),
    (0.3214, 0.5357, 370.97),
    (0.4162, 0.6393, 367.78),
    (0.4942, 0.7110, 365.36),
    (0.5659, 0.7661, 363.37),
    (0.6604, 0.8318, 360.86),
    (0.7223, 0.8671, 359.32),
    (0.7921, 0.9075, 357.63),
    (0.8716, 0.9457, 355.94),
    (0.9552, 0.9834, 354.16),
    (1.0000, 1.0000, 353.26),
]

BENZENE_TOLUENE_CITATION = (
    "Li, H.; Han, M.; Gao, X.; Li, X. "
    "Isobaric vapor-liquid equilibrium for binary system of cinnamaldehyde + "
    "benzaldehyde at 10, 20 and 30 kPa. "
    "Fluid Phase Equilibria 2014, 364, 62-66. "
    "https://doi.org/10.1016/j.fluid.2013.12.002 "
    "(benzene + toluene at 101.33 kPa is the apparatus-validation binary; "
    "numbers via NIST TRC ThermoML)"
)


# ==========================================================================
# TYPE 2 -- positive deviation, no azeotrope
# ==========================================================================
# methanol (1) + water (2), isobaric, 16 points at each of two pressures.
#
# Yang, C.; Sun, F.; Ma, S.; Yin, X.; Zeng, H.
#   "Organic Salt Effect on Vapor-Liquid Equilibrium of the Methanol + Water
#    System at Subatmospheric Pressure"
#   Journal of Chemical & Engineering Data 2012, 57(10), 2696-2701.
#   https://doi.org/10.1021/je300613v
#   Editorial notices: none (checked 2026).
#
# WHY TYPE 2: methanol and water both hydrogen-bond, but a methanol-water bond
# is weaker than the water-water network it disrupts, so mixing costs energy
# and both activity coefficients exceed one. From the 66.52 kPa table, gamma1
# runs 1.007-2.166 and gamma2 runs 1.008-1.371 -- positive throughout. y1 > x1
# at every single point, at both pressures: there is no y = x crossing, so no
# azeotrope. Methanol + water is the standard textbook example of a system that
# deviates positively and still separates cleanly by ordinary distillation.
#
# END-POINT CHECK at 66.52 kPa (both pure points measured):
#   x1 = 1 (methanol): T = 327.45 K, Psat_Antoine = 66.35 kPa vs 66.52 -> -0.25 %
#   x1 = 0 (water):    T = 361.51 K, Psat_Antoine = 65.91 kPa vs 66.52 -> -0.91 %
# END-POINT CHECK at 37.5 kPa:
#   x1 = 1 (methanol): T = 313.55 K, Psat_Antoine = 35.87 kPa vs 37.50 -> -4.33 %
#   x1 = 0 (water):    T = 347.16 K, Psat_Antoine = 37.07 kPa vs 37.50 -> -1.14 %
#
# CAVEAT 1 -- the 37.5 kPa set. That -4.33 % is the one end-point discrepancy in
# this module that is larger than measurement scatter can explain. In
# temperature it is 0.96 K: the paper reports pure methanol boiling at 313.55 K
# where the Antoine correlation gives 314.51 K. Note also that the paper's own
# abstract quotes the lower pressure as 37.60 kPa while the NIST ThermoML record
# carries 37.5 kPa; 0.1 kPa accounts for only ~0.07 K, so it does not explain
# the gap. Either the reported pure-methanol boiling point is slightly low or
# the true pressure was lower than recorded. The 66.52 kPa set shows no such
# problem, so it is the default returned by methanol_water(); the 37.5 kPa set
# is provided because the discrepancy is worth showing to students rather than
# quietly dropping.
#
# CAVEAT 2 -- provenance. As with the Type 1 set, the binary is the reference
# measurement in a paper whose subject is the salt effect of tetramethyl-
# ammonium bicarbonate. The authors state that the salt-free binary passed both
# the Redlich-Kister area test and the Van Ness point test, which is consistent
# with what is found below at 66.52 kPa but not at 37.5 kPa.
#
# TYPO / SMOOTHNESS CHECK: residuals of T(x1) about a quintic are 0.28 K rms at
# both pressures, largest 2.3 sigma, at the pure-water end where the curve is
# steepest. No transposed digits.
#
# CONSISTENCY at 66.52 kPa:
#   area (Redlich-Kister)        11.51   threshold 10    FAIL (marginal)
#   Herington D-J                4.091   threshold 10    pass
#   point (Van Ness-Byer-Gibbs)  0.00562 threshold 0.01  pass, index 3
#   direct (Van Ness 1995)       0.0600  threshold 0.05  FAIL (marginal), index 3
#   infinite dilution (Kojima)   54.59   threshold 30    FAIL
# CONSISTENCY at 37.5 kPa:
#   area (Redlich-Kister)        15.50   threshold 10    FAIL
#   Herington D-J                0.579   threshold 10    pass
#   point (Van Ness-Byer-Gibbs)  0.0126  threshold 0.01  FAIL, index 6
#   direct (Van Ness 1995)       0.0919  threshold 0.05  FAIL, index 4
#   infinite dilution (Kojima)   81.01   threshold 30    FAIL
# The lower-pressure set is measurably the worse of the two, in the same
# direction as the end-point check. The Herington correction rescues the area
# test at both pressures, which is the whole point of it for isobaric data.
METHANOL_WATER_66KPA = [
    # x1(methanol), y1(methanol), T/K    at P = 66.52 kPa
    (0.0000, 0.0000, 361.51),
    (0.0200, 0.1390, 358.06),
    (0.0350, 0.2130, 355.60),
    (0.0740, 0.3710, 351.74),
    (0.1600, 0.5380, 346.11),
    (0.2460, 0.6270, 342.55),
    (0.2900, 0.6640, 341.13),
    (0.3330, 0.6980, 339.66),
    (0.3940, 0.7290, 338.28),
    (0.4490, 0.7690, 336.93),
    (0.5350, 0.8030, 335.15),
    (0.6200, 0.8490, 333.76),
    (0.7050, 0.8950, 332.21),
    (0.8190, 0.9350, 330.31),
    (0.9480, 0.9830, 328.20),
    (1.0000, 1.0000, 327.45),
]

METHANOL_WATER_37KPA = [
    # x1(methanol), y1(methanol), T/K    at P = 37.5 kPa (abstract says 37.60)
    (0.0000, 0.0000, 347.16),
    (0.0110, 0.0910, 344.65),
    (0.0360, 0.2470, 341.32),
    (0.0740, 0.4040, 337.78),
    (0.1610, 0.5830, 331.90),
    (0.2480, 0.6630, 328.06),
    (0.2920, 0.6920, 326.40),
    (0.3370, 0.7170, 325.30),
    (0.3910, 0.7400, 324.29),
    (0.4500, 0.7690, 322.68),
    (0.5420, 0.8110, 320.75),
    (0.6210, 0.8420, 319.47),
    (0.7070, 0.8750, 318.26),
    (0.8190, 0.9220, 316.24),
    (0.9460, 0.9790, 314.13),
    (1.0000, 1.0000, 313.55),
]

METHANOL_WATER_CITATION = (
    "Yang, C.; Sun, F.; Ma, S.; Yin, X.; Zeng, H. "
    "Organic Salt Effect on Vapor-Liquid Equilibrium of the Methanol + Water "
    "System at Subatmospheric Pressure. "
    "Journal of Chemical & Engineering Data 2012, 57(10), 2696-2701. "
    "https://doi.org/10.1021/je300613v "
    "(salt-free binary; numbers via NIST TRC ThermoML)"
)


# ==========================================================================
# TYPE 3 -- positive deviation with a minimum-boiling azeotrope
# ==========================================================================
# ethanol (1) + water (2), isobaric at 101.3 kPa, 21 points.
#
# Kamihama, N.; Matsuda, H.; Kurihara, K.; Tochigi, K.; Oba, S.
#   "Isobaric Vapor-Liquid Equilibria for Ethanol + Water + Ethylene Glycol and
#    Its Constituent Three Binary Systems"
#   Journal of Chemical & Engineering Data 2012, 57(2), 339-344.
#   https://doi.org/10.1021/je2008704
#   Editorial notices: none (checked 2026).
#   Measured with a modified Rogalski-Malanoski still; the authors state they
#   applied the point and area tests to the binary data themselves.
#
# WHY TYPE 3: the same hydrogen-bond argument as methanol + water, but ethanol's
# ethyl group makes the mismatch much larger -- gamma1 reaches 5.30 at the
# dilute-ethanol end. The deviation is strong enough that the relative
# volatility passes through one: y1 - x1 changes sign, giving the classical
# minimum-boiling azeotrope that makes anhydrous ethanol impossible to reach by
# simple distillation.
#
# AZEOTROPE CHECK: linear interpolation of y1 - x1 through zero between
# (x1 = 0.8690, y1 = 0.8730) and (x1 = 0.9010, y1 = 0.9000) gives
#     x_az = 0.8946
# against the accepted literature value of 0.894 at 101.3 kPa. The temperature
# minimum in the table, 351.26 K at x1 = 0.901-0.914, sits at the same place and
# is 0.08 K below the boiling point of pure ethanol, as it must be.
#
# COMPONENT NUMBERING -- a real trap, worth reading. The ThermoML record lists
# the substances as (water, ethanol) but numbers the mole fraction "component
# 1"; the numbering does not follow the listed order. Physics settles it: at
# x1 = 0.018 the mixture boils at 368.18 K and at x1 = 0.972 it boils at
# 351.35 K, and pure water and pure ethanol boil at 373.15 K and 351.4 K. The
# component whose mole fraction is tabulated is therefore ethanol. Any dataset
# taken from a machine-readable archive should be subjected to this check
# before it is used.
#
# END-POINT CHECK -- the pure components were NOT measured (x1 runs 0.018 to
# 0.972), so the ends are reached by fitting a quadratic to the four points
# nearest each end and extrapolating:
#   x1 -> 1 (ethanol): T_extrap = 351.42 K vs Antoine Tsat(101.3) = 351.34 K,
#                      dT = +0.08 K, equivalent to +0.32 % in pressure
#   x1 -> 0 (water):   T_extrap = 371.27 K vs Antoine Tsat(101.3) = 373.14 K,
#                      dT = -1.87 K, equivalent to -6.48 % in pressure
# The water end looks bad and is not. T(x1) is nearly vertical below
# x1 = 0.1 -- the lowest measured point is x1 = 0.018 -- so a quadratic fitted
# over 0.018 to 0.147 has no chance of tracking it to x1 = 0. The single point
# at x1 = 0.018 is itself entirely consistent: it gives gamma2 = 0.999, i.e.
# water at that composition is behaving as pure water should. The 6.5 % is an
# artefact of the extrapolation, not evidence against the data, and saying so
# requires looking at which quantity is actually poorly determined.
#
# TYPO / SMOOTHNESS CHECK: residuals of T(x1) about a quintic are 0.27 K rms,
# largest 2.0 sigma at x1 = 0.244. Nothing suggests a digit error.
#
# CONSISTENCY:
#   area (Redlich-Kister)        1.056   threshold 10    pass
#   Herington D-J                6.169   threshold 10    pass
#   point (Van Ness-Byer-Gibbs)  0.00541 threshold 0.01  pass, index 3
#   direct (Van Ness 1995)       0.0533  threshold 0.05  FAIL (marginal), index 3
#   infinite dilution (Kojima)   13.52   threshold 30    pass
# Four of five pass and the fifth misses by 6 %. This is a good dataset by any
# reasonable standard.
ETHANOL_WATER_101KPA = [
    # x1(ethanol), y1(ethanol), T/K      at P = 101.3 kPa
    (0.0180, 0.1800, 368.18),
    (0.0790, 0.4180, 360.50),
    (0.0900, 0.4410, 359.70),
    (0.1470, 0.5100, 357.27),
    (0.2440, 0.5670, 355.38),
    (0.3110, 0.5890, 354.55),
    (0.3530, 0.6040, 354.11),
    (0.4250, 0.6270, 353.45),
    (0.4880, 0.6520, 352.96),
    (0.5700, 0.6880, 352.39),
    (0.6160, 0.7130, 352.11),
    (0.6700, 0.7360, 351.82),
    (0.7110, 0.7600, 351.64),
    (0.8020, 0.8190, 351.37),
    (0.8350, 0.8440, 351.30),
    (0.8690, 0.8730, 351.27),
    (0.9010, 0.9000, 351.26),   # y1 - x1 changes sign between this row
    (0.9140, 0.9120, 351.26),   # and the one above it
    (0.9220, 0.9200, 351.27),
    (0.9400, 0.9370, 351.29),
    (0.9720, 0.9690, 351.35),
]

ETHANOL_WATER_CITATION = (
    "Kamihama, N.; Matsuda, H.; Kurihara, K.; Tochigi, K.; Oba, S. "
    "Isobaric Vapor-Liquid Equilibria for Ethanol + Water + Ethylene Glycol "
    "and Its Constituent Three Binary Systems. "
    "Journal of Chemical & Engineering Data 2012, 57(2), 339-344. "
    "https://doi.org/10.1021/je2008704 "
    "(ethanol + water binary; numbers via NIST TRC ThermoML)"
)


# ==========================================================================
# TYPE 4 -- negative deviation with a maximum-boiling azeotrope
# ==========================================================================
# chloroform (1) + 2-butanone (2), ISOTHERMAL at 303.15 K, 22 points.
# This is the only isothermal P-x-y set in the module, and therefore the one to
# use whenever the exercise is about Gibbs-Duhem in its clean form.
#
# Clara, R. A.; Gomez Marigliano, A. C.; Solimo, H. N.
#   "Density, Viscosity, Vapor-Liquid Equilibrium, Excess Molar Volume,
#    Viscosity Deviation, and Their Correlations for the Chloroform +
#    2-Butanone Binary System"
#   Journal of Chemical & Engineering Data 2006, 51(4), 1473-1478.
#   https://doi.org/10.1021/je060150a
#   Editorial notices: none (checked 2026).
#
# WHY TYPE 4: chloroform has an acidic C-H and 2-butanone a carbonyl, so the
# unlike pair forms a hydrogen bond that neither pure liquid has. Mixing is
# energetically favourable, both activity coefficients fall below one
# (gamma1 = 0.401-1.002, gamma2 = 0.362-1.043 from the table), the total
# pressure drops below both pure vapour pressures, and the mixture boils higher
# than either component.
#
# THE PAPER'S OWN CLAIM, and the check against it. The abstract states: "This
# binary system shows negative deviations from ideal behavior and forms a
# minimum pressure azeotrope at x1 = 0.199 and p = 15.3 kPa." From the
# transcribed table:
#   - the lowest measured pressure is 15.33 kPa, against the paper's 15.3 kPa
#   - linear interpolation of y1 - x1 through zero gives x_az = 0.1907,
#     against the paper's 0.199
# Both agree. This is the strongest single piece of evidence that the table was
# transcribed correctly, because it tests the x, y and P columns jointly against
# a number the authors computed independently.
#
# END-POINT CHECK (both pure points measured, isothermal so this is direct):
#   x1 = 1 (chloroform):  P = 32.19 kPa, Psat_Antoine = 32.330 -> +0.44 %
#   x1 = 0 (2-butanone):  P = 15.74 kPa, Psat_Antoine = 15.224 -> -3.28 %
# The 3.3 % is in the correlation, not the data. LIBRARY's 2-butanone entry is
# the Yaws log10(mmHg) set, and independent tabulations put the vapour pressure
# of 2-butanone at 303.15 K nearer 15.7-15.9 kPa, i.e. the paper's value. Worth
# remembering when this dataset is regressed: a 3 % error in Psat2 propagates
# straight into gamma2 and hence into any fitted parameter.
#
# REPLICATE POINTS: the paper reports x1 = 0.252 twice, as (y1 = 0.281,
# P = 15.35) and (y1 = 0.274, P = 15.33). Both are kept. They are a genuine
# repeat measurement and give a direct read on the scatter: 0.007 in y1 and
# 0.02 kPa in P. Note this means x1 is non-strictly monotonic.
#
# TYPO / SMOOTHNESS CHECK: residuals of P(x1) about a quintic are 0.138 kPa rms.
# The largest are x1 = 0.732 (-2.7 sigma) and x1 = 0.571 (+2.0 sigma). Neither
# is a plausible transposed digit -- 23.37 and 19.26 both sit on a monotone rise
# and both agree with their neighbours to better than 2 % -- so they are read as
# scatter. NIST TRC's assessed expanded uncertainty on P for this set is
# 0.39-0.65 kPa, which comfortably covers a 0.37 kPa residual.
#
# UNCERTAINTIES as recorded by NIST TRC (combined expanded, 95 %): u(x1) 0.001,
# u(y1) 0.001-0.021, u(P) 0.39-0.65 kPa, u(T) 0.01 K.
#
# CONSISTENCY:
#   area (Redlich-Kister)        3.184   threshold 10    pass
#   point (Van Ness-Byer-Gibbs)  0.00709 threshold 0.01  pass, index 3
#   direct (Van Ness 1995)       0.0757  threshold 0.05  FAIL, index 4
#   infinite dilution (Kojima)   1181    threshold 30    FAIL badly
# (No Herington row: it applies only to isobaric data.)
# The Kojima number is spectacular and should not be taken at face value. It
# compares gamma at infinite dilution extrapolated from the data against the
# same limit from a Redlich-Kister fit, and this system has gamma2 falling to
# about 0.36 while the end points x1 = 0 and x1 = 1 are included in the table,
# where one gamma is 0/0. Strongly negative-deviation systems with measured pure
# end points routinely blow this test up. The direct-test failure is real but
# modest: index 4 on the 1-10 scale still means the data are usable for
# regression, which is what the authors did with them.
CHLOROFORM_BUTANONE_303K = [
    # x1(chloroform), y1(chloroform), P/kPa   at T = 303.15 K
    (0.0000, 0.0000, 15.74),
    (0.0740, 0.0630, 15.59),
    (0.1420, 0.1190, 15.47),
    (0.2520, 0.2810, 15.35),   # replicate pair; azeotrope (paper: x1 = 0.199,
    (0.2520, 0.2740, 15.33),   # p = 15.3 kPa) sits just below these
    (0.3630, 0.4430, 15.89),
    (0.3770, 0.4690, 16.13),
    (0.4440, 0.5730, 16.69),
    (0.4740, 0.6170, 17.17),
    (0.5070, 0.6730, 17.69),
    (0.5600, 0.7470, 18.75),
    (0.5710, 0.7510, 19.26),   # +2.0 sigma from a smooth fit; kept as scatter
    (0.6020, 0.7990, 19.86),
    (0.6300, 0.8230, 20.41),
    (0.6310, 0.8300, 20.58),
    (0.6780, 0.8680, 21.74),
    (0.7320, 0.9050, 23.37),   # -2.7 sigma from a smooth fit; kept as scatter
    (0.7570, 0.9290, 24.66),
    (0.8230, 0.9580, 27.26),
    (0.8800, 0.9760, 29.22),
    (0.9130, 0.9840, 30.00),
    (1.0000, 1.0000, 32.19),
]

CHLOROFORM_BUTANONE_CITATION = (
    "Clara, R. A.; Gomez Marigliano, A. C.; Solimo, H. N. "
    "Density, Viscosity, Vapor-Liquid Equilibrium, Excess Molar Volume, "
    "Viscosity Deviation, and Their Correlations for the Chloroform + "
    "2-Butanone Binary System. "
    "Journal of Chemical & Engineering Data 2006, 51(4), 1473-1478. "
    "https://doi.org/10.1021/je060150a "
    "(numbers via NIST TRC ThermoML)"
)


# ==========================================================================
# TYPE 4, second example -- the textbook system
# ==========================================================================
# acetone (1) + chloroform (2), isobaric at 101.3 kPa, 9 points.
#
# Gao, Q.; Zhao, Z.; Jia, P.; Zhang, X.
#   "Effect of Ionic Liquids on the Isobaric Vapor-Liquid Equilibrium Behavior
#    of Acetone-Chloroform"
#   Applied Sciences 2018, 8(9), 1519.
#   https://doi.org/10.3390/app8091519
#   Open access, CC-BY. Editorial notices: none (checked 2026).
#   Table A1, Appendix B (the ionic-liquid-free binary, measured in a modified
#   Othmer still to validate the apparatus).
#
# This one is included because acetone + chloroform is *the* example of a
# maximum-boiling azeotrope in every textbook, and because being open access it
# is the one dataset here a student can open and read for themselves. It is not
# from the ThermoML archive: the table was read from the publisher's HTML
# article and independently from the publisher's PDF, and the two renderings
# were required to agree digit for digit before it was accepted. They did.
#
# WHY TYPE 4: the acetone carbonyl accepts a hydrogen bond from chloroform's
# C-H. gamma1 runs 0.531-1.000 and gamma2 0.574-0.994 -- negative deviation
# throughout -- and the boiling temperature passes through a maximum.
#
# AZEOTROPE CHECK: y1 - x1 changes sign between (0.301, 0.280) and
# (0.396, 0.401), giving x_az = 0.378. The measured temperature maximum is
# 337.6 K = 64.45 C at x1 = 0.301-0.396. The accepted literature azeotrope is
# 64.5 C at roughly x1 = 0.34-0.36. The temperature matches to 0.05 K; the
# composition from this 9-point table is on the high side by about 0.03, which
# is what a coarse grid with a flat maximum will give.
#
# END-POINT CHECK -- the pure components were NOT measured (x1 runs 0.102 to
# 0.893), so a quadratic through the four points nearest each end is
# extrapolated:
#   x1 -> 1 (acetone):    T_extrap = 329.39 K vs Antoine Tsat = 329.34 K,
#                         dT = +0.05 K, +0.18 % in pressure
#   x1 -> 0 (chloroform): T_extrap = 333.79 K vs Antoine Tsat = 334.35 K,
#                         dT = -0.55 K, -1.79 % in pressure
# Both acceptable, the chloroform end slightly worse because the extrapolation
# runs across the azeotropic maximum.
#
# UNCERTAINTIES as stated by the authors: u(x1) = u(y1) = 0.002, u(T) = 0.1 K,
# pressure read on a mercury manometer to 0.01 kPa and corrected to 101.3 kPa.
#
# CAVEAT: nine points, none of them pure, is a thin dataset. It is here for
# recognisability and for the open-access argument, not because it is the best
# Type 4 data in the module -- the chloroform + 2-butanone set above is.
#
# CONSISTENCY:
#   area (Redlich-Kister)        1.439   threshold 10    pass
#   Herington D-J                1.552   threshold 10    pass
#   point (Van Ness-Byer-Gibbs)  0.00589 threshold 0.01  pass, index 3
#   direct (Van Ness 1995)       0.0414  threshold 0.05  pass, index 2
#   infinite dilution (Kojima)   1.887   threshold 30    pass
# Five out of five, the only clean sweep in the module -- helped considerably by
# the fact that with no pure end points the Kojima test has nothing to trip on.
ACETONE_CHLOROFORM_101KPA = [
    # x1(acetone), y1(acetone), T/K      at P = 101.3 kPa
    (0.102, 0.067, 335.7),
    (0.202, 0.160, 336.9),
    (0.301, 0.280, 337.6),   # temperature maximum, and y1 - x1 changes sign
    (0.396, 0.401, 337.6),   # between these two rows
    (0.494, 0.544, 336.9),
    (0.587, 0.660, 335.9),
    (0.679, 0.765, 334.5),
    (0.786, 0.866, 332.5),
    (0.893, 0.945, 331.0),
]

ACETONE_CHLOROFORM_CITATION = (
    "Gao, Q.; Zhao, Z.; Jia, P.; Zhang, X. "
    "Effect of Ionic Liquids on the Isobaric Vapor-Liquid Equilibrium "
    "Behavior of Acetone-Chloroform. "
    "Applied Sciences 2018, 8(9), 1519. "
    "https://doi.org/10.3390/app8091519 "
    "(Table A1, ionic-liquid-free binary; open access, CC-BY)"
)


# --------------------------------------------------------------------------
# Loaders
#
# Each returns a fresh VLEData so that a caller who sorts or slices one cannot
# corrupt the copy the next caller gets. `sigma` carries the uncertainties the
# source reports where it reports them; where a source gives a range, the
# larger end is used, because an optimistic sigma makes every consistency test
# look better than it is.
# --------------------------------------------------------------------------
def _isobaric(rows, c1, c2, P, label, source, sigma):
    a = np.asarray(rows, dtype=float)
    return VLEData(a[:, 0], a[:, 1], np.full(len(a), P), a[:, 2],
                   c1, c2, kind="isobaric", label=label, source=source,
                   sigma=dict(sigma))


def _isothermal(rows, c1, c2, T, label, source, sigma):
    a = np.asarray(rows, dtype=float)
    return VLEData(a[:, 0], a[:, 1], a[:, 2], np.full(len(a), T),
                   c1, c2, kind="isothermal", label=label, source=source,
                   sigma=dict(sigma))


def benzene_toluene():
    """Type 1. benzene (1) + toluene (2), isobaric, 101.33 kPa, 13 points."""
    return _isobaric(BENZENE_TOLUENE_101KPA, component("benzene"), TOLUENE,
                     101.33, "benzene + toluene, 101.33 kPa",
                     BENZENE_TOLUENE_CITATION,
                     {"x": 1e-4, "y": 7e-3, "P": 0.01, "T": 0.32})


def methanol_water(P=66.52):
    """Type 2. methanol (1) + water (2), isobaric, 16 points.

    P must be 66.52 (default) or 37.5 kPa. The 37.5 kPa set is the one whose
    pure-methanol end point disagrees with Antoine by 4.3 per cent and which
    fails the point test; it is kept for exactly that reason.
    """
    table = {66.52: METHANOL_WATER_66KPA, 37.5: METHANOL_WATER_37KPA}
    if P not in table:
        raise ValueError(f"methanol + water was measured at 66.52 and 37.5 kPa, not {P}")
    return _isobaric(table[P], component("methanol"), component("water"),
                     P, f"methanol + water, {P} kPa", METHANOL_WATER_CITATION,
                     {"x": 1e-3, "y": 0.01, "P": 0.01, "T": 0.3})


def ethanol_water():
    """Type 3. ethanol (1) + water (2), isobaric, 101.3 kPa, 21 points."""
    return _isobaric(ETHANOL_WATER_101KPA, component("ethanol"), component("water"),
                     101.3, "ethanol + water, 101.3 kPa", ETHANOL_WATER_CITATION,
                     {"x": 1e-3, "y": 0.015, "P": 0.1, "T": 0.1})


def chloroform_butanone():
    """Type 4. chloroform (1) + 2-butanone (2), isothermal, 303.15 K, 22 points.

    The only isothermal set in the module.
    """
    return _isothermal(CHLOROFORM_BUTANONE_303K, component("chloroform"), component("mek"),
                       303.15, "chloroform + 2-butanone, 303.15 K",
                       CHLOROFORM_BUTANONE_CITATION,
                       {"x": 1e-3, "y": 0.021, "P": 0.65, "T": 0.01})


def acetone_chloroform():
    """Type 4, textbook version. acetone (1) + chloroform (2), 101.3 kPa, 9 points."""
    return _isobaric(ACETONE_CHLOROFORM_101KPA, component("acetone"), component("chloroform"),
                     101.3, "acetone + chloroform, 101.3 kPa",
                     ACETONE_CHLOROFORM_CITATION,
                     {"x": 2e-3, "y": 2e-3, "P": 0.01, "T": 0.1})


# --------------------------------------------------------------------------
DATASETS = {
    "benzene-toluene": benzene_toluene,
    "methanol-water": methanol_water,
    "ethanol-water": ethanol_water,
    "chloroform-butanone": chloroform_butanone,
    "acetone-chloroform": acetone_chloroform,
}

#: Deviation class of each dataset, in the course's 1-4 numbering.
TYPES = {
    "benzene-toluene": 1,
    "methanol-water": 2,
    "ethanol-water": 3,
    "chloroform-butanone": 4,
    "acetone-chloroform": 4,
}

#: DOI of the source paper for each dataset, for the citation check.
DOIS = {
    "benzene-toluene": "10.1016/j.fluid.2013.12.002",
    "methanol-water": "10.1021/je300613v",
    "ethanol-water": "10.1021/je2008704",
    "chloroform-butanone": "10.1021/je060150a",
    "acetone-chloroform": "10.3390/app8091519",
}


def load(name, **kw):
    """Fetch a dataset by short name, with a useful error."""
    try:
        return DATASETS[name](**kw)
    except KeyError:
        raise KeyError(f"unknown dataset {name!r}; have {sorted(DATASETS)}") from None
