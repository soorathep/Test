"""UNIFAC: activity coefficients with no parameters fitted to the data.

This module exists to answer one question at the end of Module 4: what did the
fitting actually buy? A regressed NRTL will always follow the data more closely
than a group-contribution prediction — it was shown the answer. The comparison
worth making is whether it follows them enough better to justify the two
parameters, and whether it still beats UNIFAC outside the range it was fitted
in. Often it does not.

The implementation is the original VLE UNIFAC (Fredenslund, Jones & Prausnitz),
written out rather than imported, because a student should be able to read the
group sums. It carries only the subgroups needed by `data.LIBRARY`; anything
else raises rather than guessing. When the `thermo` package is installed,
tests/test_unifac.py checks every parameter and every predicted gamma against
it, so the embedded table is verified rather than trusted.
"""
from __future__ import annotations

import numpy as np

from .data import SUBGROUP_RQ

R = 8.314462618
Z = 10.0

# subgroup -> main group, for the subgroups in data.SUBGROUP_RQ
SUBGROUP_MAIN = {
    1: 1,      # CH3    -> CH2
    2: 1,      # CH2    -> CH2
    3: 1,      # CH     -> CH2
    9: 3,      # ACH    -> ACH
    14: 5,     # OH     -> OH
    15: 6,     # CH3OH  -> CH3OH
    16: 7,     # H2O    -> H2O
    18: 9,     # CH3CO  -> CH2CO
    50: 23,    # CHCl3  -> CCl3
}

# Group interaction parameters a_mn / K, VLE table (Hansen et al.).
# a_mn is not symmetric: a_mn != a_nm, and that asymmetry is the model, not a
# typing error. Verified against the `thermo` package in the test suite.
A_MN = {
    1:  {3: 61.13, 5: 986.5, 6: 697.2, 7: 1318.0, 9: 476.4, 23: 24.9},
    3:  {1: -11.12, 5: 636.1, 6: 637.35, 7: 903.8, 9: 25.77, 23: -231.9},
    5:  {1: 156.4, 3: 89.6, 6: -137.1, 7: 353.5, 9: 84.0, 23: -98.12},
    6:  {1: 16.51, 3: -50.0, 5: 249.1, 7: -180.95, 9: 23.39, 23: -139.35},
    7:  {1: 300.0, 3: 362.3, 5: -229.1, 6: 289.6, 9: -195.4, 23: 353.68},
    9:  {1: 26.76, 3: 140.1, 5: 164.5, 6: 108.65, 7: 472.5, 23: -354.55},
    23: {1: 36.7, 3: 288.5, 5: 742.1, 6: 649.1, 7: 826.76, 9: 552.1},
}


def a_mn(m, n):
    if m == n:
        return 0.0
    try:
        return A_MN[m][n]
    except KeyError:
        raise KeyError(
            f"no UNIFAC interaction parameter for main groups {m} and {n}; "
            "this module carries only the groups used by data.LIBRARY"
        ) from None


# --------------------------------------------------------------------------
def _rq(groups):
    r = sum(n * SUBGROUP_RQ[k][0] for k, n in groups.items())
    q = sum(n * SUBGROUP_RQ[k][1] for k, n in groups.items())
    return r, q


def _ln_Gamma(subgroup_x, T, subgroups):
    """ln Gamma_k for every subgroup, in a mixture with the given group fractions.

    Gamma_k is the residual activity coefficient of group k. The same function
    is called twice — once for the real mixture and once for a hypothetical
    liquid of pure component i — and the difference is what makes ln gamma_i
    vanish for a pure component. That subtraction is the whole trick of the
    group-contribution idea and is worth pointing at in the code.
    """
    Q = np.array([SUBGROUP_RQ[k][1] for k in subgroups])
    X = np.asarray(subgroup_x, dtype=float)
    denom = np.dot(Q, X)
    Th = Q * X / denom
    mains = [SUBGROUP_MAIN[k] for k in subgroups]
    Psi = np.array([[np.exp(-a_mn(mains[m], mains[n]) / T)
                     for n in range(len(subgroups))]
                    for m in range(len(subgroups))])
    s = Th @ Psi                                  # s[k] = sum_m Th_m Psi_mk
    with np.errstate(divide="ignore", invalid="ignore"):
        term = np.array([np.sum(Th * Psi[k, :] / s) for k in range(len(subgroups))])
        return Q * (1.0 - np.log(s) - term)


def gammas(x1, T, c1, c2):
    """UNIFAC activity coefficients for a binary at composition x1 and T.

    No parameter here has ever seen the dataset. That is the point of the
    comparison it is used for.
    """
    x1 = np.atleast_1d(np.asarray(x1, dtype=float))
    comps = (c1, c2)
    for c in comps:
        if not c.groups:
            raise ValueError(f"{c.name} has no UNIFAC group decomposition")
    subgroups = sorted(set(c1.groups) | set(c2.groups))
    nu = np.array([[c.groups.get(k, 0) for k in subgroups] for c in comps],
                  dtype=float)

    rq = [_rq(c.groups) for c in comps]
    r = np.array([v[0] for v in rq])
    q = np.array([v[1] for v in rq])
    l = (Z / 2) * (r - q) - (r - 1)

    # pure-component reference: ln Gamma_k in a liquid of pure i
    lnG_pure = []
    for i in range(2):
        Xi = nu[i] / nu[i].sum()
        lnG_pure.append(_ln_Gamma(Xi, T, subgroups))

    lg1 = np.empty_like(x1)
    lg2 = np.empty_like(x1)
    for j, xa in enumerate(x1):
        x = np.array([xa, 1 - xa])
        # combinatorial
        phi = r * x / np.dot(r, x)
        th = q * x / np.dot(q, x)
        with np.errstate(divide="ignore", invalid="ignore"):
            lnC = (np.log(phi / x) + (Z / 2) * q * np.log(th / phi)
                   + l - (phi / x) * np.dot(x, l))
        # residual
        Xg = nu.T @ x
        Xg = Xg / Xg.sum()
        lnG = _ln_Gamma(Xg, T, subgroups)
        lnR = np.array([np.dot(nu[i], lnG - lnG_pure[i]) for i in range(2)])
        lg1[j], lg2[j] = (lnC + lnR)[0], (lnC + lnR)[1]
    return np.exp(lg1), np.exp(lg2)


def ln_gammas(x1, T, c1, c2):
    g1, g2 = gammas(x1, T, c1, c2)
    return np.log(g1), np.log(g2)


# --------------------------------------------------------------------------
class UNIFACModel:
    """Adapter so UNIFAC can be passed anywhere a fitted model is expected.

    It has no parameters, so it cannot be fitted; `fit` will refuse it. That is
    deliberate — the whole value of the comparison is that this one did not get
    to look at the answer.
    """

    name = "UNIFAC"
    param_names = ()
    param_labels = ()

    def __init__(self, c1, c2):
        self.c1, self.c2 = c1, c2
        self.params = np.array([])

    def ln_gamma(self, x1, T=None):
        if T is None:
            raise ValueError("UNIFAC needs a temperature")
        T = np.atleast_1d(np.asarray(T, dtype=float))
        x1 = np.atleast_1d(np.asarray(x1, dtype=float))
        if T.size == 1:
            return ln_gammas(x1, float(T[0]), self.c1, self.c2)
        lg1 = np.empty_like(x1)
        lg2 = np.empty_like(x1)
        for i, (xa, Ta) in enumerate(zip(x1, T)):
            a, b = ln_gammas(np.array([xa]), float(Ta), self.c1, self.c2)
            lg1[i], lg2[i] = a[0], b[0]
        return lg1, lg2

    def gamma(self, x1, T=None):
        lg1, lg2 = self.ln_gamma(x1, T)
        return np.exp(lg1), np.exp(lg2)

    def gE_RT(self, x1, T=None):
        x1 = np.asarray(x1, dtype=float)
        lg1, lg2 = self.ln_gamma(x1, T)
        return x1 * lg1 + (1 - x1) * lg2

    def __repr__(self):
        return f"<UNIFAC {self.c1.name}/{self.c2.name}, no fitted parameters>"


def benchmark(dat, fits, vapour="ideal"):
    """UNIFAC against one or more fitted models, on the same data.

    Returns rows of (label, rms in y, rms in P, mean |d ln gamma1|) so the
    prediction and the fits can be read on one scale. A fitted model that beats
    UNIFAC by less than the experimental scatter has bought nothing.
    """
    from .regress import bubble_P

    rows = []
    uf = UNIFACModel(dat.c1, dat.c2)
    g1e, g2e = dat.gamma(vapour)
    m = dat.interior() & np.isfinite(g1e) & np.isfinite(g2e)

    def row(label, model):
        P, y = bubble_P(model, dat.x1, dat.T, dat.c1, dat.c2, vapour)
        lg1, _ = model.ln_gamma(dat.x1, dat.T)
        return (label,
                float(np.sqrt(np.mean((y - dat.y1) ** 2))),
                float(np.sqrt(np.mean((P - dat.P) ** 2))),
                float(np.mean(np.abs(lg1[m] - np.log(g1e[m])))))

    for f in fits:
        rows.append(row(f"{f.model.name} (fitted)", f.model))
    rows.append(row("UNIFAC (predicted)", uf))
    return rows


def benchmark_table(rows, width=74):
    lines = ["-" * width,
             f"{'model':<26}{'rms dy':>12}{'rms dP / kPa':>16}"
             f"{'mean |d ln g1|':>18}",
             "-" * width]
    for lab, ry, rp, rg in rows:
        lines.append(f"{lab:<26}{ry:>12.5f}{rp:>16.4g}{rg:>18.4f}")
    lines.append("-" * width)
    return "\n".join(lines)
