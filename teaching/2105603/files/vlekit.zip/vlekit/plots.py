"""Diagnostic plots for the VLE workflow.

Each figure answers one question, and the question is in the function name. A
plot that shows five things at once is a plot nobody reads, and in a
consistency analysis the whole point is that different failures look different.

The palette matches the 2105603 lecture slides so that a figure a student
generates in a notebook and a figure on the screen behind them are visibly the
same object.
"""
from __future__ import annotations

import matplotlib
import matplotlib.pyplot as plt
import numpy as np

# ------------------------------------------------------------------ palette
INK = "#1C242B"
GRAPHITE = "#333F4A"
SLATE = "#66727C"
MIST = "#B9C1C6"
PAPER = "#FFFFFF"
NAVY = "#1F4E79"
SKYBLUE = "#5A91BE"
AMBER = "#E29A2D"
TEAL = "#0F6E6B"
RUST = "#BE654C"
SAND = "#DFC98F"

CYCLE = [NAVY, AMBER, TEAL, SKYBLUE, RUST, SLATE]

STYLE = {
    "figure.facecolor": PAPER, "savefig.facecolor": PAPER,
    "axes.facecolor": PAPER, "axes.edgecolor": GRAPHITE,
    "axes.linewidth": 0.9, "axes.labelcolor": INK, "axes.labelsize": 13,
    "axes.titlesize": 13.5, "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.prop_cycle": matplotlib.cycler(color=CYCLE),
    "xtick.color": GRAPHITE, "ytick.color": GRAPHITE,
    "xtick.labelsize": 11.5, "ytick.labelsize": 11.5,
    "text.color": INK, "grid.color": MIST, "grid.linewidth": 0.6,
    "grid.alpha": 0.55, "lines.linewidth": 2.0, "lines.markersize": 6.0,
    "legend.frameon": False, "legend.fontsize": 11,
    "font.family": "sans-serif", "font.sans-serif": ["DejaVu Sans"],
    "mathtext.fontset": "dejavusans", "figure.dpi": 110,
}


def use_style():
    plt.rcParams.update(STYLE)


def newfig(w=6.4, h=4.3, **kw):
    use_style()
    fig, ax = plt.subplots(figsize=(w, h), **kw)
    ax.grid(True, zorder=0)
    ax.set_axisbelow(True)
    return fig, ax


def save(fig, path, dpi=300):
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight", pad_inches=0.03, dpi=dpi)
    plt.close(fig)
    return path


# ==========================================================================
def pxy(dat, fit=None, ax=None, title=None):
    """The P-x-y diagram: what was measured, and what the fit says.

    Bubble and dew curves from the model are drawn on a fine grid rather than
    through the data points, because the model is a continuous function and
    drawing it as a polyline through the measurements hides the places where it
    misbehaves between them.
    """
    if ax is None:
        _, ax = newfig()
    ax.plot(dat.x1, dat.P, "o", color=NAVY, label="$P$-$x_1$ (measured)",
            mfc="white", mew=1.6)
    ax.plot(dat.y1, dat.P, "s", color=RUST, label="$P$-$y_1$ (measured)",
            mfc="white", mew=1.6)
    if fit is not None:
        from .regress import bubble_P
        xs = np.linspace(1e-6, 1 - 1e-6, 300)
        Ts = np.full_like(xs, np.mean(dat.T))
        Ps, ys = bubble_P(fit.model, xs, Ts, dat.c1, dat.c2, fit.vapour)
        ax.plot(xs, Ps, "-", color=NAVY, lw=2.0, label=f"{fit.model.name} bubble")
        ax.plot(ys, Ps, "--", color=RUST, lw=2.0, label=f"{fit.model.name} dew")
    ax.set_xlabel("$x_1$, $y_1$")
    ax.set_ylabel("$P$ / kPa")
    ax.set_xlim(0, 1)
    ax.legend(loc="best")
    if title:
        ax.set_title(title)
    return ax


def gamma_plot(dat, fit=None, vapour="ideal", ax=None, title=None):
    """Activity coefficients from the data, with the fitted model over them."""
    if ax is None:
        _, ax = newfig()
    g1, g2 = dat.gamma(vapour)
    m = dat.interior() & np.isfinite(g1) & np.isfinite(g2)
    ax.plot(dat.x1[m], g1[m], "o", color=TEAL, mfc="white", mew=1.6,
            label=r"$\gamma_1$ from data")
    ax.plot(dat.x1[m], g2[m], "s", color=AMBER, mfc="white", mew=1.6,
            label=r"$\gamma_2$ from data")
    if fit is not None:
        xs = np.linspace(1e-4, 1 - 1e-4, 300)
        lg1, lg2 = fit.model.ln_gamma(xs, np.mean(dat.T))
        ax.plot(xs, np.exp(lg1), "-", color=TEAL, lw=2.0)
        ax.plot(xs, np.exp(lg2), "-", color=AMBER, lw=2.0)
    ax.axhline(1.0, color=SLATE, lw=1.0, ls=":")
    ax.set_xlabel("$x_1$")
    ax.set_ylabel(r"$\gamma_i$")
    ax.set_xlim(0, 1)
    ax.legend(loc="best")
    if title:
        ax.set_title(title)
    return ax


def area_plot(dat, vapour="ideal", order=4, ax=None, title=None):
    """The area test, drawn as the two areas whose difference must vanish.

    Shading the positive and negative lobes separately is the whole argument:
    the test compares their sizes, so an error that adds equally to both is
    invisible to it. Students who have seen this picture stop treating a small
    D as a certificate.
    """
    from .consistency import rk_fit, rk_eval, area_test

    if ax is None:
        _, ax = newfig()
    d = dat.sorted_by_x()
    g1, g2 = d.gamma(vapour)
    m = d.interior() & np.isfinite(g1) & np.isfinite(g2) & (g1 > 0) & (g2 > 0)
    x, r = d.x1[m], np.log(g1[m] / g2[m])
    c = rk_fit(x, r, order)
    xs = np.linspace(0, 1, 500)
    rs = rk_eval(c, xs)

    ax.fill_between(xs, rs, 0, where=rs >= 0, color=TEAL, alpha=0.22,
                    interpolate=True, label="positive area")
    ax.fill_between(xs, rs, 0, where=rs < 0, color=RUST, alpha=0.22,
                    interpolate=True, label="negative area")
    ax.plot(xs, rs, "-", color=GRAPHITE, lw=1.8)
    ax.plot(x, r, "o", color=NAVY, mfc="white", mew=1.6, label="data")
    ax.axhline(0.0, color=GRAPHITE, lw=1.0)

    res = area_test(dat, vapour, order)
    ax.set_xlabel("$x_1$")
    ax.set_ylabel(r"$\ln(\gamma_1/\gamma_2)$")
    ax.set_xlim(0, 1)
    ax.legend(loc="best")
    ax.set_title(title or f"Area test: $D$ = {res.statistic:.2f} "
                          f"({'pass' if res.passed else 'FAIL'})")
    return ax


def point_test_plot(dat, fit, ax=None, title=None, threshold=0.01):
    """Residuals in y from a fit that never saw y.

    A random scatter about zero is a consistent dataset. A residual with a
    shape — a bow, a tilt, a step — is a systematic error, and the shape often
    says which measurement caused it.
    """
    if ax is None:
        _, ax = newfig()
    dy = fit.y1_calc - dat.y1
    ax.axhspan(-threshold, threshold, color=MIST, alpha=0.35,
               label=f"$\\pm${threshold:g} band")
    ax.axhline(0.0, color=GRAPHITE, lw=1.0)
    ax.plot(dat.x1, dy, "o-", color=NAVY, mfc="white", mew=1.6, lw=1.2)
    ax.set_xlabel("$x_1$")
    ax.set_ylabel(r"$\delta y_1 = y_1^{\rm calc} - y_1^{\rm exp}$")
    ax.set_xlim(0, 1)
    # keep the acceptance band visible as a band rather than as the whole
    # panel: a residual plot whose axis is set by the residuals alone makes
    # every dataset look equally scattered.
    lim = max(1.35 * threshold, 1.15 * np.nanmax(np.abs(dy)))
    ax.set_ylim(-lim, lim)
    ax.legend(loc="best")
    mad = float(np.mean(np.abs(dy[np.isfinite(dy)])))
    ax.set_title(title or f"Point test: mean $|\\delta y_1|$ = {mad:.4f}")
    return ax


def direct_test_plot(dat, fit, vapour="ideal", ax=None, title=None):
    """Residuals in ln(gamma1/gamma2), the variable Gibbs-Duhem is written in."""
    if ax is None:
        _, ax = newfig()
    g1, g2 = dat.gamma(vapour)
    lg1, lg2 = fit.model.ln_gamma(dat.x1, dat.T)
    delta = np.log(g1 / g2) - (lg1 - lg2)
    m = np.isfinite(delta) & dat.interior()
    ax.axhline(0.0, color=GRAPHITE, lw=1.0)
    ax.plot(dat.x1[m], delta[m], "o-", color=TEAL, mfc="white", mew=1.6, lw=1.2)
    ax.set_xlabel("$x_1$")
    ax.set_ylabel(r"$\delta = \ln(\gamma_1/\gamma_2)_{\rm exp} - "
                  r"\ln(\gamma_1/\gamma_2)_{\rm fit}$")
    ax.set_xlim(0, 1)
    rms = float(np.sqrt(np.mean(delta[m] ** 2)))
    ax.set_title(title or f"Direct test: RMS $\\delta$ = {rms:.4f}")
    return ax


def bootstrap_plot(boot, truth=None, ax=None, title=None):
    """The parameter cloud, which is what a confidence interval hides.

    Two standard errors quoted separately describe a rectangle. The cloud is
    usually a narrow diagonal ridge, meaning the parameters trade off against
    one another and neither is determined on its own.
    """
    if ax is None:
        _, ax = newfig(5.6, 4.8)
    B = boot["samples"]
    if B.shape[1] < 2:
        ax.hist(B[:, 0], bins=25, color=SKYBLUE, edgecolor=NAVY)
        ax.set_xlabel(boot["base"].model.param_labels[0])
        return ax
    names = boot["base"].model.param_labels
    ax.plot(B[:, 0], B[:, 1], "o", color=SKYBLUE, ms=4, alpha=0.55,
            label="bootstrap replicates")
    ax.plot(*boot["base"].params[:2], "o", color=NAVY, ms=10,
            label="best fit")
    if truth is not None:
        ax.plot(truth[0], truth[1], "*", color=RUST, ms=16,
                label="generating value")
    ax.set_xlabel(names[0])
    ax.set_ylabel(names[1])
    ax.legend(loc="best")
    r = boot["corr"][0, 1]
    ax.set_title(title or f"Bootstrap cloud, correlation = {r:+.2f}")
    return ax


def objective_spread_plot(fits, truth=None, ax=None, title=None):
    """One model, four objectives, four answers.

    The horizontal spread is the size of the modelling decision. If it is
    comparable to the quoted standard error, the error bar is describing the
    optimiser rather than the experiment.
    """
    if ax is None:
        _, ax = newfig(6.0, 4.6)
    P = np.array([f.params for f in fits])
    if P.shape[1] < 2:
        ax.plot(range(len(fits)), P[:, 0], "o", color=NAVY)
        return ax
    names = fits[0].model.param_labels
    for f, col in zip(fits, CYCLE):
        ax.plot(f.params[0], f.params[1], "o", color=col, ms=11,
                label=f"objective '{f.objective}'")
    if truth is not None:
        ax.plot(truth[0], truth[1], "*", color=RUST, ms=17,
                label="generating value")
    ax.set_xlabel(names[0])
    ax.set_ylabel(names[1])
    ax.legend(loc="best")
    ax.set_title(title or "The same data, four objective functions")
    return ax


def gibbs_duhem_plot(dat, vapour="ideal", order=4, model=None, ax=None,
                     title=None):
    """The Gibbs-Duhem residual from data, next to the model's own residual.

    The model's line sits on zero to machine precision because it was
    constructed from a single G^E. The data's line does not. Everything the
    consistency tests do is a way of deciding whether the gap between the two
    is measurement noise or a real error.
    """
    from .consistency import gibbs_duhem_residual

    if ax is None:
        _, ax = newfig()
    xs, res, rms = gibbs_duhem_residual(dat, vapour, order)
    ax.axhline(0.0, color=GRAPHITE, lw=1.0)
    ax.plot(xs, res, "-", color=RUST, lw=2.0,
            label=f"from data (RMS {rms:.3g})")
    if model is not None:
        h = 1e-5
        lg1p, lg2p = model.ln_gamma(xs + h, np.mean(dat.T))
        lg1m, lg2m = model.ln_gamma(xs - h, np.mean(dat.T))
        d1 = (lg1p - lg1m) / (2 * h)
        d2 = (lg2p - lg2m) / (2 * h)
        ax.plot(xs, xs * d1 + (1 - xs) * d2, "-", color=TEAL, lw=2.0,
                label="from the model (identically zero)")
    ax.set_xlabel("$x_1$")
    ax.set_ylabel(r"$x_1\,\mathrm{d}\ln\gamma_1/\mathrm{d}x_1 + "
                  r"x_2\,\mathrm{d}\ln\gamma_2/\mathrm{d}x_1$")
    ax.set_xlim(0, 1)
    ax.legend(loc="best")
    if title:
        ax.set_title(title)
    return ax


def diagnostic_panel(dat, fit, vapour="ideal", truth=None, suptitle=None):
    """The four plots a referee would want, on one page."""
    use_style()
    fig, axes = plt.subplots(2, 2, figsize=(11.6, 8.4))
    pxy(dat, fit, ax=axes[0, 0])
    axes[0, 0].set_title("P-x-y")
    gamma_plot(dat, fit, vapour, ax=axes[0, 1])
    axes[0, 1].set_title("Activity coefficients")
    area_plot(dat, vapour, ax=axes[1, 0])
    point_test_plot(dat, fit, ax=axes[1, 1])
    for a in axes.ravel():
        a.grid(True)
        a.set_axisbelow(True)
    if suptitle:
        fig.suptitle(suptitle, fontsize=15, y=0.995)
    fig.tight_layout()
    return fig


def extrapolation_plot(dat, fits, ax=None, title=None, T=None):
    """Fits that agree on the data and disagree everywhere else.

    The shaded band is the composition range the data actually cover. Inside
    it the curves are on top of one another; outside it they separate, and the
    separation is not small. This is the figure to put next to any parameter
    set quoted without a domain of validity.
    """
    if ax is None:
        _, ax = newfig(6.6, 4.6)
    T = float(np.mean(dat.T)) if T is None else T
    xs = np.linspace(1e-4, 1 - 1e-4, 400)
    lo, hi = float(np.min(dat.x1)), float(np.max(dat.x1))
    ax.axvspan(lo, hi, color=MIST, alpha=0.30, zorder=0,
               label=f"data cover $x_1$ = {lo:.2f}–{hi:.2f}")
    for f, col in zip(fits, CYCLE):
        lg1, _ = f.model.ln_gamma(xs, T)
        ax.plot(xs, lg1, "-", color=col, lw=2.0,
                label=f"{f.model.name} (rms $\\delta y$ {f.rms_y:.4f})")
    g1, _ = dat.gamma()
    m = dat.interior() & np.isfinite(g1)
    ax.plot(dat.x1[m], np.log(g1[m]), "o", color=INK, mfc="white", mew=1.6,
            ms=6, label="data", zorder=5)
    ax.set_xlabel("$x_1$")
    ax.set_ylabel(r"$\ln\gamma_1$")
    ax.set_xlim(0, 1)
    ax.legend(loc="best", fontsize=9.5)
    ax.set_title(title or "Same data, same quality of fit, different claims")
    return ax


def gmix_plot(models, T=None, labels=None, ax=None, title=None):
    """Gibbs energy of mixing, with the common tangent where there is one.

    The equilibrium question a flash calculation never asks. A curve that dips
    below its own chord has two stable phases, and the composition of each is
    read off the points of tangency — not from any equilibrium equation.
    """
    from .flash import g_mix, miscibility_gap

    if ax is None:
        _, ax = newfig(6.4, 4.6)
    xs = np.linspace(1e-4, 1 - 1e-4, 600)
    labels = labels or [getattr(m, "name", f"model {i}")
                        for i, m in enumerate(models)]
    gaps = []
    ymin = 0.0
    for m, lab, col in zip(models, labels, CYCLE):
        g = g_mix(m, xs, T)
        ymin = min(ymin, float(np.nanmin(g)))
        gap = miscibility_gap(m, T)
        gaps.append((m, lab, col, g, gap))

    # The split labels go on the plot, next to the construction they describe.
    # They are placed in the empty band *above* the curves rather than on the
    # chord: the chord midpoints of two models that split at similar
    # compositions are almost the same point, which is where the labels used to
    # collide. The upper envelope of the curves is computed first, so each row
    # is guaranteed to clear every curve rather than being nudged by hand.
    env = np.max(np.vstack([g for _, _, _, g, _ in gaps]), axis=0)
    row = 0.085 * abs(ymin)

    ytop = ymin
    for i, (m, lab, col, g, gap) in enumerate(gaps):
        ax.plot(xs, g, "-", color=col, lw=2.0, label=lab, zorder=3)
        if not gap:
            continue
        xa, xb = gap["x1_phase_a"], gap["x1_phase_b"]
        ya = float(g_mix(m, np.array([xa]), T)[0])
        yb = float(g_mix(m, np.array([xb]), T)[0])
        ax.plot([xa, xb], [ya, yb], "--", color=col, lw=1.4, zorder=2)
        ax.plot([xa, xb], [ya, yb], "o", color=col, ms=7, zorder=4)

        xm = 0.5 * (xa + xb)
        inside = (xs > xa) & (xs < xb)
        ylab = float(np.max(env[inside])) + 0.55 * row + i * row
        ytop = max(ytop, ylab)
        ax.annotate(f"split {xa:.2f} / {xb:.2f}", xy=(xm, 0.5 * (ya + yb)),
                    xytext=(xm, ylab), ha="center", va="bottom",
                    fontsize=10, color=col, zorder=6,
                    bbox=dict(boxstyle="round,pad=0.18", fc=PAPER, ec="none",
                              alpha=0.85),
                    arrowprops=dict(arrowstyle="-", color=col, lw=0.8,
                                    alpha=0.6, shrinkA=1, shrinkB=3))

    ax.axhline(0.0, color=GRAPHITE, lw=1.0, zorder=1)
    ax.set_xlabel("$x_1$")
    ax.set_ylabel(r"$\Delta g_{\rm mix}/RT$")
    ax.set_xlim(0, 1)
    ax.set_ylim(ymin * 1.10, max(0.0, ytop + row) + 0.02 * abs(ymin))
    ax.legend(loc="lower left", fontsize=10)
    if title:
        ax.set_title(title)
    return ax


def rachford_rice_plot(z1, K1, K2, ax=None, title=None):
    """The Rachford-Rice function, drawn to show that it cannot trap a solver."""
    from .flash import rachford_rice_curve, rachford_rice

    if ax is None:
        _, ax = newfig()
    V, F = rachford_rice_curve(z1, K1, K2)
    ax.plot(V, F, "-", color=NAVY, lw=2.2)
    ax.axhline(0.0, color=GRAPHITE, lw=1.0)
    v, status = rachford_rice(z1, K1, K2)
    if status == "two phase":
        ax.plot([v], [0.0], "o", color=RUST, ms=10, label=f"root at $V$ = {v:.3f}")
        ax.legend(loc="best")
    ax.set_xlabel("vapour fraction $V$")
    ax.set_ylabel(r"$\sum_i z_i (K_i-1)/[1+V(K_i-1)]$")
    ax.set_xlim(0, 1)
    ax.set_title(title or f"Rachford-Rice, $z_1$ = {z1:g}, "
                          f"$K_1$ = {K1:.3f}, $K_2$ = {K2:.3f}")
    return ax


def cross_validation_plot(cv, ax=None, title=None):
    """Training points, held-out points, and the prediction over both."""
    from .regress import bubble_P

    if ax is None:
        _, ax = newfig()
    dat, f, m = cv["train"], cv["fit"], cv["mask"]
    full = cv["train"], cv["test"]
    xs = np.linspace(1e-6, 1 - 1e-6, 300)
    Ts = np.full_like(xs, float(np.mean(dat.T)))
    Ps, _ = bubble_P(f.model, xs, Ts, dat.c1, dat.c2, f.vapour)
    ax.plot(xs, Ps, "-", color=NAVY, lw=2.0, label=f"{f.model.name}, fitted on training only")
    ax.plot(full[0].x1, full[0].P, "o", color=NAVY, mfc="white", mew=1.7,
            label="training points")
    ax.plot(full[1].x1, full[1].P, "s", color=RUST, ms=7,
            label="held out")
    ax.set_xlabel("$x_1$")
    ax.set_ylabel("$P$ / kPa")
    ax.set_xlim(0, 1)
    ax.legend(loc="best")
    ax.set_title(title or
                 f"Cross-validation: rms $\\delta y$ {cv['rms_y_train']:.5f} "
                 f"training, {cv['rms_y_test']:.5f} held out")
    return ax
