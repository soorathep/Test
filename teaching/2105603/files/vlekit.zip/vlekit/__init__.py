"""vlekit — a small, readable toolkit for binary VLE data analysis.

Written for 2105603 Advanced Chemical Engineering Thermodynamics,
Chulalongkorn University. Soorathep Kheawhom.

The pipeline the course follows, in the order the modules appear:

    data          T, P, x, y  ->  gamma, with the vapour-phase assumption made
                  explicit and its uncertainty propagated
    consistency   does the dataset obey Gibbs-Duhem? five tests, each blind to
                  something the others catch
    regress       fit a model; the objective function is a modelling decision
    unifac        the same prediction with nothing fitted, for comparison
    flash         bubble, dew, Rachford-Rice — and the stability question
    validate      cross-validation, and what a fit implies outside its data
    multi         N-component models, tangent plane distance, LLE, residue curves
    cubic         Peng-Robinson for mixtures: one equation for both phases, the
                  phi-phi route, and the P-T envelope with its critical point

Nothing here is fast and nothing here is a black box. Every routine is short
enough to read in one sitting, because a student who cannot read the code
cannot be asked to trust the number that comes out of it.
"""
from .data import (Component, VLEData, LIBRARY, component, from_table,
                   phi_virial, B_cross)
from .models import (ActivityModel, TwoSuffixMargules, Margules,
                     FourSuffixMargules, VanLaar, Wilson, NRTL, UNIQUAC,
                     MODELS, build)
from .regress import (fit, barker_fit, bubble_P, bubble_T, generate,
                      compare_models, compare_objectives, bootstrap,
                      model_table, objective_table, FitResult)
from . import consistency, unifac, flash, validate, multi, reaction, cubic
from .cubic import PengRobinson

__version__ = "0.1.0"
__author__ = "Soorathep Kheawhom"

__all__ = [
    "Component", "VLEData", "LIBRARY", "component", "from_table",
    "phi_virial", "B_cross",
    "ActivityModel", "TwoSuffixMargules", "Margules", "FourSuffixMargules",
    "VanLaar", "Wilson", "NRTL", "UNIQUAC", "MODELS", "build",
    "fit", "barker_fit", "bubble_P", "bubble_T", "generate",
    "compare_models", "compare_objectives", "bootstrap",
    "model_table", "objective_table", "FitResult",
    "consistency", "unifac", "flash", "validate", "multi", "reaction", "cubic",
    "PengRobinson",
]
