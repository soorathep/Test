"""Activity coefficient models.

Every model here is a choice of functional form for the excess Gibbs energy.
That is the only thing that distinguishes them, and it is worth saying in code
as well as on a slide: each class supplies gE_RT, and ln gamma follows from it
as a partial molar quantity. The analytical ln gamma is written out because it
is what the derivations in class produce, but `check_partial_molar` verifies
that it agrees with numerical differentiation of gE_RT, which is the statement
that the two are the same object.

Binary systems only, which is what the course and the teaching datasets use.
"""
from __future__ import annotations

import numpy as np

R = 8.314462618          # J / mol / K


# --------------------------------------------------------------------------
class ActivityModel:
    """Base class. A model supplies gE_RT(x1, T) and ln_gamma(x1, T)."""

    name = "base"
    param_names: tuple[str, ...] = ()
    param_labels: tuple[str, ...] = ()          # LaTeX, for axis labels

    def __init__(self, params):
        self.params = np.asarray(params, dtype=float)
        if not self.param_labels:
            type(self).param_labels = self.param_names
        if len(self.params) != len(self.param_names):
            raise ValueError(
                f"{self.name} takes {len(self.param_names)} parameters "
                f"{self.param_names}, got {len(self.params)}")

    def gE_RT(self, x1, T=None):
        raise NotImplementedError

    def ln_gamma(self, x1, T=None):
        raise NotImplementedError

    def gamma(self, x1, T=None):
        return np.exp(self.ln_gamma(x1, T))

    # ---------------------------------------------------------------- checks
    def check_partial_molar(self, T=None, tol=1e-6):
        """ln gamma_i must equal the partial molar quantity of nG^E/RT.

        For a binary at fixed n = 1 this reduces to
            ln g1 = gE_RT + x2 d(gE_RT)/dx1
            ln g2 = gE_RT - x1 d(gE_RT)/dx1
        Any disagreement means the analytical expression and the excess Gibbs
        energy in the same class describe different models.
        """
        x1 = np.linspace(0.02, 0.98, 97)
        h = 1e-6
        dg = (self.gE_RT(x1 + h, T) - self.gE_RT(x1 - h, T)) / (2 * h)
        g = self.gE_RT(x1, T)
        lg1_num, lg2_num = g + (1 - x1) * dg, g - x1 * dg
        lg1, lg2 = self.ln_gamma(x1, T)
        err = max(np.max(np.abs(lg1 - lg1_num)), np.max(np.abs(lg2 - lg2_num)))
        return err, err < tol

    def gibbs_duhem_residual(self, T=None):
        """x1 dln(g1)/dx1 + x2 dln(g2)/dx1, which must vanish identically.

        Any model derived from a single G^E satisfies this by construction, so
        a non-zero result here is a bug in the model, not a property of a
        fluid. The same quantity computed from *data* is the point test, and
        the distinction between the two is worth making explicit to students.
        """
        x1 = np.linspace(0.02, 0.98, 97)
        h = 1e-6
        lg1p, lg2p = self.ln_gamma(x1 + h, T)
        lg1m, lg2m = self.ln_gamma(x1 - h, T)
        d1 = (lg1p - lg1m) / (2 * h)
        d2 = (lg2p - lg2m) / (2 * h)
        return np.max(np.abs(x1 * d1 + (1 - x1) * d2))


# --------------------------------------------------------------------------
class TwoSuffixMargules(ActivityModel):
    """G^E/RT = A x1 x2. One parameter, symmetric, cannot skew."""

    name = "Margules-1"
    param_names = ("A",)
    param_labels = ("$A$",)

    def gE_RT(self, x1, T=None):
        A, = self.params
        return A * x1 * (1 - x1)

    def ln_gamma(self, x1, T=None):
        A, = self.params
        x2 = 1 - x1
        return A * x2 ** 2, A * x1 ** 2


class Margules(ActivityModel):
    """Three-suffix (two-parameter) Margules.

    G^E/RT = x1 x2 (A21 x1 + A12 x2)
    """

    name = "Margules-2"
    param_names = ("A12", "A21")
    param_labels = ("$A_{12}$", "$A_{21}$")

    def gE_RT(self, x1, T=None):
        A12, A21 = self.params
        x2 = 1 - x1
        return x1 * x2 * (A21 * x1 + A12 * x2)

    def ln_gamma(self, x1, T=None):
        A12, A21 = self.params
        x2 = 1 - x1
        lg1 = x2 ** 2 * (A12 + 2 * (A21 - A12) * x1)
        lg2 = x1 ** 2 * (A21 + 2 * (A12 - A21) * x2)
        return lg1, lg2


class FourSuffixMargules(ActivityModel):
    """Four-suffix (three-parameter) Margules, i.e. a Redlich-Kister expansion.

        G^E/RT = x1 x2 [ A + B (x1 - x2) + C (x1 - x2)^2 ]

    Writing z = x1 - x2, the quantity every azeotrope calculation actually
    needs is

        ln(gamma_1/gamma_2) = B/2 + (C - A) z - (3B/2) z^2 - 2 C z^3

    a *cubic* in z. The two-parameter forms give at most a quadratic (Margules,
    C = 0) or a function with a single interior zero (van Laar), so the third
    parameter is what buys the freedom to place two interior azeotropes
    independently. That is the whole reason this form appears in Module 5.

    C = 0 reduces exactly to the three-suffix `Margules` with
    A12 = A - B and A21 = A + B; A = B = 0 reduces to `TwoSuffixMargules`.
    """

    name = "Margules-3"
    param_names = ("A", "B", "C")
    param_labels = ("$A$", "$B$", "$C$")

    def gE_RT(self, x1, T=None):
        A, B, C = self.params
        x1 = np.asarray(x1, dtype=float)
        x2 = 1 - x1
        z = x1 - x2
        return x1 * x2 * (A + B * z + C * z ** 2)

    def ln_gamma(self, x1, T=None):
        A, B, C = self.params
        x1 = np.asarray(x1, dtype=float)
        x2 = 1 - x1
        z = x1 - x2
        Q = A + B * z + C * z ** 2          # the bracket itself
        D = B + 2 * C * z                   # d(bracket)/dz
        lg1 = x2 ** 2 * Q + 2 * x1 * x2 ** 2 * D
        lg2 = x1 ** 2 * Q - 2 * x1 ** 2 * x2 * D
        return lg1, lg2


class VanLaar(ActivityModel):
    """G^E/RT = A B x1 x2 / (A x1 + B x2).

    Cannot represent a system whose ln gamma curves change sign, which is the
    limitation worth pointing out next to its two-parameter simplicity.
    """

    name = "van Laar"
    param_names = ("A", "B")
    param_labels = ("$A$", "$B$")

    def gE_RT(self, x1, T=None):
        A, B = self.params
        x2 = 1 - x1
        den = A * x1 + B * x2
        return np.where(den == 0, 0.0, A * B * x1 * x2 / np.where(den == 0, 1.0, den))

    def ln_gamma(self, x1, T=None):
        A, B = self.params
        x2 = 1 - x1
        den = A * x1 + B * x2
        den = np.where(den == 0, 1e-300, den)
        lg1 = A * (B * x2 / den) ** 2
        lg2 = B * (A * x1 / den) ** 2
        return lg1, lg2


class Wilson(ActivityModel):
    """Wilson, parameterised directly by the two Lambda values.

    Structurally incapable of predicting liquid-liquid equilibrium: the
    function has no inflection that can produce two stable branches, whatever
    the parameters. That is a property of the form, not of the fitting.
    """

    name = "Wilson"
    param_names = ("L12", "L21")
    param_labels = (r"$\Lambda_{12}$", r"$\Lambda_{21}$")

    def gE_RT(self, x1, T=None):
        L12, L21 = self.params
        x2 = 1 - x1
        return -(x1 * np.log(x1 + L12 * x2) + x2 * np.log(x2 + L21 * x1))

    def ln_gamma(self, x1, T=None):
        L12, L21 = self.params
        x2 = 1 - x1
        a = x1 + L12 * x2
        b = x2 + L21 * x1
        lg1 = -np.log(a) + x2 * (L12 / a - L21 / b)
        lg2 = -np.log(b) - x1 * (L12 / a - L21 / b)
        return lg1, lg2


class NRTL(ActivityModel):
    """Non-random two-liquid model.

    Parameters are the two dimensionless interaction energies tau12, tau21 and
    the non-randomness parameter alpha. alpha is held fixed at 0.3 by default
    because fitting it as well as tau makes the problem badly conditioned, and
    that is itself a teaching point about parameter identifiability.
    """

    name = "NRTL"
    param_names = ("tau12", "tau21")
    param_labels = (r"$\tau_{12}$", r"$\tau_{21}$")

    def __init__(self, params, alpha=0.3):
        super().__init__(params)
        self.alpha = float(alpha)

    def _G(self):
        t12, t21 = self.params
        a = self.alpha
        return np.exp(-a * t12), np.exp(-a * t21)

    def gE_RT(self, x1, T=None):
        t12, t21 = self.params
        G12, G21 = self._G()
        x2 = 1 - x1
        return x1 * x2 * (t21 * G21 / (x1 + x2 * G21) + t12 * G12 / (x2 + x1 * G12))

    def ln_gamma(self, x1, T=None):
        t12, t21 = self.params
        G12, G21 = self._G()
        x2 = 1 - x1
        d1 = x1 + x2 * G21
        d2 = x2 + x1 * G12
        lg1 = x2 ** 2 * (t21 * (G21 / d1) ** 2 + t12 * G12 / d2 ** 2)
        lg2 = x1 ** 2 * (t12 * (G12 / d2) ** 2 + t21 * G21 / d1 ** 2)
        return lg1, lg2


MODELS = {
    "margules1": TwoSuffixMargules,
    "margules": Margules,
    "margules3": FourSuffixMargules,
    "vanlaar": VanLaar,
    "wilson": Wilson,
    "nrtl": NRTL,
}


def build(name, params, **kw):
    """Instantiate a model by name, for use from a config or a notebook cell."""
    try:
        cls = MODELS[name.lower()]
    except KeyError:
        raise KeyError(f"unknown model {name!r}; choose from {sorted(MODELS)}")
    return cls(params, **kw)


class UNIQUAC(ActivityModel):
    """Universal quasi-chemical model.

    G^E is split into two physically distinct contributions:

        combinatorial   entropic, from the difference in molecular size and
                        shape. Fixed by r and q, which are properties of the
                        molecules and are NOT fitted.
        residual        energetic, from the interaction energies. This is where
                        the two adjustable parameters live.

    That split is the reason UNIQUAC extrapolates in composition better than
    Margules or van Laar: the part of the non-ideality that comes from size is
    already accounted for before any fitting starts.

    Parameters are tau12 and tau21 at a fixed temperature, matching the way
    NRTL is parameterised here. tau_ij = exp(-du_ij / RT), so a temperature
    dependence requires du rather than tau; `from_du` builds a model that way
    when the interaction energies are what is known.

    r and q must be supplied. `UNIQUAC.for_pair(c1, c2, params)` takes them from
    the Component objects, which derive them from the UNIFAC group table.
    """

    name = "UNIQUAC"
    param_names = ("tau12", "tau21")
    param_labels = (r"$\tau_{12}$", r"$\tau_{21}$")
    z = 10.0                     # lattice coordination number, conventional

    def __init__(self, params, r1=None, q1=None, r2=None, q2=None):
        super().__init__(params)
        for v, n in ((r1, "r1"), (q1, "q1"), (r2, "r2"), (q2, "q2")):
            if v is None or not np.isfinite(v):
                raise ValueError(f"UNIQUAC needs {n}; use UNIQUAC.for_pair")
        self.r1, self.q1, self.r2, self.q2 = float(r1), float(q1), float(r2), float(q2)

    @classmethod
    def for_pair(cls, c1, c2, params):
        return cls(params, r1=c1.r, q1=c1.q, r2=c2.r, q2=c2.q)

    @classmethod
    def from_du(cls, du12, du21, T, **kw):
        """Build from interaction energies in J/mol at temperature T."""
        return cls([np.exp(-du12 / (R * T)), np.exp(-du21 / (R * T))], **kw)

    # ------------------------------------------------------------ internals
    def _fractions(self, x1):
        x2 = 1 - x1
        rs = x1 * self.r1 + x2 * self.r2
        qs = x1 * self.q1 + x2 * self.q2
        phi1 = x1 * self.r1 / rs
        th1 = x1 * self.q1 / qs
        return x2, phi1, 1 - phi1, th1, 1 - th1

    # ------------------------------------------------------------------ gE
    def gE_RT(self, x1, T=None):
        t12, t21 = self.params
        x1 = np.asarray(x1, dtype=float)
        x2, ph1, ph2, th1, th2 = self._fractions(x1)
        with np.errstate(divide="ignore", invalid="ignore"):
            comb = (np.where(x1 > 0, x1 * np.log(ph1 / np.where(x1 > 0, x1, 1)), 0.0)
                    + np.where(x2 > 0, x2 * np.log(ph2 / np.where(x2 > 0, x2, 1)), 0.0)
                    + (self.z / 2) * (self.q1 * x1 * np.log(th1 / ph1)
                                      + self.q2 * x2 * np.log(th2 / ph2)))
            res = -(self.q1 * x1 * np.log(th1 + th2 * t21)
                    + self.q2 * x2 * np.log(th2 + th1 * t12))
        return comb + res

    def ln_gamma(self, x1, T=None):
        t12, t21 = self.params
        x1 = np.asarray(x1, dtype=float)
        x2, ph1, ph2, th1, th2 = self._fractions(x1)
        l1 = (self.z / 2) * (self.r1 - self.q1) - (self.r1 - 1)
        l2 = (self.z / 2) * (self.r2 - self.q2) - (self.r2 - 1)
        with np.errstate(divide="ignore", invalid="ignore"):
            c1 = (np.log(ph1 / np.where(x1 > 0, x1, 1e-300))
                  + (self.z / 2) * self.q1 * np.log(th1 / ph1)
                  + l1 - (ph1 / np.where(x1 > 0, x1, 1e-300)) * (x1 * l1 + x2 * l2))
            c2 = (np.log(ph2 / np.where(x2 > 0, x2, 1e-300))
                  + (self.z / 2) * self.q2 * np.log(th2 / ph2)
                  + l2 - (ph2 / np.where(x2 > 0, x2, 1e-300)) * (x1 * l1 + x2 * l2))
            s1 = th1 + th2 * t21
            s2 = th2 + th1 * t12
            r1 = self.q1 * (1 - np.log(s1) - (th1 / s1 + th2 * t12 / s2))
            r2 = self.q2 * (1 - np.log(s2) - (th2 / s2 + th1 * t21 / s1))
        return c1 + r1, c2 + r2


MODELS["uniquac"] = UNIQUAC
