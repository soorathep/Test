"""Chemical equilibrium: the same criterion, under a different constraint.

Phase equilibrium equates the chemical potential of a species between phases.
Reaction equilibrium sets a weighted sum of chemical potentials to zero within
one phase:

    sum_i nu_i mu_i = 0

Both are the statement that the Gibbs energy is at a minimum; they differ only
in what is being varied. Making that equivalence explicit is the point of this
module, and it is why nothing new has to be invented here — the fugacity
coefficient from the equation of state and the activity coefficient from the
excess Gibbs energy model are simply applied to a new constraint.

Two formulations are provided, and the notebook requires them to agree:

    extent      pick a stoichiometrically independent reaction set, solve for
                the extents. Exact, fast, and useless when the reaction set is
                not known — which is the normal case in combustion, reforming
                and pyrolysis.
    Gibbs min   minimise the total Gibbs energy over all species subject to
                conservation of atoms. No reaction set is needed, only an
                element list. This is what an equilibrium reactor block in a
                process simulator solves.

Thermochemical data are read from the `chemicals` package rather than typed in.
That is deliberate: standard formation properties copied by hand are wrong more
often than any other quantity in this subject, and every value used here can be
traced to a maintained compilation and re-checked by anyone.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

import numpy as np
from scipy.optimize import brentq, minimize

R = 8.314462618
T_REF = 298.15
P_REF = 100.0          # kPa — the standard-state pressure, 1 bar
F_FARADAY = 96485.33212


# ==========================================================================
# Species
# ==========================================================================
def parse_formula(formula):
    """Element counts from a formula string. 'C2H5OH' -> {'C':2,'H':6,'O':1}."""
    counts = {}
    for el, n in re.findall(r"([A-Z][a-z]?)(\d*)", formula):
        if not el:
            continue
        counts[el] = counts.get(el, 0) + (int(n) if n else 1)
    return counts


@dataclass(eq=False)          # identity equality, so a Species can be a dict key
class Species:
    """One reacting species, with its standard formation properties.

    Hf and S0 are the standard enthalpy of formation and the absolute entropy
    at 298.15 K and 1 bar, in J/mol and J/mol/K. `cp` is a callable giving the
    ideal-gas heat capacity in J/mol/K; when it is absent the constant-Cp
    approximation is used and `Gf(T)` says so.
    """

    name: str
    formula: str
    Hf: float
    S0: float
    cp: object = None
    phase: str = "g"                  # 'g' | 'l' | 's' | 'aq'
    charge: int = 0
    cas: str = ""
    source: str = ""
    elements: dict = field(default_factory=dict)

    def __post_init__(self):
        if not self.elements:
            self.elements = parse_formula(self.formula)

    # ------------------------------------------------------------------
    def Cp(self, T):
        if self.cp is None:
            return 0.0
        return float(self.cp(T))

    def dH(self, T):
        """H(T) - H(298.15), by integrating Cp. Zero if no Cp is available."""
        if self.cp is None:
            return 0.0
        return _quad(self.cp, T_REF, T)

    def dS(self, T):
        """S(T) - S(298.15) = integral Cp/T dT."""
        if self.cp is None:
            return 0.0
        return _quad(lambda t: self.cp(t) / t, T_REF, T)

    def H(self, T):
        return self.Hf + self.dH(T)

    def S(self, T):
        return self.S0 + self.dS(T)

    def G(self, T):
        """Standard Gibbs energy on the element-reference scale.

        G = Hf(T) - T S(T) is *not* the Gibbs energy of formation: it still
        carries the absolute entropy of the species rather than the entropy
        change of forming it. The element entropies cancel in any balanced
        reaction, which is why this form is the convenient one for both the
        extent formulation and the Gibbs minimisation. `Gf` below does the
        cancellation explicitly for a single species.
        """
        return self.H(T) - T * self.S(T)


def _quad(f, a, b, n=200):
    """Simpson integration. Fixed-step because Cp correlations are smooth and a
    predictable cost matters more here than an adaptive one."""
    if b == a:
        return 0.0
    n = n if n % 2 == 0 else n + 1
    x = np.linspace(a, b, n + 1)
    y = np.array([f(xi) for xi in x])
    h = (b - a) / n
    return float(h / 3 * (y[0] + y[-1] + 4 * y[1:-1:2].sum() + 2 * y[2:-1:2].sum()))


# --------------------------------------------------------------------------
_ELEMENT_REFERENCE = {
    # element -> (formula of its reference state, atoms of the element per
    # molecule of that reference state). Used to convert the absolute-entropy
    # scale into formation properties.
    "H": ("H2", 2), "N": ("N2", 2), "O": ("O2", 2), "C": ("C", 1),
    "S": ("S", 1), "Cl": ("Cl2", 2), "Na": ("Na", 1), "K": ("K", 1),
    "Li": ("Li", 1), "Br": ("Br2", 2), "F": ("F2", 2), "I": ("I2", 2),
}


def from_chemicals(name, phase="g", cp=True):
    """Build a Species from the `chemicals` package.

    Raises rather than guessing when a value is missing. A silently defaulted
    formation enthalpy would move every equilibrium constant downstream by
    orders of magnitude and would look like a modelling result.
    """
    from chemicals.identifiers import CAS_from_any, search_chemical
    from chemicals.reaction import Hfg, S0g, Hfl, S0l, Hfs, S0s

    cas = CAS_from_any(name)
    meta = search_chemical(cas)
    getters = {"g": (Hfg, S0g), "l": (Hfl, S0l), "s": (Hfs, S0s)}
    if phase not in getters:
        raise ValueError(f"phase must be one of {sorted(getters)}")
    Hgetter, Sgetter = getters[phase]
    Hf, S0 = Hgetter(cas), Sgetter(cas)
    if Hf is None or S0 is None:
        raise ValueError(
            f"{name} ({phase}): the chemicals package has "
            f"Hf={Hf}, S0={S0}. Supply them explicitly rather than defaulting.")

    cpf = None
    if cp and phase == "g":
        cpf = _trc_cp(cas)

    return Species(name=meta.common_name or name, formula=meta.formula,
                   Hf=float(Hf), S0=float(S0), cp=cpf, phase=phase, cas=cas,
                   source="chemicals package (TRC / CRC compilations)")


def _trc_cp(cas):
    """Ideal-gas Cp from the TRC correlation shipped with `chemicals`."""
    from chemicals import heat_capacity as hc

    hc._load_Cp_data()
    try:
        row = hc.TRC_gas_data.loc[cas]
    except Exception:
        return None
    a = [float(row[f"a{i}"]) for i in range(8)]
    Tmin, Tmax = float(row["Tmin"]), float(row["Tmax"])

    def cp(T):
        T = float(np.clip(T, Tmin, Tmax))
        return hc.TRCCp(T, *a)

    cp.range = (Tmin, Tmax)
    return cp


# ==========================================================================
# Reactions
# ==========================================================================
@dataclass
class Reaction:
    """A balanced reaction: species with stoichiometric coefficients.

    nu is negative for reactants and positive for products, which is the
    convention that makes  sum_i nu_i mu_i = 0  the equilibrium condition with
    no sign bookkeeping at the call site.
    """

    species: list
    nu: np.ndarray
    name: str = ""

    def __post_init__(self):
        self.nu = np.asarray(self.nu, dtype=float)
        if len(self.nu) != len(self.species):
            raise ValueError("nu and species must be the same length")
        bad = self.element_balance()
        if bad:
            raise ValueError(f"reaction is not balanced: {bad}")

    # ------------------------------------------------------------------
    def element_balance(self):
        """Net atoms of each element. Must be empty for a balanced reaction."""
        tot = {}
        for s, n in zip(self.species, self.nu):
            for el, k in s.elements.items():
                tot[el] = tot.get(el, 0.0) + n * k
        charge = sum(n * s.charge for s, n in zip(self.species, self.nu))
        out = {el: v for el, v in tot.items() if abs(v) > 1e-9}
        if abs(charge) > 1e-9:
            out["charge"] = charge
        return out

    @property
    def dnu(self):
        return float(np.sum(self.nu))

    # ------------------------------------------------------- thermochemistry
    def dH(self, T=T_REF):
        return float(sum(n * s.H(T) for s, n in zip(self.species, self.nu)))

    def dS(self, T=T_REF):
        return float(sum(n * s.S(T) for s, n in zip(self.species, self.nu)))

    def dG(self, T=T_REF):
        """Standard Gibbs energy change. The absolute entropies cancel here
        exactly as they would in a formation-property calculation."""
        return self.dH(T) - T * self.dS(T)

    def K(self, T=T_REF):
        return float(np.exp(-self.dG(T) / (R * T)))

    def lnK(self, T=T_REF):
        return -self.dG(T) / (R * T)

    def K_vant_hoff(self, T, T0=T_REF):
        """K(T) with dH held at its value at T0 — the constant-enthalpy form.

            ln[K(T)/K(T0)] = -(dH/R)(1/T - 1/T0)

        Provided so that the approximation can be *plotted against* the exact
        result rather than described. Where the two separate is the useful
        teaching output.
        """
        dH0 = self.dH(T0)
        return float(self.K(T0) * np.exp(-dH0 / R * (1.0 / T - 1.0 / T0)))

    def __repr__(self):
        left = " + ".join(f"{-n:g} {s.name}" for s, n in
                          zip(self.species, self.nu) if n < 0)
        right = " + ".join(f"{n:g} {s.name}" for s, n in
                           zip(self.species, self.nu) if n > 0)
        return f"<Reaction {left} -> {right}>"


def reaction(species, coeffs, name=""):
    """Build a Reaction from a dict {species: nu} or parallel lists."""
    if isinstance(species, dict):
        sp = list(species.keys())
        nu = list(species.values())
        return Reaction(sp, nu, name)
    return Reaction(list(species), list(coeffs), name)


# ==========================================================================
# Extent of reaction
# ==========================================================================
def moles_from_extent(n0, nu, xi):
    """n_i = n_i0 + sum_j nu_ij xi_j."""
    n0 = np.asarray(n0, dtype=float)
    nu = np.atleast_2d(np.asarray(nu, dtype=float))
    xi = np.atleast_1d(np.asarray(xi, dtype=float))
    return n0 + nu.T @ xi


def extent_bounds(n0, nu):
    """The range of a single extent that keeps every mole number non-negative.

    Worth computing rather than guessing: the limiting reactant sets one end
    and, for a reversible reaction written the other way, a product sets the
    other. A solver started outside this window evaluates ln of a negative
    number and fails in a way that looks like a physics problem.
    """
    n0 = np.asarray(n0, dtype=float)
    nu = np.asarray(nu, dtype=float)
    lo, hi = -np.inf, np.inf
    for ni, vi in zip(n0, nu):
        if vi > 0:
            lo = max(lo, -ni / vi)
        elif vi < 0:
            hi = min(hi, -ni / vi)
    return lo, hi


def K_from_extent(rxn, n0, xi, T, P, phi=None, gamma=None):
    """The activity quotient at a given extent.

    For a gas phase   Ka = prod (y_i phi_i P / P0)^nu_i = Kphi Ky (P/P0)^dnu
    For a liquid      Ka = prod (x_i gamma_i)^nu_i      = Kgamma Kx

    `phi` and `gamma` are callables taking (y or x, T, P) and returning the
    coefficient vector. Leaving both None is the ideal case, and the difference
    between that and the corrected result is exactly what section 6.2 is about.
    """
    n = moles_from_extent(n0, rxn.nu, xi)
    if np.any(n < -1e-12):
        raise ValueError(f"extent {xi} gives a negative mole number: {n}")
    n = np.clip(n, 1e-300, None)
    y = n / n.sum()
    ln_a = np.log(y)
    if rxn.species[0].phase == "g":
        ln_a = ln_a + np.log(P / P_REF)
        if phi is not None:
            ln_a = ln_a + np.log(np.asarray(phi(y, T, P), dtype=float))
    elif gamma is not None:
        ln_a = ln_a + np.log(np.asarray(gamma(y, T, P), dtype=float))
    return float(np.exp(np.dot(rxn.nu, ln_a)))


def solve_extent(rxn, n0, T, P, phi=None, gamma=None, eps=1e-10):
    """Solve Ka(xi) = K(T) for a single reaction, by bisection on the extent.

    Bisection rather than Newton because the objective
    ln Ka(xi) - ln K is monotonic in xi over the feasible window — every
    product activity rises and every reactant activity falls — so bisection
    cannot fail, and the physically meaningful bracket is already known.
    """
    lo, hi = extent_bounds(n0, rxn.nu)
    span = hi - lo
    a, b = lo + eps * span, hi - eps * span

    def f(xi):
        return np.log(K_from_extent(rxn, n0, xi, T, P, phi, gamma)) - rxn.lnK(T)

    fa, fb = f(a), f(b)
    if fa > 0:
        return a
    if fb < 0:
        return b
    xi = brentq(f, a, b, xtol=1e-14, rtol=1e-15)
    return float(xi)


def equilibrium_composition(rxn, n0, T, P, phi=None, gamma=None):
    """Mole numbers and mole fractions at equilibrium for a single reaction."""
    xi = solve_extent(rxn, n0, T, P, phi, gamma)
    n = moles_from_extent(n0, rxn.nu, xi)
    return {"xi": xi, "n": n, "y": n / n.sum(),
            "K": rxn.K(T), "Ka": K_from_extent(rxn, n0, xi, T, P, phi, gamma)}


# ==========================================================================
# Gibbs energy minimisation
# ==========================================================================
def element_matrix(species):
    """A[k, i] = atoms of element k in species i, plus a charge row if needed."""
    els = sorted({e for s in species for e in s.elements})
    A = np.array([[s.elements.get(e, 0) for s in species] for e in els],
                 dtype=float)
    if any(s.charge for s in species):
        A = np.vstack([A, [s.charge for s in species]])
        els = els + ["charge"]
    return A, els


def total_G(species, n, T, P, phi=None, gamma=None):
    """Total Gibbs energy of a mixture, in J.

        G = sum_i n_i [ G_i^0(T) + RT ln a_i ]

    with a_i = y_i P/P0 for an ideal gas. The `n ln n` structure is what makes
    this objective ill-conditioned as any mole number approaches zero, which is
    the single practical difficulty of the whole method.
    """
    n = np.clip(np.asarray(n, dtype=float), 1e-300, None)
    # clip the fraction too: n is bounded away from zero but n/sum(n) can still
    # underflow when one species is 10^290 times smaller than the others, and
    # the resulting log(0) is the ill-conditioning this objective is known for
    y = np.clip(n / n.sum(), 1e-300, None)
    G0 = np.array([s.G(T) for s in species])
    ln_a = np.log(y)
    if species[0].phase == "g":
        ln_a = ln_a + np.log(P / P_REF)
        if phi is not None:
            ln_a = ln_a + np.log(np.asarray(phi(y, T, P), dtype=float))
    elif gamma is not None:
        ln_a = ln_a + np.log(np.asarray(gamma(y, T, P), dtype=float))
    return float(np.dot(n, G0 + R * T * ln_a))


def gibbs_minimise(species, n0, T, P, phi=None, gamma=None, nmin=1e-14,
                   restarts=6, seed=0):
    """Minimise G over mole numbers subject to conservation of atoms.

    No reaction set is required — only the element list, which comes from the
    formulae. That is the whole advantage of the method and the reason a
    process simulator's equilibrium reactor works without being told what
    reactions occur.

    Solved with SLSQP on ln(n) rather than n. The change of variable enforces
    positivity exactly, which matters because the objective contains
    n ln n and a solver that steps to a negative mole number produces a NaN
    rather than a rejected step. Several restarts are used because the
    objective is not convex in these variables and a bad start can stall on a
    boundary.
    """
    rng = np.random.default_rng(seed)
    A, els = element_matrix(species)
    b = A @ np.asarray(n0, dtype=float)
    nsp = len(species)

    def unpack(u):
        return np.exp(u)

    def obj(u):
        return total_G(species, unpack(u), T, P, phi, gamma) / (R * T)

    def con(u):
        return A @ unpack(u) - b

    best = None
    starts = [np.asarray(n0, dtype=float)]
    tot = max(float(np.sum(n0)), 1e-12)
    for _ in range(restarts - 1):
        w = rng.dirichlet(np.ones(nsp))
        # scale a random composition onto the element balance as best it can
        starts.append(np.maximum(w * tot, 1e-8))

    for s0 in starts:
        u0 = np.log(np.clip(s0, 1e-10, None))
        # Bound ln n. Without bounds SLSQP occasionally takes a step of a few
        # hundred in the log variable, exp overflows, and the constraint
        # evaluates to nan; the run usually recovers but emits warnings that
        # look like a physics failure to a student. The window spans thirty
        # orders of magnitude around the feed, which is far wider than the
        # objective can resolve anyway.
        scale = np.log(max(float(np.sum(n0)), 1e-12))
        bnds = [(scale - 60.0, scale + 5.0)] * nsp
        try:
            r = minimize(obj, u0, jac=None, method="SLSQP", bounds=bnds,
                         constraints=[{"type": "eq", "fun": con}],
                         options={"maxiter": 800, "ftol": 1e-12})
        except Exception:
            continue
        n = unpack(r.x)
        if np.max(np.abs(A @ n - b)) > 1e-6 * max(1.0, float(np.max(np.abs(b)))):
            continue
        g = total_G(species, n, T, P, phi, gamma)
        if best is None or g < best[0]:
            best = (g, n, r)

    if best is None:
        raise RuntimeError("Gibbs minimisation did not satisfy the element "
                           "balance from any starting point")
    g, n, r = best
    n = np.clip(n, nmin, None)
    lam = element_potentials(species, n, T, P, A, phi, gamma)
    return {"n": n, "y": n / n.sum(), "G": g, "elements": els,
            "element_potentials": lam, "success": bool(r.success),
            "residual": float(np.max(np.abs(A @ n - b)))}


def element_potentials(species, n, T, P, A=None, phi=None, gamma=None):
    """The Lagrange multipliers of the element balances, in J per mol of atom.

    At the minimum the chemical potential of every species is a linear
    combination of the element potentials weighted by its formula:

        mu_i = sum_k a_ki lambda_k

    That is a strong statement. It says a species carries no equilibrium
    information beyond the atoms it is made of — and it gives the cheapest
    possible check on a converged solution, because the residual of that
    relation is computable without re-solving anything.
    """
    if A is None:
        A, _ = element_matrix(species)
    mu = chemical_potentials(species, n, T, P, phi, gamma)
    lam, *_ = np.linalg.lstsq(A.T, mu, rcond=None)
    return lam


def chemical_potentials(species, n, T, P, phi=None, gamma=None):
    n = np.clip(np.asarray(n, dtype=float), 1e-300, None)
    # clip the fraction too: n is bounded away from zero but n/sum(n) can still
    # underflow when one species is 10^290 times smaller than the others, and
    # the resulting log(0) is the ill-conditioning this objective is known for
    y = np.clip(n / n.sum(), 1e-300, None)
    G0 = np.array([s.G(T) for s in species])
    ln_a = np.log(y)
    if species[0].phase == "g":
        ln_a = ln_a + np.log(P / P_REF)
        if phi is not None:
            ln_a = ln_a + np.log(np.asarray(phi(y, T, P), dtype=float))
    elif gamma is not None:
        ln_a = ln_a + np.log(np.asarray(gamma(y, T, P), dtype=float))
    return G0 + R * T * ln_a


def element_potential_residual(species, n, T, P, phi=None, gamma=None):
    """max |mu_i - sum_k a_ki lambda_k|, the check the previous docstring names."""
    A, _ = element_matrix(species)
    mu = chemical_potentials(species, n, T, P, phi, gamma)
    lam = element_potentials(species, n, T, P, A, phi, gamma)
    return float(np.max(np.abs(mu - A.T @ lam)))


# ==========================================================================
# Electrolytes
# ==========================================================================
def ionic_strength(molalities, charges):
    """I = 1/2 sum m_i z_i^2, in mol/kg."""
    m = np.asarray(molalities, dtype=float)
    z = np.asarray(charges, dtype=float)
    return float(0.5 * np.sum(m * z ** 2))


def debye_huckel_A(T=298.15, eps_r=None, rho=997.0):
    """The Debye-Huckel constant A for a molal scale, (kg/mol)^(1/2).

    Computed from the solvent properties rather than quoted, so that its
    temperature dependence is visible. The permittivity of water is taken from
    the Bradley-Pitzer style correlation below when eps_r is not supplied; at
    298.15 K the result is 0.5092, against the value of 0.509 quoted in every
    textbook, which is the check.
    """
    e = 1.602176634e-19
    k = 1.380649e-23
    Na = 6.02214076e23
    eps0 = 8.8541878128e-12
    if eps_r is None:
        eps_r = water_permittivity(T)
    eps = eps_r * eps0
    return float((np.sqrt(2 * np.pi * Na * rho) / np.log(10))
                 * (e ** 2 / (4 * np.pi * eps * k * T)) ** 1.5)


def water_permittivity(T):
    """Relative permittivity of liquid water, 273-373 K.

    A simple polynomial fit; it reproduces 78.4 at 298.15 K and 55.6 at 373 K,
    which is enough for the Debye-Huckel constant to be right to three figures
    over the range this course uses.
    """
    t = T - 273.15
    return 87.740 - 0.40008 * t + 9.398e-4 * t ** 2 - 1.410e-6 * t ** 3


def dh_limiting(I, z_plus, z_minus, T=298.15, A=None):
    """log10 gamma_pm = -A |z+ z-| sqrt(I). Valid to about I = 0.01 mol/kg."""
    A = debye_huckel_A(T) if A is None else A
    return 10.0 ** (-A * abs(z_plus * z_minus) * np.sqrt(np.asarray(I, float)))


def dh_extended(I, z_plus, z_minus, a_ang=4.0, T=298.15, A=None, B=None):
    """The extended law with an ion-size parameter. Valid to about 0.1 mol/kg."""
    I = np.asarray(I, dtype=float)
    A = debye_huckel_A(T) if A is None else A
    B = 0.3283 if B is None else B          # (kg/mol)^0.5 / angstrom, 298 K
    return 10.0 ** (-A * abs(z_plus * z_minus) * np.sqrt(I)
                    / (1 + B * a_ang * np.sqrt(I)))


def pitzer(I, m, z_plus, z_minus, beta0, beta1, Cphi=0.0, T=298.15,
           alpha=2.0, b=1.2, A=None):
    """Pitzer's model for a single 1:1 or 2:1 electrolyte, molal scale.

        ln g_pm = -A_phi |z+z-| f + m (2 nu+nu-/nu) B + m^2 [2(nu+nu-)^1.5/nu] C

    The three parameters are fitted, not predicted, exactly like the binary
    parameters of an activity model — and the same obligations follow. Their
    role is to extend the range from 0.1 mol/kg to several mol/kg, which is
    where every industrial electrolyte actually sits.
    """
    I = np.asarray(I, dtype=float)
    m = np.asarray(m, dtype=float)
    A10 = debye_huckel_A(T) if A is None else A
    Aphi = A10 * np.log(10) / 3.0
    zz = abs(z_plus * z_minus)
    nu_p, nu_m = abs(z_minus), abs(z_plus)      # electroneutral stoichiometry
    nu = nu_p + nu_m

    sq = np.sqrt(I)
    f_gamma = -Aphi * (sq / (1 + b * sq) + (2.0 / b) * np.log(1 + b * sq))
    x = alpha * sq
    with np.errstate(divide="ignore", invalid="ignore"):
        g = 2 * (1 - (1 + x) * np.exp(-x)) / x ** 2
        gp = -2 * (1 - (1 + x + 0.5 * x ** 2) * np.exp(-x)) / x ** 2
    # B^gamma = 2 beta0 + beta1 [ 2 g(x) + g'(x) ], the standard combination
    # in which the beta1 term appears in both B^phi and B itself
    B_gamma = 2 * beta0 + beta1 * (2 * g + gp)
    C_gamma = 1.5 * Cphi
    ln_g = (zz * f_gamma
            + m * (2 * nu_p * nu_m / nu) * B_gamma
            + m ** 2 * (2 * (nu_p * nu_m) ** 1.5 / nu) * C_gamma)
    return np.exp(ln_g)


# ==========================================================================
# Electrochemistry
# ==========================================================================
def nernst(E0, T, n_electrons, activity_quotient):
    """E = E0 - (RT/nF) ln Q.

    Derived, not quoted: the equilibrium condition for a cell reaction is the
    equality of the *electrochemical* potential, mu~_i = mu_i + z_i F phi, and
    setting sum_i nu_i mu~_i = 0 gives exactly this once the potential
    difference is collected. The notebook does that derivation in five lines.
    """
    return float(E0 - (R * T / (n_electrons * F_FARADAY))
                 * np.log(activity_quotient))


def cell_voltage(E0, T, n_electrons, m, gamma_pm, nu_ions=2, m_ref=1.0):
    """Open-circuit voltage of a cell whose reaction consumes the electrolyte.

    Q is written in the mean ionic activity a_pm = gamma_pm m / m0, raised to
    the stoichiometric power. The activity coefficient is where the electrolyte
    model enters, and the difference between using gamma = 1 and a Pitzer
    gamma is the point of the comparison in section 6.4.
    """
    a = np.asarray(gamma_pm, dtype=float) * np.asarray(m, dtype=float) / m_ref
    return E0 - (R * T / (n_electrons * F_FARADAY)) * nu_ions * np.log(a)


# ==========================================================================
def graphite():
    """Graphite as a Species, built entirely from the `chemicals` tables.

    It needs its own constructor because the obvious route does not work:
    `CAS_from_any('carbon')` resolves to 7440-44-0, for which the dataset has
    no solid formation enthalpy at all and an entropy of 6.017 J/mol/K — a
    different allotrope. Graphite is 7782-42-5, with Hf = 0 by definition of
    the element reference state and S0 = 5.7 J/mol/K, and the heat capacity is
    the JANAF solid table: 8.5 J/mol/K at 298 K rising to 23.2 at 1300 K, a
    variation a constant-Cp assumption would throw away.

    Verified in the test suite against two published reactions rather than
    against itself: the Boudouard reaction and methane cracking.
    """
    from chemicals import heat_capacity as hc
    from chemicals.reaction import Hfs, S0s

    hc._load_Cp_data()
    Ts, Cps = hc.Cp_dict_JANAF_solid["7782-42-5"]
    Ts, Cps = np.asarray(Ts, dtype=float), np.asarray(Cps, dtype=float)

    def cp(T):
        return float(np.interp(float(T), Ts, Cps))

    cp.range = (float(Ts[1]), float(Ts[-1]))
    return Species(name="graphite", formula="C", Hf=float(Hfs("7782-42-5")),
                   S0=float(S0s("7782-42-5")), cp=cp, phase="s",
                   cas="7782-42-5",
                   source="chemicals: reaction.Hfs / reaction.S0s, "
                          "heat_capacity.Cp_dict_JANAF_solid")
