"""Fitting activity coefficient models to VLE data.

The engineering content of this module is not the optimiser. It is the choice
of objective function, which is a modelling decision disguised as a numerical
one. Fitting the same dataset to the same model against P, against y, against
gamma, or by maximum likelihood gives four different parameter sets, and the
differences are larger than most students expect. Each objective is therefore
selectable by name, and `compare_objectives` runs all of them side by side so
the spread is seen rather than described.

Barker's method — objective='P' — is the default because it uses only the
quantities that are measured most accurately (P and x) and leaves y free to be
predicted. That is what makes the point test and the direct test possible: a y
that was never fitted can be compared with a y that was measured.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy.optimize import least_squares, brentq, minimize_scalar

from .data import phi_virial, phi_sat_virial, poynting
from .models import MODELS, build

R = 8.314462618


# --------------------------------------------------------------------------
# Bubble point calculations
# --------------------------------------------------------------------------
def bubble_P(model, x1, T, c1, c2, vapour="ideal", k12=0.0, tol=1e-10, itmax=60):
    """Bubble pressure and vapour composition at given x1 and T.

    gamma_i x_i Psat_i phi_i^sat PF_i = y_i phi_i P

    With an ideal vapour this is one line. With the virial equation phi_i
    depends on y, which depends on P, which depends on phi_i, so it is solved
    by successive substitution — which converges in a handful of iterations at
    the pressures this course works at, and is worth showing precisely because
    it is not a black box.
    """
    x1 = np.atleast_1d(np.asarray(x1, dtype=float))
    T = np.broadcast_to(np.asarray(T, dtype=float), x1.shape)
    x2 = 1 - x1
    g1, g2 = model.gamma(x1, T)
    Ps1, Ps2 = c1.Psat(T), c2.Psat(T)

    P = x1 * g1 * Ps1 + x2 * g2 * Ps2
    y1 = np.where(P > 0, x1 * g1 * Ps1 / np.where(P > 0, P, 1.0), x1)
    if vapour == "ideal":
        return P, y1
    if vapour != "virial":
        raise ValueError("vapour must be 'ideal' or 'virial'")

    ps1 = phi_sat_virial(T, c1)
    ps2 = phi_sat_virial(T, c2)
    for _ in range(itmax):
        f1 = x1 * g1 * Ps1 * ps1 * poynting(T, P, c1)
        f2 = x2 * g2 * Ps2 * ps2 * poynting(T, P, c2)
        ph1, ph2 = phi_virial(y1, T, P, c1, c2, k12)
        Pn = f1 / ph1 + f2 / ph2
        y1n = (f1 / ph1) / Pn
        if np.max(np.abs(Pn - P)) < tol * np.max(Pn) and np.max(np.abs(y1n - y1)) < tol:
            P, y1 = Pn, y1n
            break
        P, y1 = Pn, y1n
    return P, y1


def bubble_T(model, x1, P, c1, c2, vapour="ideal", k12=0.0,
             bracket=None, tol=1e-8):
    """Bubble temperature at given x1 and P. Brent on bubble_P(T) - P."""
    x1 = np.atleast_1d(np.asarray(x1, dtype=float))
    P = np.broadcast_to(np.asarray(P, dtype=float), x1.shape)
    Tout = np.empty_like(x1)
    yout = np.empty_like(x1)
    for i, (xi, Pi) in enumerate(zip(x1, P)):
        lo, hi = bracket or (min(c1.Tsat(Pi), c2.Tsat(Pi)) - 60.0,
                             max(c1.Tsat(Pi), c2.Tsat(Pi)) + 60.0)

        def f(T, xi=xi, Pi=Pi):
            return bubble_P(model, np.array([xi]), np.array([T]),
                            c1, c2, vapour, k12)[0][0] - Pi

        flo, fhi = f(lo), f(hi)
        k = 0
        while flo * fhi > 0 and k < 12:      # widen if the bracket missed
            lo -= 20.0
            hi += 20.0
            flo, fhi = f(lo), f(hi)
            k += 1
        if flo * fhi > 0:
            Tout[i], yout[i] = np.nan, np.nan
            continue
        Ti = brentq(f, lo, hi, xtol=tol)
        Tout[i] = Ti
        yout[i] = bubble_P(model, np.array([xi]), np.array([Ti]),
                           c1, c2, vapour, k12)[1][0]
    return Tout, yout


# --------------------------------------------------------------------------
@dataclass
class FitResult:
    """Everything needed to defend a fitted parameter set."""

    model: object
    params: np.ndarray
    objective: str
    vapour: str
    data: object
    P_calc: np.ndarray = None
    T_calc: np.ndarray = None
    y1_calc: np.ndarray = None
    rms_P: float = np.nan
    rms_T: float = np.nan
    rms_y: float = np.nan
    sse: float = np.nan
    aic: float = np.nan
    bic: float = np.nan
    cov: np.ndarray = None
    stderr: np.ndarray = None
    success: bool = True
    nfev: int = 0
    extra: dict = field(default_factory=dict)

    # ------------------------------------------------------------------
    @property
    def npar(self):
        return len(self.params)

    def summary(self):
        names = self.model.param_names
        w = max(len(n) for n in names) + 2
        out = [f"{self.model.name} fitted by objective '{self.objective}' "
               f"(vapour: {self.vapour})"]
        for i, n in enumerate(names):
            if self.stderr is not None and np.isfinite(self.stderr[i]):
                out.append(f"  {n:<{w}}{self.params[i]:+.5f}  "
                           f"+/- {self.stderr[i]:.5f}")
            else:
                out.append(f"  {n:<{w}}{self.params[i]:+.5f}")
        out.append(f"  rms dP  {self.rms_P:.4g} kPa"
                   f"    rms dy  {self.rms_y:.5f}"
                   + (f"    rms dT  {self.rms_T:.4g} K"
                      if np.isfinite(self.rms_T) else ""))
        out.append(f"  AIC {self.aic:.2f}   BIC {self.bic:.2f}")
        return "\n".join(out)

    def __repr__(self):
        p = ", ".join(f"{n}={v:.4f}" for n, v in
                      zip(self.model.param_names, self.params))
        return f"<FitResult {self.model.name} [{p}] rms_y={self.rms_y:.5f}>"


# --------------------------------------------------------------------------
def _predict(model, dat, vapour, k12=0.0):
    """Model prediction of the dependent variable for the dataset's kind."""
    if dat.kind == "isobaric":
        Tc, yc = bubble_T(model, dat.x1, dat.P, dat.c1, dat.c2, vapour, k12)
        Pc = np.full_like(Tc, np.nan)
        Pc = dat.P.copy()
        return Pc, Tc, yc
    Pc, yc = bubble_P(model, dat.x1, dat.T, dat.c1, dat.c2, vapour, k12)
    return Pc, dat.T.copy(), yc


def _residuals(model, dat, objective, vapour, k12=0.0):
    """Residual vector for the chosen objective."""
    if objective == "gamma":
        g1e, g2e = dat.gamma(vapour)
        m = dat.interior() & np.isfinite(g1e) & np.isfinite(g2e) \
            & (g1e > 0) & (g2e > 0)
        lg1, lg2 = model.ln_gamma(dat.x1[m], dat.T[m])
        return np.concatenate([lg1 - np.log(g1e[m]), lg2 - np.log(g2e[m])])

    Pc, Tc, yc = _predict(model, dat, vapour, k12)
    if objective == "P":
        return (Pc - dat.P) / np.mean(dat.P)
    if objective == "T":
        return Tc - dat.T
    if objective == "y":
        return yc - dat.y1
    if objective == "Py":
        s = dat.sigma
        a = (Pc - dat.P) / s["P"]
        b = (yc - dat.y1) / s["y"]
        return np.concatenate([a, b]) / np.sqrt(2)
    raise ValueError(f"unknown objective {objective!r}")


def _mle_residuals(model, dat, vapour, k12=0.0):
    """Errors-in-variables residuals: x is also allowed to be wrong.

    For each measured point the 'true' liquid composition xhat is the one that
    minimises the weighted sum of the residuals in x, P and y at the current
    parameters. Treating x as exact — which every other objective here does —
    puts all of the disagreement into P and y and biases the parameters
    whenever the composition analysis is the weakest measurement, which in a
    student laboratory it usually is.
    """
    s = dat.sigma
    out = []
    for i in range(dat.n):
        Ti = np.array([dat.T[i]])

        def cost(xh, i=i, Ti=Ti):
            xh = float(np.clip(xh, 1e-9, 1 - 1e-9))
            Pc, yc = bubble_P(model, np.array([xh]), Ti,
                              dat.c1, dat.c2, vapour, k12)
            return (((xh - dat.x1[i]) / s["x"]) ** 2
                    + ((Pc[0] - dat.P[i]) / s["P"]) ** 2
                    + ((yc[0] - dat.y1[i]) / s["y"]) ** 2)

        lo = max(1e-9, dat.x1[i] - 20 * s["x"])
        hi = min(1 - 1e-9, dat.x1[i] + 20 * s["x"])
        r = minimize_scalar(cost, bounds=(lo, hi), method="bounded",
                            options={"xatol": 1e-10})
        out.append(np.sqrt(max(r.fun, 0.0)))
    return np.asarray(out)


# --------------------------------------------------------------------------
_START = {
    "margules1": [0.5],
    "margules": [0.5, 0.5],
    "margules3": [0.5, 0.0, 0.0],
    "vanlaar": [0.8, 0.8],
    "wilson": [0.5, 0.5],
    "nrtl": [0.5, 0.5],
    "uniquac": [0.8, 0.8],
}

_BOUNDS = {
    "wilson": ([1e-4, 1e-4], [20.0, 20.0]),
    "vanlaar": ([1e-4, 1e-4], [20.0, 20.0]),
    "uniquac": ([1e-3, 1e-3], [20.0, 20.0]),
}


def fit(dat, model="margules", objective=None, vapour="ideal", k12=0.0,
        p0=None, model_kw=None, bounds=None):
    """Fit one model to one dataset.

    objective defaults to 'P' for isothermal data and 'T' for isobaric data,
    which in both cases is Barker's method: only the measured pressure or
    temperature and the liquid composition enter, and y is left free.
    """
    name = model if isinstance(model, str) else model.__class__.__name__.lower()
    if objective is None:
        objective = "T" if dat.kind == "isobaric" else "P"
    model_kw = dict(model_kw or {})
    if name == "uniquac" and "r1" not in model_kw:
        # r and q are molecular properties, not fitted parameters, so they are
        # taken from the components rather than asked for at the call site.
        for c in (dat.c1, dat.c2):
            if not np.isfinite(c.r) or not np.isfinite(c.q):
                raise ValueError(f"{c.name} has no UNIQUAC r and q; add a "
                                 f"UNIFAC group decomposition in data.GROUPS")
        model_kw.update(r1=dat.c1.r, q1=dat.c1.q, r2=dat.c2.r, q2=dat.c2.q)
    p0 = np.asarray(p0 if p0 is not None else _START[name], dtype=float)
    lo, hi = bounds or _BOUNDS.get(name, (-np.inf, np.inf))

    def resid(p):
        m = build(name, p, **model_kw)
        if objective == "mle":
            return _mle_residuals(m, dat, vapour, k12)
        r = _residuals(m, dat, objective, vapour, k12)
        return np.where(np.isfinite(r), r, 1e3)

    sol = least_squares(resid, p0, bounds=(lo, hi), method="trf",
                        x_scale="jac", ftol=1e-12, xtol=1e-12)
    m = build(name, sol.x, **model_kw)
    Pc, Tc, yc = _predict(m, dat, vapour, k12)

    n, k = len(sol.fun), len(sol.x)
    sse = float(2 * sol.cost)
    dof = max(n - k, 1)
    s2 = sse / dof
    try:
        JtJ = sol.jac.T @ sol.jac
        cov = s2 * np.linalg.inv(JtJ)
        stderr = np.sqrt(np.diag(cov))
    except np.linalg.LinAlgError:
        cov, stderr = None, np.full(k, np.nan)

    good = np.isfinite(yc)
    res = FitResult(
        model=m, params=sol.x, objective=objective, vapour=vapour, data=dat,
        P_calc=Pc, T_calc=Tc, y1_calc=yc,
        rms_P=float(np.sqrt(np.mean((Pc - dat.P) ** 2))),
        rms_T=float(np.sqrt(np.nanmean((Tc - dat.T) ** 2))),
        rms_y=float(np.sqrt(np.mean((yc[good] - dat.y1[good]) ** 2))),
        sse=sse,
        aic=n * np.log(sse / n) + 2 * k,
        bic=n * np.log(sse / n) + k * np.log(n),
        cov=cov, stderr=stderr, success=bool(sol.success), nfev=int(sol.nfev),
        extra={"k12": k12, "model_kw": model_kw, "p0": p0})
    return res


def barker_fit(dat, model="margules", vapour="ideal", **kw):
    """Barker's method by name, for code that wants to say what it is doing."""
    obj = "T" if dat.kind == "isobaric" else "P"
    return fit(dat, model, objective=obj, vapour=vapour, **kw)


# --------------------------------------------------------------------------
def compare_models(dat, models=("margules1", "margules", "vanlaar",
                                "wilson", "nrtl", "uniquac"), **kw):
    """Fit several models to the same data and rank them by AIC.

    AIC rather than the residual alone, because a two-parameter model will
    always fit at least as well as a one-parameter model and the question is
    whether the improvement is worth the parameter. Reporting the raw RMS
    without the penalty is how a three-parameter fit to eight noisy points gets
    published.
    """
    out = []
    for m in models:
        try:
            out.append(fit(dat, m, **kw))
        except Exception as e:                    # a model may not converge
            out.append(e)
    ok = [r for r in out if isinstance(r, FitResult)]
    ok.sort(key=lambda r: r.aic)
    return ok


def compare_objectives(dat, model="margules",
                       objectives=("P", "y", "gamma", "Py"), **kw):
    """The same model fitted against each objective, for the spread."""
    if dat.kind == "isobaric":
        objectives = tuple("T" if o == "P" else o for o in objectives)
    return [fit(dat, model, objective=o, **kw) for o in objectives]


def objective_table(fits, width=80, truth=None):
    """Compare objectives on the residuals, deliberately without AIC.

    AIC is not comparable across objectives: each one minimises a different
    residual vector, in different units and sometimes of different length, so
    the likelihood being approximated is not the same likelihood. Ranking
    objectives by AIC would be a category error, and leaving the column out is
    less misleading than printing it with a footnote nobody reads.
    """
    lines = ["-" * width,
             f"{'objective':<12}{'parameters':<34}{'rms dP':>10}{'rms dy':>10}"
             + (f"{'|err|':>10}" if truth is not None else ""),
             "-" * width]
    for f in fits:
        p = ", ".join(f"{n}={v:+.4f}" for n, v in
                      zip(f.model.param_names, f.params))
        row = f"{f.objective:<12}{p:<34}{f.rms_P:>10.4g}{f.rms_y:>10.5f}"
        if truth is not None:
            row += f"{np.max(np.abs(f.params - np.asarray(truth))):>10.4f}"
        lines.append(row)
    lines.append("-" * width)
    return "\n".join(lines)


def model_table(fits, width=92):
    lines = ["-" * width,
             f"{'model':<14}{'parameters':<34}{'rms dP':>10}{'rms dy':>10}"
             f"{'AIC':>10}{'dAIC':>10}",
             "-" * width]
    a0 = min(f.aic for f in fits)
    for f in fits:
        p = ", ".join(f"{n}={v:+.4f}" for n, v in
                      zip(f.model.param_names, f.params))
        lines.append(f"{f.model.name:<14}{p:<34}{f.rms_P:>10.4g}"
                     f"{f.rms_y:>10.5f}{f.aic:>10.2f}{f.aic - a0:>10.2f}")
    lines.append("-" * width)
    return "\n".join(lines)


# --------------------------------------------------------------------------
def bootstrap(dat, model="margules", n_boot=200, objective=None,
              vapour="ideal", seed=0, **kw):
    """Residual-resampling bootstrap of the parameter distribution.

    The linearised standard errors from the covariance matrix assume the
    objective is quadratic near the optimum and that the residuals are normal.
    For a two-parameter activity model fitted to fifteen points, neither is
    reliable, and the resulting confidence region is often not even an
    ellipse — Wilson and NRTL in particular produce long curved valleys, which
    is the visual form of parameter correlation. Resampling makes the true
    shape visible.
    """
    rng = np.random.default_rng(seed)
    base = fit(dat, model, objective=objective, vapour=vapour, **kw)
    key = "T" if dat.kind == "isobaric" else "P"
    obs = dat.T if key == "T" else dat.P
    pred = base.T_calc if key == "T" else base.P_calc
    resid = obs - pred

    from .data import VLEData
    boots = []
    for _ in range(n_boot):
        rs = rng.choice(resid, size=len(resid), replace=True)
        newobs = pred + rs
        if key == "T":
            d = VLEData(dat.x1, dat.y1, dat.P, newobs, dat.c1, dat.c2,
                        dat.kind, dat.label, dat.source, dict(dat.sigma))
        else:
            d = VLEData(dat.x1, dat.y1, newobs, dat.T, dat.c1, dat.c2,
                        dat.kind, dat.label, dat.source, dict(dat.sigma))
        try:
            boots.append(fit(d, model, objective=objective,
                             vapour=vapour, p0=base.params, **kw).params)
        except Exception:
            continue
    B = np.asarray(boots)
    return {"base": base, "samples": B,
            "mean": B.mean(axis=0), "std": B.std(axis=0, ddof=1),
            "ci95": np.percentile(B, [2.5, 97.5], axis=0),
            "corr": np.corrcoef(B.T) if B.shape[1] > 1 else np.array([[1.0]])}


# --------------------------------------------------------------------------
def generate(model, x1, T=None, P=None, c1=None, c2=None, kind="isothermal",
             vapour="ideal", noise=None, seed=0, label="", sigma=None):
    """Synthesise a dataset from a known model. The ground truth for tests.

    Data produced here satisfy Gibbs-Duhem by construction, so every
    consistency test must pass on them. Adding a *bias* — as opposed to
    scatter — to y is how a dataset that should fail is manufactured, and
    comparing the two is the cleanest demonstration of what each test can and
    cannot see.

    noise['y_bias'] may be a number, in which case the bias applied to y is
    c x1 x2, or a callable f(x1, y1) returning the bias directly. The callable
    form matters: `odd_bias` below builds the one error the area test cannot
    detect, and constructing it deliberately is more convincing than being told
    that such errors exist.
    """
    from .data import VLEData

    rng = np.random.default_rng(seed)
    x1 = np.asarray(x1, dtype=float)
    if kind == "isothermal":
        Tarr = np.full_like(x1, float(T))
        Parr, y1 = bubble_P(model, x1, Tarr, c1, c2, vapour)
    else:
        Parr = np.full_like(x1, float(P))
        Tarr, y1 = bubble_T(model, x1, Parr, c1, c2, vapour)

    if noise:
        Parr = Parr + rng.normal(0, noise.get("P", 0.0), x1.shape)
        Tarr = Tarr + rng.normal(0, noise.get("T", 0.0), x1.shape)
        y1 = y1 + rng.normal(0, noise.get("y", 0.0), x1.shape)
        x1 = x1 + rng.normal(0, noise.get("x", 0.0), x1.shape)
        b = noise.get("y_bias")                   # a deliberate inconsistency
        if callable(b):
            y1 = y1 + b(x1, y1)
        elif b:
            y1 = y1 + b * x1 * (1 - x1)
        y1 = np.clip(y1, 1e-9, 1 - 1e-9)
        x1 = np.clip(x1, 1e-9, 1 - 1e-9)

    return VLEData(x1, y1, Parr, Tarr, c1, c2, kind=kind, label=label,
                   source="synthetic",
                   sigma=sigma or {"x": 1e-3, "y": 2e-3, "P": 0.05, "T": 0.05})


def odd_bias(eps):
    """The error the area test is structurally unable to detect.

    Perturbing y1 changes the measured ratio by

        d ln(g1/g2) = dy1 / [ y1 (1 - y1) ]

    so choosing dy1 = eps y1 (1 - y1) (2 x1 - 1) shifts ln(g1/g2) by
    eps (2 x1 - 1), which is odd about x1 = 1/2 and therefore contributes
    exactly nothing to the Redlich-Kister area integral. The dataset is
    thermodynamically wrong and the area test says it is fine. The point and
    direct tests, which never integrate, see it immediately.
    """
    return lambda x1, y1: eps * y1 * (1 - y1) * (2 * x1 - 1)
