"""Multicomponent activity models, and the stability question.

Everything before this module is binary, because binary VLE is what gets
measured and what gets tested for consistency. Stability is different: the
interesting failures are ternary, and a two-component picture makes the tangent
*plane* look like a tangent *line*, which is exactly the intuition that has to
be generalised.

The central routine is `tpd`. A flash calculation solves the equilibrium
equations, and those equations have solutions that are not the global minimum
of the Gibbs energy. A converged flash can be confidently wrong. The tangent
plane distance is the test that catches it, and it is the reason a modern
flowsheet package runs a stability analysis *before* the flash rather than
after.
"""
from __future__ import annotations

import numpy as np
from scipy.optimize import minimize

R = 8.314462618
Z_LATTICE = 10.0


# ==========================================================================
# Models
# ==========================================================================
class MultiModel:
    """Base class for an N-component excess Gibbs energy model."""

    name = "base"

    def __init__(self, n):
        self.n = int(n)

    def ln_gamma(self, x):
        raise NotImplementedError

    def gamma(self, x):
        return np.exp(self.ln_gamma(x))

    def gE_RT(self, x):
        x = np.asarray(x, dtype=float)
        return float(np.dot(x, self.ln_gamma(x)))

    # ------------------------------------------------------------ checks
    def check_gibbs_duhem(self, x=None, h=1e-6):
        """Sum_i x_i d(ln gamma_i) = 0 along any composition path.

        Verified here as a directional derivative along a random but fixed
        direction in the composition simplex, which is the multicomponent form
        of the binary check in `models.py`. A non-zero result is a bug in the
        model, not a property of the mixture.
        """
        rng = np.random.default_rng(0)
        x = np.full(self.n, 1.0 / self.n) if x is None else np.asarray(x, float)
        worst = 0.0
        for _ in range(20):
            d = rng.normal(size=self.n)
            d -= d.mean()                       # stay on the simplex
            d /= np.linalg.norm(d)
            lp = self.ln_gamma(x + h * d)
            lm = self.ln_gamma(x - h * d)
            worst = max(worst, abs(float(np.dot(x, (lp - lm) / (2 * h)))))
        return worst

    def check_pure_limit(self, eps=1e-9):
        """gamma_i -> 1 when the mixture is pure i."""
        worst = 0.0
        for i in range(self.n):
            x = np.full(self.n, eps)
            x[i] = 1 - eps * (self.n - 1)
            worst = max(worst, abs(float(self.gamma(x)[i]) - 1.0))
        return worst


class NRTLMulti(MultiModel):
    """N-component NRTL.

        ln g_i = sum_j tau_ji G_ji x_j / sum_k G_ki x_k
               + sum_j [ x_j G_ij / sum_k G_kj x_k ]
                 * [ tau_ij - sum_m x_m tau_mj G_mj / sum_k G_kj x_k ]

    tau is an n x n matrix with zero diagonal; alpha is symmetric with zero
    diagonal, conventionally 0.3 for a fully miscible pair and 0.2 for a pair
    that splits. The binary parameters are exactly those fitted in Module 4 —
    a ternary NRTL calculation uses no ternary parameters at all, which is the
    property that makes the model worth its awkwardness.
    """

    name = "NRTL"

    def __init__(self, tau, alpha=0.3):
        tau = np.asarray(tau, dtype=float)
        super().__init__(tau.shape[0])
        if tau.shape != (self.n, self.n):
            raise ValueError("tau must be square")
        self.tau = tau.copy()
        np.fill_diagonal(self.tau, 0.0)
        a = np.full((self.n, self.n), float(alpha)) if np.isscalar(alpha) \
            else np.asarray(alpha, dtype=float)
        self.alpha = a.copy()
        np.fill_diagonal(self.alpha, 0.0)
        if not np.allclose(self.alpha, self.alpha.T):
            raise ValueError("alpha must be symmetric")
        self.G = np.exp(-self.alpha * self.tau)

    def ln_gamma(self, x):
        x = np.asarray(x, dtype=float)
        x = np.clip(x, 1e-300, None)
        G, t = self.G, self.tau
        den = G.T @ x                       # den[k] = sum_m G_mk x_m
        num = (G * t).T @ x                 # num[k] = sum_m G_mk t_mk x_m
        s = num / den                       # s[k]
        first = s                           # first[i] uses k = i
        second = np.array([
            np.sum(x * G[i, :] / den * (t[i, :] - s)) for i in range(self.n)])
        return first + second


class UNIQUACMulti(MultiModel):
    """N-component UNIQUAC. r and q are molecular, not fitted."""

    name = "UNIQUAC"

    def __init__(self, tau, r, q, z=Z_LATTICE):
        tau = np.asarray(tau, dtype=float)
        super().__init__(tau.shape[0])
        self.tau = tau.copy()
        np.fill_diagonal(self.tau, 1.0)     # tau_ii = 1 by definition
        self.r = np.asarray(r, dtype=float)
        self.q = np.asarray(q, dtype=float)
        self.z = float(z)
        self.l = (self.z / 2) * (self.r - self.q) - (self.r - 1)

    def ln_gamma(self, x):
        x = np.clip(np.asarray(x, dtype=float), 1e-300, None)
        phi = self.r * x / np.dot(self.r, x)
        th = self.q * x / np.dot(self.q, x)
        comb = (np.log(phi / x) + (self.z / 2) * self.q * np.log(th / phi)
                + self.l - (phi / x) * np.dot(x, self.l))
        s = th @ self.tau                    # s[j] = sum_i th_i tau_ij
        # Written as an explicit loop rather than compressed into matrix
        # products: the index order of tau is the single easiest thing to get
        # wrong in this model, and a reader has to be able to check it against
        # the printed equation without unpacking an einsum.
        res = np.empty(self.n)
        for i in range(self.n):
            a = np.dot(th, self.tau[:, i])          # sum_j th_j tau_ji
            b = np.sum(th * self.tau[i, :] / s)     # sum_j th_j tau_ij / s_j
            res[i] = self.q[i] * (1.0 - np.log(a) - b)
        return comb + res


# ==========================================================================
# Gibbs energy of mixing
# ==========================================================================
def g_mix(model, x):
    """Delta g_mix / RT = sum_i x_i ln x_i + G^E/RT."""
    x = np.clip(np.asarray(x, dtype=float), 1e-300, None)
    return float(np.dot(x, np.log(x))) + model.gE_RT(x)


def mu_over_RT(model, x):
    """The intercepts the tangent plane is built from: ln x_i + ln gamma_i."""
    x = np.clip(np.asarray(x, dtype=float), 1e-300, None)
    return np.log(x) + model.ln_gamma(x)


# ==========================================================================
# Tangent plane distance (Michelsen)
# ==========================================================================
def tpd(model, z, w):
    """Tangent plane distance of a trial phase w against a feed z.

        TPD(w) = sum_i w_i [ ln w_i + ln gamma_i(w)
                             - ln z_i - ln gamma_i(z) ]

    Geometrically: the vertical distance from the Gibbs energy surface at w
    down to the plane tangent to that surface at z. The feed is stable if and
    only if this is non-negative for **every** trial composition — one negative
    value anywhere is a proof of instability, and it also points at the phase
    that will form.
    """
    z = np.clip(np.asarray(z, dtype=float), 1e-300, None)
    w = np.clip(np.asarray(w, dtype=float), 1e-300, None)
    return float(np.dot(w, mu_over_RT(model, w) - mu_over_RT(model, z)))


def _initial_estimates(model, z, extra=()):
    """Trial phases to start the minimisation from.

    Michelsen's recommendation: one estimate near each pure component, plus the
    feed perturbed toward each vertex. Starting from the feed itself converges
    to the trivial solution w = z, where TPD is exactly zero and tells you
    nothing — so the feed is deliberately not in this list.
    """
    n = model.n
    out = []
    for i in range(n):
        w = np.full(n, 0.01 / max(n - 1, 1))
        w[i] = 0.99
        out.append(w)
        out.append(0.5 * z + 0.5 * w)
    out.extend(np.asarray(e, dtype=float) for e in extra)
    return [w / w.sum() for w in out]


def stability(model, z, extra_starts=(), tol=-1e-8):
    """Is the feed z a single stable phase?

    Minimises the tangent plane distance from several starting points and
    reports the most negative value found. Returns a dict with `stable`, the
    minimum TPD, and the trial composition that achieved it — which is the
    useful output, because it is the composition of the phase that will appear.

    The minimisation is over the unconstrained variables
    `alpha_i = 2 sqrt(w_i)`, a standard change of variable that removes the
    positivity constraint and conditions the problem near the vertices, where
    an unstable feed's answer usually lives.
    """
    z = np.asarray(z, dtype=float) / np.sum(z)
    muz = mu_over_RT(model, z)

    def f(a):
        w = np.clip(a, 0, None) ** 2
        s = w.sum()
        if s <= 0:
            return 1.0
        w = w / s
        return float(np.dot(w, mu_over_RT(model, w) - muz))

    best, best_w = np.inf, None
    for w0 in _initial_estimates(model, z, extra_starts):
        r = minimize(f, 2 * np.sqrt(w0), method="Nelder-Mead",
                     options={"xatol": 1e-10, "fatol": 1e-12, "maxiter": 4000})
        w = np.clip(r.x, 0, None) ** 2
        if w.sum() <= 0:
            continue
        w = w / w.sum()
        # discard the trivial solution: it is a stationary point of TPD for
        # every feed, and it certifies nothing
        if np.max(np.abs(w - z)) < 1e-4:
            continue
        val = tpd(model, z, w)
        if val < best:
            best, best_w = val, w
    if best_w is None:
        best, best_w = 0.0, z.copy()
    return {"stable": best > tol, "tpd_min": best, "w": best_w, "z": z}


def tpd_curve(model, z, i=0, j=1, n=401, rest=None):
    """TPD along a line in composition space, for the figure.

    For a binary this is the whole story. For a ternary it is a slice, and the
    slice is chosen by naming which two components vary.
    """
    z = np.asarray(z, dtype=float)
    ts = np.linspace(1e-4, 1 - 1e-4, n)
    out = np.empty(n)
    for k, t in enumerate(ts):
        w = np.zeros(model.n)
        if rest is None:
            w[i], w[j] = t, 1 - t
        else:
            w[:] = rest
            free = 1.0 - np.sum(rest) + rest[i] + rest[j]
            w[i], w[j] = t * free, (1 - t) * free
        out[k] = tpd(model, z, w / w.sum())
    return ts, out


# ==========================================================================
# Liquid-liquid equilibrium
# ==========================================================================
def lle_flash(model, z, K0=None, tol=1e-11, itmax=2000):
    """Two-liquid flash by successive substitution on K_i = gamma_i^I / gamma_i^II.

    Returns (beta, xI, xII, ok) with beta the fraction in phase I. Successive
    substitution is slow near the plait point and is used anyway because every
    step is one line and a student can follow it; a production code would
    switch to a second-order method once the residual is small.

    `ok` is False when the iteration collapses onto the trivial solution
    xI = xII, which is what happens for a feed that does not split — so the
    honest use of this routine is after a stability test, never instead of one.
    """
    z = np.asarray(z, dtype=float) / np.sum(z)
    n = model.n
    if K0 is None:
        st = stability(model, z)
        if st["stable"]:
            return 0.0, z.copy(), z.copy(), False
        w = st["w"]
        K = np.clip(w / z, 1e-8, 1e8)
    else:
        K = np.asarray(K0, dtype=float)

    beta = 0.5
    for _ in range(itmax):
        # Rachford-Rice for the phase split at the current K
        def g(b):
            return float(np.sum(z * (K - 1) / (1 + b * (K - 1))))

        lo, hi = 0.0, 1.0
        if g(0.0) < 0:
            beta = 0.0
        elif g(1.0) > 0:
            beta = 1.0
        else:
            for _ in range(80):
                mid = 0.5 * (lo + hi)
                if g(mid) > 0:
                    lo = mid
                else:
                    hi = mid
            beta = 0.5 * (lo + hi)
        xII = z / (1 + beta * (K - 1))
        xI = K * xII
        xI = xI / xI.sum()
        xII = xII / xII.sum()
        Kn = np.exp(model.ln_gamma(xII) - model.ln_gamma(xI))
        if np.max(np.abs(Kn - K)) < tol:
            K = Kn
            break
        K = Kn
    ok = np.max(np.abs(xI - xII)) > 1e-4 and 0.0 < beta < 1.0
    return beta, xI, xII, ok


def tie_lines(model, feeds, rich_in=0):
    """LLE tie lines for a list of overall compositions.

    Feeds that do not split are dropped rather than returned as degenerate
    lines, and the count of dropped feeds is returned so that a caller plotting
    a ternary diagram knows how much of the grid was outside the dome.

    The two phases are labelled consistently — phase I is always the one richer
    in component `rich_in`. The flash has no reason to prefer either ordering
    and will swap them from one feed to the next, which draws a ternary diagram
    whose binodal appears to cross itself.
    """
    lines, dropped = [], 0
    for z in feeds:
        beta, xI, xII, ok = lle_flash(model, np.asarray(z, dtype=float))
        if not ok:
            dropped += 1
            continue
        if xI[rich_in] < xII[rich_in]:
            xI, xII, beta = xII, xI, 1.0 - beta
        lines.append({"z": np.asarray(z, dtype=float), "beta": beta,
                      "xI": xI, "xII": xII})
    return lines, dropped


def binodal_from_tielines(lines):
    """The two ends of every tie line, which trace the binodal curve."""
    if not lines:
        return np.zeros((0, 0)), np.zeros((0, 0))
    a = np.array([l["xI"] for l in lines])
    b = np.array([l["xII"] for l in lines])
    return a, b


def plait_point(lines, use=4):
    """Plait-point estimate by extrapolating tie-line length to zero.

    The plait point is where the two conjugate phases become identical, so the
    tie-line length goes to zero there. Taking the shortest line and calling
    its midpoint the plait point is wrong by however far the grid stopped short
    of the dome's top; extrapolating the midpoint against the length, linearly,
    to length zero is a defensible estimate from the same data.

    Returned as (composition, shortest length actually computed) so the caller
    can report how far the extrapolation reached. It is an estimate, and a
    figure using it should say so.
    """
    if len(lines) < 3:
        return None
    L = np.array([np.linalg.norm(l["xI"] - l["xII"]) for l in lines])
    mid = np.array([0.5 * (l["xI"] + l["xII"]) for l in lines])
    k = np.argsort(L)[:max(3, min(use, len(lines)))]
    pp = np.array([np.polyval(np.polyfit(L[k], mid[k, i], 1), 0.0)
                   for i in range(mid.shape[1])])
    pp = np.clip(pp, 0.0, None)
    return pp / pp.sum(), float(L[k].min())


# ==========================================================================
# Residue curves
# ==========================================================================
def residue_curve(model, comps, x0, T=None, P=101.325, steps=4000, dxi=2.5e-3,
                  forward=True):
    """Integrate  dx_i/d(xi) = x_i - y_i  for simple open evaporation.

    The residue curve is the composition path of the liquid left behind as a
    batch boils away. Its fixed points are the pure components and the
    azeotropes, and the separatrices joining them are the distillation
    boundaries that a simple column cannot cross.

    Integrated with an explicit midpoint step, which is enough because the
    field is smooth away from the fixed points, and the fixed points are
    exactly where the integration should stop anyway.
    """
    from .regress import bubble_T

    n = model.n
    x = np.asarray(x0, dtype=float).copy()
    x = np.clip(x, 1e-12, None)
    x /= x.sum()
    sgn = 1.0 if forward else -1.0
    path = [x.copy()]
    Ts = []

    Tlo = min(c.Tsat(P) for c in comps) - 60.0
    Thi = max(c.Tsat(P) for c in comps) + 60.0
    warm = [None]                      # bubble T from the previous step

    def vapour(xv):
        """Bubble-point vapour composition at fixed P by modified Raoult.

        The bracket is warm-started from the previous integration step: along a
        residue curve the temperature moves by a fraction of a kelvin per step,
        so a +/- 4 K window almost always contains the root and the bisection
        needs a third of the iterations. The full-range bracket is retained as
        the fallback, because near a fixed point the composition — and with it
        the temperature — can move faster than the window allows.
        """
        xv = np.clip(xv, 1e-12, None)
        xv = xv / xv.sum()
        g = model.gamma(xv)

        def resid(T):
            return float(np.sum(xv * g * np.array([c.Psat(T) for c in comps]))) - P

        lo, hi = Tlo, Thi
        if warm[0] is not None:
            a, b = warm[0] - 4.0, warm[0] + 4.0
            if resid(a) * resid(b) < 0:
                lo, hi = a, b
        for _ in range(48):
            mid = 0.5 * (lo + hi)
            if resid(mid) < 0:
                lo = mid
            else:
                hi = mid
        Tb = 0.5 * (lo + hi)
        warm[0] = Tb
        Ps = np.array([c.Psat(Tb) for c in comps])
        y = xv * g * Ps / P
        return y / y.sum(), Tb

    for _ in range(steps):
        y, Tb = vapour(x)
        Ts.append(Tb)
        d1 = sgn * (x - y)
        if np.max(np.abs(d1)) < 1e-7:            # a fixed point
            break
        xm = np.clip(x + 0.5 * dxi * d1, 1e-12, None)
        xm /= xm.sum()
        ym, _ = vapour(xm)
        d2 = sgn * (xm - ym)
        x = np.clip(x + dxi * d2, 1e-12, None)
        x /= x.sum()
        path.append(x.copy())
        if np.max(x) > 1 - 1e-6:
            break
    return np.array(path), np.array(Ts)


def fixed_points(model, comps, P=101.325, grid=41, tol=1e-6):
    """Pure components and binary azeotropes, which are the nodes of the map.

    Ternary azeotropes are not searched for here: finding them reliably needs a
    homotopy method, and stating that limitation is better than returning a
    list that quietly misses one.
    """
    from .flash import azeotrope

    n = model.n
    out = [{"x": np.eye(n)[i], "kind": "pure", "which": (i,)} for i in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            xs = np.linspace(1e-4, 1 - 1e-4, grid)
            prev = None
            for t in xs:
                x = np.zeros(n)
                x[i], x[j] = t, 1 - t
                g = model.gamma(x)
                Tb = _bubble_T_multi(model, comps, x, P)
                Ps = np.array([c.Psat(Tb) for c in comps])
                f = np.log(g[i] * Ps[i]) - np.log(g[j] * Ps[j])
                if prev is not None and prev[1] * f < 0:
                    lo, hi = prev[0], t
                    for _ in range(60):
                        mid = 0.5 * (lo + hi)
                        xm = np.zeros(n)
                        xm[i], xm[j] = mid, 1 - mid
                        gm = model.gamma(xm)
                        Tm = _bubble_T_multi(model, comps, xm, P)
                        Pm = np.array([c.Psat(Tm) for c in comps])
                        fm = np.log(gm[i] * Pm[i]) - np.log(gm[j] * Pm[j])
                        if fm * prev[1] > 0:
                            lo = mid
                        else:
                            hi = mid
                    xa = np.zeros(n)
                    xa[i], xa[j] = 0.5 * (lo + hi), 1 - 0.5 * (lo + hi)
                    out.append({"x": xa, "kind": "binary azeotrope",
                                "which": (i, j),
                                "T": _bubble_T_multi(model, comps, xa, P)})
                prev = (t, f)
    for o in out:
        if "T" not in o:
            o["T"] = _bubble_T_multi(model, comps, o["x"], P)
    return out


def _bubble_T_multi(model, comps, x, P):
    x = np.clip(np.asarray(x, dtype=float), 1e-12, None)
    x = x / x.sum()
    g = model.gamma(x)
    lo = min(c.Tsat(P) for c in comps) - 60.0
    hi = max(c.Tsat(P) for c in comps) + 60.0
    for _ in range(90):
        mid = 0.5 * (lo + hi)
        Pc = float(np.sum(x * g * np.array([c.Psat(mid) for c in comps])))
        if Pc < P:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


# ==========================================================================
# Ternary plotting helpers
# ==========================================================================
def to_xy(x):
    """Barycentric to Cartesian, with component 1 at the left vertex.

    Vertices: 1 at (0,0), 2 at (1,0), 3 at (0.5, sqrt(3)/2).
    """
    x = np.atleast_2d(np.asarray(x, dtype=float))
    a, b, c = x[:, 0], x[:, 1], x[:, 2]
    return np.column_stack([b + 0.5 * c, (np.sqrt(3) / 2) * c])
