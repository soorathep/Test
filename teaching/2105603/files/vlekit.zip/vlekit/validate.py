"""Does the fit describe the system, or the noise?

Two questions that a residual sum of squares cannot answer.

The first is whether the model has learned anything transferable. Fitting and
reporting the residual on the same points is not evidence: with enough
parameters the residual goes to zero and the model has learned the scatter.
Holding out part of the composition range and predicting it is evidence.

The second is what the parameters imply *outside* the data. Two parameter sets
that are statistically indistinguishable over the measured range can disagree
completely about the infinite-dilution activity coefficients, about whether the
system has an azeotrope, and about whether the liquid splits into two phases.
That is not a defect of the fitting; it is what it means for data to be silent
about a region. The job of this module is to make the silence audible.
"""
from __future__ import annotations

import numpy as np

from .data import VLEData
from .regress import fit, bubble_P


# --------------------------------------------------------------------------
def _subset(dat, mask):
    return VLEData(dat.x1[mask], dat.y1[mask], dat.P[mask], dat.T[mask],
                   dat.c1, dat.c2, dat.kind, dat.label, dat.source,
                   dict(dat.sigma))


def split_mask(dat, how="middle", frac=0.5):
    """Boolean mask of the *training* points.

    how='middle'  train on the middle of the composition range, predict the
                  dilute ends — the hardest and most useful test, because the
                  ends are where models differ most and where the dilute-region
                  behaviour a designer needs actually lives
    how='ends'    the reverse
    how='half'    train on x1 < 0.5
    how='even'    train on every other point, which tests almost nothing and is
                  included so that students can see it tests almost nothing
    """
    x = dat.x1
    if how == "middle":
        lo, hi = np.quantile(x, [(1 - frac) / 2, 1 - (1 - frac) / 2])
        return (x >= lo) & (x <= hi)
    if how == "ends":
        lo, hi = np.quantile(x, [(1 - frac) / 2, 1 - (1 - frac) / 2])
        return (x < lo) | (x > hi)
    if how == "half":
        return x < 0.5
    if how == "even":
        return np.arange(len(x)) % 2 == 0
    raise ValueError(f"unknown split {how!r}")


def cross_validate(dat, model="nrtl", how="middle", frac=0.5, **kw):
    """Fit on part of the composition range, predict the rest.

    Returns the fit, the held-out residuals, and the two RMS values. The
    comparison that matters is train against test: a model that fits the
    training points three times better than it predicts the held-out ones has
    learned the noise, and no amount of AIC on the training set would have said
    so.
    """
    m = split_mask(dat, how, frac)
    if m.sum() < 4 or (~m).sum() < 2:
        raise ValueError("split leaves too few points on one side")
    train, test = _subset(dat, m), _subset(dat, ~m)
    f = fit(train, model, **kw)
    Pt, yt = bubble_P(f.model, test.x1, test.T, test.c1, test.c2, f.vapour)
    return {
        "fit": f, "train": train, "test": test, "mask": m,
        "rms_P_train": f.rms_P, "rms_y_train": f.rms_y,
        "rms_P_test": float(np.sqrt(np.mean((Pt - test.P) ** 2))),
        "rms_y_test": float(np.sqrt(np.mean((yt - test.y1) ** 2))),
        "dP_test": Pt - test.P, "dy_test": yt - test.y1,
    }


def cross_validation_table(results, width=80):
    lines = ["-" * width,
             f"{'model':<14}{'split':<10}{'rms dP tr':>12}{'rms dP te':>12}"
             f"{'rms dy tr':>12}{'rms dy te':>12}{'ratio':>8}",
             "-" * width]
    for r in results:
        ratio = r["rms_y_test"] / r["rms_y_train"] if r["rms_y_train"] > 0 else np.inf
        lines.append(f"{r['fit'].model.name:<14}{r.get('how', ''):<10}"
                     f"{r['rms_P_train']:>12.4g}{r['rms_P_test']:>12.4g}"
                     f"{r['rms_y_train']:>12.5f}{r['rms_y_test']:>12.5f}"
                     f"{ratio:>8.2f}")
    lines.append("-" * width)
    return "\n".join(lines)


# --------------------------------------------------------------------------
def implications(model, T, c1, c2):
    """What a parameter set claims about regions the data may not cover.

    Four claims, each of which a designer might act on:
        gamma1_inf, gamma2_inf   sizing a stripper or judging a trace impurity
        azeotrope                whether ordinary distillation can reach purity
        liquid-liquid split      whether the column will throw a second phase
        maximum |G^E/RT|         a crude measure of how hard the system is
    """
    from .flash import azeotrope, miscibility_gap

    lg1, lg2 = model.ln_gamma(np.array([1e-8, 1 - 1e-8]), T)
    az = azeotrope(model, T, c1, c2)
    gap = miscibility_gap(model, T)
    x = np.linspace(1e-3, 1 - 1e-3, 501)
    return {
        "gamma1_inf": float(np.exp(lg1[0])),
        "gamma2_inf": float(np.exp(lg2[1])),
        "azeotrope_x1": None if az is None else az["x1"],
        "azeotrope_P": None if az is None else az["P"],
        "liquid_split": gap is not None,
        "split_range": None if gap is None else
                       (gap["x1_phase_a"], gap["x1_phase_b"]),
        "max_gE_RT": float(np.max(np.abs(model.gE_RT(x, T)))),
    }


def implications_table(named_models, T, c1, c2, width=92):
    """Side-by-side implications of several fits. The divergence is the message."""
    rows = [(n, implications(m, T, c1, c2)) for n, m in named_models]
    lines = ["-" * width,
             f"{'fit':<22}{'g1_inf':>10}{'g2_inf':>10}{'azeo x1':>10}"
             f"{'azeo P':>10}{'LL split':>11}{'split range':>19}",
             "-" * width]
    for n, r in rows:
        az = "-" if r["azeotrope_x1"] is None else f"{r['azeotrope_x1']:.3f}"
        ap = "-" if r["azeotrope_P"] is None else f"{r['azeotrope_P']:.2f}"
        sr = "-" if r["split_range"] is None else \
             f"{r['split_range'][0]:.3f}-{r['split_range'][1]:.3f}"
        lines.append(f"{n:<22}{r['gamma1_inf']:>10.3f}{r['gamma2_inf']:>10.3f}"
                     f"{az:>10}{ap:>10}{str(r['liquid_split']):>11}{sr:>19}")
    lines.append("-" * width)
    return "\n".join(lines)


# --------------------------------------------------------------------------
def indistinguishable_pair(dat, models=("nrtl", "wilson", "vanlaar",
                                        "margules", "uniquac"), tol=0.15, **kw):
    """Find fits that the data cannot tell apart, then compare their claims.

    'Cannot tell apart' is defined as within `tol` (relative) of the best rms in
    y — a deliberately loose criterion, because the point is that the data are
    not deciding between them. Returns the qualifying fits together with the
    implications table, which is where they stop agreeing.
    """
    fits = []
    for m in models:
        try:
            fits.append(fit(dat, m, **kw))
        except Exception:
            continue
    if not fits:
        return {"fits": [], "table": ""}
    best = min(f.rms_y for f in fits)
    keep = [f for f in fits if f.rms_y <= best * (1 + tol)]
    named = [(f"{f.model.name} (rms dy {f.rms_y:.5f})", f.model) for f in keep]
    return {"fits": keep,
            "table": implications_table(named, float(np.mean(dat.T)),
                                        dat.c1, dat.c2)}


# --------------------------------------------------------------------------
def domain_statement(fit_result, dat, unifac_rows=None):
    """The sentence a regression report must end with, assembled from the fit.

    The blueprint for this module says the deliverable of a regression is not a
    parameter set but a parameter set plus a statement of where it may be used.
    This builds a draft of that statement from what was actually done, so that
    a student who omits it has to delete it on purpose.
    """
    T = float(np.mean(dat.T))
    xr = (float(np.min(dat.x1)), float(np.max(dat.x1)))
    Pr = (float(np.min(dat.P)), float(np.max(dat.P)))
    imp = implications(fit_result.model, T, dat.c1, dat.c2)
    p = ", ".join(f"{n} = {v:+.4f}" for n, v in
                  zip(fit_result.model.param_names, fit_result.params))
    lines = [
        f"Model      {fit_result.model.name} with {p}",
        f"Fitted to  {dat.label or 'this dataset'} "
        f"({dat.n} points, {dat.kind})",
        f"Objective  '{fit_result.objective}', vapour phase treated as "
        f"'{fit_result.vapour}'",
        f"Valid over x1 = {xr[0]:.3f} to {xr[1]:.3f} at T = {T:.2f} K, "
        f"P = {Pr[0]:.2f} to {Pr[1]:.2f} kPa",
        f"Residuals  rms dP = {fit_result.rms_P:.4g} kPa, "
        f"rms dy = {fit_result.rms_y:.5f}",
    ]
    if fit_result.stderr is not None and np.all(np.isfinite(fit_result.stderr)):
        se = ", ".join(f"{n} +/- {s:.4f}" for n, s in
                       zip(fit_result.model.param_names, fit_result.stderr))
        lines.append(f"Uncertainty {se} (linearised; see the bootstrap for the "
                     f"correlation)")
    lines.append(
        f"Implies    gamma1_inf = {imp['gamma1_inf']:.3f}, "
        f"gamma2_inf = {imp['gamma2_inf']:.3f}, "
        + ("azeotrope at x1 = %.3f" % imp["azeotrope_x1"]
           if imp["azeotrope_x1"] is not None else "no azeotrope")
        + (", predicts a liquid-liquid split at x1 = %.3f-%.3f"
           % imp["split_range"] if imp["liquid_split"] else ""))
    caveats = []
    if xr[0] > 0.02:
        caveats.append(f"no data below x1 = {xr[0]:.3f}, so gamma1_inf is an "
                       f"extrapolation")
    if xr[1] < 0.98:
        caveats.append(f"no data above x1 = {xr[1]:.3f}, so gamma2_inf is an "
                       f"extrapolation")
    if imp["liquid_split"]:
        caveats.append("the predicted liquid-liquid split is outside anything "
                       "the VLE data can confirm and must be checked against "
                       "LLE measurements before it is believed")
    if dat.kind == "isothermal":
        caveats.append("parameters are for one temperature only; using them at "
                       "another temperature assumes G^E is independent of T")
    if unifac_rows:
        fitted = [r for r in unifac_rows if "fitted" in r[0]]
        pred = [r for r in unifac_rows if "UNIFAC" in r[0]]
        if fitted and pred:
            gain = pred[0][1] / max(fitted[0][1], 1e-12)
            caveats.append(f"UNIFAC, with nothing fitted, gives rms dy "
                           f"{pred[0][1]:.5f} against {fitted[0][1]:.5f} here "
                           f"— a factor of {gain:.1f}")
    if caveats:
        lines.append("Caveats")
        lines += [f"  - {c}" for c in caveats]
    return "\n".join(lines)
