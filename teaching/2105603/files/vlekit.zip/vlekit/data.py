"""Pure-component properties, VLE datasets, and gamma from raw measurements.

The step this module performs is the one students most often skip: a reported
gamma is not a measurement. What is measured is T, P, x and y. Turning those
four numbers into an activity coefficient requires a vapour pressure
correlation and a decision about the vapour phase, and every subsequent
conclusion inherits the error in both. Everything here is therefore explicit
about which assumption produced a given number.

    gamma_i = y_i Phi_i P / (x_i Psat_i)

with the correction factor

    Phi_i = phi_i / (phi_i^sat) * exp( -v_i^L (P - Psat_i) / RT )

Setting vapour='ideal' makes Phi_i = 1 and recovers modified Raoult's law.
Setting vapour='virial' evaluates phi from the two-term virial equation with
Pitzer-Tsonopoulos second virial coefficients and includes the Poynting factor.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

R = 8.314462618          # J / mol / K


# --------------------------------------------------------------------------
# Pure components
# --------------------------------------------------------------------------
@dataclass
class Component:
    """One pure component.

    Antoine is stored in the form  log10(Psat / kPa) = A - B / (T/K + C).
    Coefficients published in mmHg or with T in Celsius must be converted
    before they get here; `Component.from_antoine` does that conversion so the
    provenance of a number is visible at the call site rather than buried.
    """

    name: str
    A: float                       # Antoine, log10(kPa), T in K
    B: float
    C: float
    Tc: float = np.nan             # K
    Pc: float = np.nan             # kPa
    omega: float = np.nan
    vL: float = np.nan             # liquid molar volume, m^3/mol
    Trange: tuple = (np.nan, np.nan)
    source: str = ""
    groups: dict = field(default_factory=dict)   # UNIFAC subgroup -> count
    r: float = np.nan              # UNIQUAC volume parameter
    q: float = np.nan              # UNIQUAC surface parameter

    # ---------------------------------------------------------------- ctor
    @classmethod
    def from_antoine(cls, name, A, B, C, *, punit="kPa", tunit="K", **kw):
        """Build a component from Antoine coefficients in any common unit set.

        punit  'kPa' | 'bar' | 'mmHg' | 'Pa'
        tunit  'K' | 'C'
        """
        shift = {"kPa": 0.0,
                 "bar": np.log10(100.0),
                 "Pa": -3.0,
                 "mmHg": np.log10(101.325 / 760.0)}
        if punit not in shift:
            raise ValueError(f"unknown pressure unit {punit!r}")
        A = A + shift[punit]
        if tunit.upper() == "C":
            C = C - 273.15
        elif tunit.upper() != "K":
            raise ValueError(f"unknown temperature unit {tunit!r}")
        return cls(name=name, A=A, B=B, C=C, **kw)

    @classmethod
    def from_antoine_ln(cls, name, A, B, C, **kw):
        """Antoine in the natural-log form ln(Psat/kPa) = A - B/(T/K + C).

        This is the form tabulated in Smith, Van Ness & Abbott, so it is worth
        supporting directly rather than asking every caller to divide by ln 10
        and get it wrong once.
        """
        return cls(name=name, A=A / np.log(10.0), B=B / np.log(10.0), C=C, **kw)

    # ---------------------------------------------------------------- Psat
    def Psat(self, T):
        """Saturation pressure in kPa. T in K."""
        T = np.asarray(T, dtype=float)
        return 10.0 ** (self.A - self.B / (T + self.C))

    def Tsat(self, P):
        """Saturation temperature in K for P in kPa. Antoine inverted."""
        P = np.asarray(P, dtype=float)
        return self.B / (self.A - np.log10(P)) - self.C

    def dPsat_dT(self, T):
        """Analytical derivative, kPa/K. Used for uncertainty propagation."""
        T = np.asarray(T, dtype=float)
        return self.Psat(T) * np.log(10.0) * self.B / (T + self.C) ** 2

    def in_range(self, T):
        lo, hi = self.Trange
        if not np.isfinite(lo) or not np.isfinite(hi):
            return np.ones_like(np.asarray(T, dtype=float), dtype=bool)
        T = np.asarray(T, dtype=float)
        return (T >= lo) & (T <= hi)

    # ------------------------------------------------------- second virial
    def B_virial(self, T):
        """Pure-component second virial coefficient, m^3/mol.

        Pitzer-Curl form with the Tsonopoulos temperature functions. Only
        valid for non-polar and slightly polar species; for strongly polar or
        associating vapours the polar term matters and this underestimates the
        deviation. That limitation is stated rather than hidden because it is
        exactly the kind of assumption a consistency test will blame on the
        data.
        """
        if not (np.isfinite(self.Tc) and np.isfinite(self.Pc)):
            raise ValueError(f"{self.name}: Tc and Pc needed for the virial route")
        Tr = np.asarray(T, dtype=float) / self.Tc
        B0 = 0.1445 - 0.330 / Tr - 0.1385 / Tr ** 2 - 0.0121 / Tr ** 3 - 0.000607 / Tr ** 8
        B1 = 0.0637 + 0.331 / Tr ** 2 - 0.423 / Tr ** 3 - 0.008 / Tr ** 8
        w = 0.0 if not np.isfinite(self.omega) else self.omega
        return (R * self.Tc / (self.Pc * 1e3)) * (B0 + w * B1)


# --------------------------------------------------------------------------
def B_cross(c1, c2, T, k12=0.0):
    """Cross second virial coefficient by the usual combining rules.

    Tc by a geometric mean with a binary correction, Pc from the critical
    compressibilities, omega by an arithmetic mean. k12 = 0 is the default and
    is almost never right, but it is the honest default.
    """
    Tcij = np.sqrt(c1.Tc * c2.Tc) * (1 - k12)
    w = 0.5 * (np.nan_to_num(c1.omega) + np.nan_to_num(c2.omega))
    Zc1 = 0.291 - 0.080 * np.nan_to_num(c1.omega)
    Zc2 = 0.291 - 0.080 * np.nan_to_num(c2.omega)
    Zcij = 0.5 * (Zc1 + Zc2)
    Vc1 = Zc1 * R * c1.Tc / (c1.Pc * 1e3)
    Vc2 = Zc2 * R * c2.Tc / (c2.Pc * 1e3)
    Vcij = ((Vc1 ** (1 / 3) + Vc2 ** (1 / 3)) / 2) ** 3
    Pcij = Zcij * R * Tcij / Vcij / 1e3          # kPa
    Tr = np.asarray(T, dtype=float) / Tcij
    B0 = 0.1445 - 0.330 / Tr - 0.1385 / Tr ** 2 - 0.0121 / Tr ** 3 - 0.000607 / Tr ** 8
    B1 = 0.0637 + 0.331 / Tr ** 2 - 0.423 / Tr ** 3 - 0.008 / Tr ** 8
    return (R * Tcij / (Pcij * 1e3)) * (B0 + w * B1)


def phi_virial(y1, T, P, c1, c2, k12=0.0):
    """Vapour fugacity coefficients from the two-term virial equation.

    ln phi_1 = (P / RT) [ B11 + y2^2 d12 ],  d12 = 2 B12 - B11 - B22
    P in kPa, returned as (phi1, phi2).
    """
    y1 = np.asarray(y1, dtype=float)
    y2 = 1 - y1
    B11 = c1.B_virial(T)
    B22 = c2.B_virial(T)
    B12 = B_cross(c1, c2, T, k12)
    d12 = 2 * B12 - B11 - B22
    RT = R * np.asarray(T, dtype=float)
    Pa = np.asarray(P, dtype=float) * 1e3
    ln_phi1 = Pa / RT * (B11 + y2 ** 2 * d12)
    ln_phi2 = Pa / RT * (B22 + y1 ** 2 * d12)
    return np.exp(ln_phi1), np.exp(ln_phi2)


def phi_sat_virial(T, c):
    """phi of the pure saturated vapour, the reference state in Phi_i."""
    Ps = c.Psat(T) * 1e3
    return np.exp(Ps * c.B_virial(T) / (R * np.asarray(T, dtype=float)))


def poynting(T, P, c):
    """exp[ vL (P - Psat) / RT ]. Small below a few bar, but not zero."""
    if not np.isfinite(c.vL):
        return np.ones_like(np.asarray(P, dtype=float))
    dP = (np.asarray(P, dtype=float) - c.Psat(T)) * 1e3
    return np.exp(c.vL * dP / (R * np.asarray(T, dtype=float)))


# --------------------------------------------------------------------------
# Datasets
# --------------------------------------------------------------------------
@dataclass
class VLEData:
    """One isothermal or isobaric binary P-T-x-y dataset.

    T in K, P in kPa, x1 and y1 mole fractions of component 1. Any of the four
    may be a constant. `kind` records which variable was held fixed, because
    the area test and the point test take different forms in the two cases.
    """

    x1: np.ndarray
    y1: np.ndarray
    P: np.ndarray
    T: np.ndarray
    c1: Component
    c2: Component
    kind: str = "isothermal"           # 'isothermal' | 'isobaric'
    label: str = ""
    source: str = ""
    sigma: dict = field(default_factory=lambda: {"x": 1e-3, "y": 2e-3,
                                                 "P": 0.05, "T": 0.05})

    def __post_init__(self):
        n = None
        for k in ("x1", "y1", "P", "T"):
            v = np.atleast_1d(np.asarray(getattr(self, k), dtype=float))
            setattr(self, k, v)
            if v.size > 1:
                n = v.size if n is None else n
        n = n or 1
        for k in ("x1", "y1", "P", "T"):
            v = getattr(self, k)
            if v.size == 1 and n > 1:
                setattr(self, k, np.full(n, v[0]))
        self.n = len(self.x1)
        if self.kind == "isothermal" and np.ptp(self.T) > 1.0:
            raise ValueError("declared isothermal but T varies by more than 1 K")
        if self.kind == "isobaric" and np.ptp(self.P) > 0.05 * np.mean(self.P):
            raise ValueError("declared isobaric but P varies by more than 5%")

    # -------------------------------------------------------------- gamma
    def gamma(self, vapour="ideal", k12=0.0):
        """Activity coefficients from the raw measurements.

        vapour='ideal'   modified Raoult, Phi_i = 1
        vapour='virial'  two-term virial plus the Poynting correction

        The pure-component end points are excluded from the return by nothing:
        at x1 = 0 or 1 one of the two gammas is 0/0 and comes back as nan, which
        is correct and is easier to reason about than a silently substituted
        value.
        """
        Ps1, Ps2 = self.c1.Psat(self.T), self.c2.Psat(self.T)
        if vapour == "ideal":
            Phi1 = Phi2 = np.ones(self.n)
        elif vapour == "virial":
            ph1, ph2 = phi_virial(self.y1, self.T, self.P, self.c1, self.c2, k12)
            Phi1 = ph1 / phi_sat_virial(self.T, self.c1) / poynting(self.T, self.P, self.c1)
            Phi2 = ph2 / phi_sat_virial(self.T, self.c2) / poynting(self.T, self.P, self.c2)
        else:
            raise ValueError("vapour must be 'ideal' or 'virial'")
        with np.errstate(divide="ignore", invalid="ignore"):
            g1 = self.y1 * Phi1 * self.P / (self.x1 * Ps1)
            g2 = (1 - self.y1) * Phi2 * self.P / ((1 - self.x1) * Ps2)
        return g1, g2

    def gE_RT(self, vapour="ideal", k12=0.0):
        """G^E/RT from the data, the quantity every model is fitted against."""
        g1, g2 = self.gamma(vapour, k12)
        with np.errstate(divide="ignore", invalid="ignore"):
            return self.x1 * np.log(g1) + (1 - self.x1) * np.log(g2)

    # -------------------------------------------------- uncertainty in gamma
    def gamma_sigma(self, vapour="ideal", k12=0.0):
        """First-order propagation of the measurement error into ln gamma.

        ln g1 = ln y1 + ln P - ln x1 - ln Psat1(T), so
            var(ln g1) = (s_y/y1)^2 + (s_P/P)^2 + (s_x/x1)^2
                       + (dlnPsat/dT * s_T)^2
        The temperature term is the one that surprises people: at moderate
        pressures a 0.1 K error moves ln gamma more than a 0.002 error in y.
        """
        s = self.sigma
        d1 = self.c1.dPsat_dT(self.T) / self.c1.Psat(self.T)
        d2 = self.c2.dPsat_dT(self.T) / self.c2.Psat(self.T)
        with np.errstate(divide="ignore", invalid="ignore"):
            v1 = ((s["y"] / self.y1) ** 2 + (s["P"] / self.P) ** 2
                  + (s["x"] / self.x1) ** 2 + (d1 * s["T"]) ** 2)
            v2 = ((s["y"] / (1 - self.y1)) ** 2 + (s["P"] / self.P) ** 2
                  + (s["x"] / (1 - self.x1)) ** 2 + (d2 * s["T"]) ** 2)
        return np.sqrt(v1), np.sqrt(v2)

    # ------------------------------------------------------------- helpers
    def interior(self, eps=1e-6):
        """Mask excluding the pure end points, where gamma is indeterminate."""
        return (self.x1 > eps) & (self.x1 < 1 - eps)

    def sorted_by_x(self):
        """A copy ordered in x1, which the integral tests assume."""
        i = np.argsort(self.x1)
        return VLEData(self.x1[i], self.y1[i], self.P[i], self.T[i],
                       self.c1, self.c2, self.kind, self.label, self.source,
                       dict(self.sigma))

    def __len__(self):
        return self.n

    def __repr__(self):
        t = (f"T={self.T[0]:.2f} K" if self.kind == "isothermal"
             else f"P={self.P[0]:.2f} kPa")
        return (f"<VLEData {self.label or self.c1.name + '/' + self.c2.name} "
                f"{self.kind} {t}, n={self.n}>")


# --------------------------------------------------------------------------
def from_table(rows, c1, c2, *, kind="isothermal", T=None, P=None, **kw):
    """Build a VLEData from the way a paper actually prints a table.

    rows is a sequence of (x1, y1, value) where value is P in kPa for an
    isothermal set and T in K for an isobaric one.
    """
    a = np.asarray(rows, dtype=float)
    if kind == "isothermal":
        if T is None:
            raise ValueError("isothermal data needs T")
        return VLEData(a[:, 0], a[:, 1], a[:, 2], np.full(len(a), T),
                       c1, c2, kind=kind, **kw)
    if P is None:
        raise ValueError("isobaric data needs P")
    return VLEData(a[:, 0], a[:, 1], np.full(len(a), P), a[:, 2],
                   c1, c2, kind=kind, **kw)


# --------------------------------------------------------------------------
# A small library of components, enough to run the course examples offline.
# Most entries use the ln(kPa) Antoine form tabulated in Smith, Van Ness &
# Abbott; two use the log10(mmHg), T-in-Celsius form because the SVA values for
# those species reproduce the normal boiling point badly. Critical constants
# from Poling, Prausnitz & O'Connell. Every entry is checked against its normal
# boiling point and its 25 C vapour pressure in tests/test_data.py, which is
# the only reason to trust a hard-coded table at all.
# --------------------------------------------------------------------------
LIBRARY = {
    "acetone": Component.from_antoine_ln(
        "acetone", 14.3145, 2756.22, -45.09,
        Tc=508.2, Pc=4701.0, omega=0.307, vL=74.0e-6, Trange=(259, 508),
        source="SVA App. B, ln(kPa)"),
    "methanol": Component.from_antoine_ln(
        "methanol", 16.5785, 3638.27, -33.65,
        Tc=512.6, Pc=8097.0, omega=0.564, vL=40.7e-6, Trange=(275, 513),
        source="SVA App. B, ln(kPa)"),
    "water": Component.from_antoine_ln(
        "water", 16.3872, 3885.70, -42.98,
        Tc=647.1, Pc=22055.0, omega=0.345, vL=18.07e-6, Trange=(273, 647),
        source="SVA App. B, ln(kPa)"),
    "ethanol": Component.from_antoine_ln(
        "ethanol", 16.8958, 3795.17, -42.23,
        Tc=513.9, Pc=6148.0, omega=0.645, vL=58.7e-6, Trange=(292, 514),
        source="SVA App. B, ln(kPa)"),
    "2-propanol": Component.from_antoine_ln(
        "2-propanol", 16.6796, 3640.20, -53.54,
        Tc=508.3, Pc=4762.0, omega=0.665, vL=76.9e-6, Trange=(283, 508),
        source="SVA App. B, ln(kPa)"),
    "benzene": Component.from_antoine_ln(
        "benzene", 13.7819, 2726.81, -55.58,
        Tc=562.2, Pc=4898.0, omega=0.210, vL=89.4e-6, Trange=(280, 562),
        source="SVA App. B, ln(kPa)"),
    "cyclohexane": Component.from_antoine_ln(
        "cyclohexane", 13.6568, 2723.44, -52.53,
        Tc=553.6, Pc=4073.0, omega=0.212, vL=108.7e-6, Trange=(280, 554),
        source="SVA App. B, ln(kPa)"),
    "n-hexane": Component.from_antoine_ln(
        "n-hexane", 13.8193, 2696.04, -48.83,
        Tc=507.6, Pc=3025.0, omega=0.301, vL=131.6e-6, Trange=(250, 508),
        source="SVA App. B, ln(kPa)"),
    # The SVA coefficients for the next two miss the normal boiling point by
    # several kelvin, so the Yaws log10(mmHg) set is used instead.
    "mek": Component.from_antoine(
        "2-butanone", 7.06356, 1261.34, 221.969, punit="mmHg", tunit="C",
        Tc=536.8, Pc=4207.0, omega=0.323, vL=90.2e-6, Trange=(273, 410),
        source="Yaws, log10(mmHg), T in C"),
    "chloroform": Component.from_antoine(
        "chloroform", 6.95465, 1170.966, 226.232, punit="mmHg", tunit="C",
        Tc=536.4, Pc=5472.0, omega=0.222, vL=80.7e-6, Trange=(263, 400),
        source="Yaws, log10(mmHg), T in C"),
    # Added for the cubic-EOS module. A light gas and a light alkane are the
    # classical retrograde pair, and neither can be handled by the gamma-phi
    # route at all: methane is supercritical above 190.6 K, so it has no
    # vapour pressure to put in Raoult's law. Both Antoine sets are checked
    # against the normal boiling point in tests/test_cubic.py; the 25 C anchor
    # used for the solvents is meaningless for methane, which is supercritical
    # there, so a second sub-critical point is checked instead.
    "methane": Component.from_antoine(
        "methane", 6.61184, 389.93, 266.00, punit="mmHg", tunit="C",
        Tc=190.56, Pc=4599.0, omega=0.0115, vL=37.97e-6, Trange=(91, 190),
        source="Yaws, log10(mmHg), T in C; Tc/Pc/omega Poling et al."),
    "n-butane": Component.from_antoine(
        "n-butane", 6.83029, 945.90, 240.00, punit="mmHg", tunit="C",
        Tc=425.12, Pc=3796.0, omega=0.200, vL=100.4e-6, Trange=(196, 425),
        source="Yaws, log10(mmHg), T in C; Tc/Pc/omega Poling et al."),
}


# --------------------------------------------------------------------------
# UNIFAC subgroup decomposition, and the UNIQUAC size parameters derived from
# it. Deriving r and q as sums of the UNIFAC group R and Q values is
# reproducible from a published table rather than copied from memory, and it
# keeps the two models on one convention.
#
# It is NOT the convention of the original UNIQUAC papers. For hydrogen-bonding
# species the group sums are larger — ethanol comes out at r = 2.576 here
# against r = 2.106 in the Abrams-Prausnitz table, because the UNIFAC OH group
# volume is an average over environments rather than Bondi's value for this
# molecule. The consequence is practical and worth stating in class: tau values
# fitted with the r and q in this file cannot be swapped for published tau
# values. Parameters carry their conventions with them, exactly as they do for
# the Huron-Vidal mixing rule.
# --------------------------------------------------------------------------
GROUPS = {
    "acetone":     {1: 1, 18: 1},        # CH3 + CH3CO
    "methanol":    {15: 1},              # CH3OH
    "water":       {16: 1},              # H2O
    "ethanol":     {1: 1, 2: 1, 14: 1},  # CH3 + CH2 + OH
    "2-propanol":  {1: 2, 3: 1, 14: 1},  # 2 CH3 + CH + OH
    "benzene":     {9: 6},               # 6 ACH
    "cyclohexane": {2: 6},               # 6 CH2
    "n-hexane":    {1: 2, 2: 4},         # 2 CH3 + 4 CH2
    "mek":         {1: 1, 2: 1, 18: 1},  # CH3 + CH2 + CH3CO
    "chloroform":  {50: 1},              # CHCl3
}

# UNIFAC subgroup volume R and surface area Q for the subgroups used above,
# in the standard Hansen numbering. tests/test_unifac.py checks every one of
# these against the table shipped with the `thermo` package when it is
# installed, which is the only reason to keep a copy here at all: the package
# must still run in a lecture room with no network.
SUBGROUP_RQ = {
    1:  (0.9011, 0.848),    # CH3
    2:  (0.6744, 0.540),    # CH2
    3:  (0.4469, 0.228),    # CH
    9:  (0.5313, 0.400),    # ACH
    14: (1.0000, 1.200),    # OH
    15: (1.4311, 1.432),    # CH3OH
    16: (0.9200, 1.400),    # H2O
    18: (1.6724, 1.488),    # CH3CO
    50: (2.8700, 2.410),    # CHCl3
}

for _name, _g in GROUPS.items():
    _c = LIBRARY[_name]
    _c.groups = dict(_g)
    _c.r = sum(n * SUBGROUP_RQ[k][0] for k, n in _g.items())
    _c.q = sum(n * SUBGROUP_RQ[k][1] for k, n in _g.items())
del _name, _g, _c


def component(name):
    """Fetch a library component by name, with a useful error."""
    try:
        return LIBRARY[name.lower()]
    except KeyError:
        raise KeyError(f"unknown component {name!r}; "
                       f"have {sorted(LIBRARY)}") from None
