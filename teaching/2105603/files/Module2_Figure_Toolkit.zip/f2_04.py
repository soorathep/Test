#!/usr/bin/env python3
"""F2.4  How big is the Poynting correction, and when may it be dropped?

2105603 Advanced Chemical Engineering Thermodynamics — Module 2
Soorathep Kheawhom, Chulalongkorn University

    Poy = exp[ v^L (P - P^sat) / RT ]

The factor that turns the saturated liquid's fugacity into the fugacity of a
compressed liquid at the system pressure. It is the term students are told they
may usually neglect, and "usually" is doing a lot of work in that sentence.

The map is drawn against the two quantities the factor actually depends on:
the pressure above saturation and the liquid molar volume. On log-log axes the
contours are exactly straight, because v^L (P - P^sat) is constant along each
one. THE ONE PER CENT CONTOUR IS DRAWN HEAVY: below it the correction changes a
fugacity by less than a per cent, which for most purposes is smaller than the
uncertainty in P^sat itself.

Three real liquids are marked at their library v^L, and the pressure at which
each one reaches the one per cent line is solved for rather than read off:

    P - P^sat = RT ln(1.01) / v^L

The answers are small. n-hexane passes one per cent under 2 bar. That is the
point of the figure: the Poynting factor is negligible at ambient pressure and
not at all negligible in anything pressurised.

ASSUMPTIONS, both stated on the figure:
  * T = 298.15 K, a choice. RT appears only as a scale factor, so raising T
    pushes every contour to the right in proportion to T.
  * v^L is taken as constant, independent of pressure. That IS the Poynting
    approximation; a liquid compressed to 1000 bar is measurably denser and the
    exact integral of v^L dP is smaller than the exponential drawn here. The
    library carries one v^L per component with no temperature attached.

Run:  python3 f2_04.py
"""
from __future__ import annotations

import os
import sys

import numpy as np

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                  # noqa: E402
from matplotlib.colors import LinearSegmentedColormap, LogNorm   # noqa: E402
from matplotlib.transforms import blended_transform_factory      # noqa: E402

from vlekit.data import LIBRARY, R                               # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,      # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, use_style)

OUT = os.environ.get("F2_OUT", "/home/claude/vle2/qmd/figures")
SLUG = "f2_04_poynting_map"

T = 298.15                       # K — a choice, stated on the figure
DP_LO, DP_HI = 0.3, 1000.0       # bar above saturation
VL_LO, VL_HI = 10.0, 250.0       # cm3/mol
FLUIDS = ("water", "ethanol", "n-hexane")
LEVELS = (1.001, 1.005, 1.01, 1.02, 1.05, 1.1, 1.2, 1.5, 2.0, 3.0, 5.0,
          10.0, 30.0, 100.0, 300.0)
ONE_PC = 1.01
TEN_PC = 1.1


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


# --------------------------------------------------------------------------
def make():
    RT = R * T                                   # J/mol
    dP = np.geomspace(DP_LO, DP_HI, 500)         # bar
    vL = np.geomspace(VL_LO, VL_HI, 400)         # cm3/mol
    X, Y = np.meshgrid(dP, vL)
    Poy = np.exp(Y * 1e-6 * X * 1e5 / RT)

    def dP_for(target, v_cm3):
        """The pressure above saturation at which Poy reaches `target`."""
        return RT * np.log(target) / (v_cm3 * 1e-6) / 1e5      # bar

    rows = []
    for nm in FLUIDS:
        c = LIBRARY[nm]
        v = c.vL * 1e6                            # cm3/mol
        rows.append(dict(name=nm, comp=c, vL=v,
                         Psat=float(c.Psat(T)),
                         in_range=bool(c.in_range(T)),
                         dP1=dP_for(ONE_PC, v),
                         dP10=dP_for(TEN_PC, v),
                         at10=float(np.exp(v * 1e-6 * 10.0 * 1e5 / RT)),
                         at100=float(np.exp(v * 1e-6 * 100.0 * 1e5 / RT))))
    return dict(RT=RT, dP=dP, vL=vL, X=X, Y=Y, Poy=Poy, rows=rows,
                dP_for=dP_for)


# --------------------------------------------------------------------------
def label_points(levels, RT, y_top=195.0, y_bot=11.0, x_lo=0.45, x_hi=780.0):
    """Where to put each contour label, computed from the contour equation.

    A contour of the Poynting factor is the straight line
    v^L[cm3/mol] * (P - Psat)[bar] = 10 RT ln(Poy), so the position of a label
    at a chosen v^L follows in closed form. Two rows are used, one near the top
    of the frame and one near the bottom, both far from the three marked
    liquids so that no label can land on one of their lines.
    """
    out = []
    for L in levels:
        C = 10.0 * RT * np.log(L)
        for y in (y_top, y_bot):
            x = C / y
            if x_lo <= x <= x_hi:
                out.append((x, y))
                break
        else:
            out.append(None)
    return out


def build(d):
    use_style()
    fig, ax = plt.subplots(figsize=(12.6, 8.0))
    fig.subplots_adjust(left=0.080, right=0.855, top=0.860, bottom=0.235)
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlim(DP_LO, DP_HI)
    ax.set_ylim(VL_LO, VL_HI)

    cmap = LinearSegmentedColormap.from_list(
        "poynting", [PAPER, MIST, SKYBLUE, NAVY])
    fill = list(LEVELS) + [1.0e4]
    ax.contourf(d["X"], d["Y"], d["Poy"], levels=fill, cmap=cmap,
                norm=LogNorm(vmin=LEVELS[0], vmax=1.0e4), alpha=0.42,
                zorder=1, extend="min")

    minor = [v for v in LEVELS if v not in (ONE_PC, TEN_PC)]
    cs = ax.contour(d["X"], d["Y"], d["Poy"], levels=minor, colors=[GRAPHITE],
                    linewidths=1.2, zorder=4)
    pts = label_points(minor, d["RT"])
    ax.clabel(cs, fmt=lambda v: f"{v:g}", fontsize=10.5, inline=True,
              inline_spacing=6, manual=[q for q in pts if q is not None])

    c10 = ax.contour(d["X"], d["Y"], d["Poy"], levels=[TEN_PC],
                     colors=[AMBER], linewidths=2.8, zorder=5)
    ax.clabel(c10, fmt=lambda v: "  10 %  ", fontsize=12.5, inline=True,
              inline_spacing=8, colors=[AMBER],
              manual=[(10.0 * d["RT"] * np.log(TEN_PC) / 90.0, 90.0)])
    c01 = ax.contour(d["X"], d["Y"], d["Poy"], levels=[ONE_PC],
                     colors=[RUST], linewidths=3.6, zorder=6)
    ax.clabel(c01, fmt=lambda v: "  1 %  ", fontsize=13.5, inline=True,
              inline_spacing=8, colors=[RUST],
              manual=[(10.0 * d["RT"] * np.log(ONE_PC) / 90.0, 90.0)])

    ax.grid(True, which="major", color=PAPER, alpha=0.45, lw=0.7, zorder=2)

    # the three real liquids: a line at their v^L, a marker where it meets the
    # one per cent contour, and the name in the margin so no label sits on a
    # contour
    marg = blended_transform_factory(ax.transAxes, ax.transData)
    for r, col in zip(d["rows"], (TEAL, NAVY, RUST)):
        ax.axhline(r["vL"], color=col, lw=2.0, ls=(0, (6, 4)), zorder=7)
        ax.plot([r["dP1"]], [r["vL"]], "o", color=col, ms=12, mec=PAPER,
                mew=2.0, zorder=9)
        ax.text(1.020, r["vL"],
                f"{r['name']}\n$v^L$ = {r['vL']:.2f} cm$^3$/mol\n"
                f"1 % at {r['dP1']:.2f} bar\n"
                f"10 % at {r['dP10']:.1f} bar",
                transform=marg, ha="left", va="center", fontsize=11,
                color=col, linespacing=1.5, zorder=10,
                bbox=dict(boxstyle="round,pad=0.22", fc=PAPER, ec=col, lw=1.0,
                          alpha=0.95))

    ax.set_xlabel("$P - P^{\\rm sat}$  /  bar      (log scale)")
    ax.set_ylabel("liquid molar volume  $v^L$ / cm$^3$ mol$^{-1}$   "
                  "(log scale)")
    ax.set_xticks([0.3, 1, 3, 10, 30, 100, 300, 1000])
    ax.set_xticklabels(["0.3", "1", "3", "10", "30", "100", "300", "1000"])
    ax.set_yticks([10, 20, 30, 50, 80, 130, 200, 250])
    ax.set_yticklabels(["10", "20", "30", "50", "80", "130", "200", "250"])
    ax.tick_params(which="minor", length=0)

    fig.text(0.5, 0.960,
             "The Poynting factor  "
             r"$\exp[\,v^L(P-P^{\rm sat})/RT\,]$  at  "
             f"$T$ = {T:g} K",
             ha="center", va="center", fontsize=16, color=INK)
    fig.text(0.5, 0.915,
             "below the heavy 1 % contour it changes a fugacity by less than "
             "the uncertainty in $P^{\\rm sat}$ itself; above it, it stops "
             "being a correction at all",
             ha="center", va="center", fontsize=12.5, color=GRAPHITE)

    r0, r1, r2 = d["rows"]
    fig.text(0.5, 0.012,
             f"ASSUMED: $T$ = {T:g} K. $RT$ enters only as a scale factor, so "
             "every contour slides to the right in proportion to $T$.\n"
             "ASSUMED: $v^L$ constant, independent of pressure — that is what "
             "the Poynting factor is. A real liquid at 1000 bar is denser, so "
             "the true $\\int v^L\\,\\mathrm{d}P$\n"
             "is smaller than the exponential drawn here. $v^L$ values are "
             "`vlekit.data.LIBRARY`, one number per component with no "
             "temperature attached to it.\n"
             "The contours are exactly straight because "
             "$v^L(P-P^{\\rm sat})$ is constant along each one; the marked "
             "pressures follow from $P-P^{\\rm sat} = RT\\ln(1.01)/v^L$ and "
             "nothing else.\n"
             f"$P^{{\\rm sat}}$({T:g} K) from the library Antoine constants "
             f"is {r0['Psat']:.2f} kPa for {r0['name']}, "
             f"{r1['Psat']:.2f} kPa for {r1['name']}, "
             f"{r2['Psat']:.2f} kPa for {r2['name']} — all far below 1 bar, "
             "so here $P - P^{\\rm sat}$ and $P$ are the same number.",
             ha="center", va="bottom", fontsize=10.3, color=SLATE,
             linespacing=1.6)
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = make()
    print(f"F2.4  Poynting factor map at T = {T:g} K, RT = {d['RT']:.4f} J/mol")
    print(f"  grid: P - Psat from {DP_LO:g} to {DP_HI:g} bar, "
          f"v^L from {VL_LO:g} to {VL_HI:g} cm3/mol")
    print("  fluid       v^L/cm3   Psat/kPa  in Antoine range   "
          "dP for 1 %   dP for 10 %   Poy(10 bar)  Poy(100 bar)")
    for r in d["rows"]:
        print(f"  {r['name']:10s} {r['vL']:7.2f}  {r['Psat']:9.3f}   "
              f"{str(r['in_range']):5s}          {r['dP1']:8.3f} bar  "
              f"{r['dP10']:8.3f} bar   {r['at10']:9.5f}    {r['at100']:9.5f}")
    for r in d["rows"]:
        print(f"    [{r['name']}] source: {r['comp'].source}")
    print(f"  the {ONE_PC:g} contour passes through "
          f"v^L (P - Psat) = {d['RT'] * np.log(ONE_PC):.4f} J/mol; "
          f"the {TEN_PC:g} contour through "
          f"{d['RT'] * np.log(TEN_PC):.4f} J/mol")
    print(f"  corner values: Poy({DP_LO:g} bar, {VL_LO:g} cm3) = "
          f"{np.exp(VL_LO * 1e-6 * DP_LO * 1e5 / d['RT']):.6f}, "
          f"Poy({DP_HI:g} bar, {VL_HI:g} cm3) = "
          f"{np.exp(VL_HI * 1e-6 * DP_HI * 1e5 / d['RT']):.4g}")
    for p in write(build(d), SLUG):
        print("wrote", p)
