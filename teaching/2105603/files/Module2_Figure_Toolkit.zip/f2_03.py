#!/usr/bin/env python3
"""F2.3  Fugacity across the saturation line, and the branch that is not there.

2105603 Advanced Chemical Engineering Thermodynamics — Module 2
Soorathep Kheawhom, Chulalongkorn University

n-butane at 350 K (Tr = 0.823). Peng-Robinson has three roots over this whole
pressure range, so at every pressure drawn there is a vapour fugacity AND a
liquid fugacity — the equation of state has no idea which phase is present.
The equilibrium criterion is what decides:

    f^L(T, P) = f^V(T, P)   at   P = P^sat

`vlekit.cubic.psat` finds that pressure by driving g^V - g^L to zero on the
same equation of state, and the crossing marked on panel (a) is its answer,
not a reading off the curves.

WHAT THE DASHED SEGMENTS ARE FOR. Past the crossing each branch continues.
Below P^sat the liquid root still exists and its fugacity is still computable —
that is a superheated liquid, metastable, and it has the HIGHER fugacity, which
is exactly why it is not the phase you find. Above P^sat the vapour root
survives up to the vapour spinodal, located here by dP/dv = 0 on the same
isotherm; past that pressure there is no vapour root at all and the branch
simply stops. Both dashed segments are real solutions of a real equation, and
both are wrong answers to the question "what phase is this?".

Panel (b) is the same information as a chemical potential:

    mu^V - mu^L = RT ln(f^V/f^L)

which is negative where the vapour wins, positive where the liquid wins, and
zero at P^sat. The equality of fugacity and the minimisation of Gibbs energy
are one statement, and the two panels are the same numbers.

Run:  python3 f2_03.py
"""
from __future__ import annotations

import os
import sys

import numpy as np
from scipy.optimize import brentq

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                  # noqa: E402

from vlekit.cubic import PengRobinson, R, psat                   # noqa: E402
from vlekit.data import LIBRARY                                  # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,      # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, use_style)

OUT = os.environ.get("F2_OUT", "/home/claude/vle2/qmd/figures")
SLUG = "f2_03_fugacity_across_saturation"

NAME = "n-butane"
T = 350.0                      # K
P_LO = 20.0                    # kPa, where the drawing starts
N = 700


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


# --------------------------------------------------------------------------
def spinodals(mix, T):
    """The two pressures where (dP/dv)_T = 0 on this isotherm, in kPa.

    The vapour branch of the cubic exists only below the upper one and the
    liquid branch only above the lower one; between them all three roots are
    real. Located by bisecting dP/dv on a volume grid rather than by counting
    roots, which is a discrete test and cannot be refined.
    """
    x = np.array([1.0])
    b = mix.b_mix(x)
    a = mix.a_mix(T, x)

    def P_of_v(v):
        return (R * T / (v - b) - a / (v * (v + b) + b * (v - b))) / 1e3

    def dPdv(v):
        h = v * 1e-7
        return (P_of_v(v + h) - P_of_v(v - h)) / (2 * h)

    vs = np.geomspace(1.0005 * b, 1.0, 8000)
    d = np.array([dPdv(v) for v in vs])
    s = np.where(np.sign(d[:-1]) != np.sign(d[1:]))[0]
    out = []
    for i in s:
        vr = brentq(dPdv, vs[i], vs[i + 1], xtol=1e-16, rtol=1e-14)
        out.append((float(vr), float(P_of_v(vr))))
    return out


def make():
    c = LIBRARY[NAME]
    mix = PengRobinson([c])
    x = np.array([1.0])
    RT = R * T / 1000.0

    Ps = psat(mix, 0, T)
    sp = spinodals(mix, T)
    P_sv = max(p for _, p in sp)              # vapour spinodal
    P_sl = min(p for _, p in sp)              # liquid spinodal

    P_hi = 0.995 * P_sv                       # the last pressure with a vapour root
    P = np.linspace(P_LO, P_hi, N)
    P = np.sort(np.unique(np.concatenate([P, [Ps]])))

    fV, fL = [], []
    for p in P:
        lv, _ = mix.ln_phi(T, p, x, "vapour")
        ll, _ = mix.ln_phi(T, p, x, "liquid")
        fV.append(float(np.exp(lv[0])) * p)
        fL.append(float(np.exp(ll[0])) * p)
    fV, fL = np.array(fV), np.array(fL)

    dmu = RT * np.log(fV / fL)
    j = int(np.argmin(np.abs(P - Ps)))
    f_sat = 0.5 * (fV[j] + fL[j])
    phi_sat = f_sat / Ps

    return dict(c=c, mix=mix, RT=RT, P=P, fV=fV, fL=fL, dmu=dmu, Ps=Ps,
                f_sat=f_sat, phi_sat=phi_sat, P_sv=P_sv, P_sl=P_sl, sp=sp,
                mismatch=float(abs(fV[j] - fL[j])),
                P_ant=float(c.Psat(T)), j=j, P_hi=P_hi)


# --------------------------------------------------------------------------
def build(d):
    use_style()
    fig = plt.figure(figsize=(14.2, 7.6))
    gs = fig.add_gridspec(1, 2, width_ratios=[1.42, 1.0],
                          left=0.055, right=0.985, top=0.855, bottom=0.275,
                          wspace=0.20)
    ax = fig.add_subplot(gs[0, 0])
    bx = fig.add_subplot(gs[0, 1])
    for a in (ax, bx):
        a.grid(True, zorder=0)
        a.set_axisbelow(True)

    Pb = d["P"] / 100.0
    Psb = d["Ps"] / 100.0
    Psvb = d["P_sv"] / 100.0
    lo = Pb <= Psb
    hi = Pb >= Psb
    XHI = 18.2
    YHI = 1330.0

    # =============================================================== panel a
    ax.plot([0.0, YHI / 100.0], [0.0, YHI], "-", color=MIST, lw=1.8, zorder=2,
            label="ideal gas, $f = P$")
    ax.plot(Pb[lo], d["fV"][lo], "-", color=TEAL, lw=2.8, zorder=6,
            label="$f^V$, the vapour root  (stable below $P^{\\rm sat}$)")
    ax.plot(Pb[hi], d["fV"][hi], "--", color=TEAL, lw=2.2, zorder=5,
            label="$f^V$ continued: metastable, then no root at all")
    ax.plot(Pb[hi], d["fL"][hi], "-", color=NAVY, lw=2.8, zorder=6,
            label="$f^L$, the liquid root  (stable above $P^{\\rm sat}$)")
    ax.plot(Pb[lo], d["fL"][lo], "--", color=NAVY, lw=2.2, zorder=5,
            label="$f^L$ continued: a superheated, metastable liquid")

    ax.axvline(Psb, color=RUST, lw=1.6, ls=(0, (5, 3)), zorder=3)
    ax.plot([Psb], [d["f_sat"]], "o", color=RUST, ms=13, mec=PAPER, mew=2.0,
            zorder=9)

    ax.set_xlim(0.0, XHI)
    ax.set_ylim(0.0, YHI)
    ax.set_xlabel("$P$ / bar")
    ax.set_ylabel("fugacity  $f$ / kPa")
    ax.set_title(f"(a)  {NAME} at {T:g} K  ($T_r$ = {T / d['c'].Tc:.3f}): "
                 "two roots, two fugacities, one crossing",
                 fontsize=13.5, pad=8, loc="left", x=0.0)
    # The curves fill a band across the middle. The legend goes in the empty
    # wedge above the f = P line at the top left; the crossing callout goes in
    # the empty rectangle below both branches at the bottom right.
    ax.legend(loc="lower right", fontsize=10.6, labelspacing=0.62,
              bbox_to_anchor=(0.985, 0.030))

    ax.annotate(f"$f^L = f^V$ at $P^{{\\rm sat}}$ = {d['Ps']:.2f} kPa\n"
                f"          = {Psb:.4f} bar\n"
                f"$f^{{\\rm sat}}$ = {d['f_sat']:.2f} kPa,  "
                f"$\\phi^{{\\rm sat}}$ = {d['phi_sat']:.4f}\n"
                f"the two branches agree there to "
                f"{d['mismatch']:.1e} kPa",
                xy=(Psb, d["f_sat"]), xytext=(0.040, 0.985),
                textcoords="axes fraction",
                ha="left", va="top", fontsize=11.5, color=RUST, zorder=10,
                linespacing=1.55,
                bbox=dict(boxstyle="round,pad=0.30", fc=PAPER, ec=RUST,
                          lw=1.2, alpha=0.96),
                arrowprops=dict(arrowstyle="-", color=RUST, lw=1.3,
                                shrinkA=8, shrinkB=10))

    ax.annotate("superheated liquid:\nstill a root, higher $f$,\n"
                "so not the phase you find",
                xy=(2.5, float(np.interp(250.0, d["P"], d["fL"]))),
                xytext=(0.040, 0.745), textcoords="axes fraction",
                ha="left", va="top", fontsize=11, color=NAVY, zorder=10,
                linespacing=1.5,
                bbox=dict(boxstyle="round,pad=0.28", fc=PAPER, ec=NAVY,
                          lw=1.1, alpha=0.96),
                arrowprops=dict(arrowstyle="-", color=NAVY, lw=1.2,
                                shrinkA=5, shrinkB=7))

    ax.annotate("the vapour root ends here:\n"
                f"spinodal at {Psvb:.3f} bar",
                xy=(Pb[-1], d["fV"][-1]), xytext=(0.985, 0.755),
                textcoords="axes fraction",
                ha="right", va="top", fontsize=11, color=TEAL, zorder=10,
                linespacing=1.5,
                bbox=dict(boxstyle="round,pad=0.26", fc=PAPER, ec=TEAL,
                          lw=1.1, alpha=0.96),
                arrowprops=dict(arrowstyle="-", color=TEAL, lw=1.2,
                                shrinkA=5, shrinkB=6))

    # =============================================================== panel b
    dmu = d["dmu"]
    YLO2, YHI2 = -6.6, 3.2
    bx.fill_between(Pb, dmu, 0.0, where=dmu <= 0, color=TEAL, alpha=0.20,
                    interpolate=True, zorder=2)
    bx.fill_between(Pb, dmu, 0.0, where=dmu >= 0, color=NAVY, alpha=0.20,
                    interpolate=True, zorder=2)
    bx.plot(Pb, dmu, "-", color=GRAPHITE, lw=2.8, zorder=6)
    bx.axhline(0.0, color=GRAPHITE, lw=1.2, zorder=3)
    bx.axvline(Psb, color=RUST, lw=1.6, ls=(0, (5, 3)), zorder=3)
    bx.plot([Psb], [0.0], "o", color=RUST, ms=13, mec=PAPER, mew=2.0, zorder=9)

    bx.set_xlim(0.0, XHI)
    bx.set_ylim(YLO2, YHI2)
    bx.set_xlabel("$P$ / bar")
    bx.set_ylabel(r"$\mu^V - \mu^L = RT\ln(f^V/f^L)$  /  kJ mol$^{-1}$")
    bx.set_title("(b)  the same numbers as a chemical potential",
                 fontsize=13.5, pad=8, loc="left", x=0.0)

    bx.text(0.030, 0.975,
            "$P < P^{\\rm sat}$:  $\\mu^V < \\mu^L$\nthe vapour is stable",
            transform=bx.transAxes, ha="left", va="top", fontsize=11.5,
            color=TEAL, zorder=10, linespacing=1.5,
            bbox=dict(boxstyle="round,pad=0.26", fc=PAPER, ec=TEAL, lw=1.1,
                      alpha=0.96))
    bx.text(0.970, 0.975,
            "$P > P^{\\rm sat}$:  $\\mu^L < \\mu^V$\nthe liquid is stable",
            transform=bx.transAxes, ha="right", va="top", fontsize=11.5,
            color=NAVY, zorder=10, linespacing=1.5,
            bbox=dict(boxstyle="round,pad=0.26", fc=PAPER, ec=NAVY, lw=1.1,
                      alpha=0.96))
    bx.annotate("one crossing, and it is at the\n"
                f"same {Psb:.4f} bar as panel (a)",
                xy=(Psb, 0.0), xytext=(0.045, 0.055),
                textcoords="axes fraction",
                ha="left", va="bottom", fontsize=11, color=RUST, zorder=10,
                linespacing=1.5,
                bbox=dict(boxstyle="round,pad=0.28", fc=PAPER, ec=RUST,
                          lw=1.1, alpha=0.96),
                arrowprops=dict(arrowstyle="-", color=RUST, lw=1.2,
                                shrinkA=5, shrinkB=8))

    fig.text(0.5, 0.955,
             "The equation of state offers two answers at every pressure; "
             "the equilibrium criterion picks one, and they are equal only "
             "at $P^{\\rm sat}$",
             ha="center", va="center", fontsize=15.5, color=INK)

    c = d["c"]
    fig.text(0.5, 0.012,
             f"{NAME}: $T_c$ = {c.Tc:g} K, $P_c$ = {c.Pc / 100:g} bar, "
             f"$\\omega$ = {c.omega:g}  [{c.source}].\n"
             "Fugacities from `vlekit.cubic.PengRobinson.ln_phi` with the "
             "root forced to 'liquid' and to 'vapour'; $P^{\\rm sat}$ from "
             "`vlekit.cubic.psat`;\n"
             "the spinodals from $(\\partial P/\\partial v)_T = 0$ on the "
             "same isotherm. ASSUMED: nothing beyond the library constants "
             "above and the 1976 $\\alpha$ function.\n"
             f"Peng-Robinson puts $P^{{\\rm sat}}$ at {d['Ps']:.2f} kPa; the "
             f"library Antoine correlation puts it at {d['P_ant']:.2f} kPa, "
             f"{100 * abs(d['Ps'] / d['P_ant'] - 1):.1f} % lower.\n"
             "The figure uses the equation of state throughout so that both "
             "branches come from one model — the discrepancy is the cubic's, "
             "and it is stated rather than patched.\n"
             f"The liquid root survives down to the liquid spinodal at "
             f"{d['P_sl'] / 100:.2f} bar, which is negative, so it exists "
             f"everywhere on this axis; the vapour root dies at "
             f"{Psvb:.3f} bar.",
             ha="center", va="bottom", fontsize=10.2, color=SLATE,
             linespacing=1.6)
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = make()
    c = d["c"]
    print(f"F2.3  {NAME} at T = {T:g} K  (Tr = {T / c.Tc:.4f})")
    print(f"  {d['mix']!r}; Tc = {c.Tc:g} K, Pc = {c.Pc:g} kPa, "
          f"omega = {c.omega:g}   [{c.source}]")
    print(f"  P^sat (cubic.psat)      = {d['Ps']:.6f} kPa "
          f"= {d['Ps'] / 100:.6f} bar")
    print(f"  P^sat (library Antoine) = {d['P_ant']:.6f} kPa  -> the cubic is "
          f"{100 * (d['Ps'] / d['P_ant'] - 1):+.2f} %")
    print(f"  f^sat = {d['f_sat']:.6f} kPa, phi^sat = {d['phi_sat']:.6f}; "
          f"|f^V - f^L| at P^sat = {d['mismatch']:.3e} kPa")
    for v, p in d["sp"]:
        print(f"  spinodal: v = {v:.6e} m3/mol, P = {p:.4f} kPa "
              f"= {p / 100:.4f} bar")
    print("    P/bar        f^V/kPa      f^L/kPa    mu^V-mu^L (kJ/mol)")
    for Pb in (0.5, 1.0, 3.0, 5.0, 7.0, d["Ps"] / 100, 12.0, 15.0, 17.0):
        P = Pb * 100.0
        if P > d["P"][-1] or P < d["P"][0]:
            continue
        fv = float(np.interp(P, d["P"], d["fV"]))
        fl = float(np.interp(P, d["P"], d["fL"]))
        print(f"  {Pb:8.4f}   {fv:11.4f}  {fl:11.4f}    "
              f"{d['RT'] * np.log(fv / fl):+8.4f}")
    print(f"  vapour branch drawn up to {d['P_hi'] / 100:.4f} bar "
          f"(0.995 of the vapour spinodal)")
    for p in write(build(d), SLUG):
        print("wrote", p)
