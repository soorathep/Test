#!/usr/bin/env python3
"""F2.5  The Maxwell equal-area construction, re-read as a statement about f.

2105603 Advanced Chemical Engineering Thermodynamics — Module 2
Soorathep Kheawhom, Chulalongkorn University

n-butane at 400 K (Tr = 0.941). One Peng-Robinson isotherm, drawn twice.

LEFT: the classical picture. The horizontal line is placed so that the two
lobes it cuts off the isotherm have equal area, which is the condition

    integral_{v^L}^{v^V} P dv  =  P^sat (v^V - v^L)

and is solved here for P^sat with Brent, using the closed-form antiderivative
of the Peng-Robinson P(v):

    F(v) = RT ln(v-b) + a/(2 sqrt2 b) ln[(v+(1+sqrt2)b)/(v+(1-sqrt2)b)]

RIGHT: the same isotherm's fugacity, obtained by walking along it in v. For a
pure fluid ln phi = G^res/RT exactly, so `PengRobinson.gres_RT` evaluated at
Z = Pv/RT gives phi on EVERY branch — including the mechanically unstable
middle one, which no root selector will ever return. That is what makes the
loop in the right panel visible at all. Its P^sat comes from
`vlekit.cubic.psat`, which solves f^L = f^V and knows nothing about areas.

THE TWO ANSWERS MUST AGREE, and the figure prints both and their difference.
They agree because they are the same statement: equal areas is
integral v dP = 0 along the isotherm from liquid to vapour, which is
g^V - g^L = 0, which is RT ln(f^V/f^L) = 0. The residual difference printed on
the figure is the tolerance of two different root-finders, not physics, and the
figure says so rather than presenting coincidence as confirmation.

ASSUMED: nothing beyond the library Tc, Pc and omega for n-butane, the 1976
alpha function, and the choice of 400 K — picked because both spinodal
pressures are positive there, so the whole construction fits on one linear
axis without a negative-pressure excursion.

Run:  python3 f2_05.py
"""
from __future__ import annotations

import os
import sys

import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                  # noqa: E402

from vlekit.cubic import PengRobinson, R, SQRT2, psat            # noqa: E402
from vlekit.data import LIBRARY                                  # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,      # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, use_style)

OUT = os.environ.get("F2_OUT", "/home/claude/vle2/qmd/figures")
SLUG = "f2_05_maxwell_equal_area_fugacity"

NAME = "n-butane"
T = 400.0                     # K
V_HI = 1300.0e-6              # m^3/mol, right edge of the isotherm drawn
P_TOP = 4200.0                # kPa, top of the P axis (sets the left edge)


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


# --------------------------------------------------------------------------
def make():
    c = LIBRARY[NAME]
    mix = PengRobinson([c])
    x = np.array([1.0])
    b = mix.b_mix(x)
    a = mix.a_mix(T, x)

    def P_of_v(v):
        """Peng-Robinson pressure, kPa, from molar volume in m^3/mol."""
        return (R * T / (v - b) - a / (v * (v + b) + b * (v - b))) / 1e3

    def F_of_v(v):
        """The antiderivative of P(v) dv, in J/mol (P in Pa)."""
        return (R * T * np.log(v - b)
                + a / (2 * SQRT2 * b)
                * np.log((v + (1 + SQRT2) * b) / (v + (1 - SQRT2) * b)))

    def dPdv(v):
        h = v * 1e-8
        return (P_of_v(v + h) - P_of_v(v - h)) / (2 * h)

    # --- the two spinodals: the turning points of the isotherm
    vg = np.geomspace(1.0005 * b, 1.0, 20000)
    dd = np.array([dPdv(v) for v in vg])
    s = np.where(np.sign(dd[:-1]) != np.sign(dd[1:]))[0]
    vsp = [float(brentq(dPdv, vg[i], vg[i + 1], xtol=1e-18, rtol=8.9e-16))
           for i in s]
    v_sl, v_sv = min(vsp), max(vsp)
    P_sl, P_sv = P_of_v(v_sl), P_of_v(v_sv)

    def roots_v(P):
        Z = mix.Z_roots(T, P, x)
        return np.sort(Z * R * T / (P * 1e3))

    # --- P^sat by equal areas
    def maxwell(P):
        v = roots_v(P)
        if v.size < 3:
            return np.nan
        return F_of_v(v[2]) - F_of_v(v[0]) - P * 1e3 * (v[2] - v[0])

    P_max = float(brentq(maxwell, 1.0001 * P_sl, 0.9999 * P_sv,
                         xtol=1e-11, rtol=8.9e-16))
    # --- P^sat by equality of fugacity, from the package
    P_fug = float(psat(mix, 0, T))

    v0, v1, v2 = roots_v(P_max)
    A1 = float(quad(lambda q: (P_of_v(q) - P_max) * 1e3, v0, v1, limit=300)[0])
    A2 = float(quad(lambda q: (P_of_v(q) - P_max) * 1e3, v1, v2, limit=300)[0])
    A1_x = float(F_of_v(v1) - F_of_v(v0) - P_max * 1e3 * (v1 - v0))
    A2_x = float(F_of_v(v2) - F_of_v(v1) - P_max * 1e3 * (v2 - v1))

    # --- the isotherm, and the fugacity along every branch of it
    v_lo = float(brentq(lambda v: P_of_v(v) - P_TOP, 1.0001 * b, v_sl))
    v = np.sort(np.unique(np.concatenate([
        np.geomspace(v_lo, V_HI, 2400), [v_sl, v_sv, v0, v1, v2]])))
    P = np.array([P_of_v(q) for q in v])
    Z = P * 1e3 * v / (R * T)
    lnphi = np.array([mix.gres_RT(T, p, x, z) for p, z in zip(P, Z)])
    f = np.exp(lnphi) * P

    f_sat = float(np.exp(mix.gres_RT(T, P_max, x,
                                     P_max * 1e3 * v0 / (R * T))) * P_max)
    f_satV = float(np.exp(mix.gres_RT(T, P_max, x,
                                      P_max * 1e3 * v2 / (R * T))) * P_max)

    return dict(c=c, mix=mix, b=b, a=a, v=v, P=P, f=f, lnphi=lnphi,
                P_max=P_max, P_fug=P_fug, v0=v0, v1=v1, v2=v2,
                A1=A1, A2=A2, A1_x=A1_x, A2_x=A2_x,
                v_sl=v_sl, v_sv=v_sv, P_sl=P_sl, P_sv=P_sv, v_lo=v_lo,
                f_sat=f_sat, f_satV=f_satV, P_of_v=P_of_v)


# --------------------------------------------------------------------------
def build(d):
    use_style()
    fig = plt.figure(figsize=(14.6, 7.8))
    gs = fig.add_gridspec(1, 2, width_ratios=[1.0, 1.0],
                          left=0.055, right=0.985, top=0.835, bottom=0.295,
                          wspace=0.20)
    ax = fig.add_subplot(gs[0, 0])
    bx = fig.add_subplot(gs[0, 1])
    for a in (ax, bx):
        a.grid(True, zorder=0)
        a.set_axisbelow(True)

    vc = d["v"] * 1e6                    # cm3/mol
    Pb = d["P"] / 100.0                  # bar
    Ps = d["P_max"] / 100.0
    v0, v1, v2 = d["v0"] * 1e6, d["v1"] * 1e6, d["v2"] * 1e6
    XLO, XHI = d["v_lo"] * 1e6, V_HI * 1e6
    YLO, YHI = 13.0, P_TOP / 100.0

    # =========================================================== (a)  P vs v
    inside = (vc >= v0) & (vc <= v2)
    ax.fill_between(vc, Pb, Ps, where=inside & (vc <= v1), color=TEAL,
                    alpha=0.28, interpolate=True, zorder=2)
    ax.fill_between(vc, Pb, Ps, where=inside & (vc >= v1), color=AMBER,
                    alpha=0.32, interpolate=True, zorder=2)
    ax.plot(vc, Pb, "-", color=GRAPHITE, lw=2.8, zorder=6)
    ax.plot([XLO, XHI], [Ps, Ps], "-", color=RUST, lw=2.4, zorder=5)
    ax.plot([v0, v1, v2], [Ps, Ps, Ps], "o", color=RUST, ms=11, mec=PAPER,
            mew=1.8, zorder=9)
    for vs, Pss in ((d["v_sl"] * 1e6, d["P_sl"] / 100.0),
                    (d["v_sv"] * 1e6, d["P_sv"] / 100.0)):
        ax.plot([vs], [Pss], "s", color=GRAPHITE, ms=9, mfc=PAPER, mew=1.8,
                zorder=9)

    ax.set_xlim(XLO, XHI)
    ax.set_ylim(YLO, YHI)
    ax.set_xlabel("molar volume  $v$ / cm$^3$ mol$^{-1}$")
    ax.set_ylabel("$P$ / bar")
    ax.set_title(f"(a)  the isotherm: equal areas fix $P^{{\\rm sat}}$",
                 fontsize=13.5, pad=8, loc="left", x=0.0)

    ax.text(0.5 * (v0 + v1), Ps - 4.6, "$A_1$", ha="center", va="center",
            fontsize=15, color=TEAL, zorder=10)
    ax.text(0.5 * (v1 + v2), Ps + 1.25, "$A_2$", ha="center", va="center",
            fontsize=15, color=AMBER, zorder=10)

    # everything above P = 29 bar and to the right of v = 200 is empty, so the
    # arithmetic block goes there
    ax.text(0.985, 0.985,
            f"$P^{{\\rm sat}}$ (equal areas) = {Ps:.4f} bar\n"
            f"$v^L$ = {v0:.2f},  $v^V$ = {v2:.2f} cm$^3$/mol\n"
            f"$A_1$ = {d['A1']:+.4f} J/mol   (below the line)\n"
            f"$A_2$ = {d['A2']:+.4f} J/mol   (above it)\n"
            f"$A_1 + A_2$ = {d['A1'] + d['A2']:+.2e} J/mol",
            transform=ax.transAxes, ha="right", va="top", fontsize=11.5,
            color=INK, zorder=10, linespacing=1.55,
            bbox=dict(boxstyle="round,pad=0.30", fc=PAPER, ec=MIST, lw=1.1,
                      alpha=0.96))

    ax.annotate("liquid spinodal\n"
                f"{d['P_sl'] / 100:.3f} bar",
                xy=(d["v_sl"] * 1e6, d["P_sl"] / 100.0),
                xytext=(0.175, 0.030), textcoords="axes fraction",
                ha="left", va="bottom", fontsize=10.5, color=GRAPHITE,
                zorder=10, linespacing=1.45,
                bbox=dict(boxstyle="round,pad=0.24", fc=PAPER, ec=MIST,
                          lw=1.0, alpha=0.96),
                arrowprops=dict(arrowstyle="-", color=GRAPHITE, lw=1.1,
                                shrinkA=4, shrinkB=6))
    ax.annotate("vapour spinodal\n"
                f"{d['P_sv'] / 100:.3f} bar",
                xy=(d["v_sv"] * 1e6, d["P_sv"] / 100.0),
                xytext=(0.200, 0.620), textcoords="axes fraction",
                ha="left", va="bottom", fontsize=10.5, color=GRAPHITE,
                zorder=10, linespacing=1.45,
                bbox=dict(boxstyle="round,pad=0.24", fc=PAPER, ec=MIST,
                          lw=1.0, alpha=0.96),
                arrowprops=dict(arrowstyle="-", color=GRAPHITE, lw=1.1,
                                shrinkA=4, shrinkB=6))
    ax.text(XHI - 0.015 * (XHI - XLO), Ps + 0.45,
            f"$P^{{\\rm sat}}$ = {Ps:.4f} bar", ha="right", va="bottom",
            fontsize=12, color=RUST, zorder=10,
            bbox=dict(boxstyle="round,pad=0.22", fc=PAPER, ec="none",
                      alpha=0.90))

    # =========================================================== (b)  f vs P
    liq = vc <= d["v_sl"] * 1e6
    mid = (vc >= d["v_sl"] * 1e6) & (vc <= d["v_sv"] * 1e6)
    vap = vc >= d["v_sv"] * 1e6
    bx.plot(Pb[liq], d["f"][liq], "-", color=NAVY, lw=3.0, zorder=6,
            label="liquid branch  ($v$ below the liquid spinodal)")
    bx.plot(Pb[mid], d["f"][mid], ":", color=GRAPHITE, lw=2.6, zorder=5,
            label="the middle root: mechanically unstable")
    bx.plot(Pb[vap], d["f"][vap], "-", color=TEAL, lw=3.0, zorder=6,
            label="vapour branch  ($v$ above the vapour spinodal)")
    bx.axvline(Ps, color=RUST, lw=2.0, ls=(0, (5, 3)), zorder=3)
    bx.plot([Ps], [d["f_sat"]], "o", color=RUST, ms=13, mec=PAPER, mew=2.0,
            zorder=10)
    for vs, Pss in ((d["v_sl"] * 1e6, d["P_sl"] / 100.0),
                    (d["v_sv"] * 1e6, d["P_sv"] / 100.0)):
        j = int(np.argmin(np.abs(vc - vs)))
        bx.plot([Pss], [d["f"][j]], "s", color=GRAPHITE, ms=9, mfc=PAPER,
                mew=1.8, zorder=9)

    bx.set_xlim(YLO, 46.0)
    bx.set_ylim(1330.0, 2080.0)
    bx.set_xlabel("$P$ / bar")
    bx.set_ylabel("fugacity  $f$ / kPa")
    bx.set_title("(b)  the same isotherm as a fugacity: $f^L = f^V$ fixes it "
                 "too", fontsize=13.5, pad=8, loc="left", x=0.0)
    bx.legend(loc="upper left", fontsize=10.6, labelspacing=0.65,
              bbox_to_anchor=(0.015, 0.995))

    dP = d["P_max"] - d["P_fug"]
    bx.text(0.985, 0.030,
            f"$P^{{\\rm sat}}$, equal areas  = {d['P_max']:.7f} kPa\n"
            f"$P^{{\\rm sat}}$, $f^L = f^V$     = {d['P_fug']:.7f} kPa\n"
            f"difference {dP:+.3e} kPa  ({dP / d['P_fug']:+.2e})\n"
            f"$f^L = f^V$ = {d['f_sat']:.4f} kPa,  "
            f"$\\phi^{{\\rm sat}}$ = {d['f_sat'] / d['P_max']:.6f}\n"
            "the two are the same statement, so this\n"
            "residual is solver tolerance, not physics",
            transform=bx.transAxes, ha="right", va="bottom", fontsize=11.2,
            color=INK, zorder=11, linespacing=1.55,
            bbox=dict(boxstyle="round,pad=0.30", fc=PAPER, ec=RUST, lw=1.3,
                      alpha=0.97))

    fig.text(0.5, 0.945,
             "Equal areas and equal fugacities are one statement: "
             r"$\int_{v^L}^{v^V} v\,\mathrm{d}P = g^V - g^L = "
             r"RT\ln(f^V/f^L) = 0$",
             ha="center", va="center", fontsize=15.5, color=INK)

    c = d["c"]
    fig.text(0.5, 0.012,
             f"{NAME} at {T:g} K ($T_r$ = {T / c.Tc:.3f}), Peng-Robinson with "
             f"$T_c$ = {c.Tc:g} K, $P_c$ = {c.Pc / 100:g} bar, "
             f"$\\omega$ = {c.omega:g}  [{c.source}], 1976 $\\alpha$.\n"
             "LEFT: $P^{\\rm sat}$ from Brent on "
             "$F(v^V) - F(v^L) - P^{\\rm sat}(v^V - v^L)$, with $F$ the "
             "closed-form antiderivative of $P(v)$;\n"
             "the two areas are then re-integrated numerically with "
             "`scipy.integrate.quad` as an independent check.\n"
             "RIGHT: $\\ln\\phi = G^{\\rm res}/RT$ from "
             "`PengRobinson.gres_RT` at $Z = Pv/RT$ along the same isotherm — "
             "that is what puts the unstable middle branch on the figure;\n"
             "$P^{\\rm sat}$ from `vlekit.cubic.psat`. Open squares are the "
             "spinodals, where a branch runs out of roots.\n"
             f"ASSUMED: only the constants above and the choice of {T:g} K, "
             "picked because both spinodal pressures are positive there so "
             "the construction fits on one linear axis.\n"
             f"Quadrature check: $A_1 + A_2$ = {d['A1'] + d['A2']:+.2e} J/mol "
             f"against the closed form's {d['A1_x'] + d['A2_x']:+.2e} J/mol.",
             ha="center", va="bottom", fontsize=10.2, color=SLATE,
             linespacing=1.6)
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = make()
    c = d["c"]
    print(f"F2.5  {NAME} at T = {T:g} K  (Tr = {T / c.Tc:.4f})")
    print(f"  {d['mix']!r}; Tc = {c.Tc:g} K, Pc = {c.Pc:g} kPa, "
          f"omega = {c.omega:g}   [{c.source}]")
    print(f"  b = {d['b']:.6e} m3/mol, a({T:g} K) = {d['a']:.6f} J m3/mol2")
    print(f"  liquid spinodal: v = {d['v_sl'] * 1e6:.4f} cm3/mol, "
          f"P = {d['P_sl']:.4f} kPa = {d['P_sl'] / 100:.4f} bar")
    print(f"  vapour spinodal: v = {d['v_sv'] * 1e6:.4f} cm3/mol, "
          f"P = {d['P_sv']:.4f} kPa = {d['P_sv'] / 100:.4f} bar")
    print()
    print(f"  P^sat, equal-area construction : {d['P_max']:.10f} kPa")
    print(f"  P^sat, f^L = f^V (cubic.psat)  : {d['P_fug']:.10f} kPa")
    dP = d["P_max"] - d["P_fug"]
    print(f"  difference                     : {dP:+.6e} kPa  "
          f"({dP / d['P_fug']:+.4e} relative)")
    print()
    print(f"  v^L = {d['v0'] * 1e6:.5f}, v_mid = {d['v1'] * 1e6:.5f}, "
          f"v^V = {d['v2'] * 1e6:.5f} cm3/mol")
    print(f"  area below the line A1 = {d['A1']:+.8f} J/mol   "
          f"(closed form {d['A1_x']:+.8f})")
    print(f"  area above the line A2 = {d['A2']:+.8f} J/mol   "
          f"(closed form {d['A2_x']:+.8f})")
    print(f"  A1 + A2 = {d['A1'] + d['A2']:+.3e} J/mol   "
          f"(closed form {d['A1_x'] + d['A2_x']:+.3e})")
    print(f"  f^L = {d['f_sat']:.8f} kPa, f^V = {d['f_satV']:.8f} kPa, "
          f"|f^L - f^V| = {abs(d['f_sat'] - d['f_satV']):.3e} kPa")
    print(f"  phi^sat = {d['f_sat'] / d['P_max']:.8f}")
    print("     v/cm3      P/bar        f/kPa")
    for q in (d["v_lo"] * 1e6, 160.0, d["v_sl"] * 1e6, d["v0"] * 1e6,
              d["v1"] * 1e6, d["v_sv"] * 1e6, d["v2"] * 1e6, 1000.0, 1300.0):
        j = int(np.argmin(np.abs(d["v"] * 1e6 - q)))
        print(f"  {d['v'][j] * 1e6:9.3f}  {d['P'][j] / 100:9.4f}  "
              f"{d['f'][j]:11.4f}")
    for p in write(build(d), SLUG):
        print("wrote", p)
