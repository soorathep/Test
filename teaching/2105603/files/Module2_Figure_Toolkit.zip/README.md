# Module 2 lecture figures — 2105603 Advanced Chemical Engineering Thermodynamics

**Fugacity, chemical potential and the equilibrium criterion.**
Soorathep Kheawhom, Chulalongkorn University.

Standalone scripts, one per figure. Each writes a PNG **and** a PDF of the same
render into `/home/claude/vle2/qmd/figures/` at 300 dpi and prints, to stdout,
every number it computed and every path it wrote.

```
cd /home/claude/vle2/toolkit
python3 f2_01.py          # ... f2_02, f2_03, f2_04, f2_05
for f in f2_*.py; do python3 "$f"; done
```

Every script adds `/home/claude/vlekit` to `sys.path` and does its physics with
`vlekit` — `cubic` (`PengRobinson.ln_phi`, `.phi`, `.gres_RT`, `.Z_roots`,
`.a_mix`, `.b_mix`, and `psat`) and `data` (`LIBRARY`, `Component`). Colours and
rcParams come from `vlekit.plots` (NAVY, SKYBLUE, TEAL, AMBER, RUST, GRAPHITE,
SLATE, MIST, INK, PAPER — no others). The output directory can be overridden
with the `F2_OUT` environment variable.

**`vlekit` was not modified for this set.** `python3 -m pytest -q` in
`/home/claude/vlekit` gives **238 passed** before and after, so the baseline
holds trivially.

**Rule for this set: no number printed on a figure was typed in.** Each is the
value a run of the code returned. Where an input is a *choice* rather than a
measurement, the figure says so on its own face and the relevant row below
repeats it.

---

## The figures

| file | figure | the one claim it supports | assumed / chosen inputs, all stated on the figure |
|---|---|---|---|
| `f2_01.py` | F2.1 `f2_01_mu_vs_P_ideal_real` | The logarithm in `μ − μ° = RT ln(f/P°)` does two things at once: it separates the real fluid from the ideal gas at high pressure, and it destroys **both** of them at `P = 0` — which is why no zero-pressure reference state exists. | **Fluid and temperature: n-butane at 450 K** (`T_r` = 1.0585), chosen because it is just supercritical, so there is one root everywhere and no saturation discontinuity. **`P° = 100 kPa` and an ideal-gas standard state** — a definition, not a measurement, and labelled as such. `T_c`, `P_c`, `ω` are the library values; 1976 α function. |
| `f2_02.py` | F2.2 `f2_02_generalised_phi_chart` | A "generalised" fugacity-coefficient chart is a one-parameter fiction: fix ω and the whole chart follows from Peng-Robinson, and a real fluid at the same `T_r` departs from it by a computable amount. Below `T_c` the vapour curve must stop at `P_r^sat`. | **ω = 0 on every solid curve** — that single choice is what "generalised" means here. Implemented as a `data.Component` with `T_c` = 300 K, `P_c` = 5000 kPa, which cancel out of `φ(T_r, P_r)` and are printed only so the run can be repeated. `T_r` = 0.8, 0.9, 1.0, 1.2, 1.5, 2.0, 4.0 and `P_r` = 0.05–10 are choices of range. The dotted overlay is **n-butane, library ω = 0.200**, at `T_r` = 1.2. |
| `f2_03.py` | F2.3 `f2_03_fugacity_across_saturation` | The equation of state offers a liquid fugacity and a vapour fugacity at every pressure; the equilibrium criterion picks one, and they are equal only at `P^sat`. The metastable continuation of each branch is a real solution of a real equation and a wrong answer to "what phase is this?". | **n-butane at 350 K** (`T_r` = 0.823), a choice. Nothing else beyond the library constants and the 1976 α function. The figure states, rather than patches, that Peng-Robinson's `P^sat` here is 1.4 % above the library Antoine value. |
| `f2_04.py` | F2.4 `f2_04_poynting_map` | The Poynting factor is negligible at ambient pressure and stops being a correction at all in anything pressurised — n-hexane passes one per cent below 2 bar. | **T = 298.15 K**, a choice; `RT` enters only as a scale factor. **`v^L` constant, independent of pressure** — that assumption *is* the Poynting factor, and the real `∫v^L dP` is smaller. `v^L` values are `vlekit.data.LIBRARY`, one number per component with no temperature attached to it. Axis ranges (0.3–1000 bar, 10–250 cm³/mol) and contour levels are choices. |
| `f2_05.py` | F2.5 `f2_05_maxwell_equal_area_fugacity` | Maxwell's equal-area construction and `f^L = f^V` are not two results that happen to agree — they are the same statement, `∫v dP = g^V − g^L = RT ln(f^V/f^L) = 0`, and the residual difference between the two computed `P^sat` is root-finder tolerance. | **n-butane at 400 K** (`T_r` = 0.941), chosen because both spinodal pressures are positive there, so the whole construction fits on one linear axis with no negative-pressure excursion. Nothing else beyond the library constants and the 1976 α function. |

---

## What each figure computed, rather than asserted

### F2.1 — n-butane, 450 K, `P°` = 100 kPa, `RT` = 3.741508 kJ/mol

| `P` / bar | `f/P` | `μ−μ°` ideal | `μ−μ°` real | `RT ln φ` |
|---|---|---|---|---|
| 0.01 | 0.99992 | −17.2303 | −17.2306 | −0.0003 |
| 1.00 | 0.99162 | 0.0000 | −0.0315 | −0.0315 |
| 10.0 | 0.91810 | +8.6151 | +8.2954 | −0.3197 |
| 50.0 | 0.62181 | +14.6369 | +12.8592 | −1.7777 |
| 150.0 | 0.32668 | +18.7473 | +14.5615 | −4.1859 |

(kJ/mol.) The two marked points come from Brent on `φ(P) − target`:
`f/P` = 0.90 at **1227.8613 kPa = 12.2786 bar** (μ falls 0.3942 kJ/mol short of
the ideal line) and `f/P` = 0.50 at **7073.5959 kPa = 70.7360 bar**
(2.5934 kJ/mol short). At the left edge of the log panel, `P` = 10⁻⁶ kPa,
`φ` = 1.00000000 and both curves are at **−68.921 kJ/mol** and still falling:
below 0.1 bar the two curves differ by at most **0.0031 kJ/mol**, against
4.19 kJ/mol at 150 bar.

### F2.2 — generalised chart, ω = 0

| `T_r` | `P_r^sat` | `φ^sat` | `φ(0.1)` | `φ(1)` | `φ(5)` | `φ(10)` |
|---|---|---|---|---|---|---|
| 0.8 | 0.25785 | 0.82990 | 0.9332 | — | — | — |
| 0.9 | 0.54228 | 0.73928 | 0.9505 | — | — | — |
| 1.0 | — | — | 0.9624 | 0.6425 | 0.2329 | 0.2105 |
| 1.2 | — | — | 0.9772 | 0.7899 | 0.4172 | 0.3742 |
| 1.5 | — | — | 0.9882 | 0.8916 | 0.6543 | 0.6091 |
| 2.0 | — | — | 0.9958 | 0.9612 | 0.8753 | 0.8744 |
| 4.0 | — | — | 1.0008 | 1.0087 | 1.0507 | 1.1174 |

The `T_r` = 0.8 and 0.9 curves stop at their saturation pressures, from
`cubic.psat`. **No isotherm drawn crosses φ = 1** — the `T_r` = 4 curve is above
it over the whole range and every other one below, which is what the shaded band
labels. The real-fluid check: n-butane (ω = 0.200) at `T_r` = 1.2 reads
**φ = 0.41810 at `P_r` = 10 against 0.37420** for ω = 0, a departure of
**11.73 %**, which is also the largest departure anywhere on the range drawn.

### F2.3 — n-butane, 350 K

* `P^sat` from `cubic.psat` = **946.452616 kPa = 9.464526 bar**.
* Library Antoine gives 932.972267 kPa, so the cubic is **+1.44 %**. Stated on
  the figure; not corrected, because both branches must come from one model.
* `f^sat` = **792.463401 kPa**, `φ^sat` = **0.837299**; the two branches agree
  there to **1.4 × 10⁻⁹ kPa**.
* Spinodals from `(∂P/∂v)_T = 0`: liquid at `v` = 1.465151×10⁻⁴ m³/mol,
  `P` = **−60.6492 bar** (negative, so the liquid root exists everywhere on the
  drawn axis); vapour at `v` = 7.419077×10⁻⁴ m³/mol, `P` = **+17.4491 bar**,
  where the vapour branch simply stops. The vapour branch is drawn to 0.995 of
  that, 17.3618 bar.
* `μ^V − μ^L = RT ln(f^V/f^L)`: −7.965 kJ/mol at 0.5 bar, −2.910 at 3 bar,
  0.0000 at `P^sat`, +0.508 at 12 bar, +1.119 at 17 bar.

### F2.4 — Poynting factor, 298.15 K, `RT` = 2478.957 J/mol

| fluid | `v^L` / cm³ mol⁻¹ | `P^sat` / kPa | `P−P^sat` for 1 % | for 10 % | Poy at 10 bar | at 100 bar |
|---|---|---|---|---|---|---|
| water | 18.07 | 3.188 | **13.650 bar** | 130.753 bar | 1.00732 | 1.07562 |
| ethanol | 58.70 | 7.895 | **4.202 bar** | 40.250 bar | 1.02396 | 1.26718 |
| n-hexane | 131.60 | 20.201 | **1.874 bar** | 17.954 bar | 1.05452 | 1.70041 |

All three `P^sat` are inside the components' Antoine ranges (checked in the
script with `Component.in_range`). The 1 % contour is the line
`v^L (P−P^sat) = 24.6664 J/mol`; the 10 % contour is 236.2698 J/mol. Corner
values of the map: `Poy(0.3 bar, 10 cm³/mol)` = 1.000121 and
`Poy(1000 bar, 250 cm³/mol)` = 2.398×10⁴. Contour labels are placed from the
closed-form contour equation, at two fixed rows of `v^L` well away from the
three marked liquids, so no label can land on one of their lines.

### F2.5 — n-butane, 400 K: the two `P^sat`, and their difference

```
P^sat, equal-area construction : 2515.7061797535 kPa
P^sat, f^L = f^V (cubic.psat)  : 2515.7061797158 kPa
difference                     : +3.766127e-08 kPa   (+1.4970e-11 relative)
```

Both to more digits than either solver's tolerance justifies, printed that way
deliberately so that the agreement is visible. **The figure says on its face
that this is solver tolerance and not a physical result**: equal areas is
`∫v dP = 0`, which is `g^V − g^L = 0`, which is `RT ln(f^V/f^L) = 0`. They are
one equation, so a difference of 1.5×10⁻¹¹ is the most the arithmetic can be
asked to show.

Supporting numbers from the same run:

* `b` = 7.243979×10⁻⁵ m³/mol, `a(400 K)` = 1.566196 J m³/mol².
* Roots at `P^sat`: `v^L` = **152.14333**, `v_mid` = 319.01939,
  `v^V` = **778.40603** cm³/mol.
* Areas about the line: `A₁` = **−96.17585944 J/mol** (numerical quadrature)
  against **−96.17585944 J/mol** (closed form); `A₂` = **+96.17585944** against
  **+96.17585944**. `A₁ + A₂` = +3.00×10⁻¹² J/mol by quadrature and
  −5.68×10⁻¹⁴ J/mol from the closed form.
* `f^L` = `f^V` = **1790.54877042 kPa**, `|f^L − f^V|` = 2.0×10⁻¹² kPa,
  `φ^sat` = **0.71174797**.
* Spinodals: liquid at `v` = 189.1891 cm³/mol, **14.6203 bar**; vapour at
  `v` = 473.8068 cm³/mol, **28.4589 bar**. Both positive, which is why 400 K was
  chosen.

---

## Two things worth saying out loud in the lecture

**The `T_r` = 4 curve is the only one above φ = 1 on F2.2.** That is not a
drawing accident: with ω = 0 the Peng-Robinson Boyle temperature sits between
`T_r` = 2 and 4 over this pressure range, and the script prints the crossing
search it ran (`no isotherm drawn here crosses φ = 1` — the `T_r` = 4 curve
starts above 1 and stays there). The shaded band is labelled from that search,
not from an expectation.

**F2.5 is a consistency check that cannot fail.** It is included because the
module's closing argument is that the equal-area construction, the equality of
Gibbs energy, and the equality of fugacity are three sentences for one fact.
A figure that showed the two answers agreeing to three digits would be evidence
of a bug; agreement to eleven is what identical equations solved by different
root-finders look like.
