#!/usr/bin/env python3
"""F2.1  Chemical potential against pressure: the ideal gas and a real fluid.

2105603 Advanced Chemical Engineering Thermodynamics — Module 2
Soorathep Kheawhom, Chulalongkorn University

    ideal gas   mu - mu0 = RT ln(P/P0)
    real fluid  mu - mu0 = RT ln(f/P0),        f = phi(T,P) P

Two things have to be visible at once, and they pull the axes in opposite
directions.

The first is that the two curves separate. On a linear pressure axis the gap
between them is RT ln phi, and for n-butane at 450 K it is worth several
kJ/mol well before the pressure reaches anything an engineer would call
extreme. Where the gap starts to matter is marked by the pressures at which
f/P has fallen to 0.9 and to 0.5, both located by Brent on phi(P) - target
rather than read off the curve.

The second is that *both* curves go to minus infinity as P goes to zero. The
logarithm does not care whether its argument is P or f, because f/P goes to 1
in that limit — the real fluid is not rescued by being real. That is the
reason a zero-pressure reference state is impossible and why every standard
state in this course is defined at a finite P0. The right panel exists only to
show that divergence: the same two curves against log P, running off the
bottom of the frame together.

n-butane at 450 K is Tr = 1.06, just above the critical temperature, so the
whole isotherm is a single phase and there is no saturation discontinuity to
explain away. Tc, Pc and omega come from `vlekit.data.LIBRARY`; the fugacity
comes from `vlekit.cubic.PengRobinson.phi` with the 1976 alpha function.

ASSUMED: the reference pressure P0 = 100 kPa (1 bar) and the reference state
is the *ideal gas* at P0, which is a definition, not a measurement. It is
labelled on the figure.

Run:  python3 f2_01.py
"""
from __future__ import annotations

import os
import sys

import numpy as np
from scipy.optimize import brentq

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                  # noqa: E402

from vlekit.cubic import PengRobinson, R                         # noqa: E402
from vlekit.data import LIBRARY                                  # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,      # noqa: E402
                          PAPER, RUST, SLATE, TEAL, use_style)

OUT = os.environ.get("F2_OUT", "/home/claude/vle2/qmd/figures")
SLUG = "f2_01_mu_vs_P_ideal_real"

NAME = "n-butane"
T = 450.0                    # K
P0 = 100.0                   # kPa, the reference pressure — ASSUMED
P_MAX = 15000.0              # kPa (150 bar)
P_LO_LIN = 2.0               # kPa, where the linear-axis curves start
P_LO_LOG = 1.0e-6            # kPa, how far down the log panel reaches
TARGETS = (0.9, 0.5)         # the f/P values to mark


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


# --------------------------------------------------------------------------
def make():
    c = LIBRARY[NAME]
    mix = PengRobinson([c])
    x = np.array([1.0])
    RT = R * T / 1000.0                       # kJ/mol

    def phi(P):
        return float(mix.phi(T, float(P), x, "stable")[0][0])

    P_lin = np.concatenate([np.geomspace(P_LO_LIN, 200.0, 260),
                            np.linspace(200.0, P_MAX, 900)[1:]])
    P_log = np.geomspace(P_LO_LOG, P_MAX, 700)

    def curves(P):
        ph = np.array([phi(p) for p in P])
        mu_id = RT * np.log(P / P0)
        mu_re = RT * np.log(ph * P / P0)
        return ph, mu_id, mu_re

    ph_lin, mu_id_lin, mu_re_lin = curves(P_lin)
    ph_log, mu_id_log, mu_re_log = curves(P_log)

    marks = []
    for t in TARGETS:
        Pt = brentq(lambda p: phi(p) - t, 1.0, P_MAX, xtol=1e-8, rtol=1e-13)
        marks.append(dict(target=t, P=float(Pt), phi=phi(Pt),
                          mu_id=RT * np.log(Pt / P0),
                          mu_re=RT * np.log(t * Pt / P0),
                          gap=RT * np.log(t)))

    # how close the two curves are over the low-pressure decades: the largest
    # separation anywhere at or below P_AGREE, computed rather than asserted
    P_agree = 10.0                              # kPa = 0.1 bar
    sel = P_log <= P_agree
    gap_lo = float(np.max(np.abs(RT * np.log(ph_log[sel]))))

    return dict(c=c, mix=mix, RT=RT, P_lin=P_lin, phi_lin=ph_lin,
                mu_id_lin=mu_id_lin, mu_re_lin=mu_re_lin,
                P_log=P_log, phi_log=ph_log, mu_id_log=mu_id_log,
                mu_re_log=mu_re_log, marks=marks, phi_max=phi(P_MAX),
                P_agree=P_agree, gap_lo=gap_lo,
                phi_agree=phi(P_agree),
                span=float(mu_id_lin[-1] - mu_id_lin[0]))


# --------------------------------------------------------------------------
def build(d):
    use_style()
    fig = plt.figure(figsize=(14.0, 7.2))
    gs = fig.add_gridspec(1, 2, width_ratios=[1.45, 1.0],
                          left=0.055, right=0.985, top=0.845, bottom=0.215,
                          wspace=0.22)
    ax = fig.add_subplot(gs[0, 0])
    bx = fig.add_subplot(gs[0, 1])
    for a in (ax, bx):
        a.grid(True, zorder=0)
        a.set_axisbelow(True)

    RT = d["RT"]

    # ================================================== (a) linear in P
    Pb = d["P_lin"] / 100.0                       # bar
    ax.fill_between(Pb, d["mu_id_lin"], d["mu_re_lin"], color=AMBER,
                    alpha=0.22, zorder=2,
                    label=r"the gap is $RT\ln\phi$")
    ax.plot(Pb, d["mu_id_lin"], "--", color=NAVY, lw=2.6, zorder=5,
            label=r"ideal gas:  $\mu-\mu^\circ = RT\ln(P/P^\circ)$")
    ax.plot(Pb, d["mu_re_lin"], "-", color=RUST, lw=2.8, zorder=6,
            label=r"real fluid:  $\mu-\mu^\circ = RT\ln(f/P^\circ)$,"
                  "\n" r"          $f$ from Peng-Robinson")

    ylo, yhi = -14.5, 21.5
    ax.set_xlim(0.0, P_MAX / 100.0)
    ax.set_ylim(ylo, yhi)
    ax.axhline(0.0, color=GRAPHITE, lw=1.0, zorder=3)
    ax.set_xlabel("$P$ / bar")
    ax.set_ylabel(r"$\mu - \mu^\circ$  /  kJ mol$^{-1}$")
    ax.set_title(f"(a)  {NAME} at {T:g} K  ($T_r$ = "
                 f"{T / d['c'].Tc:.3f}), linear in $P$",
                 fontsize=13.5, pad=8, loc="left", x=0.0)
    # Both curves live in the upper band of this panel, so everything written
    # on it goes in the lower half: the legend in the lower-right corner, the
    # two f/P callouts stacked to its left, the divergence note bottom-left.
    # The blocks below are placed in axes fractions and their vertical bands
    # (0.02-0.30, 0.30-0.40, 0.44-0.54, 0.10-0.20) do not overlap.
    ax.legend(loc="lower right", fontsize=11.2, labelspacing=0.85,
              bbox_to_anchor=(0.985, 0.020))

    for m, col, (fx, fy) in zip(d["marks"], (TEAL, RUST),
                                ((0.055, 0.44), (0.240, 0.30))):
        Pm = m["P"] / 100.0
        ax.plot([Pm, Pm], [m["mu_re"], m["mu_id"]], "-", color=col, lw=2.6,
                zorder=7)
        ax.plot([Pm, Pm], [m["mu_re"], m["mu_id"]], "o", color=col, ms=8.5,
                mec=PAPER, mew=1.5, zorder=8)
        ax.annotate(f"$f/P$ = {m['target']:.2f}  at  {Pm:.2f} bar\n"
                    f"$\\mu$ falls {abs(m['gap']):.2f} kJ/mol short",
                    xy=(Pm, 0.5 * (m["mu_re"] + m["mu_id"])),
                    xytext=(fx, fy), textcoords="axes fraction",
                    ha="left", va="bottom", fontsize=11, color=col, zorder=10,
                    linespacing=1.5,
                    bbox=dict(boxstyle="round,pad=0.30", fc=PAPER, ec=col,
                              lw=1.1, alpha=0.95),
                    arrowprops=dict(arrowstyle="-", color=col, lw=1.2,
                                    shrinkA=4, shrinkB=6))

    ax.annotate("both curves plunge here:\n"
                r"$\ln(P/P^\circ) \rightarrow -\infty$",
                xy=(0.40, -11.5), xytext=(0.055, 0.100),
                textcoords="axes fraction",
                ha="left", va="bottom", fontsize=10.5, color=GRAPHITE,
                zorder=10, linespacing=1.5,
                bbox=dict(boxstyle="round,pad=0.26", fc=PAPER, ec=MIST,
                          lw=1.0, alpha=0.95),
                arrowprops=dict(arrowstyle="->", color=GRAPHITE, lw=1.2,
                                shrinkA=4, shrinkB=3))

    # ================================================== (b) log in P
    Pbl = d["P_log"] / 100.0
    bx.semilogx(Pbl, d["mu_id_log"], "--", color=NAVY, lw=2.6, zorder=5)
    bx.semilogx(Pbl, d["mu_re_log"], "-", color=RUST, lw=2.8, zorder=4)
    bx.set_xlim(Pbl[0], Pbl[-1])
    bx.set_ylim(-72.0, 34.0)
    bx.axhline(0.0, color=GRAPHITE, lw=1.0, zorder=3)
    bx.set_xlabel("$P$ / bar    (log scale)")
    bx.set_ylabel(r"$\mu - \mu^\circ$  /  kJ mol$^{-1}$")
    bx.set_title("(b)  the same two curves against $\\log P$",
                 fontsize=13.5, pad=8, loc="left", x=0.0)

    # This panel is a single diagonal band, so the two empty regions are the
    # upper-left and lower-right triangles. One block goes in each.
    bx.annotate("no zero-pressure reference state:\n"
                r"$\mu \rightarrow -\infty$ for the ideal gas"
                "\nAND for the real fluid, because\n"
                r"$f/P \rightarrow 1$ as $P \rightarrow 0$",
                xy=(Pbl[0] * 4.0, RT * np.log(Pbl[0] * 4.0 * 100.0 / P0)),
                xytext=(0.045, 0.985), textcoords="axes fraction",
                ha="left", va="top", fontsize=11, color=RUST, zorder=10,
                linespacing=1.5,
                bbox=dict(boxstyle="round,pad=0.30", fc=PAPER, ec=RUST,
                          lw=1.1, alpha=0.95),
                arrowprops=dict(arrowstyle="->", color=RUST, lw=1.3,
                                shrinkA=6, shrinkB=3))

    bx.annotate("below "
                f"{d['P_agree'] / 100:g} bar the two curves are\n"
                f"one line here: they differ by\n"
                f"at most {d['gap_lo']:.4f} kJ/mol, against\n"
                f"{abs(RT * np.log(d['phi_max'])):.2f} kJ/mol at "
                f"{P_MAX / 100:g} bar",
                xy=(d["P_agree"] / 100.0,
                    RT * np.log(d["P_agree"] / P0) - 14.0),
                xytext=(0.985, 0.030), textcoords="axes fraction",
                ha="right", va="bottom", fontsize=10.5, color=TEAL, zorder=10,
                linespacing=1.5,
                bbox=dict(boxstyle="round,pad=0.28", fc=PAPER, ec=TEAL,
                          lw=1.0, alpha=0.95),
                arrowprops=dict(arrowstyle="->", color=TEAL, lw=1.2,
                                shrinkA=5, shrinkB=3))

    bx.plot([1.0], [0.0], "o", color=GRAPHITE, ms=9, mfc=PAPER, mew=1.8,
            zorder=9)
    bx.annotate(r"$P^\circ$ = 1 bar,  $\mu - \mu^\circ = 0$",
                xy=(1.0, 0.0), xytext=(0.985, 0.455),
                textcoords="axes fraction", ha="right", va="top",
                fontsize=10.5, color=GRAPHITE, zorder=10,
                bbox=dict(boxstyle="round,pad=0.22", fc=PAPER, ec=MIST,
                          lw=1.0, alpha=0.95),
                arrowprops=dict(arrowstyle="-", color=GRAPHITE, lw=1.1,
                                shrinkA=3, shrinkB=5))

    fig.text(0.5, 0.955,
             "The logarithm is the whole difficulty: it separates the two "
             "curves at high $P$ and it destroys both of them at $P = 0$",
             ha="center", va="center", fontsize=15.5, color=INK)

    c = d["c"]
    fig.text(0.5, 0.012,
             f"{NAME}, $T_c$ = {c.Tc:g} K, $P_c$ = {c.Pc / 100:g} bar, "
             f"$\\omega$ = {c.omega:g}  [{c.source}].\n"
             "Fugacity from `vlekit.cubic.PengRobinson.phi`, 1976 "
             "$\\alpha$ function, root chosen by lower $G$; at "
             f"$T_r$ = {T / c.Tc:.3f} there is only one root, so no phase "
             "choice arises.\n"
             f"ASSUMED (a definition, not a measurement): $P^\\circ$ = "
             f"{P0:g} kPa and the standard state is the ideal gas at "
             f"$P^\\circ$.  $RT$ = {RT:.4f} kJ/mol at {T:g} K.\n"
             f"At {P_MAX / 100:g} bar, $f/P$ = {d['phi_max']:.4f}, so "
             f"$\\mu$ falls {abs(RT * np.log(d['phi_max'])):.2f} kJ/mol "
             "short of the ideal-gas value.",
             ha="center", va="bottom", fontsize=10.2, color=SLATE,
             linespacing=1.6)
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = make()
    c = d["c"]
    print(f"F2.1  {NAME} at T = {T:g} K   (Tr = {T / c.Tc:.4f})")
    print(f"  {d['mix']!r}")
    print(f"  Tc = {c.Tc:g} K, Pc = {c.Pc:g} kPa, omega = {c.omega:g}"
          f"   [{c.source}]")
    print(f"  P0 = {P0:g} kPa (ASSUMED), RT = {d['RT']:.6f} kJ/mol")
    print("   P/bar      phi      mu_ideal    mu_real   RT ln phi  (kJ/mol)")
    for Pb in (0.01, 0.1, 1.0, 5.0, 10.0, 20.0, 50.0, 100.0, 150.0):
        P = Pb * 100.0
        ph = float(d["mix"].phi(T, P, np.array([1.0]), "stable")[0][0])
        mi = d["RT"] * np.log(P / P0)
        mr = d["RT"] * np.log(ph * P / P0)
        print(f"  {Pb:7.2f}  {ph:8.5f}  {mi:9.4f}  {mr:9.4f}  {mr - mi:9.4f}")
    for m in d["marks"]:
        print(f"  f/P = {m['target']:.2f} at P = {m['P']:.4f} kPa "
              f"= {m['P'] / 100:.4f} bar; mu_ideal = {m['mu_id']:.4f}, "
              f"mu_real = {m['mu_re']:.4f}, gap = {m['gap']:.4f} kJ/mol")
    print(f"  lowest pressure drawn: {P_LO_LOG:g} kPa -> "
          f"mu - mu0 = {d['mu_id_log'][0]:.3f} kJ/mol (ideal), "
          f"{d['mu_re_log'][0]:.3f} (real); phi there = {d['phi_log'][0]:.8f}")
    for p in write(build(d), SLUG):
        print("wrote", p)
