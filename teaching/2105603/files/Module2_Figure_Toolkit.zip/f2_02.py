#!/usr/bin/env python3
"""F2.2  A generalised fugacity-coefficient chart, computed rather than scanned.

2105603 Advanced Chemical Engineering Thermodynamics — Module 2
Soorathep Kheawhom, Chulalongkorn University

The chart in the back of every textbook is a two-parameter corresponding-states
correlation: phi is read as a function of Tr and Pr alone. This one is the same
object, but every point on it is a call to `vlekit.cubic.PengRobinson.ln_phi`,
so its provenance is a line of code rather than a photocopy.

WHICH FLUID IS THIS?  None. Peng-Robinson in reduced form depends on Tr, Pr and
omega only:

    A = Omega_a alpha(Tr, omega) Pr / Tr^2,     B = Omega_b Pr / Tr

so fixing omega fixes the whole chart. The curves here are omega = 0 — the
honest choice for a chart with no third parameter, and the value for which the
Pitzer expansion phi = phi0 (phi1)^omega reduces to its simple-fluid term. It
is implemented as a `data.Component` with Tc = 300 K and Pc = 5000 kPa and
omega = 0; those two numbers cancel out of the answer and are printed only so
that the calculation can be repeated.

A REAL FLUID DEPARTS FROM IT, and the size of the departure is drawn rather
than asserted: the dotted curve is n-butane (omega = 0.200, the library value)
at the same Tr = 1.2. At Pr = 10 the two differ by the amount printed on the
figure. Anything with a larger omega — methanol at 0.564, water at 0.345 —
departs further, and a polar fluid is not described by either curve.

BELOW Tc THE CURVE STOPS AT THE SATURATION PRESSURE. Continuing a vapour-branch
phi past Pr_sat draws the fugacity coefficient of a liquid on a chart labelled
for a gas. The termini are located with `vlekit.cubic.psat`, which solves
g^L = g^V on the same equation of state, and they are marked.

Run:  python3 f2_02.py
"""
from __future__ import annotations

import os
import sys

import numpy as np

sys.path.insert(0, "/home/claude/vlekit")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                  # noqa: E402
from matplotlib.transforms import blended_transform_factory      # noqa: E402

from vlekit.cubic import PengRobinson, psat                      # noqa: E402
from vlekit.data import Component, LIBRARY                       # noqa: E402
from vlekit.plots import (AMBER, GRAPHITE, INK, MIST, NAVY,      # noqa: E402
                          PAPER, RUST, SKYBLUE, SLATE, TEAL, use_style)

OUT = os.environ.get("F2_OUT", "/home/claude/vle2/qmd/figures")
SLUG = "f2_02_generalised_phi_chart"

OMEGA = 0.0                    # the whole content of the "generalised" claim
TC_REF, PC_REF = 300.0, 5000.0  # arbitrary; they cancel out of phi(Tr, Pr)
TR = (0.8, 0.9, 1.0, 1.2, 1.5, 2.0, 4.0)
COLS = (NAVY, SKYBLUE, TEAL, AMBER, RUST, SLATE, GRAPHITE)
PR_LO, PR_HI = 0.05, 10.0
TR_REAL = 1.2                  # the Tr at which a real fluid is overlaid
REAL = "n-butane"


def write(fig, slug, out=OUT):
    os.makedirs(out, exist_ok=True)
    paths = []
    for ext in ("png", "pdf"):
        p = os.path.join(out, f"{slug}.{ext}")
        fig.savefig(p, bbox_inches="tight", pad_inches=0.03, dpi=300)
        paths.append(p)
    plt.close(fig)
    return paths


# --------------------------------------------------------------------------
def branch(mix, Tc, Pc, Tr, pr_hi=PR_HI, n=400):
    """phi against Pr along one reduced isotherm, stopped at saturation.

    Returns (Pr, phi, Pr_sat, phi_sat). Pr_sat is nan at or above Tc, where
    there is no saturation pressure and the isotherm runs the whole way.
    """
    x = np.array([1.0])
    T = Tr * Tc
    Ps = psat(mix, 0, T) if Tr < 1.0 else np.nan
    pr_end = pr_hi if not np.isfinite(Ps) else min(pr_hi, Ps / Pc)
    pr = np.geomspace(PR_LO, pr_end, n)
    ph = np.array([float(mix.phi(T, p * Pc, x, "vapour")[0][0]) for p in pr])
    if np.isfinite(Ps):
        ph_s = float(mix.phi(T, Ps, x, "vapour")[0][0])
        return pr, ph, Ps / Pc, ph_s
    return pr, ph, np.nan, np.nan


def make():
    gen = Component(name=f"generalised fluid, omega = {OMEGA:g}",
                    A=np.nan, B=np.nan, C=np.nan,
                    Tc=TC_REF, Pc=PC_REF, omega=OMEGA,
                    source="not a substance: a corresponding-states surface")
    mix = PengRobinson([gen])

    curves = {}
    for Tr in TR:
        curves[Tr] = branch(mix, TC_REF, PC_REF, Tr)

    creal = LIBRARY[REAL]
    mreal = PengRobinson([creal])
    real = branch(mreal, creal.Tc, creal.Pc, TR_REAL)

    # the departure of the real fluid from the generalised curve, at the ends
    gen_at = np.interp(np.log(real[0]), np.log(curves[TR_REAL][0]),
                       curves[TR_REAL][1])
    dev = np.abs(real[1] / gen_at - 1.0)
    j = int(np.argmax(dev))

    # where phi crosses 1 on each supercritical isotherm, if it does
    cross = {}
    for Tr in TR:
        pr, ph, _, _ = curves[Tr]
        s = np.where((ph[:-1] - 1.0) * (ph[1:] - 1.0) < 0)[0]
        if s.size:
            i = s[-1]
            w = (1.0 - ph[i]) / (ph[i + 1] - ph[i])
            cross[Tr] = float(np.exp(np.log(pr[i])
                                     + w * (np.log(pr[i + 1]) - np.log(pr[i]))))

    return dict(gen=gen, mix=mix, curves=curves, real=real, creal=creal,
                dev_max=float(dev[j]), dev_pr=float(real[0][j]),
                dev_end=float(abs(real[1][-1] / gen_at[-1] - 1.0)),
                real_end=float(real[1][-1]),
                gen_end=float(gen_at[-1]), cross=cross)


# --------------------------------------------------------------------------
def build(d):
    use_style()
    fig, ax = plt.subplots(figsize=(12.8, 8.4))
    fig.subplots_adjust(left=0.075, right=0.845, top=0.905, bottom=0.255)
    ax.grid(True, which="both", zorder=0)
    ax.set_axisbelow(True)

    XLO, XHI = 0.045, 11.0
    YLO, YHI = 0.055, 1.75
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlim(XLO, XHI)
    ax.set_ylim(YLO, YHI)

    # curve labels live in the margin to the right of the frame: x in axes
    # fractions, y in data coordinates, so a label cannot drift off its curve
    marg = blended_transform_factory(ax.transAxes, ax.transData)

    # the repulsion band, shaded once across the whole width
    ax.axhspan(1.0, YHI, color=MIST, alpha=0.35, zorder=1)
    ax.axhline(1.0, color=GRAPHITE, lw=1.4, ls=(0, (6, 3)), zorder=3)

    sat_pr, sat_phi = [], []
    for Tr, col in zip(TR, COLS):
        pr, ph, prs, phs = d["curves"][Tr]
        ax.plot(pr, ph, "-", color=col, lw=2.4, zorder=5)
        if np.isfinite(prs):
            ax.plot([prs], [phs], "o", color=col, ms=10, mec=PAPER, mew=1.8,
                    zorder=8)
            sat_pr.append(prs)
            sat_phi.append(phs)
        elif Tr == TR_REAL:
            # this one shares the margin with the real-fluid curve, so it is
            # pushed down and given a leader rather than sat on its own end
            ax.annotate(f"$T_r$ = {Tr:g},  $\\omega$ = {OMEGA:g}",
                        xy=(PR_HI, ph[-1]),
                        xytext=(1.025, 0.315), textcoords=marg,
                        ha="left", va="center", fontsize=12, color=col,
                        zorder=9,
                        bbox=dict(boxstyle="round,pad=0.18", fc=PAPER,
                                  ec="none", alpha=0.90),
                        arrowprops=dict(arrowstyle="-", color=col, lw=1.1,
                                        shrinkA=3, shrinkB=4))
        else:
            ax.text(1.025, ph[-1], f"$T_r$ = {Tr:g}", transform=marg,
                    ha="left", va="center", fontsize=12, color=col, zorder=9,
                    bbox=dict(boxstyle="round,pad=0.18", fc=PAPER, ec="none",
                              alpha=0.90))

    # the real fluid, same Tr, different omega
    prr, phr, _, _ = d["real"]
    ax.plot(prr, phr, ":", color=AMBER, lw=3.0, zorder=6)
    ax.text(1.025, phr[-1], f"$T_r$ = {TR_REAL:g},  {REAL}\n"
                            f"($\\omega$ = {d['creal'].omega:g})",
            transform=marg, ha="left", va="center", fontsize=11, color=AMBER,
            zorder=9, linespacing=1.45,
            bbox=dict(boxstyle="round,pad=0.18", fc=PAPER, ec="none",
                      alpha=0.90))

    # the saturation termini, joined so that the boundary reads as a locus
    ax.plot(sat_pr, sat_phi, color=INK, lw=1.6, ls=(0, (2, 2)), zorder=4)

    # ---------------------------------------------------------- annotations
    # Every curve runs across the upper part of the frame, so all four text
    # blocks are stacked in one column down the empty left side. Their
    # vertical bands are disjoint by construction: 0.59-0.72, 0.42-0.55,
    # 0.20-0.38, 0.05-0.13 in axes fractions.
    for Tr, col, ty in zip(TR[:2], COLS[:2], (0.720, 0.520)):
        pr, ph, prs, phs = d["curves"][Tr]
        ax.annotate(f"$T_r$ = {Tr:g}:  the vapour branch STOPS\n"
                    f"at $P_r^{{\\rm sat}}$ = {prs:.4f}, where "
                    f"$\\phi$ = {phs:.4f}",
                    xy=(prs, phs), xytext=(0.035, ty),
                    textcoords="axes fraction",
                    ha="left", va="top", fontsize=11.5, color=col, zorder=10,
                    linespacing=1.5,
                    bbox=dict(boxstyle="round,pad=0.28", fc=PAPER, ec=col,
                              lw=1.1, alpha=0.95),
                    arrowprops=dict(arrowstyle="-", color=col, lw=1.2,
                                    shrinkA=5, shrinkB=9))

    ax.text(0.035, 0.380,
            "The dotted line joins the two termini.\n"
            "Below it the stable phase is a vapour;\n"
            "above it, a liquid. A chart that runs a\n"
            "vapour $\\phi$ past this line is quoting a\n"
            "number for a phase that is not there.",
            transform=ax.transAxes, ha="left", va="top", fontsize=11.5,
            color=INK, zorder=10, linespacing=1.5,
            bbox=dict(boxstyle="round,pad=0.28", fc=PAPER, ec=INK, lw=1.1,
                      alpha=0.95))

    ax.text(0.020, 0.985, r"$\phi > 1$ — repulsion dominates",
            transform=ax.transAxes, ha="left", va="top", fontsize=12.5,
            color=GRAPHITE, zorder=9,
            bbox=dict(boxstyle="round,pad=0.24", fc=PAPER, ec=MIST, lw=1.0,
                      alpha=0.92))
    ax.text(0.035, 0.130, r"$\phi < 1$ — attraction dominates",
            transform=ax.transAxes, ha="left", va="top", fontsize=12.5,
            color=GRAPHITE, zorder=9,
            bbox=dict(boxstyle="round,pad=0.24", fc=PAPER, ec=MIST, lw=1.0,
                      alpha=0.92))

    ax.set_xlabel("reduced pressure   $P_r = P/P_c$      (log scale)")
    ax.set_ylabel(r"fugacity coefficient   $\phi = f/P$      (log scale)")
    ax.set_title("Generalised fugacity coefficient from Peng-Robinson, "
                 f"$\\omega$ = {OMEGA:g} — every point computed, none scanned",
                 fontsize=15.5, pad=12, loc="left", x=0.0)

    ax.set_xticks([0.05, 0.1, 0.2, 0.5, 1.0, 2.0, 5.0, 10.0])
    ax.set_xticklabels(["0.05", "0.1", "0.2", "0.5", "1", "2", "5", "10"])
    ax.set_yticks([0.06, 0.1, 0.2, 0.3, 0.5, 0.7, 1.0, 1.5])
    ax.set_yticklabels(["0.06", "0.1", "0.2", "0.3", "0.5", "0.7", "1.0",
                        "1.5"])
    ax.tick_params(which="minor", length=0)

    fig.text(0.5, 0.012,
             "$\\phi$ from `vlekit.cubic.PengRobinson.ln_phi` (1976 "
             "$\\alpha$, vapour root); the saturation termini from "
             "`vlekit.cubic.psat`, which solves $g^L = g^V$ on the same "
             "equation of state.\n"
             f"$T_c$ = {TC_REF:g} K and $P_c$ = {PC_REF:g} kPa carry the "
             "reduced variables and then cancel out of "
             "$\\phi(T_r, P_r)$: this is not a chart of any substance.\n"
             f"ONE ACENTRIC FACTOR, ASSUMED: $\\omega$ = {OMEGA:g} on every "
             "solid curve. That single choice is what \"generalised\" means "
             "here, and it is the chart's only real assumption.\n"
             f"The dotted curve is {REAL} at the same $T_r$ = {TR_REAL:g} "
             f"with its library $\\omega$ = {d['creal'].omega:.3f}: at "
             f"$P_r$ = {PR_HI:g} it reads {d['real_end']:.4f} against "
             f"{d['gen_end']:.4f}, a departure of "
             f"{100 * d['dev_end']:.1f} %,\n"
             "and the departure grows with $\\omega$. Read the solid curves "
             "as a first estimate, never as the answer.",
             ha="center", va="bottom", fontsize=10.4, color=SLATE,
             linespacing=1.6)
    return fig


# --------------------------------------------------------------------------
if __name__ == "__main__":
    d = make()
    print(f"F2.2  generalised phi chart, omega = {OMEGA:g}")
    print(f"  {d['mix']!r}; Tc = {TC_REF:g} K and Pc = {PC_REF:g} kPa are "
          "arbitrary and cancel out of phi(Tr, Pr)")
    print("   Tr      Pr_sat      phi_sat     phi(0.1)  phi(1)   phi(5)  "
          "phi(10)")
    for Tr in TR:
        pr, ph, prs, phs = d["curves"][Tr]

        def at(p):
            if p > pr[-1]:
                return float("nan")
            return float(np.interp(np.log(p), np.log(pr), ph))

        s = "   ---        ---   " if not np.isfinite(prs) \
            else f"{prs:9.5f}  {phs:9.5f}"
        print(f"  {Tr:4.1f}  {s}   {at(0.1):7.4f}  {at(1.0):7.4f}  "
              f"{at(5.0):7.4f}  {at(10.0):7.4f}")
    for Tr, p in d["cross"].items():
        print(f"  phi crosses 1 on the Tr = {Tr:g} isotherm at Pr = {p:.4f}")
    if not d["cross"]:
        print("  no isotherm drawn here crosses phi = 1")
    c = d["creal"]
    print(f"  real-fluid overlay: {REAL}, omega = {c.omega:g}, Tc = {c.Tc:g} K,"
          f" Pc = {c.Pc:g} kPa  [{c.source}]")
    print(f"    at Tr = {TR_REAL:g}: phi = {d['real_end']:.5f} at "
          f"Pr = {PR_HI:g} against {d['gen_end']:.5f} for omega = 0, "
          f"a departure of {100 * d['dev_end']:.2f} %")
    print(f"    largest departure over the range drawn: "
          f"{100 * d['dev_max']:.2f} % at Pr = {d['dev_pr']:.3f}")
    for p in write(build(d), SLUG):
        print("wrote", p)
