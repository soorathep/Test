# Optimization Modeling for Chemical Engineers, Volume 2

An independent Quarto book with 18 original problems across six themes and three levels per theme. US English. Synthetic teaching data. Volume 1 is unchanged.

## Editions

- `output/pdf/volume-2-worked.pdf`: formulations, Pyomo implementations, computed results, and discussion.
- `output/pdf/volume-2-student.pdf`: problems, prediction questions, verification prompts, and extensions, without worked answers.
- `_book/index.html`: worked HTML edition.
- `volume-2-source.zip`: editable Quarto/Python project, including worked solutions. Do not distribute this bundle as an answer-free student package.

## Build

Use the lab optimization environment and an absolute interpreter path:

```sh
uv pip install --python ~/.venvs/optim/bin/python -r requirements.txt
./scripts/build.sh
```

Quarto is resolved from `QUARTO_BIN`, `~/.local/opt/quarto/bin/quarto`, or PATH. PDF compilation requires XeLaTeX. No licensed solver is required. The bundled palette is imported locally; no palette package installation is needed.

The build explicitly selects the `instructor` and `student` profiles. Use `quarto render --profile instructor --to html` for the worked web edition, or `quarto render --profile student --to pdf` for student-only output. A render without either profile hides both profile-specific sections and is not a publication build.

## Authoring and regeneration

- `scripts/content.py`: authored statements, formulations, questions, and checks for every level.
- `models/*.py`: six topic models, each with `build(level)`, `check`, and `report`; the reference level is 1, 2, or 3.
- `models/common.py`: solver and residual/domain audit.
- `scripts/prepare_book.py`: solves all 18 instances, regenerates chapter text and tables, and runs the additional checks.
- `figures/make_figures.py`: creates all 18 vector/600 dpi figures using the lab palette.
- `chapters/`: generated Quarto sources. Make persistent edits in `scripts/content.py` or the corresponding model module.
- `results/`: solution CSV/JSON and all variable values, sensitivity sweeps, versions, and validation record.
- `scripts/verify_models.py`: independent investment enumeration and sensitivity endpoint checks.

For one result:

```sh
~/.venvs/optim/bin/python -m models.hydrogen 3
```

Full preparation runs during each Quarto build. All reported numbers come from solving the authored models. The source archive excludes outputs and regenerates them.

## Interpretation limits

Reactor optimality is for a finite menu, not continuous nonlinear design. Water treatment is segregated with fixed removal, not unrestricted pooling. Heat sources and users are isothermal surrogates. Hydrogen demand is known before dispatch within each scenario and production/withdrawal are uniform inside each period. These are deliberate teaching assumptions and appear in the chapters.

After building, run `~/.venvs/optim/bin/python scripts/verify_book.py` to check both PDF editions, fonts, text bounds, and HTML assets. The result is written to `results/publication-validation.json`.
