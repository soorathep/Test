"""Regenerate all 18 figures directly from audited optimal solutions."""

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "styles"))
import skh_palette as skh

skh.use()
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from models.common import value

plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "font.size": 10,
        "axes.labelsize": 10,
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,
        "lines.linewidth": 1.8,
    }
)


def make(name, level, m, report, number):
    fig, ax = plt.subplots(figsize=(6.8, 3.5), layout="constrained")
    if name == "blending":
        xs = [value(m.x[i]) for i in m.I]
        ax.bar(list(m.I), xs, color=skh.C["teal"] if level == 1 else skh.C["amber"])
        ax.set(xlabel="Feed", ylabel="Flow (t/d)", ylim=(0, 65))
        for j, x in enumerate(xs):
            ax.text(j, x + 1, f"{x:.1f}", ha="center")
    elif name == "reactors":
        rows = report["rows"]
        x = np.arange(len(rows))
        w = 0.34
        ax.bar(
            x - w / 2,
            [r["Desired (kmol/h)"] for r in rows],
            w,
            color=skh.CATEGORICAL[0],
            label="Desired product",
        )
        ax.bar(
            x + w / 2,
            [r["Undesired (kmol/h)"] for r in rows],
            w,
            color=skh.CATEGORICAL[1],
            label="Byproduct",
        )
        ax.axhline(
            35,
            color=skh.C["graphite"],
            linestyle="--",
            linewidth=1.5,
            label="Required desired rate",
        )
        ax.set(
            xticks=x,
            xticklabels=[r["State"].replace("_", " ") for r in rows],
            ylabel="Production (kmol/h)",
        )
        ax.legend(fontsize=8, loc="upper right")
        ax.set_ylim(0, 100)
    elif name == "heat":
        states = list(m.S)
        x = np.arange(len(states))
        w = 0.26
        rec = [sum(value(m.q[s, h, c]) for h, c in m.A) for s in states]
        hu = [sum(value(m.hu[s, c]) for c in m.C) for s in states]
        cu = [sum(value(m.cu[s, h]) for h in m.H) for s in states]
        for off, vals, label, col in zip(
            [-1, 0, 1],
            [rec, hu, cu],
            ["Recovered", "Hot utility", "Cold utility"],
            skh.CATEGORICAL,
        ):
            ax.bar(x + off * w, vals, w, label=label, color=col)
        ax.set(xticks=x, xticklabels=states, ylabel="Heat rate (kW)")
        ax.legend(fontsize=8)
    elif name == "scheduling":
        for j, r in enumerate(report["rows"]):
            ax.barh(
                j,
                r["Finish (h)"] - r["Start (h)"],
                left=r["Start (h)"],
                color=skh.CATEGORICAL[j],
                height=0.55,
            )
            ax.text(
                (r["Start (h)"] + r["Finish (h)"]) / 2,
                j,
                r["Job"],
                ha="center",
                va="center",
                color=skh.C["graphite"],
                fontweight="bold",
            )
        ax.set(xlabel="Time (h)", yticks=[], xlim=(0, 17))
        ax.invert_yaxis()
        ax.axvline(
            12,
            color=skh.C["graphite"],
            linewidth=1.5,
            linestyle="--",
            label="Shift end",
        )
        ax.legend(fontsize=8)
        ax.set_title("Gaps include cleaning or release-time waiting", fontsize=10)
    elif name == "hydrogen":
        ax.set(xlabel="Period boundary (4 h per period)", ylabel="Inventory (kg)")
        for j, s in enumerate(m.S):
            ax.plot(
                range(7),
                [50] + [value(m.stock[s, t]) for t in m.T],
                marker="o",
                markersize=4,
                color=skh.CATEGORICAL[j],
                label=s,
            )
        ax.axhline(
            value(m.k),
            color=skh.C["graphite"],
            linewidth=1.5,
            linestyle="--",
            label="Tank capacity",
        )
        ax.set_ylim(0, max(180, value(m.k) * 1.2))
        ax.legend(fontsize=8)
    else:
        rows = report["rows"]
        bottom = np.zeros(2)
        for key, col, label in zip(
            ["Fresh (m3/h)", "Direct reuse (m3/h)", "Treated reuse (m3/h)"],
            skh.CATEGORICAL,
            ["Freshwater", "Direct reuse", "Treated reuse"],
        ):
            vals = np.array([r[key] for r in rows])
            ax.bar(["U1", "U2"], vals, bottom=bottom, color=col, label=label)
            bottom += vals
        ax.set(xlabel="Water user", ylabel="Inlet flow (m³/h)", ylim=(0, 65))
        ax.legend(fontsize=8)
    ax.spines[["top", "right"]].set_visible(False)
    out = ROOT / "figures/generated" / f"problem-{number:02d}"
    out.parent.mkdir(parents=True, exist_ok=True)
    for ext in ["svg", "pdf", "png"]:
        fig.savefig(out.with_suffix("." + ext), dpi=600)
    plt.close(fig)


if __name__ == "__main__":
    from importlib import import_module
    from models.common import solve

    for topic, name in enumerate(
        ["blending", "reactors", "heat", "scheduling", "hydrogen", "water"]
    ):
        module = import_module("models." + name)
        for level in [1, 2, 3]:
            m = solve(module.build(level))
            module.check(m, level)
            make(name, level, m, module.report(m, level), topic * 3 + level)
