"""Check both editions, local HTML links, PDF text bounds, and font embedding."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import subprocess,json,re,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
TMP=ROOT/'tmp/pdfs';TMP.mkdir(parents=True,exist_ok=True)
ns={'x':'http://www.w3.org/1999/xhtml'}
summary={};errors=[]
for edition in ['worked','student']:
    path=ROOT/'output/pdf'/f'volume-2-{edition}.pdf'
    bbox=TMP/f'{edition}-bbox.html'
    subprocess.run(['pdftotext','-bbox',str(path),str(bbox)],check=True)
    text=subprocess.check_output(['pdftotext','-layout',str(path),'-'],text=True)
    pages=ET.parse(bbox).findall('.//x:page',ns)
    for i,page in enumerate(pages,1):
        for word in page.findall('x:word',ns):
            if float(word.attrib['xMax'])>float(page.attrib['width'])-22 or float(word.attrib['xMin'])<22:
                errors.append(f'{edition} page {i}: text near page edge: {word.text}')
    if edition=='student':
        for forbidden in ['Reference objective','reference objective','def build(', 'Optimal Solution','The nominal blend costs','The selected tank is']:
            if forbidden in text:errors.append(f'Answer leak in student edition: {forbidden}')
        if text.count('Formulation workspace')!=18:errors.append('Student problem count mismatch')
    else:
        if len(re.findall(r'\d+\.4 Optimal Solution',text))!=18:errors.append('Worked solution count mismatch')
    summary[edition]={'pages':len(pages),'bytes':path.stat().st_size}
for pdf in list((ROOT/'figures/generated').glob('*.pdf'))+list((ROOT/'output/pdf').glob('*.pdf')):
    fonts=subprocess.check_output(['pdffonts',str(pdf)],text=True)
    for line in fonts.splitlines()[2:]:
        bits=line.split()
        if 'Type 3' in line or (bits and bits[-5]!='yes'):errors.append(f'Font not embedded or Type 3: {pdf.name}: {line}')
class Links(HTMLParser):
    def __init__(self):super().__init__();self.urls=[]
    def handle_starttag(self,tag,attrs):
        self.urls += [v for k,v in attrs if k in ['href','src'] and v]
for page in (ROOT/'_book').rglob('*.html'):
    parser=Links();parser.feed(page.read_text())
    for url in parser.urls:
        bits=urlsplit(url)
        if bits.scheme or bits.netloc or not bits.path:continue
        target=(ROOT/'_book'/unquote(bits.path).lstrip('/')) if bits.path.startswith('/') else page.parent/unquote(bits.path)
        if not target.exists():errors.append(f'Missing resource: {page.name} -> {url}')
summary['figure_pdfs']=len(list((ROOT/'figures/generated').glob('*.pdf')))
summary['errors']=errors
(ROOT/'results/publication-validation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
assert not errors
