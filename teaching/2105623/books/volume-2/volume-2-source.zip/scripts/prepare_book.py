"""Solve, audit, and regenerate all chapters and figures from source."""

from pathlib import Path
import sys, json, importlib, importlib.metadata, inspect

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
import pandas as pd
import pyomo.environ as pyo
from models.common import solve, audit, value
from content import TOPICS
from figures.make_figures import make
from verify_models import extra_checks


def table(rows):
    return pd.DataFrame(rows).to_markdown(index=False, floatfmt=".4f")


def finding(name, level, report, all_results):
    o = report["objective"]
    m = report["metrics"]
    base = all_results[(name, 1)]["objective"]
    if name == "blending":
        if level == 1:
            return f"The nominal blend costs {o:,.2f} USD/d but reaches {m['Full-box impurity (%)']:.3f}% impurity at the full upper corner. An optimal nominal solution can therefore violate the specification under uncertainty."
        return f"The protected design costs {o:,.2f} USD/d, a premium of {o - base:,.2f} USD/d ({100 * (o / base - 1):.2f}%) over the nominal optimum. Full-box impurity is {m['Full-box impurity (%)']:.3f}%. Protection at a smaller budget must not be described as full-box protection."
    if name == "reactors":
        return (
            f"The selected {m['Reactor']} operates at {m['Temperature (K)']:.0f} K and {m['Residence time (h)']:.1f} h with feed {m['Feed (kmol/h)']:.3f} kmol/h. The objective is {o:.3f} USD/h. "
            + (
                "This is the guaranteed profit across the two activity states; state-specific profit can be higher."
                if level == 3
                else "The feed-holdup tradeoff, product selectivity, and operating cost are included in this choice."
            )
            + " Enumerating the same menu independently reproduces the optimum. Refining the menu is a different model, not a stronger claim about this result."
        )
    if name == "heat":
        return (
            f"The objective is {o:.2f} USD/d. "
            + (
                "The existing system still needs 10 kW of hot utility and rejects 10 kW because the match limits prevent full recovery."
                if level == 1
                else "The objective includes ownership charges, so its increase relative to the existing-system LP is not an efficiency loss."
            )
            + " For a physical exchanger network with varying stream temperatures, stagewise temperature balances and minimum approaches would need to replace this fixed-temperature representation."
        )
    if name == "scheduling":
        return (
            f"One optimal sequence is {m['Sequence']}, with makespan {m['Makespan (h)']:.2f} h and {m['Cleaning (h)']:.2f} h of cleaning. "
            + (
                f"Total tardiness and overtime cost is {o:.2f} USD. The cost-optimal schedule need not be the fastest schedule."
                if level == 3
                else f"The makespan is {o - base:.2f} h above the idealized no-cleaning lower bound."
            )
            + " Equivalent optimal sequences may differ across solver versions; the objective and feasibility checks are the comparison criteria."
        )
    if name == "hydrogen":
        if level == 1:
            return f"Daily electricity costs {o:.2f} USD. Total energy is {m['Expected electricity (MWh/d)']:.2f} MWh: the storage benefit comes from purchase timing, not reduced energy use."
        if level == 2:
            fair = base + 0.15 * 150
            return f"The selected tank is {m['Tank capacity (kg)']:.1f} kg. Total daily cost is {o:.2f} USD versus {fair:.2f} USD for the fixed 150 kg tank with the same ownership charge, saving {fair - o:.2f} USD/d ({100 * (1 - o / fair):.2f}%). This is a daily-equivalent planning result under uniform within-period flows."
        return f"The shared tank is {m['Tank capacity (kg)']:.1f} kg and expected daily cost is {o:.2f} USD. Expected demand is 1.025 times the original profile, so the change from the deterministic case combines a higher mean demand, uncertainty, and commitment costs. It is not a pure value-of-uncertainty comparison."
    return (
        f"The solution uses {m['Freshwater (m3/h)']:.3f} m3/h of freshwater and discharges {m['Disposal (m3/h)']:.3f} m3/h, at {o:.3f} USD/h. Treatment choice: {m['Technology']}. "
        + (
            "Even when freshwater falls to zero, 20 m3/h must leave the system because source supply exceeds user demand."
            if level == 2
            else "Contaminant removed by treatment must leave in the captured-residue stream."
        )
        + " Fixed removal and segregated paths are substantive process assumptions, not just numerical conveniences."
    )


def run():
    reports = {}
    models = {}
    valid = []
    for ti, (name, topic) in enumerate(TOPICS.items()):
        module = importlib.import_module("models." + name)
        for level in [1, 2, 3]:
            n = ti * 3 + level
            m = solve(module.build(level))
            module.check(m, level)
            r = module.report(m, level)
            reports[name, level] = r
            models[name, level] = m
            record = {
                "problem": n,
                "topic": name,
                "level": level,
                "termination": "optimal",
                "max_violation": audit(m),
                "domain_check": "passed",
                **r,
            }
            out = ROOT / "results" / f"{n:02d}"
            out.mkdir(exist_ok=True, parents=True)
            (out / "solution.json").write_text(json.dumps(record, indent=2) + "\n")
            pd.DataFrame(r["rows"]).to_csv(out / "solution.csv", index=False)
            pd.DataFrame(
                [
                    {"variable": x.name, "value": value(x)}
                    for x in m.component_data_objects(pyo.Var)
                ]
            ).to_csv(out / "variables.csv", index=False)
            make(name, level, m, r, n)
            valid.append(
                {k: v for k, v in record.items() if k not in ["rows", "metrics"]}
            )
            print(
                f"Problem {n:02d}: optimal, objective {r['objective']:.6f} {r['units']}; checks passed",
                flush=True,
            )
    checks, sweep, tank = extra_checks()
    pd.DataFrame(sweep).to_csv(ROOT / "results/uncertainty-budget.csv", index=False)
    pd.DataFrame(tank).to_csv(ROOT / "results/tank-capacity.csv", index=False)
    for ti, (name, topic) in enumerate(TOPICS.items()):
        module = importlib.import_module("models." + name)
        source = (
            inspect.getsource(module)
            .split("\ndef check(")[0]
            .split("\ndef enumerate_best(")[0]
            .split("\ndef worst_load(")[0]
        )
        for level, content in enumerate(topic["levels"], 1):
            n = ti * 3 + level
            title, kind, statement, before, form, check, extension = content
            r = reports[name, level]
            metrics = table(
                [
                    {
                        "Quantity": k,
                        "Value": f"{v:.4f}" if isinstance(v, (int, float)) else v,
                    }
                    for k, v in r["metrics"].items()
                ]
            )
            extra = ""
            if name == "blending" and level == 3:
                extra = "\n### Uncertainty-budget experiment\n\n" + table(sweep) + "\n"
            if name == "hydrogen" and level == 2:
                extra = "\n### Fixed-capacity experiment\n\n" + table(tank) + "\n"
            solution = f"""## Model Formulation

{topic["variables"]}

{form}

## Pyomo Implementation

The code below is the model-building portion of `models/{name}.py`. The `level` argument selects this problem's assumptions. Run the complete module from the source bundle to reproduce the solution, including its independent checks:

```bash
~/.venvs/optim/bin/python -m models.{name} {level}
```

```python
{source.strip()}
```

The common `solve` function calls `appsi_highs`, checks optimal termination before loading a solution, and checks constraint residuals, bounds, and integer domains. After building the model, use:

```python
from models.common import solve
m = solve(build({level}))
```

## Optimal Solution

The reference objective is **{r["objective"]:,.4f} {r["units"]}**. This value is optimal for the explicitly stated model and data.

{table(r["rows"])}

{metrics}

![{topic["name"]}: reference solution for level {level}.](../figures/generated/problem-{n:02d}.svg){{#fig-p{n:02d} fig-pos="H"}}

### Check your solution

{check}

The automated residual, bound, and integrality audit passed with a maximum violation of {audit(models[name, level]):.2e} in model units. Domain-specific checks passed. Model units differ across equations, so this numerical audit does not replace dimensional analysis.

{extra}
## Brief Discussion

{finding(name, level, r, reports)}

### Extension to investigate

{extension}
"""
            qmd = f"""# {title}

**Problem {n:02d} | {topic["name"]} | Level {level}: {kind}**

## Problem Statement

{topic["data"]}

**Your task.** {statement}

### Before you code

{before}

### Deliverables

1. Define decision variables, units, objective, and constraints. State which data and assumptions are fixed.
2. Predict one feature of the solution and explain why it should occur.
3. Build and solve a Pyomo model. Check balances and bounds independently.
4. Interpret the result and investigate the follow-up question below. For an open-ended challenge, state and defend your chosen policy separately from the reference solution.

::: {{.content-visible when-profile="student"}}
## Formulation workspace

Write the mathematical model before implementation. Identify any binary variables and justify every large constant. List one simplification that could change the engineering decision.

## Verification plan

{check}

## Follow-up investigation

{extension}

Submit your formulation, runnable code, a units-labeled result table, an independent check, and a short engineering recommendation. Numerical agreement alone is not sufficient.
:::

::: {{.content-visible when-profile="instructor"}}
{solution}
:::
"""
            (ROOT / "chapters" / f"{n:02d}-{name}.qmd").write_text(qmd)
    manifest = {
        "problems": valid,
        "independent_checks": checks,
        "versions": {
            x: importlib.metadata.version(x)
            for x in ["pyomo", "highspy", "matplotlib", "pandas"]
        },
    }
    (ROOT / "results/validation.json").write_text(json.dumps(manifest, indent=2) + "\n")
    from package_source import bundle

    bundle()


if __name__ == "__main__":
    run()
