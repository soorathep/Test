"""Authored English problem statements and mathematical explanations."""

TOPICS = {
    "blending": {
        "name": "Blending with Uncertain Feed Composition",
        "data": r"""A plant blends 100 t/d of a liquid intermediate. Impurity must not exceed 7 wt%. Costs and available flows are deterministic. Impurity has no beneficial role, so only upward deviations matter for the quality upper bound. There are no volume changes, storage, or blending losses.

| Feed | Cost (USD/t) | Available (t/d) | Nominal impurity | Maximum upward deviation |
|:--|--:|--:|--:|--:|
| A | 100 | 60 | 0.02 | 0.01 |
| B | 80 | 60 | 0.08 | 0.02 |
| C | 55 | 60 | 0.14 | 0.03 |

All fractions are mass fractions. Deviations of 0.01 mean one percentage point, not a 1% relative change.""",
        "variables": r"""Let $x_i$ be feed $i$ in t/d, with $0\le x_i\le60$. Define $c_i$ as cost, $a_i$ as nominal impurity, and $d_i$ as maximum upward deviation. Let $Q=100$ t/d and $L=0.07$.

The mass balance and cost objective are
$$\sum_i x_i=Q,\qquad \min C=\sum_i c_i x_i.$$
The impurity constraint compares impurity mass flow with $LQ$. Multiplying a fixed quality limit by the fixed product rate avoids a ratio.""",
        "levels": [
            (
                "A nominal blend",
                "Guided problem",
                "Find the least-cost blend using nominal compositions. Then evaluate that same blend when every impurity takes its upper value. Do not re-optimize during this stress test.",
                "Which feed is cheapest? Why can it not supply the entire blend? Will a minimum-cost solution necessarily leave a quality margin?",
                r"""At nominal composition, enforce
$$\sum_i a_i x_i\le LQ.$$
This is an LP: all coefficients are known constants. A binding quality constraint means the nominal design has no headroom for upward composition errors.""",
                "Independently calculate both total flow and impurity mass flow. Report the stressed composition even though the nominal solver reports an optimal solution.",
                "Predict the effect of reducing feed C availability to 20 t/d, then solve. Explain whether availability or quality now drives the result.",
            ),
            (
                "A blend protected against all upper deviations",
                "Model extension",
                r"Keep the same production target, prices, and availability. Require the specification to hold for every composition in the box $a_i\le\tilde a_i\le a_i+d_i$. Find the robust blend and the cost premium relative to Problem 1.",
                "Is testing only the average of the upper and lower compositions enough to guarantee quality? Which box corner is worst when all flows are nonnegative?",
                r"""Because $x_i\ge0$, the maximum impurity occurs at the upper corner:
$$\max_{0\le u_i\le1}\sum_i(a_i+d_i u_i)x_i=\sum_i(a_i+d_i)x_i.$$
Thus the robust counterpart is simply
$$\sum_i(a_i+d_i)x_i\le LQ.$$
No probabilities are needed. The guarantee is conditional on the stated bounds being valid.""",
                "Check all eight corners of the uncertainty box. Calculate the cost premium as $(C_{box}-C_{nominal})/C_{nominal}$, using the nominal optimum as the denominator.",
                "Reduce the allowable impurity to 6 wt%. Determine whether the available low-impurity feed still makes the robust model feasible.",
            ),
            (
                "Choosing an uncertainty budget",
                "Open-ended challenge",
                r"Use $\tilde a_i=a_i+d_i u_i$, $0\le u_i\le1$, and $\sum_i u_i\le\Gamma$. Solve the reference case $\Gamma=1.5$, then evaluate $\Gamma=0,0.5,1,1.5,2,2.5,3$. Recommend a budget and state what evidence would justify it. There is no unique correct recommendation.",
                "Does a budget of 1.5 mean that a constraint has a 50% chance of failure? Why should cost be nondecreasing as the budget grows?",
                r"""The worst additional impurity is the support function
$$W(x,\Gamma)=\max_u\left\{\sum_i d_i x_i u_i:0\le u_i\le1,\ \sum_i u_i\le\Gamma\right\}.$$
Its LP dual introduces $p\ge0$ and $q_i\ge0$, both in t/d of impurity:
$$p+q_i\ge d_i x_i,\qquad
\sum_i a_i x_i+\Gamma p+\sum_i q_i\le LQ.$$
Minimizing cost subject to these inequalities is the exact robust counterpart for this uncertainty set. For an independent check, sort $d_i x_i$ from largest to smallest, add the largest $\lfloor\Gamma\rfloor$ terms, and add the fractional part times the next term. $\Gamma=0$ gives nominal protection; $\Gamma=3$ gives full-box protection. A budget alone does not establish a probability of failure.""",
                "Check the sorted-term worst case independently of the dual variables. Confirm the two endpoints match Problems 1 and 2.",
                "Propose how historical feed assays could inform the uncertainty set. Discuss correlation and whether the box contains physically implausible combinations.",
            ),
        ],
    },
    "reactors": {
        "name": "Reactor Selection and Operating Conditions",
        "data": r"""Consider the parallel first-order reactions $A\to D$ and $A\to U$. Desired product $D$ sells for 5 USD/kmol and byproduct $U$ for 1 USD/kmol. Feed costs 1.2 USD/kmol. Fresh feed rate $F$ is at most 100 kmol/h; at least 35 kmol/h of $D$ must be produced. Unreacted feed has no recovery value. Constant density, constant temperature, and equal stoichiometric molar yields are assumed.

The synthetic kinetic functions are
$$k_D=0.5a\exp[0.025(T-330)],\qquad
k_U=0.08\exp[0.055(T-330)]\quad (\mathrm{h}^{-1}),$$
where $T$ is in K and $a$ is a dimensionless activity factor. These functions are teaching data, not measured kinetics or a full Arrhenius model.

Heating costs $0.006(T-320)$ USD per kmol of feed. The hourly equipment charge is 20 USD for a PFR or 10 USD for a CSTR. Available feed-equivalent holdup is $F\tau\le250$ kmol. If inlet concentration is fixed at 1 kmol/m$^3$, this corresponds to an equivalent volume limit of 250 m$^3$. No pressure-drop, heat-transfer, or safety feasibility calculation is included.""",
        "variables": r"""For a mode $j=(r_j,T_j,\tau_j)$, compute $k=k_D+k_U$ and
$$X_j=\begin{cases}1-e^{-k\tau_j}&r_j=\mathrm{PFR},\\
k\tau_j/(1+k\tau_j)&r_j=\mathrm{CSTR},\end{cases}
\qquad y_{Dj}=X_j k_D/k,\quad y_{Uj}=X_j k_U/k.$$
Let $z_j\in\{0,1\}$ select a mode and $f_j\ge0$ be its feed in kmol/h. Require
$$\sum_jz_j=1,\quad f_j\le100z_j,\quad\sum_j\tau_j f_j\le250,\quad\sum_j y_{Dj}f_j\ge35.$$
The profit for a fixed activity is
$$\Pi=\sum_j\left[5y_{Dj}+y_{Uj}-1.2-0.006(T_j-320)\right]f_j-\sum_j K_{r_j}z_j.$$
Although the kinetics are nonlinear in temperature and residence time, their values are constants for each listed mode. This gives a MILP that is globally optimal only over the stated finite menu, not over all continuous operating conditions.""",
        "levels": [
            (
                "Residence time and throughput",
                "Guided problem",
                "Use a PFR at 330 K with activity $a=1$. Choose residence time from 1, 2, 3, or 4 h and optimize feed rate and profit.",
                "Would maximizing conversion necessarily maximize profit when holdup is limited? Compare the throughput limits at residence times of 2 h and 4 h.",
                r"""Evaluate four modes and maximize $\Pi$. Longer residence time raises conversion but reduces the throughput bound $f_j\le250/\tau_j$. For a fixed mode the profit is linear in feed. Its feasible feed interval is $[35/y_{Dj},\min(100,250/\tau_j)]$. An empty interval means the mode cannot meet demand.""",
                r"Enumerate the four modes independently and calculate the optimal endpoint of each feasible feed interval. Confirm $D+U+\text{unreacted A}=F$.",
                "Change the desired-product price to 4 USD/kmol. Explain why the preferred residence time may or may not change.",
            ),
            (
                "Selecting reactor type and temperature",
                "Model extension",
                "Allow both PFR and CSTR designs. Use temperatures 320, 330, 340, and 350 K and residence times 0.5, 1, 2, 3, and 4 h. Activity remains 1. Optimize the 40-mode design.",
                "The undesired reaction accelerates more sharply with temperature. Does a higher temperature always improve the desired-product yield? Can a cheaper CSTR offset lower conversion?",
                r"""Use the same MILP with 40 candidate modes and their corresponding equipment charges. The binary choice makes reactor selection mutually exclusive. Feed is disaggregated by mode, so no product of a binary variable and a continuous feed variable is needed in the objective or holdup constraint.""",
                "Check the winning mode against independent enumeration of all 40 one-dimensional feed problems. State the grid limitation in the conclusion.",
                "Refine the temperature and residence-time grids near the selected mode. Quantify the profit change, and distinguish grid convergence from a proof of the continuous global optimum.",
            ),
            (
                "A design robust to catalyst activity",
                "Open-ended challenge",
                "Keep the 40-mode menu. Activity is either 0.8 or 1.2. Choose one common reactor, temperature, residence time, and feed rate before activity is known. Meet the product requirement in both cases and maximize the smaller hourly profit. Explain whether fixed operation or adjustable operation is more appropriate for a real plant.",
                "If the plant can measure activity before selecting feed rate, which decision would become scenario dependent? Would that provide a different guarantee?",
                r"""For each state $s$, calculate $y_{Djs}$ and $y_{Ujs}$. Introduce a guaranteed-profit variable $\eta$ and solve
$$\max\eta,\qquad \eta\le\Pi_s\quad\forall s,\qquad \sum_j y_{Djs}f_j\ge35\quad\forall s.$$
All $z_j$ and $f_j$ are shared across states, giving a static robust design. There are no scenario probabilities. Independent enumeration remains possible because the equipment charge for a mode is the same in both states and the lower profit slope determines its worst-case profit.""",
                "Check mass balance and minimum desired-product rate in both states. Compare the nominal optimum evaluated under low activity with the robust optimum evaluated under that same activity.",
                "Formulate adjustable feed rates $f_{js}$ with a shared mode $z_j$. Explain how the information timing changes the feasible set and whether the worst-case value can decrease.",
            ),
        ],
    },
    "heat": {
        "name": "Heat Recovery Network Design",
        "data": r"""Two fixed-temperature heat sources provide 120 kW at 180 °C (H1) and 80 kW at 110 °C (H2). Heat users require 100 kW at 150 °C (C1) and 100 kW at 80 °C (C2). A minimum approach of 20 °C allows H1-C1, H1-C2, and H2-C2; H2-C1 is forbidden. These are isothermal source/sink surrogates, not sensible-heat streams with temperature profiles.

| Match | Maximum recovered heat (kW) | Daily installation charge (USD/d) |
|:--|--:|--:|
| H1-C1 | 100 | 25 |
| H1-C2 | 90 | 20 |
| H2-C2 | 70 | 18 |

Hot utility costs 1 USD/(kW d); cold utility costs 0.15 USD/(kW d). These coefficients already convert a constant daily heat rate to a daily cost. Do not multiply by 24 again. Utilities are available at suitable temperatures without capacity limits. All unused source heat must be rejected.""",
        "variables": r"""Let $q_{hcs}\ge0$ be recovered heat on an allowed match, $u_{cs}\ge0$ hot utility, and $v_{hs}\ge0$ rejected heat, all in kW. Let $z_{hc}\in\{0,1\}$ select an exchanger. For each operating state $s$,
$$\sum_c q_{hcs}+v_{hs}=H_h,\qquad
\sum_h q_{hcs}+u_{cs}=D_{cs},\qquad
q_{hcs}\le\overline Q_{hc}z_{hc}.$$
Only allowed matches appear in the sums. The first balance accounts for surplus heat, while the second prevents counting recovered heat twice. Installation charges are daily equivalents of ownership costs, not one-time capital expenses.""",
        "levels": [
            (
                "Dispatch through existing exchangers",
                "Guided problem",
                "Assume all three exchangers are already installed and their installation charges are sunk. Minimize daily utility cost.",
                "Total source heat equals total demand. Does that guarantee zero hot utility when match capacities and temperature feasibility are respected?",
                r"""Fix every $z_{hc}=1$ and solve the LP
$$\min C=\sum_c u_c+0.15\sum_h v_h.$$
The network has 200 kW on each side, but the H2-C2 limit prevents full recovery. Simultaneous hot and cold utility is therefore possible even with equal aggregate supply and demand.""",
                r"Calculate recovered heat and both utility totals. Confirm $\text{hot utility}-\text{cold utility}=\text{total demand}-\text{total source heat}$.",
                "Increase the H2-C2 capacity from 70 to 80 kW. Predict the change in both utilities and daily cost before solving.",
            ),
            (
                "Selecting which exchangers to install",
                "Model extension",
                "Now treat every exchanger as a new investment. Minimize installation charges plus utility cost. Compare the chosen design with the existing-network result without interpreting sunk-cost and investment objectives as identical.",
                "Can an exchanger with a small heat duty still pay for its fixed charge? What must be compared to judge its value?",
                r"""Release the binaries and minimize
$$C=\sum_{(h,c)}K_{hc}z_{hc}+\sum_c u_c+0.15\sum_h v_h.$$
The capacity implication is exact because the exchanger maximum is a physical upper bound. No arbitrary large constant is needed. A zero-duty exchanger may be excluded to avoid a positive fixed charge.""",
                "Enumerate the eight installation patterns and solve the residual heat-allocation LP for each. Compare the best value with the MILP.",
                "Raise the H1-C2 daily charge. Find the threshold at which that exchanger is no longer economic and verify the two neighboring designs.",
            ),
            (
                "A shared design for two operating states",
                "Open-ended challenge",
                "Choose exchangers before the operating state is known. In the low state, C2 requires 80 kW and hot utility costs 1 USD/(kW d). In the high state, C2 requires 130 kW and hot utility costs 2 USD/(kW d). Both states have probability 0.5. C1 remains at 100 kW. Limit total daily installation charges to 45 USD/d. Operating flows may adapt after the state is observed.",
                "Which variables must be shared across states? Why is solving each state independently and averaging the costs too optimistic for one physical network?",
                r"""Use shared $z_{hc}$, state-specific heat and utilities, and
$$\sum_{h,c}K_{hc}z_{hc}\le45,$$
$$\min C=\sum_{h,c}K_{hc}z_{hc}+\sum_s\pi_s\left(c_s^H\sum_c u_{cs}+0.15\sum_hv_{hs}\right).$$
The fixed charge appears once. The objective includes expected operating cost, while the two sets of heat balances ensure feasibility in both states. This is a two-stage stochastic MILP for a finite set of states.""",
                "Check energy balances separately in both states and verify the shared design fits the budget. Enumerate budget-feasible installation patterns.",
                "Recommend a design criterion if the high state becomes rare but disruptive. Compare expected cost with a worst-case criterion and explain what stakeholder preference each expresses.",
            ),
        ],
    },
    "scheduling": {
        "name": "Batch Production with Sequence-Dependent Cleaning",
        "data": r"""Four nonpreemptive batches must be processed on one vessel. The vessel is clean and available at time zero. A release time is the earliest processing start, not the earliest cleaning start. Cleaning may occur while the next batch awaits release. Initial and final cleaning times are zero.

| Job | Processing time (h) | Release (h) | Due time (h) | Tardiness charge (USD/h) |
|:--|--:|--:|--:|--:|
| A1 | 2 | 0 | 6 | 4 |
| A2 | 3 | 2 | 12 | 2 |
| B1 | 2 | 1 | 7 | 5 |
| C1 | 4 | 0 | 14 | 1 |

Cleaning times depend on product family, denoted by the first letter of the job name:

| From / to | A | B | C |
|:--|--:|--:|--:|
| A | 0 | 1 | 2 |
| B | 3 | 0 | 1 |
| C | 1 | 2 | 0 |

All cleaning times are in hours. Normal shift length is 12 h. For the reference models, processing starts lie between 0 and 30 h and the final completion time between 0 and 40 h.""",
        "variables": r"""Let $x_{ij}=1$ if job $j$ immediately follows $i$, with dummy nodes `start` and `end`. Let $s_j$ be processing start and $C_{max}$ final completion. Each job has exactly one predecessor and one successor; `start` has one outgoing arc and `end` one incoming arc. There is no direct start-end arc.

For job-to-job arcs,
$$s_j\ge s_i+p_i+t_{ij}-M(1-x_{ij}),\qquad s_j\ge r_j.$$
For job-to-end arcs, replace $s_j$ by $C_{max}$ and set cleaning to zero. Use $M=50$ h. This is sufficient because starts are at most 30 h, processing at most 4 h, and cleaning at most 3 h; a deactivated inequality is redundant. Positive processing times rule out disconnected directed cycles: summing the time inequalities around a cycle would imply a strictly positive duration is at most zero.""",
        "levels": [
            (
                "An idealized vessel schedule",
                "Guided problem",
                "Ignore cleaning times. Minimize the time at which all four jobs finish while respecting release times. Due times are reported but are not restrictions in this first model.",
                "Calculate the total processing time as a lower bound. Can the jobs be ordered to attain it without waiting for a release?",
                r"""Set $t_{ij}=0$ for every arc and minimize $C_{max}$. Due times do not enter the objective, so a makespan-optimal sequence can still deliver some jobs late. Multiple optimal sequences are possible.""",
                "Enumerate all 24 permutations. For each one, place every job at its earliest feasible start and calculate makespan. Check that processing intervals do not overlap.",
                "Increase the release time of A2 to 10 h. Determine whether idle time becomes unavoidable and identify a sequence that attains the new lower bound.",
            ),
            (
                "Cleaning changes the preferred sequence",
                "Model extension",
                "Include the directed cleaning-time matrix and again minimize makespan. Compare the result with the idealized schedule.",
                "Is the setup between A and B symmetric? Why must cleaning be charged only between immediate neighbors rather than every ordered pair?",
                r"""Retain the time inequalities using the specified $t_{ij}$. The arc formulation is essential: a pairwise before/after indicator alone does not identify which batches are adjacent. The reference objective remains $\min C_{max}$, so late deliveries are still not penalized.""",
                "Independently total processing, cleaning, and idle time on the chosen path. Compare with exhaustive permutation enumeration.",
                "Add a restriction forbidding a direct transition from B to A. Determine whether the optimal makespan changes.",
            ),
            (
                "Balancing late deliveries and overtime",
                "Open-ended challenge",
                "Use the cleaning matrix and due times. Minimize total weighted tardiness plus overtime charged at 0.5 USD/h beyond the 12 h shift. Recommend whether these penalty rates represent a defensible service policy, and propose an alternative if some due times are contractual.",
                "Can the least-cost schedule have a longer makespan than the fastest schedule? Which late delivery is most expensive per hour?",
                r"""Introduce $T_j\ge0$ and $O\ge0$ with
$$T_j\ge s_j+p_j-d_j,\qquad O\ge C_{max}-12.$$
Minimize
$$\sum_j w_jT_j+0.5O.$$
Positive coefficients make tardiness and overtime tight at optimum. This is a monetary objective, not lexicographic optimization. A hard due date would instead require $s_j+p_j\le d_j$ and could make the model infeasible.""",
                "Calculate tardiness from the actual finish times rather than trusting a displayed auxiliary variable. Independently enumerate all 24 sequences for the monetary objective.",
                "Sweep the overtime charge over 0, 0.5, 2, and 10 USD/h. Discuss when service and makespan objectives agree and when they conflict.",
            ),
        ],
    },
    "hydrogen": {
        "name": "Hydrogen Production and Storage",
        "data": r"""An electrolyzer operates over six four-hour periods, representing one day. Electricity use is constant at 0.05 MWh/kg of hydrogen. Power is limited to 4 MW. Initial hydrogen inventory is 50 kg, and final inventory must also be 50 kg. Storage has no leakage and no charging-rate restriction. Production and withdrawal rates are each uniform within a period. Inventory therefore varies linearly between period boundaries.

| Period | Electricity price (USD/MWh) | Hydrogen demand (kg/period) |
|--:|--:|--:|
| 1 | 30 | 120 |
| 2 | 25 | 150 |
| 3 | 80 | 180 |
| 4 | 100 | 220 |
| 5 | 45 | 180 |
| 6 | 35 | 140 |

Capacity is enforced at every period boundary, including the 50 kg initial stock. Under the uniform-rate assumption, this also bounds inventory throughout each period. If deliveries are discrete or rates vary within a period, an additional inventory profile or shorter time steps is necessary for physical sizing. A daily capacity charge of 0.15 USD/(kg d) is used where investment is optimized. It is an assumed daily equivalent, not a full capital-cost model.""",
        "variables": r"""Let $P_{st}$ be power in MW, $I_{st}$ end inventory in kg, and $K$ capacity in kg. With $\Delta t=4$ h and $e=0.05$ MWh/kg,
$$I_{st}=I_{s,t-1}+\frac{\Delta t}{e}P_{st}-D_{st},\qquad
0\le P_{st}\le4,\quad0\le I_{st}\le K.$$
Use $I_{s0}=50$ before the first period and $I_{s6}=50$ at the end. Total production must equal total demand. The electricity cost is $\sum_t c_t\Delta t P_{st}$ USD/d. Omitting $\Delta t$ would understate cost by a factor of four.""",
        "levels": [
            (
                "Dispatch with a fixed tank",
                "Guided problem",
                "Fix the tank at 150 kg and minimize daily electricity cost. Meet every period demand without purchases from an external supplier.",
                "Which hours are cheapest? Why might the electrolyzer still need to operate in an expensive period despite cheap electricity earlier?",
                r"""Fix $K=150$ kg and minimize electricity cost under the inventory balances. Initial inventory is not free net supply because the terminal condition returns the same amount. The LP does not impose a minimum operating load or a startup charge.""",
                "Check daily production equals 990 kg and electricity use equals 49.5 MWh. Verify nonnegative inventory in all periods and the 50 kg terminal stock.",
                "Remove the terminal condition and quantify the apparent savings. Explain why consuming starting stock is not a repeatable daily operating policy.",
            ),
            (
                "Choosing tank capacity",
                "Model extension",
                r"Choose $50\le K\le500$ kg and minimize electricity cost plus the daily capacity charge. Compare with the 150 kg tank, charging that fixed tank the same daily capacity rate for a fair total-cost comparison.",
                "Can additional storage change total daily electricity use in this constant-efficiency model? If not, where do the savings come from?",
                r"""Solve
$$\min C=0.15K+\sum_t c_t\Delta tP_t.$$
The lower bound of 50 kg accommodates initial and final stock. This LP values the timing of production, not a change in thermodynamic efficiency. The comparison with Problem 13 must add $0.15(150)$ USD/d to its electricity-only objective.""",
                "Check the chosen tank is large enough for every reported end stock. Re-solve with fixed capacity values and verify that electricity savings eventually cease as capacity grows.",
                "Estimate the break-even daily capacity charge for increasing the tank beyond 150 kg. Describe how finer time resolution might alter the design.",
            ),
            (
                "Design before demand is known",
                "Open-ended challenge",
                "Keep one shared tank capacity. Daily demand is either 0.9 or 1.15 times the table, each with probability 0.5. The demand state is fully observed before the first dispatch decision. In either state, the electrolyzer is initially off, consumes at least 1 MW when on, and incurs 10 USD per startup. Minimize capacity cost plus expected electricity and startup cost.",
                "Why may dispatch depend on the state while tank capacity may not? Would the same model be valid if the demand state were revealed only halfway through the day?",
                r"""Use state-specific binaries $y_{st}$ for operation and $b_{st}$ for startup:
$$y_{st}\le P_{st}\le4y_{st},\qquad b_{st}\ge y_{st}-y_{s,t-1},\quad y_{s0}=0.$$
The minimum-load coefficient is 1 MW. Minimize
$$0.15K+\sum_s\pi_s\sum_t\left(c_t\Delta tP_{st}+10b_{st}\right).$$
The positive startup cost makes unnecessary startups unattractive. Capacity is shared across the two states; dispatch is recourse after full daily demand revelation. There is no minimum up/down time, ramp limit, or commitment carried to the next day. The terminal stock is restored separately in both states.""",
                "Check power is either zero or between 1 and 4 MW. Check mass balance and terminal stock in each state. Count startups directly from the on/off sequence.",
                "Formulate the nonanticipativity constraints required if the state is learned after period 2. State which decisions must coincide before that time, and explain how uncertainty in earlier withdrawals affects the scenario definition.",
            ),
        ],
    },
    "water": {
        "name": "Wastewater Treatment and Reuse",
        "data": r"""Two independent wastewater sources supply S1 = 60 m$^3$/h at 40 mg/L and S2 = 50 m$^3$/h at 120 mg/L of one contaminant. Users U1 and U2 need 50 and 40 m$^3$/h, with maximum inlet concentrations of 30 and 60 mg/L. Freshwater contains no contaminant and costs 1 USD/m$^3$. Unused source water is discharged at 0.10 USD/m$^3$. User outlet streams are outside the model boundary; this is a one-pass reuse allocation.

| Treatment | Removal fraction | Capacity (m3/h) | Variable cost (USD/m3) | Hourly ownership charge (USD/h) |
|:--|--:|--:|--:|--:|
| Moderate | 0.75 | 40 | 0.25 | 3 |
| Advanced | 0.95 | 80 | 0.45 | 12 |

Treatment conserves water volume and transfers removed contaminant to a separate captured-residue stream. Residue handling is included in the assumed treatment cost. Each source remains segregated through treatment, or equivalently uses source-specific modules with a shared total hydraulic capacity. Fixed removal fractions do not depend on loading. These assumptions avoid a common mixed treatment inlet with an unknown concentration.""",
        "variables": r"""Let $x_{ij}\ge0$ be direct reuse, $y_{ijk}\ge0$ treated reuse through technology $k$, $f_j\ge0$ freshwater, and $d_i\ge0$ discharge, all in m$^3$/h. A binary $z_k$ selects a treatment option when required. With source supply $S_i$, user demand $D_j$, source concentration $c_i$, user limit $L_j$, and removal $r_k$,
$$\sum_j\left(x_{ij}+\sum_ky_{ijk}\right)+d_i=S_i,$$
$$\sum_i\left(x_{ij}+\sum_ky_{ijk}\right)+f_j=D_j,$$
$$\sum_i c_i\left[x_{ij}+\sum_k(1-r_k)y_{ijk}\right]\le L_jD_j,$$
$$\sum_{i,j}y_{ijk}\le\overline Q_k z_k.$$
Concentration-times-flow products have units mg/L times m$^3$/h. Multiplying every term by 1000 gives mg/h, so the common factor cancels in the quality inequality. Concentrations are fixed input coefficients, which keeps this formulation linear.""",
        "levels": [
            (
                "Direct reuse without treatment",
                "Guided problem",
                "Allow direct reuse and freshwater only. Minimize freshwater and disposal costs while meeting both user quality limits.",
                "Can source S1 be sent directly to U1 without dilution? Why might some S2 still be useful to U2?",
                r"""Remove all treatment variables and minimize
$$C=\sum_j f_j+0.10\sum_i d_i.$$
The quality limits are concentration limits at fixed total user demand, so they can be written as linear contaminant-load inequalities. Mixing at each user is permitted, but no unknown intermediate pool feeds multiple users.""",
                r"Check the overall water balance $110+\sum_j f_j=90+\sum_i d_i$. Independently calculate each user concentration from incoming contaminant load.",
                "Raise the U1 concentration limit from 30 to 40 mg/L and predict the freshwater reduction before solving.",
            ),
            (
                "Reuse with an existing treatment unit",
                "Model extension",
                "Add the moderate treatment option with capacity 40 m$^3$/h and removal fraction 0.75. Its ownership cost is sunk, so charge only variable treatment, freshwater, and disposal costs.",
                "For a given treated volume, which source yields a larger contaminant reduction? Does that automatically mean all treatment should serve that source?",
                r"""Fix $z_{moderate}=1$ and minimize
$$C=\sum_jf_j+0.10\sum_id_i+0.25\sum_{i,j}y_{ij,moderate}.$$
Removed contaminant is
$$R=\sum_{i,j}c_i r_{moderate}y_{ij,moderate}.$$
Include this captured load when checking the contaminant balance. A treatment model that reduces concentration while conserving water but has no contaminant outlet is physically incomplete.""",
                "Check source contaminant input equals load sent to users plus load in discharge plus captured contaminant. Convert the final quantities to kg/h using 0.001 kg per mg/L times m3.",
                "Lower treatment removal to 0.50 and determine whether zero freshwater remains feasible at the same capacity.",
            ),
            (
                "Selecting treatment under composition uncertainty",
                "Open-ended challenge",
                "Choose at most one new treatment option, or none. Source concentrations can independently rise to 60 mg/L for S1 and 160 mg/L for S2. Require all user quality limits to hold throughout these intervals, using one fixed allocation. Minimize the deterministic cost including the selected hourly ownership charge. Explain when the segregated treatment assumption would be defensible.",
                "Which concentrations create the worst load? What nonlinear term appears if an intermediate mixed pool has both unknown flow and unknown concentration?",
                r"""Use the upper concentrations in every quality inequality, since all flows and residual fractions are nonnegative. Require $\sum_kz_k\le1$ and minimize
$$C=\sum_jf_j+0.10\sum_id_i+\sum_{i,j,k}v_ky_{ijk}+\sum_kK_kz_k.$$
This is a robust MILP for fixed-quality, segregated treatment paths. In a general pooling model, a pool concentration $c_P$ and outgoing flow $q_{Pj}$ are both variables, producing the bilinear load $c_Pq_{Pj}$. The present solution is not a global solution to that unrestricted nonlinear pooling problem. A separate nonlinear model and suitable solver would be required for it.""",
                "Check the worst-case water and contaminant balances. Fix each of the three choices (none, moderate, advanced), solve its allocation LP, and compare the feasible costs.",
                "Propose an unrestricted pool formulation with flow and concentration variables. Identify its bilinear equations and explain what additional measurements or bounds would be required before solving.",
            ),
        ],
    },
}
