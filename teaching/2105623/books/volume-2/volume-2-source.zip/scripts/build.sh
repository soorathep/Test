#!/bin/zsh
set -eu
cd "$(dirname "$0")/.."
export QUARTO_PYTHON="$HOME/.venvs/optim/bin/python"
QUARTO_BIN="${QUARTO_BIN:-$HOME/.local/opt/quarto/bin/quarto}"
if [[ ! -x "$QUARTO_BIN" ]]; then QUARTO_BIN="$(command -v quarto)"; fi
"$QUARTO_BIN" render --profile instructor
"$QUARTO_BIN" render --profile student --to pdf
mkdir -p output/pdf
cp _book/volume-2-worked.pdf output/pdf/volume-2-worked.pdf
cp _student/volume-2-student.pdf output/pdf/volume-2-student.pdf
