"""Independent checks of investment choices and nested model properties."""

import itertools
from importlib import import_module
from models.common import solve, value


def fixed_choices(module, level, keys, patterns):
    vals = []
    for pattern in patterns:
        m = module.build(level)
        for key, z in zip(keys, pattern):
            m.z[key].fix(z)
        try:
            solve(m)
        except RuntimeError:
            continue
        vals.append(value(m.obj))
    return min(vals)


def extra_checks():
    from models import heat, water, blending, hydrogen

    checks = {}
    for level in [2, 3]:
        best = fixed_choices(
            heat, level, heat.ARCS, itertools.product([0, 1], repeat=3)
        )
        assert abs(best - value(solve(heat.build(level)).obj)) < 1e-6
        checks[f"heat_level_{level}_all_8_patterns"] = True
    best = fixed_choices(water, 3, list(water.TECH), [(0, 0), (1, 0), (0, 1)])
    assert abs(best - value(solve(water.build(3)).obj)) < 1e-6
    checks["water_all_3_technologies"] = True
    sweep = []
    for g in [0, 0.5, 1, 1.5, 2, 2.5, 3]:
        m = solve(blending.build(3, gamma=g))
        blending.check(m, 3)
        sweep.append({"gamma": g, "cost": value(m.cost)})
    assert all(b["cost"] >= a["cost"] - 1e-6 for a, b in zip(sweep, sweep[1:]))
    assert abs(sweep[0]["cost"] - value(solve(blending.build(1)).cost)) < 1e-6
    assert abs(sweep[-1]["cost"] - value(solve(blending.build(2)).cost)) < 1e-6
    checks["robust_budget_endpoints_and_monotonicity"] = True
    tank = []
    for cap in [50, 100, 150, 200, 300, 400, 420, 450, 500]:
        m = hydrogen.build(2)
        m.k.fix(cap)
        solve(m)
        hydrogen.check(m, 2)
        tank.append(
            {
                "capacity_kg": cap,
                "total_cost": value(m.obj),
                "electricity_cost": value(m.obj) - 0.15 * cap,
            }
        )
    checks["fixed_capacity_sweep"] = True
    return checks, sweep, tank
