from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def bundle():
    with zipfile.ZipFile(ROOT / "volume-2-source.zip", "w", zipfile.ZIP_DEFLATED) as z:
        for directory in ["models", "scripts", "figures", "styles", "chapters"]:
            for p in sorted((ROOT / directory).rglob("*")):
                if (
                    p.is_file()
                    and p.suffix in [".py", ".sh", ".lua", ".tex", ".qmd", ".mplstyle"]
                    and "__pycache__" not in p.parts
                ):
                    z.write(p, p.relative_to(ROOT))
        for pattern in [
            "*.qmd",
            "*.yml",
            "*.md",
            "*.txt",
            ".gitignore",
            ".env.example",
        ]:
            for p in ROOT.glob(pattern):
                z.write(p, p.name)


if __name__ == "__main__":
    bundle()
