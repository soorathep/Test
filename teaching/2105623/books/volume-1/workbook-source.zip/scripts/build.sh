#!/bin/zsh
set -eu
cd "$(dirname "$0")/.."
OPTIM_PYTHON="$HOME/.venvs/optim/bin/python"
QUARTO_BIN="${QUARTO_BIN:-$HOME/.local/opt/quarto/bin/quarto}"
if [[ ! -x "$QUARTO_BIN" ]]; then
  QUARTO_BIN="$(command -v quarto)"
fi
export QUARTO_PYTHON="$OPTIM_PYTHON"
"$QUARTO_BIN" render --to html
