"""Solve, verify, illustrate, and write all adapted worked-problem chapters.
Quarto calls this through pre-render; do not hand-edit generated chapters 2–29.
Their authored statements and formulations live in models/problemNN.py.
"""

from pathlib import Path
import sys
import json

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from models.common import run, frame
from figures.workbook import create
from chapter_support import inputs, finding


def markdown_table(df):
    def fmt(x):
        if isinstance(x, (int, float)):
            if abs(x) < 1e-8:
                x = 0
            return (
                f"{x:,.4f}".rstrip("0").rstrip(".") if isinstance(x, float) else str(x)
            )
        return str(x).replace("|", "\\|")

    return "\n".join(
        [
            "| " + " | ".join(df.columns) + " |",
            "| " + " | ".join(["---"] * len(df.columns)) + " |",
        ]
        + [
            "| " + " | ".join(fmt(x) for x in row) + " |"
            for row in df.itertuples(index=False, name=None)
        ]
    )


manifest = []
for n in range(2, 30):
    module, m, tables, result = run(n)
    create(n, module, m)
    input_text = "\n\n".join(
        "### " + name + "\n\n" + markdown_table(df)
        for name, df in inputs(n, module).items()
    )
    interpretation = finding(n, module, m, tables, result)
    source = (
        (ROOT / "models" / f"problem{n:02d}.py")
        .read_text()
        .split("# MODEL CODE\n", 1)[1]
    )
    code = (
        source
        + "\n# Solve, audit constraints, and run domain-specific checks.\nfrom models.common import solve, audit\nmodel = solve(build())\naudit(model)\ncheck(model)\nfor name, result_table in tables(model).items():\n    print(name)\n    print(result_table.to_string(index=False))\n"
    )
    result_text = "\n\n".join(
        "### " + name.replace("_", " ").capitalize() + "\n\n" + markdown_table(df)
        for name, df in tables.items()
    )
    caption = {
        11: "Sensor readings and the straight-line L1 calibration.",
        17: "One optimal grid. W denotes white and D denotes dark markers.",
        23: "Optimal closed collection tours; labels identify the depot and farms.",
        27: "Selected open delivery routes. No return travel is counted.",
        28: "One optimal lattice fold. Amber residues are hydrophobic, teal residues are polar, and dashed lines identify nonbonded H contacts.",
        29: "Contact maps and an optimal order-preserving alignment. Graphite arcs are contacts; amber dashed lines are residue matches.",
    }.get(
        n,
        "Selected quantities from the verified optimal solution. Units are stated on the axis.",
    )
    objective = f"{result['objective']:,.6f}".rstrip("0").rstrip(".")
    text = f"""# {module.TITLE}

::: {{.callout-note}}
## Source and adaptation
Based on **{module.SOURCE}**, Section 12.{n} of @williams2013. {module.ADAPTATION} The results below solve the stated instance and are not presented as the numerical answer to an unmodified textbook problem.
:::

## Problem Statement

{module.PROBLEM}

{input_text}

## Model Formulation

{module.FORMULATION}

All decision variables and units refer to the problem statement above. Continuous variables are nonnegative unless explicitly stated otherwise; binary and integer domains are specified in the equations and code.

## Pyomo Implementation

The following Python implementation uses Pyomo and HiGHS. Run from the workbook root so that the `models` package and shared helpers are importable. The [shared solver and audit functions](../models/common.py) check optimal termination before loading values, then verify every active constraint, variable bound, and integer domain. Any imported earlier-chapter model supplies the data and balances already explained there.

The full source is [problem{n:02d}.py](../models/problem{n:02d}.py). To solve and print this problem independently:

```bash
~/.venvs/optim/bin/python -m models.common {n}
```

```python
{code.rstrip()}
```

## Optimal Solution

The solver reports **optimal** termination. The objective is **{objective} {module.UNITS}** ({result["sense"]}). The largest violation across active constraints, variable bounds, and integer domains is **{result["max_violation"]:.2e}** in the corresponding model units. The problem-specific checks also pass. These checks establish numerical consistency with the stated model, not the validity of its assumptions for a real facility.

{result_text}

![{caption}](../figures/generated/problem{n:02d}.svg){{#fig-problem{n:02d}}}

Tables round numerical values for reading; feasibility checks use the original solver values. Multiple optimal decisions may exist. [Machine-readable result](../results/{n:02d}/solution.json) records the solver status and package versions. Figure-generation code is in [figures/workbook.py](../figures/workbook.py).

## Brief Discussion

{interpretation}

{module.DISCUSSION}
"""
    (ROOT / "chapters" / f"{n:02d}-problem.qmd").write_text(text)
    manifest.append(result)
    print(f"Problem {n:02d}: optimal, objective={objective}, checks passed", flush=True)
(ROOT / "results" / "workbook-validation.json").write_text(
    json.dumps(manifest, indent=2) + "\n"
)

from package_source import make_bundle
make_bundle(ROOT)
