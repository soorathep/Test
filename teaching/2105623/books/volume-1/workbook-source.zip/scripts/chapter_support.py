"""Readable input tables and result-based interpretations for the chapters."""

import pyomo.environ as pyo
from models.common import frame


def inputs(n, a):
    if n == 3:
        return {
            "Product data": frame(
                [
                    [i, a.MARGIN[i], a.HOURS["reactor"][j], a.HOURS["finishing"][j]]
                    for j, i in enumerate(a.PRODUCTS)
                ],
                ["Grade", "Margin (1000 USD/t)", "Reactor (h/t)", "Finishing (h/t)"],
            ),
            "Monthly data": frame(
                [
                    [
                        t + 1,
                        *a.DEMAND[t],
                        a.CAPACITY["reactor"][t],
                        a.CAPACITY["finishing"][t],
                    ]
                    for t in range(3)
                ],
                [
                    "Month",
                    "A sales cap (t)",
                    "B sales cap (t)",
                    "C sales cap (t)",
                    "Reactor (h)",
                    "Finishing (h)",
                ],
            ),
        }
    if n == 5:
        return {
            "Required workforce": frame(
                [[t + 1, a.D["G"][t], a.D["S"][t]] for t in range(3)],
                ["Year", "General (FTE)", "Skilled (FTE)"],
            )
        }
    if n == 6:
        return {
            "Crude data": frame(
                [["A", 0.32, 100, 0.5, 0.3, 0.2], ["B", 0.28, 80, 0.3, 0.5, 0.2]],
                [
                    "Crude",
                    "Cost (1000 USD/t)",
                    "Limit (t/day)",
                    "Naphtha yield",
                    "Gas-oil yield",
                    "Residue yield",
                ],
            )
        }
    if n == 7:
        return {
            "Mine data": frame(
                [
                    ["ABC"[i], a.CAP[i], a.QUALITY[i], a.COST[i], a.ROYALTY[i]]
                    for i in range(3)
                ],
                [
                    "Mine",
                    "Limit (million t/year)",
                    "Quality",
                    "Cost (USD/t)",
                    "Royalty (million USD/year)",
                ],
            ),
            "Market data": frame(
                [[t + 1, a.DEMAND[t], a.TARGET[t]] for t in range(3)],
                ["Year", "Sales cap (million t)", "Minimum quality"],
            ),
        }
    if n == 9:
        return {
            "Input coefficients": frame(
                [
                    [name, *a.A[i]]
                    for i, name in enumerate(["Chemicals", "Utilities", "Logistics"])
                ],
                [
                    "Supplying sector",
                    "Chemicals output",
                    "Utilities output",
                    "Logistics output",
                ],
            ),
            "Sector data": frame(
                [
                    [name, a.C[i], a.D[i], a.LABOR[i]]
                    for i, name in enumerate(["Chemicals", "Utilities", "Logistics"])
                ],
                [
                    "Sector",
                    "Initial capacity",
                    "External deliveries",
                    "Labor per output unit",
                ],
            ),
        }
    if n == 10:
        return {
            "Operating cost (1000 USD/year)": frame(
                [["ABCD"[i], *a.COST[i]] for i in range(4)],
                ["Unit", "North", "Central", "South"],
            ),
            "Coordination volumes": frame(
                [["ABCD"[i], "ABCD"[j], v] for (i, j), v in a.V.items()],
                ["Unit 1", "Unit 2", "Volume"],
            ),
        }
    if n == 11:
        return {
            "Calibration data": frame(
                list(zip(a.X, a.Y)), ["Input", "Observed response"]
            )
        }
    if n == 12:
        return {"Required truth table": frame(a.ROWS, ["A", "B", "XOR output"])}
    if n == 13:
        return {
            "Distributor data": frame(
                [[i + 1, *row] for i, row in enumerate(a.DATA)],
                [
                    "Distributor",
                    "Solvent (1000 t/year)",
                    "Resin (1000 t/year)",
                    "Delivery points",
                ],
            )
        }
    if n == 14:
        return {
            "Block values": frame(
                [[b, v] for b, v in a.VALUES.items()], ["Block", "Net value (1000 USD)"]
            )
        }
    if n == 15:
        return {
            "Generating units": frame(
                [
                    ["ABC"[i], a.MIN[i], a.MAX[i], a.FIX[i], a.COST[i], a.START[i]]
                    for i in range(3)
                ],
                [
                    "Unit",
                    "Minimum (MW)",
                    "Maximum (MW)",
                    "Online (USD/h)",
                    "Energy (USD/MWh)",
                    "Startup (USD)",
                ],
            ),
            "Load profile": frame(
                [[t + 1, 8, d] for t, d in enumerate(a.DEMAND)],
                ["Period", "Duration (h)", "Demand (MW)"],
            ),
        }
    if n == 18:
        return {
            "Original inequality": frame(
                [[f"x{i + 1}", v] for i, v in enumerate(a.ORIGINAL)] + [["RHS", 37]],
                ["Term", "Coefficient"],
            )
        }
    if n == 19:
        return {
            "Inbound costs (USD/t)": frame(
                [[f"P{p + 1}", *a.C[p], a.UP[p]] for p in range(2)],
                ["Plant", "D1", "D2", "D3", "Supply limit (t/day)"],
            ),
            "Outbound costs (USD/t)": frame(
                [[f"D{d + 1}", *a.K[d], a.VD[d]] for d in range(3)],
                ["Depot", "C1", "C2", "C3", "C4", "Throughput (t/day)"],
            ),
            "Customer demands": frame(
                [[f"C{c + 1}", v] for c, v in enumerate(a.DEMAND)],
                ["Customer", "Demand (t/day)"],
            ),
        }
    if n == 21:
        return {
            "Product data": frame(
                [
                    [name, a.P[i], a.Q[i], a.E[i], a.FAT[i], a.DRY[i]]
                    for i, name in enumerate(["Milk", "Butter", "Cheese A", "Cheese B"])
                ],
                [
                    "Product",
                    "Baseline price (1000 USD/t)",
                    "Baseline demand (t/day)",
                    "Own elasticity",
                    "Fat fraction",
                    "Dry fraction",
                ],
            )
        }
    if n == 22:
        return {
            "Observed plant performance": frame(
                [["ABCDEF"[i], *row] for i, row in enumerate(a.DATA)],
                ["Plant", "Energy (GJ/day)", "Labor (FTE/day)", "Output (t/day)"],
            )
        }
    if n == 23:
        return {
            "Farm data": frame(
                [
                    [i, *a.COORD[i], a.Q[i], "Daily" if i <= 2 else "Once in two days"]
                    for i in range(1, 7)
                ],
                ["Farm", "East (km)", "North (km)", "Collection (1000 L)", "Service"],
            )
        }
    if n == 24:
        return {
            "Early menu": frame(
                list(zip(a.EP, a.EARLY)), ["Price (1000 USD/t)", "Demand cap (t)"]
            ),
            "Later menus": frame(
                [
                    ["Low" if s == 0 else "High", a.PROB[s], a.LP[k], a.LATE[s][k]]
                    for s in range(2)
                    for k in range(2)
                ],
                ["Scenario", "Probability", "Price (1000 USD/t)", "Demand cap (t)"],
            ),
        }
    if n == 25:
        return {
            "Rental opportunities": frame(
                [[t + 1, *a.DEMAND[t]] for t in range(3)], ["Day", "A", "B", "C"]
            ),
            "Return fractions": frame(
                [["ABC"[i], *a.P[i]] for i in range(3)],
                ["Origin", "Return to A", "Return to B", "Return to C"],
            ),
        }
    if n == 27:
        return {
            "Delivery coordinates": frame(
                [[i, *xy] for i, xy in enumerate(a.COORD)],
                ["Node (0 = depot)", "East", "North"],
            )
        }
    return {}


def finding(n, a, m, tables, result):
    v = pyo.value
    objective = result["objective"]
    if n == 2:
        from models.food_manufacture import build_model, solve_model

        original = pyo.value(solve_model(build_model()).profit)
        return f"The added logical restrictions reduce six-month profit by £{original - objective:,.2f} relative to Chapter 1 under the same cost convention."
    if n == 3:
        return f"The plan produces {sum(v(m.make[i, t]) for i in m.I for t in m.T):,.2f} t and sells {sum(v(m.sell[i, t]) for i in m.I for t in m.T):,.2f} t; the remaining 15 t satisfy the three terminal stocks."
    if n == 4:
        table = tables["comparison"]
        return f"Choosing maintenance months increases contribution by {table.iloc[1, 1] - table.iloc[0, 1]:,.2f} thousand USD compared with the specified fixed schedule."
    if n == 5:
        return f"The solution retrains {sum(v(m.v[t]) for t in m.T):,.2f} FTE over three years and lays off {sum(v(m.l[g, t]) for g in m.G for t in m.T):,.2f} FTE. Hiring and training jointly cover the changing skill mix."
    if n == 6:
        return f"The refinery processes {v(m.x['A'] + m.x['B']):,.2f} t/day and sells {v(m.x['G'] + m.x['F']):,.2f} t/day of products. The {v(0.2 * m.x['r'] + 0.1 * m.x['k']):,.2f} t/day difference is exactly the modeled conversion loss."
    if n == 7:
        return f"Total extraction is {sum(v(m.x[i, t]) for i in m.I for t in m.T):,.2f} million t, with a discounted net value of {objective:,.2f} million USD."
    if n == 8:
        return f"The productive herd ends year 3 at {v(m.cows[2]):,.2f} cow-equivalents. Total supplemental feed purchases are {sum(v(m.feed[t]) for t in m.T):,.2f} t across the three years."
    if n == 9:
        return f"Terminal capacity rises from {sum(a.C):,.2f} to {objective:,.2f} normalized units/year, an addition of {objective - sum(a.C):,.2f}. This objective weights every sector capacity unit equally."
    if n == 10:
        op = tables["locations"].iloc[:, 2].sum()
        return f"Annual operating cost is {op:,.2f} thousand USD, while coordination contributes another {objective - op:,.2f} thousand USD to the total."
    if n == 11:
        row = tables["fits"].iloc[0]
        return f"The straight-line L1 fit has total absolute error {row['Total absolute error']:,.3f} and maximum error {row['Maximum error']:,.3f} response units. The table separates these two loss measures."
    if n == 12:
        return f"The optimum uses {round(objective)} NOR gates and reproduces all four XOR truth-table rows in an independent circuit evaluation."
    if n == 13:
        return f"The best worst-case deviation is {100 * objective:,.3f} percentage points from the 40% target. This is a deviation in share, not in physical shipment quantity."
    if n == 14:
        return f"The chosen pit contains {round(sum(v(m.x[b]) for b in a.VALUES))} blocks and earns {objective:,.2f} thousand USD after including all selected negative-value overburden."
    if n == 15:
        t = tables["reserve_cost"]
        return f"The 15% reserve policy changes daily cost by {t.iloc[0, 1] - t.iloc[1, 1]:,.2f} USD relative to the re-solved zero-reserve case."
    if n == 16:
        t = tables["comparison"]
        return f"Hydro storage reduces daily operating cost by {t.iloc[0, 1] - t.iloc[1, 1]:,.2f} USD. It generates {8 * sum(v(m.h[t]) for t in m.T):,.2f} MWh and consumes {8 * sum(v(m.pump[t]) for t in m.T):,.2f} MWh for pumping, while restoring the initial stored energy."
    if n == 17:
        return f"The optimum has {round(objective)} monochromatic lines among the 49 possible lines, with exactly 13 white markers."
    if n == 18:
        return f"The minimum absolute right-hand side is {objective:,.0f}, compared with 37 originally. All 256 binary assignments have the same feasibility status under the displayed replacement inequality."
    if n == 19:
        return f"The network delivers {sum(a.DEMAND):,.0f} t/day at a total transport cost of {objective:,.2f} USD/day, or {objective / sum(a.DEMAND):,.2f} USD/t averaged over deliveries."
    if n == 20:
        selected = [f"D{d + 1}" for d in m.D if v(m.y[d]) > 0.5]
        return f"The selected depots are {', '.join(selected)}. D2 expansion is {'selected' if v(m.e) > 0.5 else 'not selected'}; total daily cost includes all opening charges."
    if n == 21:
        baseline = sum(a.P[i] * a.Q[i] for i in range(4))
        return f"The chosen menu earns {objective - baseline:,.2f} thousand USD/day more revenue than the baseline price-and-demand combination, subject to the unchanged baseline-basket price-index limit."
    if n == 22:
        return f"Plant C has radial input efficiency {objective:,.4f}, corresponding to a {(1 - objective) * 100:,.2f}% proportional input reduction under the constant-returns comparator model."
    if n == 23:
        return (
            f"The two tours cover {objective:,.3f} km in total. Their collection volumes are "
            + ", ".join(f"{x:,.0f}" for x in tables["routes"]["Collected (1000 L)"])
            + " thousand L, each within the 16-thousand-L tank limit."
        )
    if n == 24:
        upper = tables["information"].iloc[1, 1]
        return f"Expected contribution is {objective:,.2f} thousand USD. Perfect advance knowledge of demand would raise it to {upper:,.2f}, so the expected value of perfect information is {upper - objective:,.2f} thousand USD."
    if n == 25:
        return f"The steady-state fleet contains {v(m.fleet):,.2f} expected vehicles and supports {sum(v(m.r[i, t]) for i in m.I for t in m.T):,.2f} rentals per cycle. Fractional fleet counts reflect the expected-flow approximation."
    if n == 26:
        t = tables["comparison"]
        return f"Optimal expansion increases net cycle profit by {t.iloc[1, 1] - t.iloc[0, 1]:,.2f} USD after paying the investment charges."
    if n == 27:
        return f"The first-priority optimum uses {len(tables['routes'])} vans. Among those fleet-minimal plans, the smallest longest delivery time is {v(m.T):,.3f} min."
    if n == 28:
        return f"Enumeration tests {len(a.CONFORMATIONS)} self-avoiding conformations. The best has {round(objective)} nonbonded H–H contacts, giving energy {(-objective):,.0f} in the stated contact-energy units."
    if n == 29:
        return f"The alignment conserves {round(objective)} of the {len(a.EA)} contacts in protein A. Unconserved and extra contacts are allowed by the stated matching objective."
    return ""
