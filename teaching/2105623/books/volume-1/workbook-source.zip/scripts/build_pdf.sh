#!/bin/zsh
set -eu
cd "$(dirname "$0")/.."
export QUARTO_PYTHON="$HOME/.venvs/optim/bin/python"
QUARTO_BIN="${QUARTO_BIN:-$HOME/.local/opt/quarto/bin/quarto}"
"$QUARTO_BIN" render --to pdf
mkdir -p output/pdf
cp _book/Optimization-Modeling-for-Chemical-Engineers.pdf output/pdf/optimization-workbook.pdf
