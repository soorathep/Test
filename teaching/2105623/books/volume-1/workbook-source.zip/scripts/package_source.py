"""Bundle editable source without scans, raw data, caches, or generated figures."""
from pathlib import Path
import zipfile

def make_bundle(root):
    with zipfile.ZipFile(root / 'workbook-source.zip', 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for directory in ['models','figures','scripts','styles','chapters']:
            for path in sorted((root/directory).rglob('*')):
                if path.is_file() and path.suffix in {'.py','.sh','.qmd','.mplstyle','.lua','.tex'} and '__pycache__' not in path.parts:
                    archive.write(path,path.relative_to(root))
        for name in ['_quarto.yml','index.qmd','references.qmd','references.bib','styles.css','requirements.txt','README.md','.gitignore','.env.example']:
            archive.write(root/name,name)

if __name__ == '__main__': make_bundle(Path(__file__).resolve().parents[1])
