function Image(el)
  if FORMAT:match('latex') then
    el.src = el.src:gsub('%.svg$', '.pdf')
  end
  return el
end
