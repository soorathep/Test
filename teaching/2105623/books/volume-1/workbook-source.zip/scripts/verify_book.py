"""Verify built chapter coverage, local resources, and exported figure fonts."""

from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import unquote, urlsplit
import subprocess
import json

ROOT = Path(__file__).resolve().parents[1]
BOOK = ROOT / "_book"


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.refs = []

    def handle_starttag(self, tag, attrs):
        data = dict(attrs)
        for key in ["src", "href"]:
            if key in data:
                self.refs.append(data[key])


errors = []
chapters = sorted((BOOK / "chapters").glob("*.html"))
assert len(chapters) == 29, len(chapters)
for page in [BOOK / "index.html", *chapters, BOOK / "references.html"]:
    text = page.read_text()
    parser = Links()
    parser.feed(text)
    if page.parent.name == "chapters":
        for heading in [
            "Problem Statement",
            "Model Formulation",
            "Pyomo Implementation",
            "Optimal Solution",
            "Brief Discussion",
        ]:
            if heading not in text:
                errors.append(f"Missing section {heading}: {page.name}")
    for ref in parser.refs:
        parts = urlsplit(ref)
        if parts.scheme or parts.netloc or not parts.path:
            continue
        target = (
            (BOOK / parts.path.lstrip("/"))
            if parts.path.startswith("/")
            else page.parent / unquote(parts.path)
        )
        if not target.exists():
            errors.append(f"Broken local link: {page.name}: {ref}")
fonts = []
for pdf in sorted((ROOT / "figures/generated").glob("*.pdf")):
    result = subprocess.run(
        ["pdffonts", str(pdf)], text=True, capture_output=True, check=True
    )
    if "Type 3" in result.stdout or result.stderr:
        errors.append(f"Font issue {pdf.name}: {result.stderr}")
    for line in result.stdout.splitlines()[2:]:
        # The embedding column precedes subsetting and Unicode indicators.
        fields = line.split()
        if len(fields) >= 6 and fields[-5] != "yes":
            errors.append(f"Unembedded font: {pdf.name}: {line}")
    fonts.append(pdf.name)
summary = {
    "chapters": len(chapters),
    "figure_pdfs": len(fonts),
    "broken_links_or_layout_asset_errors": errors,
    "chapter_1_checks": json.loads((ROOT / "results/solution.json").read_text())[
        "validation"
    ],
    "additional_models": len(
        json.loads((ROOT / "results/workbook-validation.json").read_text())
    ),
}
(ROOT / "results/build-validation.json").write_text(
    json.dumps(summary, indent=2) + "\n"
)
print(json.dumps(summary, indent=2))
if errors:
    raise SystemExit(1)
