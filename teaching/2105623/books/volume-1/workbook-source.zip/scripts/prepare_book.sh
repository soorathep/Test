#!/bin/zsh
set -eu
cd "$(dirname "$0")/.."
"$HOME/.venvs/optim/bin/python" scripts/prepare_book.py
