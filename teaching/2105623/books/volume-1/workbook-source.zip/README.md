# Optimization Modeling for Chemical Engineers

English-language Quarto workbook for MSc chemical engineering students, covering all 29 problem themes in Williams (2013), Chapter 12, in source order.

## Scope

Chapter 1 retains the source numerical data. Chapter 2 retains the added logical restrictions. Most later chapters use explicitly labeled teaching adaptations, with smaller data and stated changes in assumptions. These are worked solutions to the stated adapted instances, not a reproduction of the textbook answer key. Chapter 21 uses finite pricing menus, Chapter 28 uses an eight-residue lattice model, and Chapter 29 compares small contact maps. Chapter 12 allows fan-out in its NOR network.

Each chapter contains a problem statement, formulation, runnable Pyomo code, computed solution, a Python figure, and a short discussion with an extension exercise. Chapters that extend an earlier model explicitly refer to its data. HiGHS solves every reference model; active constraints, bounds, and integer domains are checked. Domain-specific checks add balances, truth-table tests, or independent enumeration where appropriate.

## Authoring files

- `chapters/01-food-manufacture.qmd`: manually authored first chapter.
- `models/food_manufacture.py`: Chapter 1 model and scenarios.
- `models/problem02.py` through `models/problem29.py`: authored English statements, formulations, discussions, data, models, output tables, and domain checks.
- `models/common.py`: shared solver, numerical audit, and command-line runner.
- `scripts/prepare_book.py`: regenerate Chapters 2–29, tables, figures, validation manifest, and source bundle.
- `chapters/02-problem.qmd` through `chapters/29-problem.qmd`: generated editable Quarto output; edit their model-module sources for persistent changes.
- `figures/food_manufacture.py` and `figures/workbook.py`: regenerate all figures from model solutions.
- `styles/`: bundled Teal-Amber Lab Palette and Matplotlib style, imported by figure scripts.
- `results/`: CSV tables and JSON solver/check results.
- `figures/generated/`: SVG, embedded-font PDF, and 600 dpi PNG figures.
- `scan/`: original references, untouched and excluded from git and the source bundle.
- `_book/`: rendered HTML and PDF book.

## Build on a lab machine

The optimization interpreter is `~/.venvs/optim/bin/python`. Use explicit interpreter paths:

```sh
uv pip install --python ~/.venvs/optim/bin/python -r requirements.txt
~/.venvs/optim/bin/python -m ipykernel install --user --name optim --display-name 'Python (optimization)'
./scripts/build.sh
```

Quarto 1.10.18 is installed at `~/.local/opt/quarto/` on the current machine. The build script also accepts `QUARTO_BIN` or Quarto on PATH. Register the `optim` kernel on each machine to point to that machine's interpreter. Build the A4 PDF with `./scripts/build_pdf.sh` (requires XeLaTeX). The reading copy is saved to `output/pdf/optimization-workbook.pdf`. PDF rendering uses the vector PDF figures, wrapped code, a table of contents, and page numbers. Figure PDFs are also included for vector reuse.

The Quarto pre-render hook runs all 28 additional models, audits their solutions, creates their figures, and writes their chapters. Chapter 1 executes using the optimization Jupyter kernel. Rendering therefore regenerates numerical content rather than trusting stale tables. The downloadable `workbook-source.zip` is created by the same preparation step and excludes scans and generated output assets.

## Run models and figures separately

```sh
~/.venvs/optim/bin/python models/food_manufacture.py
~/.venvs/optim/bin/python -m models.common 6
~/.venvs/optim/bin/python figures/workbook.py 6
~/.venvs/optim/bin/python scripts/prepare_book.py
```

The problem number is the Williams Chapter 12 section number. Run module commands from the workbook root so imports resolve. The dependencies are open-source and no API key is needed. `skh_palette` is bundled as a local lab module, not a PyPI dependency.

The Python code printed in Chapters 2–29 is extracted directly from the modules used to solve them. Cross-chapter imports deliberately reuse earlier model definitions. The complete source bundle preserves those dependencies.

## Validation and interpretation

`results/workbook-validation.json` records Chapter 2–29 objective values, units, optimal termination, largest numerical violations, domain-check status, and solver versions. Chapter 1 has its own `results/solution.json`. Tolerance is 1e-6 in each model's units. Numerical validation does not validate a physical assumption, and multiple optimal solutions can exist.

Chapter 1 charges storage on all six closing stocks, including June. Its fixed-stock comparison keeps 500 t per oil each month. Added capacity applies in every month. Later chapters state event timing, units, and boundary conditions explicitly. In particular, power (MW) is multiplied by period duration before charging energy costs, and the stochastic model shares first-stage decisions across scenarios.

## Source

Williams, H. P. (2013). *Model Building in Mathematical Programming* (5th ed.). John Wiley & Sons. ISBN 9781118443330.

https://www.wiley-vch.de/en/areas-interest/finance-economics-law/model-building-in-mathematical-programming-978-1-118-44333-0
